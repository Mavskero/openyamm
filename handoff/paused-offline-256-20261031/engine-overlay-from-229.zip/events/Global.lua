-- generated from legacy EVT/STR

SetGlobalMetadata({
    onLoad = {},
    onLeave = {},
    openedChestIds = {
    },
    textureNames = {},
    spriteNames = {},
    castSpellIds = {3, 5, 8, 14, 17, 25, 36, 38, 51, 58, 69, 83},
    timers = {
    },
})

RegisterGlobalEvent(1, nil, function()
    evt.SetMessage("同志们，我们现在遇到的是非常危险的状况。很幸运的，我们的主人会找到方法让我们离开这个要命的地方，安全的回到阿尔瓦。虽然这是我出生的地方，但我可不想要在这边把命给送掉。")
    SetQBit(QBit(232))
end)

RegisterGlobalEvent(2, nil, function()
    evt.SetMessage("达德洛斯带领我们来到这边，准备让我们和蜥蜴人的部落首领单牙交易他们的托伯斯克果。他刚去找布拉克许・单牙谈话。也许你们可以去找他？")
    SetQBit(QBit(232))
end)

RegisterGlobalEvent(3, nil, function()
    evt.SetMessage("雷格那的海盗是贾丹姆大陆上贸易和四处旅行的最大威胁。海上只有极少的船只愿意四处旅行，因为担心被这些恐怖的家伙给弄沉……或是遇到更糟糕的命运！当你在渡鸦海滨的时候，我听说过有一小群走私者在海盗的肆虐之下依旧照旧工作。不知道他们是怎么办到的！")
    SetQBit(QBit(232))
end)

RegisterGlobalEvent(4, nil, function()
    evt.SetMessage("这就像是我在末日预言中读过的一样！“……火之大山将会从海中升起，就像是匕首一划所造成的伤口一样……”\n你一定要找到离开这些岛屿的方法，即使不为了车队，也为了你自己！一定要有人离开这里，把这边的消息告诉阿尔瓦商团公会的议会！他们必须要知道大灾变的状况和雷格那海盗的入侵才行！")
    evt.SetNPCTopic(2, 0, 20) -- 达德洛斯 topic 0: 任务
end)

RegisterGlobalEvent(5, nil, function()
    if not IsQBitSet(QBit(6)) then
        evt.SetMessage("从恐怖的岛屿雷格那来的海盗正在利用这场大灾变和它所造成的混乱四处劫掠。如果他们征服了匕伤群岛，他们就可以利用这个地方当做前哨站，攻击渡鸦海滨！阿尔瓦议会的成员必须要知道这件事情才行！你必须要找到可以离开此处的船，并且告诉他们这个消息！")
        return
    end
    evt.SetMessage("多谢你们处理掉那些海盗。在那些海盗被赶走之后，也许单牙酋长和他的同胞们可以重建村庄。在这里发生过的事情实在是太糟糕了。")
end)

RegisterGlobalEvent(6, nil, function()
    if not IsQBitSet(QBit(6)) then
        evt.SetMessage("要把车队整个运回渡鸦海滨去，我们必须要好几艘船，或者是一艘船来回好几趟才行。在雷格那海盗离开匕伤群岛附近的海面之前，我们没有办法办到这件事情。你最好赶快回到阿尔瓦去，并且告诉议会雷格那海盗攻击的这件事情。他们将会派出援军来拯救我们。")
        return
    end
    evt.SetMessage("很遗憾的，海盗们一来到这边就开始抢劫这车队。我实在想不出来他们到底有三百箱的托伯斯克果干嘛！当然，我觉得水果被抢走了很可惜，但是他们对这些车子所造成的损害更让人痛心。看起来我至少要在这边待到下一季才能够修好这些车子。我只希望这整个整修工程能够在下一次托伯斯克果采收之前完成，好让我勉强捞回一笔来。")
end)

RegisterGlobalEvent(7, nil, function()
    if not IsQBitSet(QBit(6)) then
        evt.SetMessage("在半夜的时候，整个大地突然开始震动起来！着火的岩石从天上降落！我的许多同胞都因此而受伤或者是被杀死了！村庄里面受到了很大的伤害。在各岛屿和大陆之间所搭建的桥梁也都跟着损坏了。我们发现自己被困在这座岛屿上，无法拯救那些被困在其它岛屿上的同胞。许多家人和朋友都在这场灾害中失踪了。我们无法利用船只前往其它岛屿，因此我们也没有办法前往渡鸦海滨求救。我甚至不知道有没有船只在这场灾难中留存下来。")
        return
    end
    evt.SetMessage("再经历过了巨浪、落石和海盗的劫掠之后，我不知道我们的村庄会不会再像以前一样。我知道你已经替我们做了很多，但并不是每样东西都可以恢复旧观。也许我们会重建，也许我们必须离开。也许时间到了我们就会知道。")
end)

RegisterGlobalEvent(8, nil, function()
    evt.SetMessage("在很久以前，我们的同胞会利用岩石传送门在岛与岛之间快速的往来，但是我们已经遗忘了要怎么操作这些东西。只有一座连接这个村庄和西南岛的传送门还依旧可以运作。现在桥梁都已经毁坏了，我们等于被困在这座岛屿上了！")
    evt.SetNPCTopic(1, 1, 21) -- 布瑞克许・单牙 topic 1: 任务
end)

RegisterGlobalEvent(9, nil, function()
    evt.SetMessage("一名叫做费德瑞克・塔力米尔的牧师曾经和我们居住过一阵子。他曾经在被废弃的神殿那边研究岩石传送门。也许他知道怎么让这些传送门再度启动！去找他，看看他愿不愿意帮忙！")
end)

RegisterGlobalEvent(10, nil, function()
    evt.SetMessage("啊，是的……传送门。我研究它们和建造它们的神秘文化好多年了。\n他们是在蜥蜴人来到这里之前许多旧有的文明之下所建造的。他们是用来在不同的岛屿之间传送用的工具。很遗憾的，能够启动这些传送门的能源之石目前数量非常的稀少。")
end)

RegisterGlobalEvent(11, nil, function()
    evt.SetMessage("当着火山脉降落的第一天时，我到海滩那边去观看，想要知道是否能够看到任何有关它爆发的情形。其实我不太确定，但是我想我从山脉的底端看到了有许多土元素争先恐后地冒出来。")
end)

RegisterGlobalEvent(12, nil, function()
    evt.SetMessage("啊，单牙酋长把他所拥有的能源之石给了你！这将可以启动岛上西南方的传送门。你只需要把这块石头的影像铭记在脑海中，然后就可以启动传送门。")
    evt.ForPlayer(Players.All)
    SetAutonote(492)
    AddValue(Experience, 1500)
    ClearQBit(QBit(7)) -- 将布拉克许・单牙的传送水晶带回给费德瑞克・塔力米尔
    SetQBit(QBit(8))
    evt.SetNPCTopic(28, 2, 602) -- 佛得瑞克・塔力米尔 topic 2: 加入队员清单事件
    evt.SetNPCTopic(1, 2, 0) -- 布瑞克许・单牙 topic 2 cleared
end)
RegisterCanShowTopic(12, function()
    evt._BeginCanShowTopic(12)
    local visible = true
    if HasItem(617) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(13, nil, function()
    evt.SetMessage("建造传送门的失落文明所盖的神殿废墟就在主岛屿西北方的地方。不过，因为里面有很多危险的爬虫类，所以其实我并没有探索过里面到底有什么东西。不过，我倒是怀疑庙里面可能有个水下隧道，通往西北方岛上的那座港口。\n在桥梁都被摧毁之后，那座隧道也许成为了唯一抵达港口或是船只的路径！")
end)

RegisterGlobalEvent(14, nil, function()
    if not IsQBitSet(QBit(138)) then
        evt.SetMessage("我的弟兄利舌埃斯瑞克去其它的小岛上检查托伯斯克水果的生长状况。但是他没有回来！我很担心他可能被大灾变困在其它的岛上了。他甚至可能受伤了！如果你能够修复好岩石传送门，他应该可以回来，我们也可以替那些需要帮助的人找到足够的协助！赶快替我找到他！")
        SetQBit(QBit(137)) -- 替罗特奈克斯找到他的兄弟利舌埃斯瑞克。完成任务之后回去匕伤岛的血滴镇找罗特奈克斯。
        return
    end
    evt.SetMessage("你找到了埃斯瑞克了，并且告诉他要回家了吗？我们真的非常感激你！我会告诉我们的酋长布瑞克许・单牙。请把这些疗伤药剂收下，当作我对你的回报。")
    evt.ForPlayer(Players.All)
    AddValue(Experience, 750)
    evt.ForPlayer(Players.Member0)
    AddValue(InventoryItem(222), 222)
    AddValue(InventoryItem(222), 222)
    ClearQBit(QBit(137)) -- 替罗特奈克斯找到他的兄弟利舌埃斯瑞克。完成任务之后回去匕伤岛的血滴镇找罗特奈克斯。
    evt.ForPlayer(Players.All)
    SetAward(Award(54))
    evt.SetNPCTopic(29, 0, 0) -- 罗特奈克斯 topic 0 cleared
end)

RegisterGlobalEvent(15, nil, function()
    if not IsQBitSet(QBit(1)) then
        evt.SetMessage("我的祖母曾经告诉过我们，很久以前，岩石传送门是各岛屿之间旅行的主要工具。她告诉我们，在第一次雷格那海盗侵略这座岛屿的时候，岩石传送门的钥匙也跟着消失了。如果岩石传送门能够恢复运作，那么我的兄弟利舌埃斯瑞克也可以回到这座岛上了！")
        return
    end
    evt.SetMessage("你已经修好了岩石传送门？太好了！赶快叫我的兄弟埃斯瑞克回家来！")
end)

RegisterGlobalEvent(16, nil, function()
    evt.SetMessage("那个粗鲁的家伙？他只关切那座已经变成废墟的岛屿，不再关心我们周遭人所经历的生活！我的祖母警告过他，那个神殿是居住有巨大邪恶的地方，他从来就不听。现在祖母已经不在我们身边了，而我们又只有布拉克许・单牙可以提醒我们这些过去的教训。")
end)

RegisterGlobalEvent(17, nil, function()
    evt.SetMessage("我们一定冒犯了古人！不然他们为什么会召唤来着火的大山！预言曾经说过有一天大海将会沸腾！这就是末日的开始！")
end)

RegisterGlobalEvent(18, nil, function()
    evt.SetMessage("有许多预言里面提到了贾丹姆大陆和整个世界的毁灭。这许多记载中，提到了整个世界将会被创造它的力量所摧毁。也许古人们决定要将我们给彻底摧毁掉！")
end)

RegisterGlobalEvent(19, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(652) then
        evt.SetMessage("有一个预言，也就是蛇之预言，我一直找不到任何的抄本。我想那也许和贾丹姆大陆的未来有关系。\n有一名牧师，费德瑞克・塔力米尔曾经跟我提到过这些蛇人的废墟，以及一个废弃的神殿。他同意我的看法：也许在这些建筑物中会有一份有关这个预言的抄本。你能够替我找到这份抄本吗？")
        SetQBit(QBit(135)) -- 替派赛拉・提斯克找到蛇之预言。
        return
    end
    evt.SetMessage("你找到了蛇之预言！也许我们的未来就记载在其中！请收下这些东西当作我对你的回报！")
    RemoveItem(652)
    ClearQBit(QBit(135)) -- 替派赛拉・提斯克找到蛇之预言。
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 500)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 750)
    evt.SetNPCTopic(30, 1, 0) -- 派赛拉・提斯克 topic 1 cleared
end)

RegisterGlobalEvent(20, nil, function()
    if not IsQBitSet(QBit(3)) then -- 将达德洛斯的信送给渡鸦海滨商人之家中的艾德加・费尔蒙
        evt.SetMessage("你必须要找到一个离开这些岛屿的方法。一定要有人把这里发生的事情通知我们的上级，阿尔瓦的商人们！他们一定要知道这里发生的大灾变和雷格那海盗的所作所为！\n我已经写好了一封信，你必须要把它交给渡鸦海滨的阿尔瓦商人代表，艾尔加・费尔蒙。如果这世界上有任何人有资格建议我们该作些什么，费尔蒙一定是其中之一。赶快把这封信交给他。")
        evt.SetNPCGreeting(2, 8) -- 达德洛斯 greeting 8
        AddValue(InventoryItem(741), 741)
        SetQBit(QBit(221))
        SetQBit(QBit(3)) -- 将达德洛斯的信送给渡鸦海滨商人之家中的艾德加・费尔蒙
        ClearQBit(QBit(85)) -- 找到达德洛斯，也就是负责管理你们商队的牛头人。上次你看见他的时候，他正准备要和村庄中的长老谈话。
        return
    end
    evt.SetMessage("你一定要将这封信带给在渡鸦海滨的艾德加・费尔蒙！")
end)
RegisterCanShowTopic(20, function()
    evt._BeginCanShowTopic(20)
    local visible = true
    if IsQBitSet(QBit(4)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(21, nil, function()
    if not IsQBitSet(QBit(7)) then -- 将布拉克许・单牙的传送水晶带回给费德瑞克・塔力米尔
        evt.SetMessage("把这个水晶带去给费德瑞克・塔力米尔。我知道这和岩石传送门一定有些关系。也许他可以告诉你这个石头和那些传送门有什么关系！")
        AddValue(InventoryItem(617), 617)
        SetQBit(QBit(212))
        SetQBit(QBit(7)) -- 将布拉克许・单牙的传送水晶带回给费德瑞克・塔力米尔
        evt.SetNPCTopic(28, 2, 12) -- 佛得瑞克・塔力米尔 topic 2: 能源之石
        evt.SetNPCTopic(28, 3, 13) -- 佛得瑞克・塔力米尔 topic 3: 废庙
        return
    end
    evt.SetMessage("把这个传送门水晶交给费德瑞克・塔力米尔。他会知道这有什么用的。")
end)
RegisterCanShowTopic(21, function()
    evt._BeginCanShowTopic(21)
    local visible = true
    if IsQBitSet(QBit(8)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(22, nil, function()
    evt.SetMessage("商团议会已经派出了我们最强悍的战士，考瑞・黑王座来和太阳神庙讨论即将降临贾丹姆大陆的大灾难。\n考瑞在来到阿尔瓦并听说了大灾变的谣言后，就动身前往低语森林。她在和牧师们讨论过后，应该要赶快回来。我们很担心她至今尚未归来的原因。\n至于你所关心的晋升问题，只有考瑞拥有足够的资格测试你的能力和技巧。如果你找到了她，你应该要提供她相关的协助，并且告诉我们她的状况和目前的情形。")
    SetQBit(QBit(39)) -- 找到考瑞・黑王座，然后回去低语森林，将她所在的位置告诉丹提理安。
    evt.SetNPCTopic(39, 0, 31) -- 瑞尔朋・吉普斯 topic 0: 考力在哪里？
end)

RegisterGlobalEvent(23, nil, function()
    if IsQBitSet(QBit(1537)) then
        evt.SetMessage("考瑞回来之后，告诉了我们你对她提供的协助。她也通知了我们你的晋升。恭喜，愿你的收获替你带来欢喜！")
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 15000)
        evt.SetNPCTopic(39, 1, 0) -- 瑞尔朋・吉普斯 topic 1 cleared
        return
    elseif HasAward(Award(20)) then
        evt.SetMessage("考瑞回来之后，告诉了我们你对她提供的协助。她也通知了我们你的晋升。恭喜，愿你的收获替你带来欢喜！")
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 15000)
        evt.SetNPCTopic(39, 1, 0) -- 瑞尔朋・吉普斯 topic 1 cleared
    else
        evt.SetMessage("这是考瑞・黑王座的家，她是最伟大的黑暗精灵战士。她目前不在这里，正在替阿尔瓦商人公会工作。也许你应该去找他们，问问看她人在哪里。")
    end
end)

RegisterGlobalEvent(24, nil, function()
    evt.SetMessage("多谢你们协助我处理石化蜥蜴的诅咒。通常我自己可以处理这些可恶的蜥蜴，但是这次他们的数量实在太多了些。\n太阳神庙要求我来这边寻找几名探索德鲁伊圣石圈的教徒。当我找到了第一座雕像的时候，我明白了这些教徒到底发生了什么事情。\n我自己并不知道石化蜥蜴在此地的数量大幅增加了。他们似乎是受到什么东西的鼓动。当石化蜥蜴攻击我的时候，我正准备要前往德鲁伊圣石圈。")
end)

RegisterGlobalEvent(25, nil, function()
    evt.SetMessage("考瑞看着你队伍中的黑暗精灵：\n由于你们救出了我，因此，你们必然研究过我曾经踏过的道路，调查过我曾经去过的地方。这展现了你拥有可以处理周遭细微事物的超凡能力。\n要抵达我被困住的地方，你们必须拥有击败石化蜥蜴和其它威胁的能力，证明了你们身为战士的资格。当沟通失败的时候，有时你们必须要拥有战斗的力量。\n要求我让你们晋升则展现了足够的欲望。如果你们没有足够的欲望，成功永远都会逃出你的掌握。\n你们拥有了所有黑暗精灵长所需要的特点，当我回到议会之后，我将会通知他们。如果能够和诸位再度一起旅行，这将会是我的荣幸。你们可以在渡鸦海滨的旅馆找到我。")
    for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 8) then
            SetValue(ClassId, 9)
            AddValue(Experience, 35000)
            SetQBit(QBit(1537))
        else
            AddValue(Experience, 25000)
            SetAward(Award(20))
        end
    end
    ClearQBit(QBit(39)) -- 找到考瑞・黑王座，然后回去低语森林，将她所在的位置告诉丹提理安。
    SetQBit(QBit(40))
    SetQBit(QBit(430))
    evt.SetNPCTopic(42, 1, 38) -- 考瑞・黑王座 topic 1: 多谢你的帮助！
end)

RegisterGlobalEvent(26, nil, function()
    evt.SetMessage("我必须要协助太阳神庙再进一步地调查这圣石圈。希望不是所有的信徒都遭遇到了相同的命运。希望还有人活下来！\n有什么力量刺激了这区域的怪物，我想来源应该就在圣石圈之中。")
end)

RegisterGlobalEvent(27, nil, function()
    if IsQBitSet(QBit(39)) then -- 找到考瑞・黑王座，然后回去低语森林，将她所在的位置告诉丹提理安。
        evt.SetMessage("考瑞・黑王座大概在一周之前出现在这边。她问了我们很多有关元素界入侵的问题。我们提供了她这边所有的情报。她说她将会带着这些情报回到阿尔瓦。在她离开之前，我们请她帮我们个小忙。我们请她替我们查查看一群前往此地东北方的德鲁伊圣石圈的信徒下场如何。她答应我们在回到阿尔瓦之前，一定会先看看那个地方。")
        for _, player in ipairs(PartyMembers()) do
            evt.ForPlayer(player)
            AddValue(InventoryItem(339), 339)
        end
        evt.SetNPCTopic(41, 0, 26) -- 丹提理安 topic 0: 岩石圈
        return
    elseif IsQBitSet(QBit(40)) then
        ClearQBit(QBit(39)) -- 找到考瑞・黑王座，然后回去低语森林，将她所在的位置告诉丹提理安。
    else
        evt.SetMessage("考瑞・黑王座大概在一周之前出现在这边。她问了我们很多有关元素界入侵的问题。我们提供了她这边所有的情报。她说她将会带着这些情报回到阿尔瓦。在她离开之前，我们请她帮我们个小忙。我们请她替我们查查看一群前往此地东北方的德鲁伊圣石圈的信徒下场如何。她答应我们在回到阿尔瓦之前，一定会先看看那个地方。")
        for _, player in ipairs(PartyMembers()) do
            evt.ForPlayer(player)
            AddValue(InventoryItem(339), 339)
        end
    end
evt.SetNPCTopic(41, 0, 26) -- 丹提理安 topic 0: 岩石圈
return
end)

RegisterGlobalEvent(28, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(741) then
        evt.SetMessage("你来这里声称手中握有我的一名车队队长所写的亲笔信。哼哼，这信到哪里去了？如果这信那么重要，相信你不可能会在路上把它弄丢吧！")
        return
    end
    evt.SetMessage("这是什么？我的车队队长寄来的信？达德洛斯？让我看看……嗯嗯……\n看来的确有很严重的事情发生了。真可惜，匕伤群岛上发生了这么可怕的事情。我们必须要采取行动，但是我必须要有更多的情报才行……\n……我想我知道该怎么弄到那么多情报！也许你们可以帮助我？当然，我会补偿你的。来，这是送来达德洛斯信件的一点小报酬。")
    evt.SetNPCTopic(3, 0, 29) -- 艾尔加・费尔蒙 topic 0: 任务
    evt.SetNPCGreeting(2, 58) -- 达德洛斯 greeting 58
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(3)) -- 将达德洛斯的信送给渡鸦海滨商人之家中的艾德加・费尔蒙
    SetQBit(QBit(4))
    RemoveItem(741)
    ClearQBit(QBit(221))
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 2500)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 7500)
    SetAutonote(494)
end)

RegisterGlobalEvent(29, nil, function()
    if IsQBitSet(QBit(12)) then
        evt.SetMessage("你一定要去阿尔瓦找巴斯沈・卢德林。快点！他一定要知道最近发生了什么事情！")
        return
    elseif IsQBitSet(QBit(24)) then
        evt.SetMessage("可能你也注意到了，我们公会的总部座落在阿尔瓦。如果你从没去过那个地方，要到那边最简单的方法是沿着河往上走，往北边穿过峡谷。\n去那里的公会聚会所找一个叫做巴斯沈・卢德林的人。告诉他有关这个水晶的状况，以及其它的许多传言。卢德林会知道该怎么作。")
        SetQBit(QBit(11)) -- 将消息报告至阿尔瓦商人公会会长巴斯沉・卢德林
        return
    elseif IsQBitSet(QBit(10)) then
        evt.SetMessage("很好，这就是我们之前同意的报酬。韩特的船只将可以供我们在整场危机的过程中使用。\n是的，我的确就是指这次的“危机”！自从你上次拜访此处之后，有好几个班次的商队都没有照着原先的时间抵达指定的地点。而且还有一些奇怪的谣言。我听说有燃烧的火湖突然之间出现在沙漠中。\n火山！火湖！我担心这个神秘的水晶和这件事情有关。不管如何，阿尔瓦商人公会的会长都必须要知道最新阶段的发展。")
        evt.ForPlayer(Players.All)
        SetAutonote(493)
        AddValue(Experience, 12000)
        SetQBit(QBit(24))
        ClearQBit(QBit(284)) -- 回去找阿尔瓦的费尔蒙报到，并且解释你已经成功的勒索了走私贩子艾瑞安・韩特。
        return
    elseif IsQBitSet(QBit(9)) then -- 将费尔蒙的黑函交给半鼠人走私集团的首领艾瑞安・韩特，并将结果回报至艾尔加・费尔蒙
        evt.SetMessage("听着。我们需要这些船！把这封信交给韩特，难道你忘记了吗？他的巢穴就在西边的海岸边！")
    else
        evt.SetMessage("此地的走私贩子拥有渡鸦海滨最快的船。如果我的信差们可以拥有这些船，他们将可以在沿岸执行快速的侦察任务，让我们可以知道达德洛斯信中所提到的大灾变到底是什么样状况。\n来。把这封信带给走私贩子的首脑，艾瑞安・韩特。我很确定这可以“说服”他提供相关的服务。你将可以在西方的海岸边找到他的老巢。\n喔，我几乎忘了先提。这些走私者都是鼠人，你也知道他们的恶形恶状。韩特可以被说服，但是他的手下可能就没有那么文明了。")
        SetQBit(QBit(9)) -- 将费尔蒙的黑函交给半鼠人走私集团的首领艾瑞安・韩特，并将结果回报至艾尔加・费尔蒙
        AddValue(InventoryItem(742), 742)
        SetQBit(QBit(222))
        evt.SetNPCGreeting(3, 11) -- 艾尔加・费尔蒙 greeting 11
    end
return
end)

RegisterGlobalEvent(30, nil, function()
    if not IsQBitSet(QBit(40)) then
        evt.SetMessage("这是考瑞・黑王座的家，她是最伟大的黑暗精灵战士。她目前不在这里，正在替阿尔瓦商人公会工作。也许你应该去找他们，问问看她人在哪里。")
        return
    end
    evt.SetMessage("考瑞回来之后，告诉了我们你对她提供的协助。她也通知了我们你的晋升。恭喜，愿你的收获替你带来欢喜！")
end)

RegisterGlobalEvent(31, nil, function()
    evt.SetMessage("你找到考瑞了吗？我们真的很需要知道她的状况，如果没有她，我们就都死定了！")
end)
RegisterCanShowTopic(31, function()
    evt._BeginCanShowTopic(31)
    local visible = true
    if IsQBitSet(QBit(40)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(32, nil, function()
    evt.SetMessage("你……你把我所有的守卫都……只为了送这封信！让我看看……\n……嗯嗯，费尔蒙想要我的船？绝不可能……我……什么？他用我的伊拉贝尔威胁我……我……唉……\n好，好吧。你可以告诉费尔蒙尽管用我的船吧。我想这世界上没有任何人可以拒绝阿尔瓦商人公会所提出的要求。")
    evt.ForPlayer(Players.All)
    SetQBit(QBit(10))
    ClearQBit(QBit(9)) -- 将费尔蒙的黑函交给半鼠人走私集团的首领艾瑞安・韩特，并将结果回报至艾尔加・费尔蒙
    SetQBit(QBit(284)) -- 回去找阿尔瓦的费尔蒙报到，并且解释你已经成功的勒索了走私贩子艾瑞安・韩特。
    RemoveItem(742)
    ClearQBit(QBit(222))
    evt.SetNPCTopic(4, 0, 33) -- 艾瑞安・韩特 topic 0: 走私者的船
    AddValue(History(3), 0)
    ClearQBit(QBit(231))
end)
RegisterCanShowTopic(32, function()
    evt._BeginCanShowTopic(32)
    local visible = true
    if HasItem(742) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(33, nil, function()
    evt.SetMessage("我的货柜是那种你不想要让港口官员检查的东西，所以，我的船必须要是贾丹姆大陆上最快的船才行。他们甚至可以跑得比雷格那海盗的大船要快！他们的通常航道从这边开始，西到残破镇，东到阴影塔。")
end)

RegisterGlobalEvent(34, nil, function()
    evt.SetMessage("古代的巨魔传说中，曾经有一段时间，我们并不是居住在这个孤立、残破的地区。传说中提到了一个宁静、祥和的地方，我们被石头的诅咒所驱赶。所以我们在铁沙漠中居住了好几百年的时间。现在看起来，我们又必须被迫离开这个地方。这个不停扩展的火湖摧毁了我们村庄大部分的地区。我的朋友和家人都在这场灾难中过世了。这很有可能就是我们部族的末日。\n我们的同胞还有一句俗谚，“必须有人记得，一样东西才会继续存在。”只要我还记得我们的家园，它就会继续等待我们的回归。我们只需要找到这个传说中的地方就好了。")
end)

RegisterGlobalEvent(35, nil, function()
    evt.SetMessage("也许，如果你可以替我们找到我们古代家园，替我们看看到底石之诅咒是否还继续存在于该处。如果诅咒还没有消除，请找到消除它的方法。如果你完成了这个任务，在你队伍中的巨魔将会被晋升为我们部族中的战斗巨魔。这是个拥有极高荣誉的称号，你们会永远被我的族人撰写在传说之中。\n我们的一名战士达丁・都沃克出发去寻找这个地方。他留下的一些笔记让我们知道他认为在残破镇的岩石区可以找到一些相关的线索。也许你可以在那边找到他，并且和他一起努力。或者，至少找到可以让你完成任务的线索。")
    SetQBit(QBit(68)) -- 找到古代巨魔之家，并回到铁沙漠找瓦络德・沙风解释。
    evt.SetNPCTopic(43, 0, 40) -- 瓦络格・沙风 topic 0: 古代巨魔之家
end)

RegisterGlobalEvent(36, nil, function()
    evt.SetMessage("你找到了古代巨魔之家？它就在低语森林的西边？这消息真是太好了。也许我们还有足够的时间让同胞迁移过去。不过，真遗憾我们必须先处理元素界入侵的威胁，否则在那之前没有任何人是安全的！\n在你们队伍之中的巨魔将会被晋升为战斗巨魔，他们的名号将会被永远记录在我们的歌谣之中。我将会教导你们我所会的技能，希望这能够协助你们拯救这个世界！")
    for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 38) then
            SetValue(ClassId, 39)
            AddValue(Experience, 35000)
            SetQBit(QBit(1538))
        else
            AddValue(Experience, 25000)
            SetQBit(QBit(1539))
        end
    end
    ClearQBit(QBit(68)) -- 找到古代巨魔之家，并回到铁沙漠找瓦络德・沙风解释。
    evt.SetNPCTopic(43, 1, 612) -- 瓦络格・沙风 topic 1: 加入队员清单事件
end)
RegisterCanShowTopic(36, function()
    evt._BeginCanShowTopic(36)
    local visible = true
    if IsQBitSet(QBit(69)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(37, nil, function()
    evt.SetMessage("你被派来寻找古代巨魔之家？我很欢迎你的帮助！我实在不知道接下来该怎么作，我找到的线索到了这边就断线了。没有人知道我们传说中所提到的什么石之诅咒。那个食人妖法师实在也没有帮上我们什么忙，索格，我好不容易才逃出了他恐怖的要塞。\n不过，他无意中还是提供了我一些帮助。当我对他提到石之诅咒的时候，他说如果我再烦他，它就会把我丢给他的石化蜥蜴宠物当饲料！低语森林这边有很多会将猎物石化的石化蜥蜴！")
end)

RegisterGlobalEvent(38, nil, function()
    evt.SetMessage("多谢你解除了石化蜥蜴的诅咒！赶快回去阿尔瓦！我们必须要想办法拯救贾丹姆大陆！")
end)

RegisterGlobalEvent(39, nil, function()
    evt.SetMessage("多谢你替我们找到了古代巨魔之家，一旦我们让贾丹姆大陆脱离了目前的危机，我们就可以搬到那里去了！")
end)

RegisterGlobalEvent(40, nil, function()
    evt.SetMessage("你替我们找到古代巨魔之家的位置了吗？如果你没有替我们找到那个地方，我们的同胞一定会全都完蛋的！")
end)
RegisterCanShowTopic(40, function()
    evt._BeginCanShowTopic(40)
    local visible = true
    if IsQBitSet(QBit(68)) then -- 找到古代巨魔之家，并回到铁沙漠找瓦络德・沙风解释。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(41, nil, function()
    evt.SetMessage("匕伤群岛上也有恐怖的危机发生了吗？这真是让人感到困扰。如果有人相信目前到处流传的所有谣言，那么他们将会以为贾丹姆大陆已经陷入了全面的危机和混乱之中。\n我真希望我能够知道更多的消息。我本来都是倚靠我的车队提供相关的情报，但是这个月预计要到达的车队有很多都延迟了。而我所听到的消息让我感到十分的困扰。飓风、洪水，现在还有火山！我所听到最糟糕的消息是铁沙漠中央出现了一个滚烫的火湖，而且还有许多消息来源证实了这个消息。\n不知道在渡鸦海滨的这个水晶是否和这一切有关系。看起来这一切混乱同时出现并不单纯只是巧合。")
    ClearQBit(QBit(11)) -- 将消息报告至阿尔瓦商人公会会长巴斯沉・卢德林
    SetQBit(QBit(12))
    evt.SetNPCTopic(5, 0, 42) -- 巴斯沈・卢德林 topic 0: 任务
    evt.ForPlayer(Players.All)
    AddValue(Experience, 15000)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 2000)
end)
RegisterCanShowTopic(41, function()
    evt._BeginCanShowTopic(41)
    local visible = true
    if IsQBitSet(QBit(11)) then -- 将消息报告至阿尔瓦商人公会会长巴斯沉・卢德林
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(42, nil, function()
    if not IsQBitSet(QBit(25)) then -- 找到一个目击火湖形成的证人，并且将它带回阿尔瓦的商人公会。
        evt.SetMessage("这一切混乱的状况都对我们公会的运作造成了很大的影响。我需要更多的情报，但是目前却被谣言和绘声绘影的传说所掩盖了。\n许多人告诉我铁沙漠中央出现了一个火焰之湖。我听说了有关这个火湖的许多谣言，几乎让我相信了这个怪异的传说。如果你能够证明或是否定这个传说，对我将会有很大的意义。\n如果你愿意帮我一个忙，请去铁沙漠寻找这个火湖。如果火湖的确出现在沙漠中，请替我找到一个目击火湖出现的证人。把他带回这里来，让我可以亲自听听火湖的故事。")
        SetQBit(QBit(25)) -- 找到一个目击火湖形成的证人，并且将它带回阿尔瓦的商人公会。
        AddValue(History(4), 0)
        evt.MoveNPC(7, 752) -- 欧瓦都・弹指 -> 欧瓦都的房间
        evt.MoveNPC(47, 752) -- 法希尔・弹指 -> 欧瓦都的房间
        return
    end
    if HasPlayer(4) then
        evt.SetMessage("喔，你看你把事情弄成什么样子！当我要求你找个铁沙漠事件的目击证人时，我以为你会知道应该要把他好好的带回来！你看看这个可怜的家伙！赶快把他带到神庙去治疗。\n求求你……请你至少记得是在为公会服务，我们作事情有一定的水准。")
        return
    elseif IsQBitSet(QBit(60)) then
        evt.SetMessage("啊，原来这是真的。想像一下……一个火焰构成的大湖。但是我的目击证人在哪里？我必须要和亲眼目击火湖出现的证人谈谈。这很重要，原因我现在还没办法告诉你。\n替我找个真正看到火湖出现的证人！试着去巨魔的村庄――铁锈镇找找看吧！")
    else
        evt.SetMessage("我必须要知道铁沙漠中到底发生了什么事情，谣言我已经听得够多了。\n你必须要往东走几天的路，前往铁沙漠去彻底调查真正的状况。")
    end
end)

RegisterGlobalEvent(43, nil, function()
    if IsQBitSet(QBit(19)) then
        if IsQBitSet(QBit(21)) then
            if IsQBitSet(QBit(23)) then
                evt.SetMessage("很好……至少你已经尽力了。你让另外三个势力加入了联盟，这是我们所需要的最低人手。这样我们才能满足“贾丹姆大陆必须要团结在一起……”的预言。真可惜你无法弄到更多的援军，但大灾变已经迫在眉睫，我们的动作得要快一点。\n你必须要前往渡鸦海滨和在该处聚会的联盟议会碰面。在那之后，你将必须和他们讨论如何面对元素界所带来的大危机。")
                return
            end
            evt.SetMessage("你必须要组织一个联盟，对抗我们眼前的末日威胁！你必须要去找寻太阳神庙、死灵法师公会、残破镇的牛头人、绞刑峡谷的龙、绞刑峡谷的猎龙人查尔斯・吉柯德。我知道你没办法让他们全部团结在一起，但是，你依旧必须要先尽力尝试才行。\n如果我们要逃过这一切危机，不让预言成真，我的智者告诉我至少要让前面所提到的势力中有三个同意加入这个联盟。如果你珍惜这个世界和自己的生命，赶快去完成这个任务吧！")
            return
        elseif IsQBitSet(QBit(22)) then
            if IsQBitSet(QBit(23)) then
                evt.SetMessage("很好……至少你已经尽力了。你让另外三个势力加入了联盟，这是我们所需要的最低人手。这样我们才能满足“贾丹姆大陆必须要团结在一起……”的预言。真可惜你无法弄到更多的援军，但大灾变已经迫在眉睫，我们的动作得要快一点。\n你必须要前往渡鸦海滨和在该处聚会的联盟议会碰面。在那之后，你将必须和他们讨论如何面对元素界所带来的大危机。")
                return
            end
            evt.SetMessage("你必须要组织一个联盟，对抗我们眼前的末日威胁！你必须要去找寻太阳神庙、死灵法师公会、残破镇的牛头人、绞刑峡谷的龙、绞刑峡谷的猎龙人查尔斯・吉柯德。我知道你没办法让他们全部团结在一起，但是，你依旧必须要先尽力尝试才行。\n如果我们要逃过这一切危机，不让预言成真，我的智者告诉我至少要让前面所提到的势力中有三个同意加入这个联盟。如果你珍惜这个世界和自己的生命，赶快去完成这个任务吧！")
            return
        else
            evt.SetMessage("你必须要组织一个联盟，对抗我们眼前的末日威胁！你必须要去找寻太阳神庙、死灵法师公会、残破镇的牛头人、绞刑峡谷的龙、绞刑峡谷的猎龙人查尔斯・吉柯德。我知道你没办法让他们全部团结在一起，但是，你依旧必须要先尽力尝试才行。\n如果我们要逃过这一切危机，不让预言成真，我的智者告诉我至少要让前面所提到的势力中有三个同意加入这个联盟。如果你珍惜这个世界和自己的生命，赶快去完成这个任务吧！")
            return
        end
    elseif IsQBitSet(QBit(20)) then
        if IsQBitSet(QBit(21)) then
            if IsQBitSet(QBit(23)) then
                evt.SetMessage("很好……至少你已经尽力了。你让另外三个势力加入了联盟，这是我们所需要的最低人手。这样我们才能满足“贾丹姆大陆必须要团结在一起……”的预言。真可惜你无法弄到更多的援军，但大灾变已经迫在眉睫，我们的动作得要快一点。\n你必须要前往渡鸦海滨和在该处聚会的联盟议会碰面。在那之后，你将必须和他们讨论如何面对元素界所带来的大危机。")
                return
            end
            evt.SetMessage("你必须要组织一个联盟，对抗我们眼前的末日威胁！你必须要去找寻太阳神庙、死灵法师公会、残破镇的牛头人、绞刑峡谷的龙、绞刑峡谷的猎龙人查尔斯・吉柯德。我知道你没办法让他们全部团结在一起，但是，你依旧必须要先尽力尝试才行。\n如果我们要逃过这一切危机，不让预言成真，我的智者告诉我至少要让前面所提到的势力中有三个同意加入这个联盟。如果你珍惜这个世界和自己的生命，赶快去完成这个任务吧！")
            return
        elseif IsQBitSet(QBit(22)) then
            if IsQBitSet(QBit(23)) then
                evt.SetMessage("很好……至少你已经尽力了。你让另外三个势力加入了联盟，这是我们所需要的最低人手。这样我们才能满足“贾丹姆大陆必须要团结在一起……”的预言。真可惜你无法弄到更多的援军，但大灾变已经迫在眉睫，我们的动作得要快一点。\n你必须要前往渡鸦海滨和在该处聚会的联盟议会碰面。在那之后，你将必须和他们讨论如何面对元素界所带来的大危机。")
                return
            end
            evt.SetMessage("你必须要组织一个联盟，对抗我们眼前的末日威胁！你必须要去找寻太阳神庙、死灵法师公会、残破镇的牛头人、绞刑峡谷的龙、绞刑峡谷的猎龙人查尔斯・吉柯德。我知道你没办法让他们全部团结在一起，但是，你依旧必须要先尽力尝试才行。\n如果我们要逃过这一切危机，不让预言成真，我的智者告诉我至少要让前面所提到的势力中有三个同意加入这个联盟。如果你珍惜这个世界和自己的生命，赶快去完成这个任务吧！")
            return
        else
            evt.SetMessage("你必须要组织一个联盟，对抗我们眼前的末日威胁！你必须要去找寻太阳神庙、死灵法师公会、残破镇的牛头人、绞刑峡谷的龙、绞刑峡谷的猎龙人查尔斯・吉柯德。我知道你没办法让他们全部团结在一起，但是，你依旧必须要先尽力尝试才行。\n如果我们要逃过这一切危机，不让预言成真，我的智者告诉我至少要让前面所提到的势力中有三个同意加入这个联盟。如果你珍惜这个世界和自己的生命，赶快去完成这个任务吧！")
            return
        end
    else
        evt.SetMessage("你必须要组织一个联盟，对抗我们眼前的末日威胁！你必须要去找寻太阳神庙、死灵法师公会、残破镇的牛头人、绞刑峡谷的龙、绞刑峡谷的猎龙人查尔斯・吉柯德。我知道你没办法让他们全部团结在一起，但是，你依旧必须要先尽力尝试才行。\n如果我们要逃过这一切危机，不让预言成真，我的智者告诉我至少要让前面所提到的势力中有三个同意加入这个联盟。如果你珍惜这个世界和自己的生命，赶快去完成这个任务吧！")
        return
    end
end)

RegisterGlobalEvent(44, nil, function()
    evt.SetMessage("你完成了我原先认为是不可能的任务。虽然这些日子中，整个世界面对了许多的不确定性，但是你能够让关键的势力团结在一起面对末日，已经迈出了极大的一步。\n嗯，我已经完成了我的任务。我必须要将保护整个世界的工作交给联盟议会。我希望他们能够接受我在渡鸦海滨这里替他们所布置的会议室。毕竟这座屋子并不是我们最豪华的居所，但是，我希望议会能够靠近这个神秘的水晶。\n我希望他们，还有你们，都能够获得足够的好运！")
end)

RegisterGlobalEvent(45, nil, function()
    evt.SetMessage("是的，当火湖出现的时候，我就在那附近。一个怪异的传送门出现在村庄外面的沙漠中。你目前所看见的火焰就是从里面流　出来的。那些火焰看起来就像是水流泼在地面上一样地扩散。\n一波强烈的火焰盖过了我们的村庄，我大多数的同胞立刻就丧生了。现在这座村庄就是当时灾变之后仅剩的残骸。\n当这一切发生的时候，我正好在外面的山丘上观看这一切。这些怪异的状况我都目击了，但我实在很难相信这一切。")
    evt.SetNPCTopic(7, 0, 46) -- 欧瓦都・弹指 topic 0: 来阿尔瓦
end)

RegisterGlobalEvent(46, nil, function()
    if IsQBitSet(QBit(62)) then
        evt.SetMessage("你帮了我家人一个大忙。在你把我兄弟维尔拜的骨灰放进墓穴中之后，他终于可以安息了。我父亲的情况也大为改进了。我已经和他谈过话了，我相信他可以在我和你前往阿尔瓦的过程中照顾自己。")
        SetQBit(QBit(63))
        ClearQBit(QBit(61)) -- 将弹指兄弟维尔拜的骨灰葬到村庄的墓穴之中，并回来找弹指。
        evt.ForPlayer(Players.All)
        SetAutonote(495)
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 7500)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 20000)
        evt.SetNPCTopic(7, 0, 604) -- 欧瓦都・弹指 topic 0: 加入队员清单事件
        evt.SetNPCGreeting(47, 18) -- 法希尔・弹指 greeting 18
        evt.SetNPCTopic(47, 0, 47) -- 法希尔・弹指 topic 0: 维尔拜
        return
    elseif IsQBitSet(QBit(61)) then -- 将弹指兄弟维尔拜的骨灰葬到村庄的墓穴之中，并回来找弹指。
        evt.SetMessage("在我兄弟的骨灰被安放在村庄的墓穴中之后，我才能够跟你一起走。")
    else
        evt.SetMessage("如果不是因为我的父亲，我会愿意和你一起去的。他因为我的兄弟维尔拜而太过悲伤，没有办法照顾自己。\n我的父亲相信在维尔拜的尸骨安葬在村庄的墓穴中以前，他的灵魂没有办法安息。很不幸地，当火湖出现的时候，哥魔立刻就占据了我们的墓穴。\n来！这是我兄弟的骨灰。如果它们能够被安放在墓穴中，我相信我的父亲会好过一些。替我完成这个任务，我就愿意和你一起前往阿尔瓦。")
        SetQBit(QBit(61)) -- 将弹指兄弟维尔拜的骨灰葬到村庄的墓穴之中，并回来找弹指。
        AddValue(InventoryItem(603), 603)
        SetQBit(QBit(202))
    end
return
end)

RegisterGlobalEvent(47, nil, function()
    evt.SetMessage("维尔拜是个好儿子，我会想念他的。至少现在我知道他的骨灰已经放进墓穴中，他可以安息了。多谢你替我们完成这么危险的工作。")
end)

RegisterGlobalEvent(48, nil, function()
    evt.SetMessage("你们刚刚说，“结盟，将贾丹姆大陆统一在一起。”如果不是卢德林提议这件事情，我早就把你宰了当早餐。\n虽然这个点子很有趣，但是我现在没有空闲考虑这个建议。我们每天都受到查尔斯・吉柯德旗下的骑士攻击。如果他们不再骚扰我们，我就可以考虑卢德林的建议。\n也许你们可以帮我料理吉柯德？")
    evt.SetNPCTopic(17, 0, 49) -- 达夫克劳・红斧 topic 0: 任务
end)
RegisterCanShowTopic(48, function()
    evt._BeginCanShowTopic(48)
    local visible = true
    if IsQBitSet(QBit(17)) then -- 和绞刑峡谷的飞龙们结盟
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(49, nil, function()
    if IsQBitSet(QBit(21)) then
        AddValue(History(7), 0)
        return
    elseif IsQBitSet(QBit(33)) then -- 找到龙蛋，并且带回去给飞龙的领袖，达夫克劳・红斧。
        evt.ForPlayer(Players.All)
        if not HasItem(605) then
            evt.SetMessage("如果你想要我加入联盟，你就得要协助我对付吉柯德，还不快把龙蛋带来给我！")
            return
        end
        evt.ShowMovie("\"dragonsrevenge\"", true)
        evt.SetMessage("既然现在我已不需要担心我们下一代的生命安危了，我就准备去找吉柯德复仇。他的营地将会面临我们利爪和火焰的攻击。原先狩猎我们的骑士将会变成我们的猎物。\n至于你所提到的联盟……你们帮了我很大的忙，我会遵守约定。只要我把敌人都处理掉了，我就会前往渡鸦海滨加入议会的阵容。")
        SetQBit(QBit(22))
        SetQBit(QBit(35))
        ClearQBit(QBit(16)) -- 和绞刑峡谷的猎龙人结盟
        ClearQBit(QBit(17)) -- 和绞刑峡谷的飞龙们结盟
        ClearQBit(QBit(31)) -- 从残破镇旁索格的要塞中找出龙蛋，并且带回去给绞刑峡谷的查尔斯・吉科德。
        ClearQBit(QBit(33)) -- 找到龙蛋，并且带回去给飞龙的领袖，达夫克劳・红斧。
        evt.SetNPCTopic(15, 0, 0) -- 查尔斯・科切特爵士 topic 0 cleared
        evt.SetNPCGreeting(17, 20) -- 达夫克劳・红斧 greeting 20
        evt.SetNPCTopic(17, 0, 0) -- 达夫克劳・红斧 topic 0 cleared
        evt.ForPlayer(Players.All)
        AddValue(Experience, 20000)
        evt.ForPlayer(Players.All)
        RemoveItem(605)
        ClearQBit(QBit(204))
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 10000)
        evt.ForPlayer(Players.All)
        SetAward(Award(7))
        AddValue(History(7), 0)
    else
        evt.SetMessage("上个月吉柯德派了一小群人入侵我们的洞穴。他们杀死了很多龙，并且夺走了我们那些还没孵化的龙蛋。只要这些死家伙还挟持龙蛋，我们就不能够攻击他们的营地。\n如果你们能够将龙蛋归还给我们，我就可以直接了当地杀死吉柯德。只要你替我完成这个任务，我就加入你的联盟。")
        SetQBit(QBit(33)) -- 找到龙蛋，并且带回去给飞龙的领袖，达夫克劳・红斧。
    end
end)

RegisterGlobalEvent(50, nil, function()
    evt.SetMessage("恢复之宝石也许可以治愈布拉森・暴风枪骑士身上所背负的众多诅咒。太阳神庙和死灵法师之间本来就没有任何的友谊，只要是他们的敌人，就一定是我们的朋友。救活暴风枪，让他可以回到查尔斯・吉柯德身边。")
    evt.SetNPCTopic(50, 0, 743) -- 代为瑞许・其佛龙 topic 0: 和你一起旅行！
    AddValue(InventoryItem(623), 623)
    SetQBit(QBit(73))
    SetQBit(QBit(217))
    ClearQBit(QBit(72)) -- 去渡鸦海滨找代为瑞许・其佛龙询问有关治疗布拉森・暴风枪的药方。
end)
RegisterCanShowTopic(50, function()
    evt._BeginCanShowTopic(50)
    local visible = true
    if IsQBitSet(QBit(72)) then -- 去渡鸦海滨找代为瑞许・其佛龙询问有关治疗布拉森・暴风枪的药方。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(51, nil, function()
    evt.SetMessage("我的父亲相信阴影塔地区的死灵法师意图创造出一只不死飞龙来。这将会是只非常可怕的怪兽。他认为这必须要由他来阻止才行。")
end)

RegisterGlobalEvent(52, nil, function()
    evt.SetMessage("我的父亲布拉森几年以前离开这里，要去除掉阴影塔地区的骷髅龙。很不幸的，他再也没有回来过。他把史上最强的屠龙兵器――艾邦斯特屠龙枪一起带去了。查尔斯・吉柯德因为这件事而无法原谅我的父亲。很遗憾地，我们不知道我的父亲到底遭遇到了什么样的命运。由于我的父亲是查尔斯的副手，因此他必须要为了艾邦斯特屠龙枪遗失的意外负责，因此查尔斯不愿意将我晋升为勇士，即使我的技能和表现都已经符合了水准也没办法。如果你能够找到艾邦斯特屠龙枪，也许查尔斯会把你队伍中的骑士和我一起晋升为勇士！")
    SetQBit(QBit(70)) -- 找到布拉森・暴风枪以及那柄黑木之矛。完成任务之后去绞刑峡谷找连恩・暴风枪，并且将黑木之矛交给查尔斯・吉科德。
    evt.SetNPCTopic(49, 0, 59) -- 林恩・暴风枪 topic 0: 我的父亲
end)

RegisterGlobalEvent(53, nil, function()
    evt.SetMessage("我刚好在疯狂死灵法师实验室的正中央被俘虏，我在那边遭到无数的拷打和诅咒。艾邦斯特屠龙枪一定是在我倒下的时候被夺走了，也许它现在还在同样的地方。如果你能够找回艾邦斯特屠龙枪，并且将它拿回去给吉柯德，至少你可以协助洗清我的污名，而且我的女儿不需要因为我的失败而继续过着被鄙视的生活。")
end)

RegisterGlobalEvent(54, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(623) then
        evt.SetMessage("也许太阳神庙的牧师可以将我治愈，因为只有他们能够对抗影响我的这么多种黑暗类魔法。我在渡鸦海滨有个朋友，他叫做戴维许・契夫龙。他许多年之前离开了太阳神庙，在贾丹姆大陆上探索一切神秘的事物。也许他知道某种能将我治愈的方法，甚至刚好拥有相关的药剂。如果他也没有办法，请答应我你一定还会回来这里，并且杀死我，让我安息！")
        SetQBit(QBit(72)) -- 去渡鸦海滨找代为瑞许・其佛龙询问有关治疗布拉森・暴风枪的药方。
        return
    end
    evt.ForPlayer(Players.All)
    evt.SetMessage("牧师们派你带着回复之宝石回来了？我终于脱离了这个地方的禁锢！如果你们想要我的帮助，再来找我就好了！能够和你们一起旅行是我的荣耀！我会在渡鸦海滨的冒险者旅店等你！")
    RemoveItem(623)
    ClearQBit(QBit(217))
    AddValue(Experience, 15000)
    SetQBit(QBit(134))
    SetQBit(QBit(435))
    evt.ForPlayer(Players.All)
    SetQBit(QBit(1542))
    evt.SetNPCTopic(107, 1, 0) -- 布拉森・暴风枪 topic 1 cleared
end)

RegisterGlobalEvent(55, nil, function()
    evt.SetMessage("冉索拉从阴影塔搬到这里，继续她在死灵法师公会中开始的实验。她想要创造最终极的恐怖怪兽――骷髅飞龙。她的死灵法师同行们都畏惧可能造成的可怕结果。如果那创造出来的骷髅龙逃脱了冉索拉的控制，他们将无法阻止这个怪兽。")
end)

RegisterGlobalEvent(56, nil, function()
    evt.SetMessage("布拉森・暴风枪是我的手下和忠实的朋友。我一直没办法了解他的执着――消灭这所谓骷髅龙的传言。他把我最强的工具和武器给带走了。如果我手上还有艾邦斯特屠龙枪，飞龙的问题早就在我的控制之下了。")
end)

RegisterGlobalEvent(57, nil, function()
    evt.SetMessage("太阳神庙的牧师将神力灌注在这柄武器上，让它成为史上最强的兵器。它的力量据说可以一击消灭飞龙。如果真的是这样，我可以快速、有效率的解决目前眼前的冲突。")
end)

RegisterGlobalEvent(58, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(539) then
        evt.SetMessage("你找到了布拉森・暴风枪？但是艾邦斯特屠龙枪呢？把那柄神兵带回来给我，你才能够获得晋升！")
        return
    end
    if not IsQBitSet(QBit(22)) then
        evt.SetMessage("你找到了布拉森・暴风枪？我的艾邦斯特屠龙枪呢？你也找到了它吗？\n太棒了！\n感谢你替我作的这一切，我欠你很多！我愿意将你队伍中的所有骑士晋升为勇士，并且教导其馀的队员我所专精的技能。")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 16) then
                SetValue(ClassId, 19)
                AddValue(Experience, 50000)
                SetQBit(QBit(1540))
                RemoveItem(539)
            else
                AddValue(Experience, 35000)
                SetQBit(QBit(1541))
            end
        end
        ClearQBit(QBit(70)) -- 找到布拉森・暴风枪以及那柄黑木之矛。完成任务之后去绞刑峡谷找连恩・暴风枪，并且将黑木之矛交给查尔斯・吉科德。
        evt.SetNPCTopic(15, 2, 735) -- 查尔斯・科切特爵士 topic 2: 晋升骑士
        evt.SetNPCTopic(52, 2, 735) -- 查尔斯・科切特爵士 topic 2: 晋升骑士
        return
    end
    evt.SetMessage("这是怎么一回事？你和我的死敌联盟，现在又想要帮我的忙？\n不知道飞龙们对这件事情会有什么样的看法。管它的。反正你把艾邦斯特屠龙枪还给我，我就欠你一次。我愿意将你队伍中的任何骑士晋升为勇士，不过他们没有资格在我的麾下工作。我则会教导其它人我所会的技能。\n我不想要再看到你们！")
    for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 16) then
            SetValue(ClassId, 19)
            AddValue(Experience, 50000)
            SetQBit(QBit(1540))
            RemoveItem(539)
        else
            AddValue(Experience, 35000)
            SetQBit(QBit(1541))
        end
    end
    ClearQBit(QBit(70)) -- 找到布拉森・暴风枪以及那柄黑木之矛。完成任务之后去绞刑峡谷找连恩・暴风枪，并且将黑木之矛交给查尔斯・吉科德。
    evt.SetNPCTopic(15, 2, 735) -- 查尔斯・科切特爵士 topic 2: 晋升骑士
    evt.SetNPCTopic(52, 2, 735) -- 查尔斯・科切特爵士 topic 2: 晋升骑士
end)
RegisterCanShowTopic(58, function()
    evt._BeginCanShowTopic(58)
    local visible = true
    if IsQBitSet(QBit(73)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(59, nil, function()
    if IsQBitSet(QBit(435)) then
        if HasItem(539) then
            evt.SetMessage("你找到了我的父亲和艾邦斯特屠龙枪？我真是太感激你了！我们应该赶快把艾邦斯特屠龙枪带去给查尔斯・吉柯德。如果一切顺利的话，他会把我和你们队伍中的骑士都晋升为勇士！")
            evt.ForPlayer(Players.All)
            AddValue(Experience, 5000)
            evt.SetNPCTopic(49, 0, 611) -- 林恩・暴风枪 topic 0: 加入队员清单事件
            return
        elseif IsQBitSet(QBit(1541)) then
            evt.SetMessage("你找到了我的父亲和艾邦斯特屠龙枪？我真是太感激你了！我们应该赶快把艾邦斯特屠龙枪带去给查尔斯・吉柯德。如果一切顺利的话，他会把我和你们队伍中的骑士都晋升为勇士！")
            evt.ForPlayer(Players.All)
            AddValue(Experience, 5000)
            evt.SetNPCTopic(49, 0, 611) -- 林恩・暴风枪 topic 0: 加入队员清单事件
        else
            evt.SetMessage("你找了艾邦斯特屠龙枪？我的父亲呢？他到哪里去了？我以为你会两个都找到才回来！")
        end
        return
    elseif HasItem(539) then
        evt.SetMessage("你找了艾邦斯特屠龙枪？我的父亲呢？他到哪里去了？我以为你会两个都找到才回来！")
    else
        evt.SetMessage("你找到了我爸爸吗？还有艾邦斯特屠龙枪吗？我们必须要把这两样东西都带回到查尔斯身边！")
    end
end)

RegisterGlobalEvent(60, nil, function()
    if IsQBitSet(QBit(21)) then
        evt.SetMessage("你以为我会将一个和我的死敌查尔斯结盟的龙晋升吗？这实在太无知！太可耻了！你必须要对我证明你自己的能力！但是在证明你自己能力的过程中，你将会对自己的盟友造成极大的伤害！在此地的西南方，吉柯德替他所谓的“屠龙者”创建了一个营地。这个营地是由杰瑞克・惠索朋，吉柯德的副官所带领的。摧毁那座营地！替我杀死该区所有听命于吉柯德的家伙。带着惠索朋家传屠龙神剑回到我身边。")
        SetQBit(QBit(74)) -- 杀光所有的屠龙者，并且将惠索朋之剑交给绞刑峡谷的达夫克劳・红斧。
        evt.SetNPCTopic(17, 1, 61) -- 达夫克劳・红斧 topic 1: 屠龙者
        evt.SetNPCTopic(17, 1, 61) -- 达夫克劳・红斧 topic 1: 屠龙者
        return
    elseif IsQBitSet(QBit(22)) then
        evt.SetMessage("要晋升到神龙的阶级，龙必须要能够证明自己足以对付极多的敌人。他必须要面对查尔斯・吉柯德派来攻击我们的所有攻击者。在此地的西南方，吉柯德替他所谓的“屠龙者”创建了一个营地。这个营地是由杰瑞克・惠索朋――吉柯德的副官所带领的。摧毁那座营地！替我杀死该区所有听命于吉柯德的家伙。当你带着惠索朋家传屠龙神剑回到我身边的时候，你就证明了自己的能力。")
        SetQBit(QBit(74)) -- 杀光所有的屠龙者，并且将惠索朋之剑交给绞刑峡谷的达夫克劳・红斧。
        evt.SetNPCTopic(17, 1, 61) -- 达夫克劳・红斧 topic 1: 屠龙者
        evt.SetNPCTopic(53, 1, 61) -- 达夫克劳・红斧 topic 1: 屠龙者
        return
    else
        evt.SetMessage("要晋升到神龙的阶级，龙必须要能够证明自己足以对付极多的敌人。他必须要面对查尔斯・吉柯德派来攻击我们的所有攻击者。在此地的西南方，吉柯德替他所谓的“屠龙者”创建了一个营地。这个营地是由杰瑞克・惠索朋――吉柯德的副官所带领的。摧毁那座营地！替我杀死该区所有听命于吉柯德的家伙。当你带着惠索朋家传屠龙神剑回到我身边的时候，你就证明了自己的能力。")
        SetQBit(QBit(74)) -- 杀光所有的屠龙者，并且将惠索朋之剑交给绞刑峡谷的达夫克劳・红斧。
        evt.SetNPCTopic(17, 1, 61) -- 达夫克劳・红斧 topic 1: 屠龙者
        evt.SetNPCTopic(53, 1, 61) -- 达夫克劳・红斧 topic 1: 屠龙者
        return
    end
end)

RegisterGlobalEvent(61, nil, function()
    if IsQBitSet(QBit(21)) then
        return
    end
    if not IsQBitSet(QBit(22)) then
        evt.SetMessage("那个该死的骑士查尔斯・吉柯德正在此地西南方的营地聚集最强的屠龙战士。他一定准备要对龙穴展开最猛烈的攻势了！")
        return
    end
    evt.SetMessage("你杀死了所有的“屠龙者”吗？惠索朋屠龙神剑在哪里？")
end)
RegisterCanShowTopic(61, function()
    evt._BeginCanShowTopic(61)
    local visible = true
    if IsQBitSet(QBit(75)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(62, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(540) then
        evt.SetMessage("你已经杀死了所有的屠龙者！但是惠索朋屠龙剑呢？赶快带过来给我！")
        return
    end
    if IsQBitSet(QBit(22)) then
        evt.SetMessage("你把惠索朋的屠龙神剑带回来给我了！你的确值得我对你的看重！你队伍中的龙将会被晋升为神龙！我将会教导你队伍中的其它人，以便回报他们的努力！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 10) then
                SetValue(ClassId, 11)
                AddValue(Experience, 35000)
                SetQBit(QBit(1543))
                RemoveItem(540)
            else
                AddValue(Experience, 25000)
                SetQBit(QBit(1544))
            end
        end
        evt.ForPlayer(Players.All)
        ClearQBit(QBit(74)) -- 杀光所有的屠龙者，并且将惠索朋之剑交给绞刑峡谷的达夫克劳・红斧。
        evt.SetNPCTopic(17, 2, 736) -- 达夫克劳・红斧 topic 2: 晋升飞龙
        evt.SetNPCTopic(53, 2, 736) -- 达夫克劳・红斧 topic 2: 晋升飞龙
        return
    elseif IsQBitSet(QBit(21)) then
        evt.SetMessage("你把惠索朋屠龙剑带了回来！难道你的背叛和出卖还不够吗？难道你没有任何的忠诚吗？我会把你队伍中的龙晋升为神龙，但是他们没有资格在我旗下飞翔！你们这群叛徒则可以从我这边学到他们所可以学得的技巧！快走吧！如果你们下次胆敢再出现，我就会把你给吃掉！")
    else
        evt.SetMessage("你把惠索朋的屠龙神剑带回来给我了！你的确值得我对你的看重！你队伍中的龙将会被晋升为神龙！我将会教导你队伍中的其它人，以便回报他们的努力！")
    end
for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
    evt.ForPlayer(player)
    if IsAtLeast(ClassId, 10) then
        SetValue(ClassId, 11)
        AddValue(Experience, 35000)
        SetQBit(QBit(1543))
        RemoveItem(540)
    else
        AddValue(Experience, 25000)
        SetQBit(QBit(1544))
    end
end
evt.ForPlayer(Players.All)
ClearQBit(QBit(74)) -- 杀光所有的屠龙者，并且将惠索朋之剑交给绞刑峡谷的达夫克劳・红斧。
evt.SetNPCTopic(17, 2, 736) -- 达夫克劳・红斧 topic 2: 晋升飞龙
evt.SetNPCTopic(53, 2, 736) -- 达夫克劳・红斧 topic 2: 晋升飞龙
return
end)
RegisterCanShowTopic(62, function()
    evt._BeginCanShowTopic(62)
    local visible = true
    if IsQBitSet(QBit(75)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(63, nil, function()
    evt.SetMessage("嗯嗯……如果卢德林这个奸商都开始关切他的财富之外的事情，事态一定变得非常严重……我也必须承认，空气中也似乎有着末日即将到来的味道。\n如果在一般的状况下，我很愿意加入这个联盟，只为了维持我和卢德林之间的良好关系。很遗憾的，我目前手上的资源都被困住了，没有办法抽出多馀的资源来协助他处理这个所谓的联盟。\n或者我们可以彼此帮一把？如果你能够帮我个小忙，我可以考虑接受你的建议。")
    evt.SetNPCTopic(15, 0, 64) -- 查尔斯・科切特爵士 topic 0: 任务
end)
RegisterCanShowTopic(63, function()
    evt._BeginCanShowTopic(63)
    local visible = true
    if IsQBitSet(QBit(16)) then -- 和绞刑峡谷的猎龙人结盟
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(64, nil, function()
    if IsQBitSet(QBit(22)) then
        AddValue(History(8), 0)
        return
    elseif IsQBitSet(QBit(31)) then -- 从残破镇旁索格的要塞中找出龙蛋，并且带回去给绞刑峡谷的查尔斯・吉科德。
        evt.ForPlayer(Players.All)
        if not HasItem(605) then
            evt.SetMessage("你从索格在残破镇的要塞拿回了龙蛋吗？喔，别开口，我从你挫败的表情中看得出来你又失败了。\n我很坚持原先的提议。你不把龙蛋带来，我就不会加入你的联盟。")
            return
        end
        evt.ShowMovie("\"dragonhunters\"", true)
        evt.SetMessage("好的，就这么说定了。我会赶快做好安排，亲自前往渡鸦海滨的议会。说实话，我自己也想换换环境。我会让副手来接管我的工作。\n最后，我必须对你再一次说：干得好。")
        SetQBit(QBit(21))
        SetQBit(QBit(35))
        ClearQBit(QBit(16)) -- 和绞刑峡谷的猎龙人结盟
        ClearQBit(QBit(17)) -- 和绞刑峡谷的飞龙们结盟
        ClearQBit(QBit(31)) -- 从残破镇旁索格的要塞中找出龙蛋，并且带回去给绞刑峡谷的查尔斯・吉科德。
        ClearQBit(QBit(33)) -- 找到龙蛋，并且带回去给飞龙的领袖，达夫克劳・红斧。
        evt.SetNPCTopic(15, 0, 0) -- 查尔斯・科切特爵士 topic 0 cleared
        evt.SetNPCGreeting(15, 22) -- 查尔斯・科切特爵士 greeting 22
        evt.SetNPCTopic(17, 0, 0) -- 达夫克劳・红斧 topic 0 cleared
        evt.MoveNPC(255, 0) -- 巴萨拉斯 -> removed
        evt.ForPlayer(Players.All)
        AddValue(Experience, 20000)
        evt.ForPlayer(Players.All)
        RemoveItem(605)
        ClearQBit(QBit(204))
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 10000)
        evt.ForPlayer(Players.All)
        SetAward(Award(8))
        AddValue(History(8), 0)
    else
        evt.SetMessage("我的一名顾客，有个很有魅力的称号――食人妖“豺狼索格”，它背弃了我的信任。我给了他一个很有价值的物品，他也答应未来会付尾款，但是这尾款再也没有出现过。我派了一名信差去要求归还这个物品，龙蛋是个非常稀少的宝物！但这个信差竟然被杀害了。\n不用说，这件事情让我很困扰，我花费了很多的人力和金钱想要复仇。如果，你能够从索格在残破镇的要塞中替我找回龙蛋，我将会很高兴加入你的联盟。")
        SetQBit(QBit(31)) -- 从残破镇旁索格的要塞中找出龙蛋，并且带回去给绞刑峡谷的查尔斯・吉科德。
    end
end)

RegisterGlobalEvent(65, nil, function()
    evt.SetMessage("你想要我的同胞加入你的联盟吗？我怎么可能拒绝你？你不只让我们逃出了死亡的命运，联盟所对抗的灾难还让我们受到了重大的损失！\n我们都听从你的命令。我自己将会全速赶到渡鸦海滨，加入联盟议会的行列中。")
    evt.ForPlayer(Players.All)
    SetAward(Award(9))
    AddValue(Experience, 20000)
    SetQBit(QBit(23))
    ClearQBit(QBit(18)) -- 和残破镇的牛头人结盟
    ClearQBit(QBit(30)) -- 救出被困在残破镇的巢穴中的牛头人。
    AddValue(History(11), 0)
    evt.SetNPCTopic(13, 0, 0) -- 马苏尔 topic 0 cleared
    evt.SetNPCTopic(57, 0, 613) -- 坦尼斯 topic 0: 加入队员清单事件
    evt.SetNPCTopic(57, 1, 0) -- 坦尼斯 topic 1 cleared
    evt.SetNPCTopic(57, 2, 0) -- 坦尼斯 topic 2 cleared
end)

RegisterGlobalEvent(66, nil, function()
    evt.SetMessage("那实在恐怖极了！我当时正在此地北边的主迷宫中站岗。和我人一样高的巨浪突然之间涌进隧道之中。我勉强冲到这个高地，我花了很多时间等待其它人，但他们一直没有出现。恐怕我的同胞有很多人已经去世，或者是还被困在巢穴中。")
    evt.SetNPCTopic(57, 0, 67) -- 坦尼斯 topic 0: 任务
end)

RegisterGlobalEvent(67, nil, function()
    if not IsQBitSet(QBit(30)) then -- 救出被困在残破镇的巢穴中的牛头人。
        evt.SetMessage("巴尔萨煞巢穴拥有很多不同的高度，有其它的洞穴和这个洞穴一样高，所以可能有很多其它人都活了下来。\n有关于这次的事件，我想了很久。虽然有很多隧道都已经淹入水中，但是你还是可以利用门和通气管道当做排水的信道。事实上，整个巢穴中的积水可以通过打开底层的逃生管道而把水排干。救救我的同胞！你将会赢得他们永恒的敬意！")
        SetQBit(QBit(30)) -- 救出被困在残破镇的巢穴中的牛头人。
        return
    end
    evt.SetMessage("我可以感觉到。巢穴中还有活下来的人。只要你能够搞清楚如何把水排出去，你就可以救出他们！求求你们，救救我的同胞！")
end)

RegisterGlobalEvent(68, nil, function()
    evt.SetMessage("巴尔萨煞是我族中历史上最伟大的领袖，他带领着我们和像是病毒一样从地面钻出，并且四处扩散的黑暗矮人搏斗。这场战斗并不顺利。虽然巴尔萨煞和一些战士逃了出来，但是巴尔萨煞之斧（也是他的地位象征）以及许多战士都一起在这场战争中失踪了。")
end)

RegisterGlobalEvent(69, nil, function()
    evt.SetMessage("只有我们目前的领袖马苏尔可以判断一个人到底值不值得获得牛头领主的称号。其中一个获得他青睐的方法是找到他父亲的斧头，也就是遗落在黑暗矮人矿坑之底的巴尔萨煞之斧。只要你出发去完成这个任务，你的未来就光明可期。但是你必须要确认这的确是巴尔萨煞之斧。把你找到的斧头带去给达德洛斯，也就是阿尔瓦商队中的一名牛头人。他就在匕伤群岛上。他将可以判断你所找到的斧头是否货真价实。")
    SetQBit(QBit(76)) -- 找到位于黑暗矮人矿坑中的巴尔萨煞之斧。然后请达德洛斯认证那柄斧头是真货，接着再把这柄斧头带回去给牛头人首领的继承人泰沙拉。
    evt.SetNPCTopic(58, 0, 71) -- 泰沙拉 topic 0: 任务
end)

RegisterGlobalEvent(70, nil, function()
    evt.SetMessage("这些小家伙可能和土元素合作或是听从他们的命令。没有人知道确实到底是什么状况。他们在地底挖掘各种各样的隧道，寻找财富、食物和奴隶。这些掠食者经过的地方可说是无一幸存。")
end)

RegisterGlobalEvent(71, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(541) then
        evt.SetMessage("巴尔萨煞之斧在哪？你浪费了我的时间！找到斧头，去找达德洛斯，然后再来找我！")
        return
    end
    if not HasItem(732) then
        evt.SetMessage("你找到了巴尔萨煞之斧！你把这个东西拿去给达德洛斯看过了吗？没有他的认证，我们没有办法进行净化之仪式！赶快找到他，将这柄斧头给他认证，并且回到这个地方来。")
        return
    end
    evt.SetMessage("你找到了巴尔萨煞之斧！你拿给达德洛斯看过了吗？啊，你手头有达德洛斯的认证！净化之仪式马上就要开始了！你已经证明了自己的能力，现在也成为了我们之中的一份子。和你们一起旅行的牛头人现在获得了牛头领主的称号。你队伍中的其它人将可以从我这边学到许多有用的技能。")
    evt.ForPlayer(Players.Member0)
    if IsAtLeast(ClassId, 20) then
        goto step_18
    end
    AddValue(Experience, 25000)
    SetAward(Award(29))
    goto step_23
    ::step_18::
    SetValue(ClassId, 21)
    AddValue(Experience, 35000)
    SetQBit(QBit(1545))
    RemoveItem(541)
    RemoveItem(732)
    ::step_23::
    evt.ForPlayer(Players.Member1)
    if IsAtLeast(ClassId, 20) then
        goto step_28
    end
    AddValue(Experience, 25000)
    SetAward(Award(29))
    goto step_33
    ::step_28::
    SetValue(ClassId, 21)
    AddValue(Experience, 35000)
    SetQBit(QBit(1545))
    RemoveItem(541)
    RemoveItem(732)
    ::step_33::
    evt.ForPlayer(Players.Member2)
    if IsAtLeast(ClassId, 20) then
        goto step_38
    end
    AddValue(Experience, 25000)
    SetAward(Award(29))
    goto step_43
    ::step_38::
    SetValue(ClassId, 21)
    AddValue(Experience, 35000)
    SetQBit(QBit(1545))
    RemoveItem(541)
    RemoveItem(732)
    ::step_43::
    evt.ForPlayer(Players.Member3)
    if IsAtLeast(ClassId, 20) then
        goto step_48
    end
    AddValue(Experience, 25000)
    SetAward(Award(29))
    goto step_53
    ::step_48::
    SetValue(ClassId, 21)
    AddValue(Experience, 35000)
    SetQBit(QBit(1545))
    RemoveItem(541)
    RemoveItem(732)
    ::step_53::
    evt.ForPlayer(Players.Member4)
    if IsAtLeast(ClassId, 20) then
        goto step_58
    end
    AddValue(Experience, 25000)
    SetAward(Award(29))
    goto step_64
    ::step_58::
    SetValue(ClassId, 21)
    AddValue(Experience, 35000)
    SetQBit(QBit(1545))
    RemoveItem(541)
    RemoveItem(732)
    evt.ForPlayer(Players.All)
    ::step_64::
    ClearQBit(QBit(76)) -- 找到位于黑暗矮人矿坑中的巴尔萨煞之斧。然后请达德洛斯认证那柄斧头是真货，接着再把这柄斧头带回去给牛头人首领的继承人泰沙拉。
    SetQBit(QBit(87))
    RemoveItem(541)
    RemoveItem(732)
    evt.SetNPCTopic(58, 0, 740) -- 泰沙拉 topic 0: 晋升牛头人
    do return end
end)
RegisterCanShowTopic(71, function()
    evt._BeginCanShowTopic(71)
    local visible = true
    if HasItem(732) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(72, nil, function()
    if not IsQBitSet(QBit(76)) then -- 找到位于黑暗矮人矿坑中的巴尔萨煞之斧。然后请达德洛斯认证那柄斧头是真货，接着再把这柄斧头带回去给牛头人首领的继承人泰沙拉。
        evt.SetMessage("在巴尔萨煞大王底下服务是我的荣幸，他是我族中历史上最强悍的领导者。很不幸地，我的忠诚目前已经献给了阿尔瓦的商人，不然也许我当年可以加入巴尔萨煞大人失败的那场战争。也许我的斧头和我的技巧可以救他一命，谁知道呢？")
        return
    end
    evt.SetNPCTopic(2, 3, 73) -- 达德洛斯 topic 3: 巴尔萨煞之斧
end)

RegisterGlobalEvent(73, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(541) then
        evt.SetMessage("如果我看到了巴尔萨煞之斧，我当然认得出来！你身上有带吗？如果你找到了那柄斧头，带它过来找来，让我证明这的确是属于我的前任君主巴尔萨煞的斧头。")
        return
    end
    evt.SetMessage("如果我看到了巴尔萨煞之斧，我当然认得出来！你身上有带吗？这的确就是那柄斧头！你一定要赶快带回去进行净化之仪式，好让这柄斧头能够继承给巴尔萨煞的儿子马苏尔。把这封信一起带回去，上面有我个人专属的封缄，证明这的确是巴尔萨煞之斧！")
    evt.ForPlayer(Players.Member0)
    AddValue(InventoryItem(732), 732)
    evt.SetNPCTopic(2, 3, 75) -- 达德洛斯 topic 3: 快点！
end)
RegisterCanShowTopic(73, function()
    evt._BeginCanShowTopic(73)
    local visible = true
    if HasItem(541) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(74, nil, function()
    evt.SetMessage("多谢你把巴尔萨煞之斧拿过来还给我！当我们完成了净化之仪式后，我们会把这柄斧头拿去给马苏尔。这将会被改名为马苏尔之斧，让他成为正直、聪敏的领袖。")
end)

RegisterGlobalEvent(75, nil, function()
    if not IsQBitSet(QBit(87)) then
        evt.SetMessage("你找到了巴尔萨煞之斧，我也认证了！赶快回去找泰沙拉，好让净化之仪式赶快开始！")
        return
    end
    evt.SetMessage("啊，你已经带着我对巴尔萨煞之斧的认证回去给泰沙拉了！净化之仪式马上就会开始了。很快的，马苏尔大人就会继承父亲的斧头！我们牛头人将会重新获得原先的荣耀！")
end)

RegisterGlobalEvent(76, nil, function()
    evt.ForPlayer(Players.All)
    evt.SetMessage("在贾丹姆大陆的众多预言中，我唯一没有参考过的是太预言。那座神庙是由塔西厄斯・曙光所建造的，他是许多年前从埃拉西亚赶到这边来，想要找寻这些预言。很不幸地，他没有完成这项任务。我们推测，这份预言中应该会有阻止贾丹姆大陆末日降临的解决之道。")
end)
RegisterCanShowTopic(76, function()
    evt._BeginCanShowTopic(76)
    local visible = true
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(1546)) then
        visible = true
        return visible
    else
        if HasAward(Award(31)) then
            visible = true
            return visible
        else
            visible = false
            return visible
        end
    end
end)

RegisterGlobalEvent(77, nil, function()
    evt.ForPlayer(Players.All)
    evt.SetMessage("我知道你们可以在羽蛇之巢穴中找到那份预言。但是，我根本不知道这到底是什么意思，所以这些线索对我来说根本没有用。")
end)
RegisterCanShowTopic(77, function()
    evt._BeginCanShowTopic(77)
    local visible = true
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(1546)) then
        visible = false
        return visible
    else
        if HasAward(Award(31)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(78, nil, function()
    evt.SetMessage("你想要让我晋升与你们一起旅行的牧师吗？我可以让你们晋升，但是这些日子我不太相信陌生人。如果你能够替我作些什么，譬如像是替我找回太阳预言，也许我可以让你们获得应有的晋升。")
    SetQBit(QBit(78)) -- 在废弃神庙中找到太阳预言，并且带回去给史蒂芬。
    evt.SetNPCTopic(59, 2, 81) -- 史蒂芬 topic 2: 任务
end)

RegisterGlobalEvent(79, nil, function()
    evt.SetMessage("羽蛇之巢穴？这可能指着就是那些有毒的羽翼之蛇，但是我们已经有好几个世纪没有看过他们了。")
end)

RegisterGlobalEvent(80, nil, function()
    evt.ForPlayer(Players.All)
    evt.SetMessage("我们从来没有找到过太阳预言，它们甚至可能根本不存在。预言应该是由我们最伟大的先知所撰写的，如果你找到了预言，请你将它归还给我们！")
end)
RegisterCanShowTopic(80, function()
    evt._BeginCanShowTopic(80)
    local visible = true
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(1546)) then
        visible = false
        return visible
    else
        if HasAward(Award(31)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(81, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(626) then
        evt.SetMessage("你找到了羽蛇之巢穴和太阳预言了吗？别浪费我的时间！世界都快要毁灭了，你还在这边跟我闲聊！在你找到了预言，并且将它带回到太阳神庙去，到时再来找我。")
        return
    end
    evt.SetMessage("你已经找到了太阳预言吗？愿光明永远照耀着你，愿预言指引着你的脚步。只要有了这些线索，我们就可以搞清楚贾丹姆大陆到底面对什么样的命运！")
    for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 4) then
            SetValue(ClassId, 6)
            AddValue(Experience, 35000)
            SetQBit(QBit(1546))
            RemoveItem(626)
        else
            AddValue(Experience, 25000)
            SetAward(Award(31))
        end
    end
    ClearQBit(QBit(78)) -- 在废弃神庙中找到太阳预言，并且带回去给史蒂芬。
    evt.SetNPCTopic(59, 2, 737) -- 史蒂芬 topic 2: 晋升牧师
end)
RegisterCanShowTopic(81, function()
    evt._BeginCanShowTopic(81)
    local visible = true
    if HasItem(626) then
        visible = true
        evt.ForPlayer(Players.All)
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(82, nil, function()
    evt.SetMessage("可布是吸血鬼一族中最厉害的人物。在一百年前，他出发去寻找我族所不能接受的一样东西――“宽恕”。不知道怎么搞的，可布开始体验到吸食人血所带来的罪恶感。或许他是对吸血这个动作感到罪恶感。他没有办法再靠着杀害其它人而生存下去。我族中有许多人和他起了争执。他决定要找个地方仔细思索自己存在的意义。因此，他利用残破镇附近的奴隶建造了可布墓窖。从那之后，我们就再也没有听过任何可布的消息了。")
end)

RegisterGlobalEvent(83, nil, function()
    evt.SetMessage("在这个混乱的年代中，我们需要所有长老的智能。请你找回我们的可布，如果他过世了，请找回他的尸骸。如果他真的过世了，你必须也一并带着他的石棺回来。我们将会试着让他复活，并且寻求他的智能指引。")
    SetQBit(QBit(80)) -- 找到可布的石棺和尸骸，并且将这些东西带回去给阴影塔地区的拉席安。
    evt.SetNPCTopic(62, 1, 90) -- 拉席安 topic 1: 可布的再临
end)

RegisterGlobalEvent(84, nil, function()
    evt.SetMessage("可布？他是我族中最伟大的人，但他似乎永远都有心事。我们之中还有人记得他离开之前的状况，在我看来，他真的彷佛受到什么事情的困扰。")
end)

RegisterGlobalEvent(85, nil, function()
    evt.SetMessage("在他和死灵法师达成把我们安置在阴影塔附近的协议之后，可布就离开了。我们协助死灵法师进行任何需要的研究，并且协助他们防卫整个公会。这让我们可以毫不受阻碍地猎食此地的生物。")
end)

RegisterGlobalEvent(86, nil, function()
    evt.SetMessage("啊，你想要达到黑暗类魔法的最高境界。你们队伍中的死灵法师想要成为巫妖。很好，我可以替你执行这项转换的工作，但是你必须要替我完成一项任务。我在找寻凯尔的失落之书，里面包含了凯尔一切的黑暗类魔法秘密，而在大水淹没他的高塔之后，这些魔法的秘密也跟着一起被埋没起来。匕伤群岛的蜥蜴人在大水把凯尔的知识封印起来之后，他们甚至还举行了庆典庆祝。在匕伤群岛的火山爆发之后，我相信你可以在那附近的区域找到他的高塔。把凯尔之书从图书馆中找出来，并且带回来给我！另外一件事情，如果你们想要变成巫妖，每一名死灵法师会需要一个巫妖之瓶。疯狂的死灵法师冉索拉拥有很多的巫妖之瓶，也许她愿意卖给你一些！如果不幸的话，也许你必须要从她手中强夺走这些巫妖之瓶。")
    SetQBit(QBit(82)) -- 找到凯尔的失落之书，并且带回去给阴影塔的维崔那斯。
    evt.SetNPCTopic(61, 0, 89) -- 维崔那斯・塔尔希尔 topic 0: 晋升为巫妖
end)

RegisterGlobalEvent(87, nil, function()
    evt.ForPlayer(Players.All)
    evt.SetMessage("死灵法师公会在讨论到放弃巫妖之瓶的时候总是非常的保守。你最好去找冉索拉谈谈，也许从她手中获得瓶子会比较容易。")
end)
RegisterCanShowTopic(87, function()
    evt._BeginCanShowTopic(87)
    local visible = true
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(1548)) then
        visible = true
        return visible
    else
        if HasAward(Award(35)) then
            visible = true
            return visible
        else
            visible = false
            return visible
        end
    end
end)

RegisterGlobalEvent(88, nil, function()
    evt.ForPlayer(Players.All)
    evt.SetMessage("凯尔的失落之书据说拥有黑暗类魔法最高深的秘密。也许最好永远没有人知道那本书在哪里！")
end)
RegisterCanShowTopic(88, function()
    evt._BeginCanShowTopic(88)
    local visible = true
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(1548)) then
        visible = true
        return visible
    else
        if HasAward(Award(35)) then
            visible = true
            return visible
        else
            visible = false
            return visible
        end
    end
end)

RegisterGlobalEvent(89, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(611) then
        evt.SetMessage("你没有找到凯尔的失落之书！如果你不能帮我，我就不会帮你！请你带着凯尔的失落之书，且每个想转化为巫妖的死灵法师都带上一个巫妖之瓶，再回来见我！")
        return
    end
    for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 44) then
            if not HasItem(628) then
                evt.SetMessage("你找到了凯尔的失落之书，但是你没有转换仪式所需要的巫妖之瓶！当你替队伍中的每个死灵法师都找到一个巫妖之瓶的时候再回来找我！")
                return
            end
        end
    end
    evt.SetMessage("你已经把转换仪式所需要的所有道具都带回来了！那就这样吧！你队伍中所有的死灵法师都会变成巫妖！愿黑暗之力从此永远在他们的体内流动！你们其它人将可以从我这边学到相关的技能，算是我的报答！开始吧！\n在我们的工作完成之后，我的好友拉席安将会负责诸位未来的晋升。")
    for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 44) then
            SetValue(ClassId, 45)
            AddValue(Experience, 35000)
            SetQBit(QBit(1548))
            RemoveItem(628)
        else
            AddValue(Experience, 25000)
            SetAward(Award(35))
        end
    end
    evt.ForPlayer(Players.All)
    RemoveItem(611)
    ClearQBit(QBit(82)) -- 找到凯尔的失落之书，并且带回去给阴影塔的维崔那斯。
    evt.SetNPCTopic(61, 0, 742) -- 维崔那斯・塔尔希尔 topic 0: 和你一起旅行！
end)

RegisterGlobalEvent(90, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(627) then
        if not HasItem(612) then
            evt.SetMessage("你把可布的尸骸带回来了，但是他的石棺呢？我们没有办法不靠石棺而让他复活！在你找到他的石棺和尸骸之后再回来找我！")
            return
        end
        evt.SetMessage("你们已经把可布的石棺和他神圣的遗骸带回来给我们了。我们将会寻求他的智能！在你们队伍中的吸血鬼将会被晋升为血族尊皇，其它的人将可以从我这边学习相关的技能，当做我们的回报。")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 40) then
                SetValue(ClassId, 41)
                AddValue(Experience, 35000)
                SetQBit(QBit(1547))
                RemoveItem(627)
                RemoveItem(612)
            else
                AddValue(Experience, 25000)
                SetAward(Award(33))
            end
        end
        ClearQBit(QBit(80)) -- 找到可布的石棺和尸骸，并且将这些东西带回去给阴影塔地区的拉席安。
        evt.ForPlayer(Players.All)
        RemoveItem(627)
        RemoveItem(612)
        evt.SetNPCTopic(62, 1, 739) -- 拉席安 topic 1: 晋升吸血鬼
        return
    elseif HasItem(612) then
        evt.SetMessage("你把可布的石棺带回来了，但是他的尸骸呢？我们没有办法没有尸骸而让他复活！在你找到他的石棺和尸骸之后再回来找我！")
    else
        evt.SetMessage("我们必需要和可布讨论才行！你必须要将它的尸骸和石棺带过来，在你完成这个任务之前不要回来找我们！")
    end
end)
RegisterCanShowTopic(90, function()
    evt._BeginCanShowTopic(90)
    local visible = true
    if IsQBitSet(QBit(80)) then -- 找到可布的石棺和尸骸，并且将这些东西带回去给阴影塔地区的拉席安。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(91, nil, function()
    evt.SetMessage("多谢你替我们找回了太阳预言。愿太阳永远照耀你们，提供你们冒险旅途中所需要的庇护！")
end)

RegisterGlobalEvent(92, nil, function()
    evt.SetMessage("你把可布带回到我们的身边，我们永远感激你！现在请你先离开，我们必需要和长老们开会！")
end)

RegisterGlobalEvent(93, nil, function()
    evt.SetMessage("我们必需要和可布讨论才行！你必须要将它的尸骸和石棺带过来，在你完成这个任务之前不要回来找我们！")
end)

RegisterGlobalEvent(94, nil, function()
    evt.SetMessage("巴斯沈・卢德林一直是我和公会的好友。很遗憾的，我这次必须要拒绝他的要求。即使是现在，我的公会也正努力地奋战，担心一场失败会危及我们的生存。因为，你也知道，太阳神庙已经对我们展开了一场圣战。我大部分的同志不是正在战场上作战，就是正在唤醒僵尸来协助这场战争。\n我希望我不用说得这么明白，但是那个该死的神殿目前占了上风，如果我们能够反败为胜就好了。")
    evt.SetNPCTopic(9, 0, 95) -- 山德罗 topic 0: 任务
end)
RegisterCanShowTopic(94, function()
    evt._BeginCanShowTopic(94)
    local visible = true
    if IsQBitSet(QBit(14)) then -- 和阴影塔区域的死灵法师公会结盟
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(95, nil, function()
    if not IsQBitSet(QBit(28)) then -- 将龙葵灯炉带给死灵法师公会的领导者山德罗。龙葵灯炉就在太阳神庙之中。
        evt.SetMessage("只要我们能够把龙葵灯炉夺回来，阴影塔的防卫就不会再有任何的问题了。我们可以把这场战争带到太阳神庙的大门前。我们将可以将他们通通消灭！\n由于他们知道这样东西的重要性，牧师们将这样东西放到他们神殿的最深处。戴森・李蓝认为他可以进入这个内殿。你只需要把他带到神殿去，找回那个炉子，带回那个炉子给我。你想要我加入你们的联盟吗？你只要能够替我完成这个任务，我就欠你一次。\n如果你们对于这个龙葵灯炉还有任何的问题，请去问谭特。是他创造了这个宝物。")
        SetQBit(QBit(28)) -- 将龙葵灯炉带给死灵法师公会的领导者山德罗。龙葵灯炉就在太阳神庙之中。
        if IsQBitSet(QBit(89)) or IsQBitSet(QBit(90)) then
            evt.SetNPCTopic(11, 3, 634) -- 戴森・李蓝 topic 3: 加入队员清单事件
        end
        return
    end
    evt.SetMessage("在我们公会的安全获得保障之前，我不会加入你的联盟。请你将太阳神庙中的龙葵灯炉从低语森林带过来给我。在那之后，我们再来讨论有关联盟的这件事情。")
end)

RegisterGlobalEvent(96, nil, function()
    evt.SetMessage("在我们的冲突刚开始的时候，太阳神庙派了一名信徒来渗透我们的阵营。真是太愚笨了，他们竟然认为自己可以欺骗一群黑魔法师！\n要揭穿这个戴森・李蓝的身份实在太简单了。从那之后，我们就让他成了出卖自己同伴的人。至少表面上是这样。说实话，我并不相信这个家伙的忠诚。不过，他依旧有他的用处。至少在这点还成立的时候，我们会让他继续活下去。")
end)
RegisterCanShowTopic(96, function()
    evt._BeginCanShowTopic(96)
    local visible = true
    if HasPlayer(34) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(97, nil, function()
    evt.SetMessage("怎么可能有任何人愿意为了力量而忍受黑暗之路的恐怖？但是，这里竟然有这么样的一群人！喔，他们竟然还胆敢叫自己“知识的追求者”，这些家伙根本是种低贱的传染病！寄生虫！\n只因为我对于自己的恐惧，这个该死的死灵法师公会才能够认为自己是我的主人。")
    SetQBit(QBit(89))
    if not IsQBitSet(QBit(90)) then return end
    if IsQBitSet(QBit(28)) then -- 将龙葵灯炉带给死灵法师公会的领导者山德罗。龙葵灯炉就在太阳神庙之中。
        evt.SetNPCTopic(11, 3, 634) -- 戴森・李蓝 topic 3: 加入队员清单事件
        return
    elseif IsQBitSet(QBit(26)) then -- 找到阴影塔的死灵法师公会中的骷髅转换器，摧毁它之后回去找奥斯卡・提尔报到。
        evt.SetNPCTopic(11, 3, 634) -- 戴森・李蓝 topic 3: 加入队员清单事件
    else
        evt.SetNPCTopic(11, 3, 100) -- 戴森・李蓝 topic 3: 加入
    end
end)

RegisterGlobalEvent(98, nil, function()
    evt.SetMessage("当我还年轻的时候，我满脑子想的都是如何加入光之教派的事情。我想要成为善良之道无私、奉献的仆人。当我到了适当的年纪之后，我的心中充满了洁净的火焰，义无反顾地踏进了太阳神庙。\n我真是蠢到家了。如果世界上还有任何的善良和正义，我恐怕早就错失了他们。太阳神庙的圣殿中根本没有所谓的善良！这些躲在善良大旗底下的走狗，以善良之名干尽一切肮脏的罪恶、自私、独断。如果不是因为他们的行为太过肮脏，我可能还会觉得这样的状况非常讽刺。")
    SetQBit(QBit(90))
    if not IsQBitSet(QBit(89)) then return end
    if IsQBitSet(QBit(28)) then -- 将龙葵灯炉带给死灵法师公会的领导者山德罗。龙葵灯炉就在太阳神庙之中。
        evt.SetNPCTopic(11, 3, 634) -- 戴森・李蓝 topic 3: 加入队员清单事件
        return
    elseif IsQBitSet(QBit(26)) then -- 找到阴影塔的死灵法师公会中的骷髅转换器，摧毁它之后回去找奥斯卡・提尔报到。
        evt.SetNPCTopic(11, 3, 634) -- 戴森・李蓝 topic 3: 加入队员清单事件
    else
        evt.SetNPCTopic(11, 3, 100) -- 戴森・李蓝 topic 3: 加入
    end
end)

RegisterGlobalEvent(99, nil, function()
    evt.SetMessage("几个月之前，太阳神庙的大主教――奥斯卡・提尔秘密召见我。他派我去渗透死灵法师公会。“成为他们的一份子，”他说。“获取他们的信任。当你准备好给予他们致命一击的时候，把秘密告诉我们。”\n这是一个头脑简单的人想出的简单计划！喔，我的确照着他所说的去作了，尽可能地让自己沐浴在邪恶之中，让自己成为邪恶之人。但是，彷佛公会可以直视我的内心一般，我间谍的身份被揭穿了。他们威胁要杀死我，所以我现在听从他们的命令。")
end)

RegisterGlobalEvent(100, nil, function()
    evt.SetMessage("加入你？这个点子真有趣。但是你能够给我什么呢？在我经历了这一切之后，我心中只剩下了复仇的火焰。我愿意和你一起走，但是我不愿意轻易浪费自己的力气。给我一个机会，让我可以打击我的敌人，不管是该死的太阳神庙或是邪恶的死灵法师公会都好，我就愿意和你一起走！")
end)

RegisterGlobalEvent(101, nil, function()
    evt.SetMessage("现在，龙葵灯炉已经回来了，阴影塔已经开始在黑暗中统筹军队。谭特得要带领他的部队准备出发了。")
end)

RegisterGlobalEvent(102, nil, function()
    evt.SetMessage("元素的骚动的确让我们非常关切。为什么呢？你只要从我们的神殿往北走一小段距离，你就可以看到一个强烈到让人吃惊的漩涡。真可惜，我们目前手上有很紧迫的事情必须处理。\n死灵法师公会这群该死的寄生虫必须被清除！我们已经对阴影塔地区的邪恶展开了一场圣战。我们的全心全灵都投入了和山德罗以及他手下的战斗中。在这工作完成之前，我们无法加入你的联盟。")
    evt.SetNPCTopic(33, 0, 103) -- 奥斯卡・提尔 topic 0: 任务
end)
RegisterCanShowTopic(102, function()
    evt._BeginCanShowTopic(102)
    local visible = true
    if IsQBitSet(QBit(15)) then -- 和低语森林的太阳神庙结盟
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(103, nil, function()
    if IsQBitSet(QBit(27)) then
        evt.SetMessage("干得好！在摧毁了骷髅转换器之后，我相信我们更有把握可以在光明的照耀之下摧毁阴影塔地区的邪恶。死灵法师公会已经如风中残烛了。\n如同我之前同意的，太阳神庙现在已经加入对抗元素灾变的阵营。我自己将会前往渡鸦海滨加入议会。我会尽快安排好一切，赶快赶到渡鸦海滨去。")
        ClearQBit(QBit(26)) -- 找到阴影塔的死灵法师公会中的骷髅转换器，摧毁它之后回去找奥斯卡・提尔报到。
        ClearQBit(QBit(14)) -- 和阴影塔区域的死灵法师公会结盟
        ClearQBit(QBit(15)) -- 和低语森林的太阳神庙结盟
        ClearQBit(QBit(28)) -- 将龙葵灯炉带给死灵法师公会的领导者山德罗。龙葵灯炉就在太阳神庙之中。
        SetQBit(QBit(20))
        evt.SetNPCTopic(33, 0, 0) -- 奥斯卡・提尔 topic 0 cleared
        AddValue(History(9), 0)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 50000)
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 10000)
        evt.ForPlayer(Players.All)
        SetAward(Award(11))
        return
    elseif IsQBitSet(QBit(26)) then -- 找到阴影塔的死灵法师公会中的骷髅转换器，摧毁它之后回去找奥斯卡・提尔报到。
        evt.SetMessage("你来这边再度讨论有关联盟的问题？我已经告诉你该怎么做了。赶快去阴影塔地区寻找戴森・李蓝，协助他摧毁那个骷髅转换器！快点！")
    else
        evt.SetMessage("不过，如果我们占了上风，我们应该可以派出一些人力和物力协助你们。也许你愿意助我们一臂之力？\n在死灵法师公会内部，有个被称为“骷髅转换器”的装置。这可以将活生生的生物转换成骷髅，变成黑暗法师们的士兵。如果我们可以摧毁这个装置，我们很快地就可以在这场战争中占上风。\n我们在公会中安排了一个卧底间谍戴森・李蓝。去找到他，并且协助他摧毁这个制造骷髅的机器。你只要完成这个任务，我就会更为认真地考虑你的提议。")
        SetQBit(QBit(26)) -- 找到阴影塔的死灵法师公会中的骷髅转换器，摧毁它之后回去找奥斯卡・提尔报到。
    end
end)

RegisterGlobalEvent(104, nil, function()
    evt.SetMessage("难道因为你太过轻视预言，导致你忽视了自己在预言中的地位？时机紧迫，我们也必须采用非常手段。赶快统合所有的势力，让他们团结成强大的联盟。快去，除非你对眼前的毁灭视而不见！")
end)

RegisterGlobalEvent(105, nil, function()
    evt.SetMessage("你可以利用艾瑞安・韩特的船只来收集更多的情报。我派了一艘船去残破镇，另外一艘船去匕伤群岛。根据报告，这两个地区都出现了神秘的传送门。岛上的传送门就出现在主岛东南方的火山山坡上。残破镇的传送门就在一个大湖的中央。据说构成那座湖的水是从传送门之中源源流出的。")
end)

RegisterGlobalEvent(106, nil, function()
    evt.SetMessage("就在我们第一次聚会之后几个小时，有件最幸运的事情发生了。恩洛斯的艾恩法斯特王朝中的伟大智者萨索尔和我们联络了！\n他利用他强大的法力将自己的影像投射在这个房间中。他和罗兰德以及凯瑟琳・艾恩法斯特在大灾变发生的时候，他们正好在我们国度的外海。他们勉强躲过了接下来的大暴风，现在愿意前来渡鸦海滨协助联盟。但很不幸地，他们被雷格那海盗的舰队阻挡在外海上。我们必须要协助他们登陆。萨索尔声称他对于在此地发生的事情十分了解。我们需要他的指引！")
    evt.SetNPCTopic(40, 0, 107) -- 艾尔加・费尔蒙 topic 0: 任务
end)

RegisterGlobalEvent(107, nil, function()
    if IsQBitSet(QBit(37)) then
        evt.SetMessage("你弄沉雷格那舰队的完美表现已经获得了相当不错的回报。昨天早上，凯瑟琳和罗兰德・艾恩法斯特和他们的智者萨索尔一起抵达了此地。在我们拥有了他们的协助之后，我们的力量可说是大幅地增加。\n我必须承认，这次的危机中包含了我自己遭遇到的最黑暗的时刻。多谢你的努力，我相信最糟糕的状况已经过去了。我现在认为我们应该可以成功地逃脱末日的威胁。")
        ClearQBit(QBit(36)) -- 把雷格那的舰队弄沉，回到渡鸦海滨的议会报告。
        SetQBit(QBit(38))
        evt.SetNPCTopic(40, 0, 109) -- 艾尔加・费尔蒙 topic 0: 萨索尔
        evt.ForPlayer(Players.All)
        AddValue(Experience, 100000)
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 10000)
        evt.ForPlayer(Players.All)
        SetAward(Award(12))
        return
    elseif IsQBitSet(QBit(36)) then -- 把雷格那的舰队弄沉，回到渡鸦海滨的议会报告。
        evt.SetMessage("你一定要弄沉那些雷格那的舰队！艾恩法斯特家族一定要成功进入我们的港口！他们的智者萨索尔对于我们所面对的危机拥有我们所需要的知识！")
    else
        evt.SetMessage("我们的情报来源相信雷格那海军的舰队就躲在雷格那岛上的某个港口中。如果你可以将港口中的所有船只都弄沉，你将可以大幅破坏他们巡逻邻近海域的能力。很不幸地，我们自己没有足够强大的舰队可以强行登陆雷格那。\n布拉克许・单牙已经送了一个消息给我们，通知我们雷格那人已经在匕伤群岛的主岛上兴建了一个前哨站。他的哨兵们从来没有看见过任何的船只停靠该处，但是他们的补给却总是很充足。也许你们应该去那边好好调查，解开谜团。也许解答会让你找到前往雷格那的路？\n不管如何，雷格那的舰队都必须受到重创，艾恩法斯特王朝的船只才能够在渡鸦海滨停靠。")
        SetQBit(QBit(36)) -- 把雷格那的舰队弄沉，回到渡鸦海滨的议会报告。
        AddValue(History(12), 0)
    end
end)

RegisterGlobalEvent(108, nil, function()
    evt.SetMessage("雷格那人虽然老是夸耀自己的帝国和文明，但他们只不过是贾丹姆大陆上最大群的强盗集团。他们利用这次危机来扩张自己的海盗帝国，我一点也不赶到惊讶。让我最担心的是他们在匕伤群岛上的前哨站。我认为他们一定会利用该处当做攻击主大陆的基地。哼，那里甚至让他们可以直接攻击渡鸦海滨！")
end)

RegisterGlobalEvent(109, nil, function()
    evt.SetMessage("我只有和他见过一次面，但是我相信萨索尔对于元素界的一切状况有相当的认知。很明显地他在最近和艾恩法斯特王朝的敌人于埃拉西亚作战的时候，从元素界学到了很多事情。\n现在他就正在研究镇中央的那个奇异水晶。你可能可以在该处找到他，或者他会暂时居住在附近的房屋中。")
    evt.SetNPCTopic(40, 0, 110) -- 艾尔加・费尔蒙 topic 0: 任务
end)

RegisterGlobalEvent(110, nil, function()
    if not IsQBitSet(QBit(91)) then -- 和艾恩法斯特王朝的智者萨索尔请教有关渡鸦海滨水晶的问题。
        evt.SetMessage("我们这些议会的成员对于萨索尔拥有相当大的信心。他告诉我们他有个计划，要处理这一切的危机。如果说有任何人可以找到我们所面对问题的解答，那就一定是他了。\n如果你愿意进一步协助我们，请去帮助那名伟大的智者。询问他有关水晶的问题，看看你能够替他做些什么。")
        SetQBit(QBit(91)) -- 和艾恩法斯特王朝的智者萨索尔请教有关渡鸦海滨水晶的问题。
        evt.MoveNPC(19, 899) -- 萨索尔 -> 客栈
        evt.MoveNPC(64, 0) -- 德林・戴尔瓦 -> removed
        return
    end
    evt.SetMessage("我们希望萨索尔能够指引我们下一步该做什么。去找他，看看你能够帮上什么忙。")
end)

RegisterGlobalEvent(111, nil, function()
    evt.SetMessage("我们获得了恩洛斯皇室的协助带来了非常正面的发展。我本来很担心他们会像一般的皇室一样地骄傲自大，但是他们这对佳偶并不是这样的。他们一来就开始直接协助我们解决问题。由于他们是这次联盟的主要力量之一，你可以轻易地找到他们。我们已经让他们暂时居住在渡鸦海滨的房子中。")
end)

RegisterGlobalEvent(112, nil, function()
    evt.SetMessage("从萨索尔所告诉我们的事情看来，所有的元素界都已经陷入了危机中。但是，我依旧建议你在探索火元素界的时候要特别小心。根据铁沙漠所送来的报告，火元素界的居民特别地狂野和危险。")
end)

RegisterGlobalEvent(113, nil, function()
    evt.SetMessage("我对界间之地的所知都是从阿尔瓦商人的历史学者口中所得知的。如果毁灭者的基地在那边，你最好小心一点！据说该空间中充满了其它次元创造时所拥有的混沌力量。混沌的外形并不固定。不管你在那边看到什么东西，都不见得会是他真正的形状。该地会不断持续的变化。")
end)

RegisterGlobalEvent(114, nil, function()
    evt.SetMessage("阿尔瓦商人的历史学者所告诉我有关界间之地的事情的确很符合该地的描述。虽然我很确定元素之王的监狱是用来监禁他们的地方，但是我完全不确定他们的外形到底是什么样子。")
end)

RegisterGlobalEvent(115, nil, function()
    evt.SetMessage("阿尔瓦的商人公会欠你很大的人情。虽然这只是一点小意思，但是我们想要让你可以随时使用这个商人公会之家。请把这个小礼物当做我们对你英勇行为的一点回报。")
end)

RegisterGlobalEvent(116, nil, function()
    evt.SetMessage("我知道加入你的联盟是很重要的一件事情。但是我依旧怀念四处狩猎的日子！当我在这边处理许多许多的文档的时候，我不禁会想起同伴们目前在享受的乐趣。\n快点推动联盟的事物！我想要赶快脱离这一切！没有了狩猎的趣味，我的生命就变得非常无趣。")
end)

RegisterGlobalEvent(117, nil, function()
    evt.SetMessage("从雷格那海盗所运用的战术看起来，我想黑井・古伯可能有牵涉在里面。古伯是……我应该这么说吧，他是我的一个“朋友”。如果我有赌钱的习惯，我会压注在他率领匕伤群岛上的雷格那部队这件事情上。")
end)

RegisterGlobalEvent(118, nil, function()
    evt.SetMessage("我知道我的意见在议会中算是少数，但是说实话，我实在看不出来干嘛要找个江湖卖艺人来教导我们拯救世界？！危机的确是可以解决的，一切都有解决之道，只要你手中拥有够强的武器，没有不能够解决的问题。")
end)

RegisterGlobalEvent(119, nil, function()
    evt.SetMessage("啐！如果你问我，这个萨索尔所说的话根本是放屁！我认为我们应该直接面对元素界的攻击，我们应该筹组一个军队去打击他们。说实话，这些什么预言的鬼东西让我感到浑身不自在。这个议会根本受到艾恩法斯特王朝的巫师所操纵。我认为我们应该直捣元素界，让那些该死的入侵者尝尝我们的刀锋！")
end)

RegisterGlobalEvent(120, nil, function()
    evt.SetMessage("我告诉你，萨索尔只是派你出去抓瞎而已！“界间之地”，真是无稽之谈！最要命的是，如果这些疯狂的计划失败了，我们根本没有做好作战的准备。而且我认为这些计划注定会失败。照着预言办事，在军事战术上来说简直是胡扯蛋！")
end)

RegisterGlobalEvent(121, nil, function()
    evt.SetMessage("我对于这个叫做萨索尔的家伙的确有一些怀疑，但是他愿意承认自己错误的态度让我比较放心。对我来说，他目前所给的建议都是有效的建议。如果他告诉你去拯救元素之王，那么你就应该这样做。快走吧！祝你好运！")
end)

RegisterGlobalEvent(122, nil, function()
    evt.SetMessage("贾丹姆大陆的英雄，真高兴再度见到你们。你们拯救全世界的表现实在太好了。我非常感激你们，我相信其它的人也是一样。\n我很确定你现在应该拥有很多的工作机会。不过，如果你对猎龙有兴趣，请记得跟我说一声。也许这对你这种人来说不是什么大挑战，但是请记得有我的这个承诺！")
end)

RegisterGlobalEvent(123, nil, function()
    evt.SetMessage("小家伙，快点去料理你口中联盟的事情！我对于这块土地的关切由于没有洞穴和猎物，已经开始渐渐消退了。我现在不只必须睡在谷仓里面，这些家伙甚至连牛也不养。我还必须靠着吃鱼过活！啐！\n如果你知道最好不要惹我生气，那动作就给我快一点！")
end)

RegisterGlobalEvent(124, nil, function()
    evt.SetMessage("要前往雷格那岛并不简单。我的一名斥候回报，海上雷格那人的活动相当频繁。但是他也回报了目击雷格那人有可以在水面下潜航的船只。据说他们利用这艘船只补给匕伤群岛上的前哨站。也许你可以利用这艘船来抵达雷格那。这些海盗可能会因此无法发现你的行踪，或者是把你当做他们的一份子。")
end)

RegisterGlobalEvent(125, nil, function()
    evt.SetMessage("我知道这不是想要复仇的时候，但我愿意把我对敌人的了解跟你分享。牛头人的国王马苏尔提到，据说吉柯德在要塞里面放了一把被称为“蛇”的神剑。也许这柄剑可以协助联盟的工作？")
end)

RegisterGlobalEvent(126, nil, function()
    evt.SetMessage("我的飞龙巡逻队们已经找到了两个元素界的传送门。岛上的传送门就出现在主岛东南方的火山山坡上。残破镇的传送门就在一个大湖的中央。我不知道他们的确实位置，但是你都必须要跨越很多的水才能够抵达这两座传送门。")
end)

RegisterGlobalEvent(127, nil, function()
    evt.SetMessage("在你们抵达这里不久之前，一名埃拉西亚的飞龙来我的洞穴里面拜访我。他告诉我在埃拉西亚上出现了一种新的龙类，一种似乎是由水晶所构成的飞龙。我不知道为什么我要告诉你这件事情。但也许镇中央的那座巨大的水晶让我想起这件事情。")
end)

RegisterGlobalEvent(128, nil, function()
    evt.SetMessage("真有趣，毁灭者竟然会派你出去解决他们造成的危机。我想我并不会觉得惊讶。超凡力量的行为模式总是让人难以理解。")
end)

RegisterGlobalEvent(129, nil, function()
    evt.SetMessage("你替这块大地和我们龙类都作了非常好的服务。我们非常感激你，为了这样，我们容许你进入我们的洞穴中，不会将你当做猎物看待。")
end)

RegisterGlobalEvent(130, nil, function()
    evt.SetMessage("你知道我们在低语森林的神庙是贾丹姆大陆上的第一座吗？我们的任务是将光明带到世界上的每个角落，即使在这里也不例外。我们很惊讶看见死灵法师公会竟然比我们先到了。不过没关系，我们会料理他们的。\n你觉不觉得这座屋子将来可以作为太阳神庙？当这次危机结束之后，我会跟费尔蒙提这件事情的。")
end)

RegisterGlobalEvent(131, nil, function()
    evt.SetMessage("如果你准备去雷格那，你可以会想要先找到烈阳钉锤。当我和弟兄们从埃拉西亚渡海过来的时候，我们受到了雷格那舰队的攻击。我们只有一艘船没有逃出来。很遗憾地，那艘船就是该次任务的领导者豪威弟兄的旗舰。他带着我之前所提到的武器。我目击了豪威弟兄被海盗杀死，但也许他们还保留着那柄武器。")
end)

RegisterGlobalEvent(132, nil, function()
    evt.SetMessage("我对于艾恩法斯特家族和他们的智者萨索尔加入的这件事情感到很高兴。虽然我从来没有和他们直接合作过，但是他们在恩洛斯和埃拉西亚上打击死灵法师公会和恶魔的成就确实使他们成为了光明使徒的典范。我对他们解决危机的计划充满信心。")
end)

RegisterGlobalEvent(133, nil, function()
    evt.SetMessage("太阳神庙有很多的时间研究出现在低语森林中的传送门。我很确定它是通往风元素界的信道。我的弟兄们有几次曾经亲眼目击到有风元素从传送门离开。有些更勇敢的人们甚至曾经从传送门往内看过，他们发现了一个里面有云层快速卷动的世界。")
end)

RegisterGlobalEvent(134, nil, function()
    evt.SetMessage("身为光明之道的牧师，我对于危机有自己的定义。我很确定月亮神庙或是死灵法师公会有牵扯进去。天哪！万一他们联合起来怎么办，这真是太可怕了！")
end)

RegisterGlobalEvent(135, nil, function()
    evt.SetMessage("我不太确定我们是否可以相信这个所谓毁灭者所说的话。他一定不可能是圣书中所说的毁灭者，而他所谓的恶魔和人们居住在许多世界的说法更是完全与我们这座神庙所坚持的理念相违背！")
end)

RegisterGlobalEvent(136, nil, function()
    evt.SetMessage("贾丹姆大陆的英雄，有你们在这里真好。太阳神庙认为你们也是光明的使徒。我们永远都欢迎你们。")
end)

RegisterGlobalEvent(137, nil, function()
    evt.SetMessage("真希望我来拜访渡鸦海滨的第一次旅程能够在比较不一样的状况下。这座城镇有很多有趣的事情，我真希望自己有时间多逛逛。不过，至少这座商人之家拥有非常大的图书馆。你去过那边了吗？")
end)

RegisterGlobalEvent(138, nil, function()
    evt.SetMessage("雷格那人在匕伤群岛上已经建造了一个前哨站。我们担心他们会从那边攻击渡鸦海滨。如果发生了这种悲剧，我们就必须先疏散渡鸦海滨中的居民才行。在渡鸦海滨的守军赶走了海盗之后，我们会再度回来的。")
end)
RegisterCanShowTopic(138, function()
    evt._BeginCanShowTopic(138)
    local visible = true
    if IsQBitSet(QBit(57)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(139, nil, function()
    evt.SetMessage("当我成为领袖的时候，我并没有意料到我的统治会带来这么多的经验。我根本没想过我会遇到凯瑟琳皇后！你知道吗？在她逊位之前，她本来是埃拉西亚和恩洛斯的统治者！")
end)

RegisterGlobalEvent(140, nil, function()
    evt.SetMessage("如同你知道的一样，通往水元素界的传送门出现在残破镇的巴尔萨煞巢穴，也就是在一个大湖正中央。")
end)

RegisterGlobalEvent(141, nil, function()
    if not IsQBitSet(QBit(99)) then
        evt.SetMessage("在水晶之后的世界中你可能会很难找到足够的补给。当我离开巴尔萨煞巢穴的时候，我带了一些干粮，这些是我的部队和族人旅行时携带的粮食。它们很轻，营养也很充足。我希望能够帮上你的忙。")
        AddValue(Food, 20)
        SetQBit(QBit(99))
        return
    end
    evt.SetMessage("我已经没有干粮可以给你了。如果你需要更多，你得去别的地方找才行。")
end)

RegisterGlobalEvent(142, nil, function()
    evt.SetMessage("如果元素之王的被禁锢导致了这一切的灾变，那么，释放他们当然会结束这一切！他们是拥有强大力量的生物。一旦他们脱离了毁灭者的控制，他们一定可以把事情重新处理好的。这一定就是预言所提到的状况！")
end)

RegisterGlobalEvent(143, nil, function()
    evt.SetMessage("我们对你的感激真是无比的深重。我的同胞和贾丹姆大陆上所有的生物都是你所拯救的。多谢你在此地和在元素界中的努力，巴尔萨煞巢穴又有了继续发展的机会。你和你的同志们随时都可以来拜访我们，我们永远欢迎你们。")
end)

RegisterGlobalEvent(144, nil, function()
    evt.SetMessage("我实在忍不住要想：如果我在其它地方会不会比较有用。我很确定谭特可以替我掌管死灵法师公会，但是，当我们在和太阳神庙作战的时候，我竟然不能够亲自带领军队，实在让我很担心。你的动作最好快一点！")
end)

RegisterGlobalEvent(145, nil, function()
    evt.SetMessage("当我们想到雷格那人的时候，很少人会认为他们是魔法的大师。但是我必须要提醒你一点，雷格那人已经控制了他们的岛屿许多年，拥有足够的时间和资源去研究魔法方面的知识。有许多厉害的法师居住在该处。如果你必须和他们战斗，请做好准备。")
end)

RegisterGlobalEvent(146, nil, function()
    evt.SetMessage("我们死灵法师公会其实是很尊重其它学派法师的。他们自己愿意选择低下的力量作研究是他们自己的意愿。以一个不属于黑暗界的法师来说，萨索尔算是相当厉害的家伙。就我来看，我想他的建议还算是可以接受。")
end)

RegisterGlobalEvent(147, nil, function()
    evt.SetMessage("我听说阿尔瓦的黑暗矮人手中有一个我已经寻求很久的物品，也许可以协助你在元素界之间旅行。次元之戒可以让持有者对于地、水、风、火的攻击拥有相当的抵抗力。")
end)
RegisterCanShowTopic(147, function()
    evt._BeginCanShowTopic(147)
    local visible = true
    if HasItem(519) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(148, nil, function()
    evt.SetMessage("在我研究的过程中，我对于这个界间之地有了一些认知。居住在其中的生物并非是通过一般的方式诞生的，我听说在那边的生物是通过收集人类恶梦的能源而创造出来的。我没有更进一步的信息，但是，我认为这样的生物应该拥有相当可怕的力量。")
end)

RegisterGlobalEvent(149, nil, function()
    evt.SetMessage("魔法的基本常识是：火和水互克、风和地互克。在这些配对中，每个元素都有一些对应元素可以压制的弱点。我预料毁灭者将会照着这样的相生相克来建造他的监狱。")
end)

RegisterGlobalEvent(150, nil, function()
    evt.SetMessage("当我说我们很感激你的时候，我知道自己可以代表全公会。我给予你可以在公会控制底下所有的土地自由通行的权力，以便还你这个人情债。没有任何的公会成员会绑架你进行魔法实验，也没有任何公会成员会让你成为他麾下使徒的食物。这个公会的饬令将会有一年的有效期。\n当然，我本人也对你非常的感激。")
end)

RegisterGlobalEvent(151, nil, function()
    evt.SetMessage("大人现在不在，他去议会大厅和艾尔加・费尔蒙讨论事情了。也许你可以在那边找到他。")
end)

RegisterGlobalEvent(152, nil, function()
    evt.SetMessage("毁灭者在城镇中央广场中放的水晶有两个主要的功用。第一：如果我们袖手旁观，它将可以摧毁整个世界。二：这是一个通往另一个次元――界间之地的传送门，很明显的，毁灭者就是以该处为基地。\n这个水晶将元素界的力量召唤进我们世界中，并且吸引他们往这个水晶的方向集中。当这些力量在水晶中会合的时候，整个世界将会被接续的灾变给摧毁。如果我们要阻止这一切，一定得有人通过这个传送门去寻找毁灭者，说服他终止这样的行为，或是消灭他。")
    ClearQBit(QBit(91)) -- 和艾恩法斯特王朝的智者萨索尔请教有关渡鸦海滨水晶的问题。
    SetQBit(QBit(92))
    evt.SetNPCTopic(19, 0, 153) -- 萨索尔 topic 0: 任务
    evt.SetNPCTopic(19, 1, 154) -- 萨索尔 topic 1: 传送门
end)

RegisterGlobalEvent(153, nil, function()
    if not IsQBitSet(QBit(41)) then -- 将水之心从水元素界带回来给萨索尔。
        evt.SetMessage("由于这个水晶会和元素之力共振，所以他只容许拥有元素之力的人通过。我认为可以制造一个模拟元素共振的钥匙，让像你们这样的一小群人通过。我可以制造这把钥匙，但是我需要拥有纯粹元素之力的物品来制造它。\n这种物品我只知道以一种方式存在于这个世界。在每个元素界中，你们将可以找到一种被称为元素之心的宝石。将这些东西带给我，我将可以制造打开水晶传送门的钥匙。")
        SetQBit(QBit(41)) -- 将水之心从水元素界带回来给萨索尔。
        SetQBit(QBit(42)) -- 将风之心从风元素界带回来给萨索尔。
        SetQBit(QBit(43)) -- 将地之心从土元素界带回来给萨索尔。
        SetQBit(QBit(44)) -- 将火之心从火元素界带回来给萨索尔。
        AddValue(History(14), 0)
        evt.SetNPCTopic(40, 0, 0) -- 艾尔加・费尔蒙 topic 0 cleared
        evt.SetNPCTopic(40, 1, 112) -- 艾尔加・费尔蒙 topic 1: 火元素界
        evt.SetNPCTopic(52, 0, 119) -- 查尔斯・科切特爵士 topic 0: 组织部队
        evt.SetNPCTopic(53, 0, 126) -- 达夫克劳・红斧 topic 0: 传送门
        evt.SetNPCTopic(54, 0, 133) -- 奥斯卡・提尔 topic 0: 风元素界
        evt.SetNPCTopic(55, 0, 140) -- 马苏尔 topic 0: 水元素界
        evt.SetNPCTopic(56, 0, 147) -- 山德罗 topic 0: 次元之戒
        return
    end
    evt.ForPlayer(Players.All)
    if HasItem(606) then
        evt.SetMessage("我很高兴你找回了部分的元素之心，但是，要成功的打造钥匙，我必须要有全部的四枚元素之心才行。把其它的元素之心带给我，这样我才可以继续我的工作。")
        return
    elseif HasItem(607) then
        evt.SetMessage("我很高兴你找回了部分的元素之心，但是，要成功的打造钥匙，我必须要有全部的四枚元素之心才行。把其它的元素之心带给我，这样我才可以继续我的工作。")
        return
    elseif HasItem(608) then
        evt.SetMessage("我很高兴你找回了部分的元素之心，但是，要成功的打造钥匙，我必须要有全部的四枚元素之心才行。把其它的元素之心带给我，这样我才可以继续我的工作。")
        return
    elseif HasItem(609) then
        evt.SetMessage("我很高兴你找回了部分的元素之心，但是，要成功的打造钥匙，我必须要有全部的四枚元素之心才行。把其它的元素之心带给我，这样我才可以继续我的工作。")
    else
        evt.SetMessage("要穿过水晶传送门，面对毁灭者，你将会需要我的钥匙。而我需要四个元素界中的元素之心才能打造这个物品！快点去把它们找来给我！")
    end
end)

RegisterGlobalEvent(154, nil, function()
    evt.SetMessage("这个水晶似乎让元素界的生物感应到了一种奇怪的力量。否则他们干嘛在我们的世界上掀起战火？我已经看过你们的第一手报告，看起来似乎这些元素都被一种疯狂的力量所影响。\n这的确是非常的疯狂！因为摧毁恩洛斯将有可能在元素界之间造成不平衡的状态，危及他们自己的空间，他们甚至可能在这场大灾变中把自己也给卷入。即使在最乐观的状况下，他们所居住空间的也会受到影响。我根本不明白，这样的改变怎么可能带来任何的好处？")
end)

RegisterGlobalEvent(155, nil, function()
    evt.SetMessage("元素之王被囚禁在界间之地元的事实证明了一切。我一直怀疑为什么地水风火元素界的生物会变得这么狂暴。因为在一般的状况下，他们通常只喜欢居住在自己的空间中。我认为毁灭者必须要将这些元素之王绑架后，才能让他更为轻易地操纵这些元素生物。\n你一定要救出这些元素之王才行。只有他们能够逆转大灾变，阻止末日的发生！")
end)

RegisterGlobalEvent(156, nil, function()
    evt.SetMessage("是的，我的确听过这个名字。“爱斯卡顿”。他在许多的文化和传说中拥有不同的名字。我不知道他到底是什么样的生物，但是他诞生的目的就是为了摧毁不同的世界。\n是的，我说的是各个不同的世界。有越来越多的证据指出恩洛斯并非是宇宙间唯一的世界。在大寂静之前的许多历史记载说明了有其他的生物居住在星辰之间。生物似乎不太可能生活在天空上，但是，也许这些星辰就如同我们的太阳一样。如果是这样的话，为什么那些太阳不会照耀在如同我们的恩洛斯一样的地方？如果是这样的话，的确有可能诞生一个“众多世界的毁灭者”。而我认为目前所面对的就是这样的一个生物。")
end)

RegisterGlobalEvent(157, nil, function()
    evt.SetMessage("不，我不认为我会和艾恩法斯特家族一起回到恩洛斯。也许数年之后我会回到他们身边。但是目前我对于这些世界感到相当的有兴趣。虽然他们几乎都已经被摧毁了，但我愿意继续在这边研究水晶的碎片。就我所知，这个世界上从来没有任何这么强大力量的物品被创造出来。也许我可以替这些水晶找到一个作用？\n不管怎么样，艾恩法斯特家族离开的时候我不会跟他们一起走。")
end)

RegisterGlobalEvent(158, nil, function()
    evt.SetMessage("我不需要太过谦逊，因为龙葵灯炉的确是我很感到自豪的一个创造物。如果里面的火焰经过适当的处理，该死的太阳就没有办法在附近的区域中发出光芒。夜晚舒适的阴影将会笼罩一大部分的区域。在这区域中，吸血鬼和其它的黑夜生物将拥有前所未见的自由。我们将可以自由自在地在白天漫游，不用担心被阳光所毁灭！\n太阳神庙这次夺取了我的宝物，我们一定要将它夺回才行！")
end)

RegisterGlobalEvent(159, nil, function()
    evt.SetMessage("我是毁灭者爱斯卡顿，又被称作“恶魔末日”、“蛛网之门中的蜘蛛”、或是“废墟”。有些地方把我当做天神看待。但是，我自认为是更高力量主人的仆从。\n我这次的任务是将灾变带来到你们的世界中，因为这个世界必须被摧毁。这是由于你们无法把邪恶的克里根人彻底摧毁所带来的末日。")
    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
    evt.SetNPCTopic(22, 3, 163) -- 爱斯卡顿 topic 3: 拯救世界
    evt.SetNPCTopic(19, 0, 155) -- 萨索尔 topic 0: 元素之王
    evt.SetNPCTopic(19, 1, 156) -- 萨索尔 topic 1: 毁灭者
    evt.SetNPCGreeting(19, 112) -- 萨索尔 greeting 112
    SetQBit(QBit(235))
    SetValue(MapVar(31), 4)
    SetValue(MapVar(32), 4)
    SetValue(MapVar(33), 4)
end)

RegisterGlobalEvent(160, nil, function()
    if IsAtLeast(MapVar(31), 4) then
        evt.SetMessage("我的主人是那些创造我的人。是他们给予了我外形和能力。我是无法摧毁的。我的任务是摧毁那些被克里根人所占据的世界。")
        SetValue(MapVar(31), 3)
        return
    elseif IsAtLeast(MapVar(31), 3) then
        evt.SetMessage("在你们世界上有一段传说持续了千年之久的寂静，我是在那之前许久诞生的。而我的主人们对我来说更是古老许多。")
        SetValue(MapVar(31), 2)
        return
    elseif IsAtLeast(MapVar(31), 2) then
        evt.SetMessage("宇宙中不只你们一个世界。这些世界曾经一度由如同蛛网一般的丝线所连结，各种生物可以利用这些丝线如同桥梁一般地四处通行。你们称作的大寂静是我的主人们所创造的丝线断裂的年代。")
        SetValue(MapVar(31), 1)
        return
    elseif IsAtLeast(MapVar(31), 1) then
        evt.SetMessage("在远古的时代，我的主人们是许多许多世界的照顾者。在克里根人降临，也就是在大寂静之前，这个宇宙中充满了让人惊奇的奇迹。我的主人是伟大文明的皇后和国王。我之所以被制造出来，不是因为他们需要我，而是因为他们有能力制造我。我是个保护不需要保护的宇宙的守护者……是伟大生命力量之象征。\n但是现在，从许多许多年以前开始，克里根人如同疾病一样地摧毁了这些奇迹般的文明。我的主人们也跟着倒下。他们是战将和君主，我则是他们最勇猛的士兵。")
        SetValue(MapVar(31), 4)
    else
        evt.SetMessage("我的主人是那些创造我的人。是他们给予了我外形和能力。我是无法摧毁的。我的任务是摧毁那些被克里根人所占据的世界。")
        SetValue(MapVar(31), 3)
    end
end)

RegisterGlobalEvent(161, nil, function()
    if IsAtLeast(MapVar(32), 4) then
        evt.SetMessage("你的世界将会被创造它的元素之力所摧毁。贾丹姆大陆主城中的水晶吸引元素界的生物进入你们的世界。当他们的世界在水晶处会合的时候，整个连锁反应将会释放出巨大的力量横越过大地、天空和海洋。所有活着的生物都将死亡。")
        SetValue(MapVar(32), 3)
        return
    elseif IsAtLeast(MapVar(32), 3) then
        evt.SetMessage("当我进行灾变召唤仪式时，大灾变就开始了。这是我的主人们创造出来对付克里根人的最后武器。\n我的确有其他的武器。但是，当我发现克里根人进入你的世界之后，我就认为最后武器的使用是无可避免的。你们的世界曾经陷入了极大的危机，看起来你们似乎没有自卫的能力。虽然我小看了你们的能力，而克里根人最后也被摧毁了，为了保险，我依旧觉得必须导正这一切。")
        SetValue(MapVar(32), 2)
        return
    elseif IsAtLeast(MapVar(32), 2) then
        evt.SetMessage("我的主人担心克里根人会找到可以感染我的方法，因此让我成为不受外界力量影响的战士。一旦灾变召唤仪式开始了，我就不可能逆转这个动作。这是我被创造出来的工作之一，我根本无法反抗他们。")
        SetValue(MapVar(32), 1)
        return
    elseif IsAtLeast(MapVar(32), 1) then
        evt.SetMessage("灾变召唤仪式虽然非常强大，但却不可能单靠己身而摧毁整个世界。每个元素界都在一个元素之王的统治之下。这些元素之王可以反抗对他们属下的引诱。因此，我已经将这些元素之王从他们的世界中抓了出来。他们目前是我的“客人”。\n一旦大灾变结束之后，我将会把他们放回去，好让他们重建自己的世界和你们的世界。")
        SetValue(MapVar(32), 4)
    else
        evt.SetMessage("你的世界将会被创造它的元素之力所摧毁。贾丹姆大陆主城中的水晶吸引元素界的生物进入你们的世界。当他们的世界在水晶处会合的时候，整个连锁反应将会释放出巨大的力量横越过大地、天空和海洋。所有活着的生物都将死亡。")
        SetValue(MapVar(32), 3)
    end
end)

RegisterGlobalEvent(162, nil, function()
    if IsAtLeast(MapVar(33), 4) then
        evt.SetMessage("从大寂静之后，你的世界已经忘记了克里根人的起源。对你们来说，他们和恶魔一样的这个事实就已经够了。的确，大多数的人也叫他们作恶魔。他们是从宇宙的边缘出现的。在他们攻击我们之前，我的主人们根本不知道他们的存在。\n克里根人感染我们的世界，并且尽可能地扩张。如果他们选择往另外一个方向发展，这个宇宙其实是无限大的。但是他们并没有做出这样的选择，所以我们必须防御他们的攻击。")
        SetValue(MapVar(33), 3)
        return
    elseif IsAtLeast(MapVar(33), 3) then
        evt.SetMessage("我知道恩洛斯的国王和皇后毁灭了这些恶魔。但是，我必须要摧毁你们的世界。一旦我受到了召唤，我就必须要执行仪式。一旦仪式开始了，大灾变就必须继续下去。\n我被召唤的时候是那些克里根人还存在于这个世界上的时候，即使他们在我到达的时候都已经化成灰烬了也没有影响。")
        SetValue(MapVar(33), 2)
        return
    elseif IsAtLeast(MapVar(33), 2) then
        evt.SetMessage("如果不是因为克里根人和他们四处宣战的天性，我的主人们老早就把世界之网给重建好了。我的主人们已经试图重建世界之网许多次，但是每次都被这些克里根人给摧毁了。现在他们已经意识到，如果不把克里根人彻底摧毁，黄金的年代就永远不会到来。因此，我才被创造出来。")
        SetValue(MapVar(33), 1)
        return
    elseif IsAtLeast(MapVar(33), 1) then
        evt.SetMessage("从我有限的思考模式看起来，我很惊讶你们能够消灭克里根人。他们比你们要先进许多……恩洛斯的国王和皇后一定是超凡的战略家才有可能达成这个任务。真可惜他们不能早点完成这个任务。\n如果我拥有后悔功能的话，我会觉得如此摧毁你们的世界真是遗憾。")
        SetValue(MapVar(33), 4)
    else
        evt.SetMessage("从大寂静之后，你的世界已经忘记了克里根人的起源。对你们来说，他们和恶魔一样的这个事实就已经够了。的确，大多数的人也叫他们作恶魔。他们是从宇宙的边缘出现的。在他们攻击我们之前，我的主人们根本不知道他们的存在。\n克里根人感染我们的世界，并且尽可能地扩张。如果他们选择往另外一个方向发展，这个宇宙其实是无限大的。但是他们并没有做出这样的选择，所以我们必须防御他们的攻击。")
        SetValue(MapVar(33), 3)
    end
end)

RegisterGlobalEvent(163, nil, function()
    evt.SetMessage("是的，你的世界的确需要被拯救！大灾变如果不被阻止，将会彻底摧毁这个世界。\n我可以给你一个提示：我身为大灾变的召唤者，当然知道该如何阻止大灾变。另外，我也知道由于你的世界上已经没有克里根人的存在，这个世界不需要被摧毁。但是，身为主人的仆从，我必须要让大灾变继续进行，避免因为我对你透露消息，而让大灾变被终止。\n所以，我会问你一些问题，也许这些问题的答案就是你所找寻的线索。")
    SetQBit(QBit(98))
    evt.SetNPCTopic(22, 0, 164) -- 爱斯卡顿 topic 0: 谜题一
    evt.SetNPCTopic(22, 1, 165) -- 爱斯卡顿 topic 1: 谜题二
    evt.SetNPCTopic(22, 2, 166) -- 爱斯卡顿 topic 2: 谜题三
    evt.SetNPCTopic(22, 3, 0) -- 爱斯卡顿 topic 3 cleared
end)

RegisterGlobalEvent(164, nil, function(continueStep)
    if continueStep == 2 then
        evt.SetMessage("听起来一点也不对。")
        evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
        evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
        evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
        evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
        return
    end
    if continueStep == 4 then
        if IsQBitSet(QBit(95)) then
            if not IsQBitSet(QBit(96)) then
                evt.SetMessage("是的，你的答案似乎挺正确的。也许就是正确的答案。")
                SetQBit(QBit(94))
                if IsQBitSet(QBit(95)) then
                    SetAutonote(2)
                    ClearAutonote(5)
                    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
                    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
                    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
                    evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
                    return
                elseif IsQBitSet(QBit(96)) then
                    SetAutonote(3)
                    ClearAutonote(7)
                else
                    SetAutonote(1)
                end
            evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
            evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
            evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
            evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
            return
            end
            evt.SetMessage("你已经正确回答了所有的谜题。我觉得在询问你的过程中，我已经通过某些方法帮了你的忙，这应该足够了。由于我天性的限制，我也没法多说了。\n\n为了奖励你们的努力，请收下这个小玩意儿。我拥有不只一个，因此我不需要这么多。你知道吗？我能够把它给你，是因为我不知道你懂得如何使用它。")
            SetQBit(QBit(97))
            SetQBit(QBit(48)) -- 救出火之王。
            SetQBit(QBit(50)) -- 救出地之王。
            SetQBit(QBit(52)) -- 救出水之王。
            SetQBit(QBit(54)) -- 救出风之王。
            ClearQBit(QBit(46)) -- 穿过水晶传送门，找到大灾变发生的根源。
            SetQBit(QBit(47))
            AddValue(InventoryItem(629), 629)
            SetQBit(QBit(220))
            AddValue(History(16), 0)
            ClearAutonote(6)
            SetAutonote(4)
            evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
            evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
            evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
            evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
            return
        end
        evt.SetMessage("是的，你的答案似乎挺正确的。也许就是正确的答案。")
        SetQBit(QBit(94))
        if IsQBitSet(QBit(95)) then
            SetAutonote(2)
            ClearAutonote(5)
            evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
            evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
            evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
            evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
            return
        elseif IsQBitSet(QBit(96)) then
            SetAutonote(3)
            ClearAutonote(7)
        else
            SetAutonote(1)
        end
    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
    evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
    return
    end
    if continueStep ~= nil then return end
    if not IsQBitSet(QBit(94)) then
        evt.AskQuestion(164, 2, 595, 4, 100, 101, "有个地方，人们进入此地是为了偿还一些东西，\n此地不能自由离开。\n但是离开之后就获得了自由。这是什么地方？\n请输入数字：1、商店；2、王宫；3、行会；4、监狱", {"prison", "4"})
        return nil
    end
    evt.SetMessage("监狱、牢房有许多种类的形式。听说有种所谓“心灵的监狱”。我不知道。这个谜题中暗示的似乎是个有形的监狱。你觉得呢？")
    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
    evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
    return
end)

RegisterGlobalEvent(165, nil, function(continueStep)
    if continueStep == 2 then
        evt.SetMessage("我想这也许是对的……不对，再想想，你完全错了。")
        evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
        evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
        evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
        evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
        return
    end
    if continueStep == 4 then
        if IsQBitSet(QBit(94)) then
            if not IsQBitSet(QBit(96)) then
                evt.SetMessage("语言是十分变幻莫测的。不过，你的回答似乎就是这个谜题的答案。")
                SetQBit(QBit(95))
                if IsQBitSet(QBit(94)) then
                    SetAutonote(2)
                    ClearAutonote(1)
                    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
                    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
                    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
                    evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
                    return
                elseif IsQBitSet(QBit(96)) then
                    SetAutonote(6)
                    ClearAutonote(7)
                else
                    SetAutonote(5)
                end
            evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
            evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
            evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
            evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
            return
            end
            evt.SetMessage("你已经正确回答了所有的谜题。我觉得在询问你的过程中，我已经通过某些方法帮了你的忙，这应该足够了。由于我天性的限制，我也没法多说了。\n\n为了奖励你们的努力，请收下这个小玩意儿。我拥有不只一个，因此我不需要这么多。你知道吗？我能够把它给你，是因为我不知道你懂得如何使用它。")
            SetQBit(QBit(97))
            SetQBit(QBit(48)) -- 救出火之王。
            SetQBit(QBit(50)) -- 救出地之王。
            SetQBit(QBit(52)) -- 救出水之王。
            SetQBit(QBit(54)) -- 救出风之王。
            ClearQBit(QBit(46)) -- 穿过水晶传送门，找到大灾变发生的根源。
            SetQBit(QBit(47))
            AddValue(InventoryItem(629), 629)
            SetQBit(QBit(220))
            AddValue(History(16), 0)
            ClearAutonote(3)
            SetAutonote(4)
            evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
            evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
            evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
            evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
            return
        end
        evt.SetMessage("语言是十分变幻莫测的。不过，你的回答似乎就是这个谜题的答案。")
        SetQBit(QBit(95))
        if IsQBitSet(QBit(94)) then
            SetAutonote(2)
            ClearAutonote(1)
            evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
            evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
            evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
            evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
            return
        elseif IsQBitSet(QBit(96)) then
            SetAutonote(6)
            ClearAutonote(7)
        else
            SetAutonote(5)
        end
    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
    evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
    return
    end
    if continueStep ~= nil then return end
    if not IsQBitSet(QBit(95)) then
        evt.AskQuestion(165, 2, 599, 4, 102, 103, "当你进入一个房间，你就感受到了它，\n你把门打开，它却无法离开。这是什么？\n请输入数字：1、外面；2、里面；3、房主；4、房主的宠物", {"inside", "2"})
        return nil
    end
    evt.SetMessage("里面。在什么里面？什么在里面？我们又是为了什么在研究这个问题？")
    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
    evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
    return
end)

RegisterGlobalEvent(166, nil, function(continueStep)
    if continueStep == 2 then
        evt.SetMessage("我觉得这不是正确答案。")
        evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
        evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
        evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
        evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
        return
    end
    if continueStep == 4 then
        if IsQBitSet(QBit(94)) then
            if not IsQBitSet(QBit(95)) then
                evt.SetMessage("答案还可能是什么呢？我很确定，如果你多想想，一定可以想出别的答案来。但在这样的情况下，其实第一个想到的东西多半就是正确的。我想这答案应该是正确的。")
                SetQBit(QBit(96))
                if IsQBitSet(QBit(94)) then
                    SetAutonote(3)
                    ClearAutonote(1)
                    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
                    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
                    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
                    evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
                    return
                elseif IsQBitSet(QBit(95)) then
                    SetAutonote(6)
                    ClearAutonote(5)
                else
                    SetAutonote(7)
                end
            evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
            evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
            evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
            evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
            return
            end
            evt.SetMessage("你已经正确回答了所有的谜题。我觉得在询问你的过程中，我已经通过某些方法帮了你的忙，这应该足够了。由于我天性的限制，我也没法多说了。\n\n为了奖励你们的努力，请收下这个小玩意儿。我拥有不只一个，因此我不需要这么多。你知道吗？我能够把它给你，是因为我不知道你懂得如何使用它。")
            SetQBit(QBit(97))
            SetQBit(QBit(48)) -- 救出火之王。
            SetQBit(QBit(50)) -- 救出地之王。
            SetQBit(QBit(52)) -- 救出水之王。
            SetQBit(QBit(54)) -- 救出风之王。
            ClearQBit(QBit(46)) -- 穿过水晶传送门，找到大灾变发生的根源。
            SetQBit(QBit(47))
            AddValue(InventoryItem(629), 629)
            SetQBit(QBit(220))
            AddValue(History(16), 0)
            ClearAutonote(2)
            SetAutonote(4)
            evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
            evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
            evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
            evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
            return
        end
        evt.SetMessage("答案还可能是什么呢？我很确定，如果你多想想，一定可以想出别的答案来。但在这样的情况下，其实第一个想到的东西多半就是正确的。我想这答案应该是正确的。")
        SetQBit(QBit(96))
        if IsQBitSet(QBit(94)) then
            SetAutonote(3)
            ClearAutonote(1)
            evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
            evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
            evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
            evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
            return
        elseif IsQBitSet(QBit(95)) then
            SetAutonote(6)
            ClearAutonote(5)
        else
            SetAutonote(7)
        end
    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
    evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
    return
    end
    if continueStep ~= nil then return end
    if not IsQBitSet(QBit(96)) then
        evt.AskQuestion(166, 2, 603, 4, 104, 105, "如同月亮一样颜色的容器，\n存在的目的是为了被从里面打开，\n容器保护着里面如同太阳一样颜色的生命之宝藏。\n这是什么？\n请输入数字：1、蛋；2、锅；3、纸盒；4、箱子", {"egg", "1"})
        return nil
    end
    evt.SetMessage("“蛋”，是的。蛋是生命的源头，是许多生物的种子。它们也拥有非常特殊的形状，这样的形状不是到处都可见的。也许你把所有的答案放在当前情况下想一想，就能够获得一些线索或方向。")
    evt.SetNPCTopic(22, 0, 160) -- 爱斯卡顿 topic 0: 主人
    evt.SetNPCTopic(22, 1, 161) -- 爱斯卡顿 topic 1: 大灾变
    evt.SetNPCTopic(22, 2, 162) -- 爱斯卡顿 topic 2: 克里根人
    evt.SetNPCTopic(22, 3, 171) -- 爱斯卡顿 topic 3: 谜题
    return
end)

RegisterGlobalEvent(167, nil, function()
    if IsQBitSet(QBit(51)) and IsQBitSet(QBit(53)) and IsQBitSet(QBit(49)) then
        evt.SetMessage("多谢你把我放出来，请记得，风元素之王永远感激你。\n我现在必须要去恢复我们空间的秩序，并且加入我的同伴们拯救你的世界。请小心！我们的行动会让水晶传送门变得不稳定。现在请你赶快离开，免得被永远困在这里。请通知萨索尔这里发生了什么事情。再会。")
        SetQBit(QBit(56))
        AddValue(History(17), 0)
    else
        evt.SetMessage("多谢你放出我，我现在得要回到我的世界恢复秩序，并且拯救你的世界。风元素之王永远感谢你。再会了。")
    end
    evt.SetNPCTopic(26, 0, 0) -- 夏尔温 topic 0 cleared
    evt.MoveNPC(26, 0) -- 夏尔温 -> removed
    evt.ForPlayer(Players.All)
    AddValue(Experience, 100000)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 10000)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(54)) -- 救出风之王。
    SetQBit(QBit(55))
    SetAward(Award(14))
end)

RegisterGlobalEvent(168, nil, function()
    if IsQBitSet(QBit(51)) and IsQBitSet(QBit(55)) and IsQBitSet(QBit(49)) then
        evt.SetMessage("能够把我禁锢在这边的人，用毁灭者称呼他实在是相当正确的。如果不是因为你的援手，我―水元素之王很有可能就这么被毁灭。我的毁灭将会造成所有元素界的不平衡。多谢你，我得要去加入其她的元素之王，让一切恢复旧观。\n我现在必须要去恢复我们空间的秩序，并且加入我的同伴们拯救你的世界。请小心！我们的行动会让水晶传送门变得不稳定。现在请你赶快离开，免得被永远困在这里。请通知萨索尔这里发生了什么事情。再会。")
        SetQBit(QBit(56))
        AddValue(History(17), 0)
    else
        evt.SetMessage("能够把我禁锢在这边的人，用毁灭者称呼他实在是相当正确的。如果不是因为你的援手，我――水元素之王很有可能就这么被毁灭。我的毁灭将会造成所有元素界的不平衡。多谢你，我得要去让一切恢复旧观了。")
    end
    evt.SetNPCTopic(24, 0, 0) -- 爱克瓦蓝德 topic 0 cleared
    evt.MoveNPC(24, 0) -- 爱克瓦蓝德 -> removed
    evt.ForPlayer(Players.All)
    AddValue(Experience, 100000)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 10000)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(52)) -- 救出水之王。
    SetQBit(QBit(53))
    SetAward(Award(15))
end)

RegisterGlobalEvent(169, nil, function()
    if IsQBitSet(QBit(55)) and IsQBitSet(QBit(53)) and IsQBitSet(QBit(49)) then
        evt.SetMessage("我自由了！我将要让这个囚禁我的笨蛋，什么鬼毁灭者知道我有多生气！我所受的苦将会以百倍千倍报应到他身上！\n我现在必须要去恢复我们空间的秩序，并且加入我的同伴们拯救你的世界。请小心！我们的行动会让水晶传送门变得不稳定。现在请你赶快离开，免得被永远困在这里。请通知萨索尔这里发生了什么事情。再会。")
        SetQBit(QBit(56))
        AddValue(History(17), 0)
    else
        evt.SetMessage("我自由了！我将要让这个囚禁我的笨蛋，什么鬼毁灭者知道我有多生气！我所受的苦将会以百倍千倍报应到他身上！")
    end
    evt.SetNPCTopic(25, 0, 0) -- 残酷葛罗格 topic 0 cleared
    evt.MoveNPC(25, 0) -- 残酷葛罗格 -> removed
    evt.ForPlayer(Players.All)
    AddValue(Experience, 100000)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 10000)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(50)) -- 救出地之王。
    SetQBit(QBit(51))
    SetAward(Award(16))
end)

RegisterGlobalEvent(170, nil, function()
    if IsQBitSet(QBit(51)) and IsQBitSet(QBit(53)) and IsQBitSet(QBit(55)) then
        evt.SetMessage("我终于被释放了。我的苦刑已经结束了，但是我的子民们呢？我知道毁灭者强迫他们执行一个可怕的任务。我的出现将会让他们获得安宁。我得赶快走了，我要去恢复各地的秩序了。\n我现在必须要去恢复我们空间的秩序，并且加入我的同伴们拯救你的世界。请小心！我们的行动会让水晶传送门变得不稳定。现在请你赶快离开，免得被永远困在这里。请通知萨索尔这里发生了什么事情。再会。")
        SetQBit(QBit(56))
        AddValue(History(17), 0)
    else
        evt.SetMessage("我终于被释放了。我的苦刑已经结束了，但是我的子民们呢？我知道毁灭者强迫他们执行一个可怕的任务。我的出现将会让他们获得安宁。我得赶快走了。再会……")
    end
    evt.SetNPCTopic(23, 0, 0) -- 派蓝纳斯特 topic 0 cleared
    evt.MoveNPC(23, 0) -- 派蓝纳斯特 -> removed
    evt.ForPlayer(Players.All)
    AddValue(Experience, 100000)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 10000)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(48)) -- 救出火之王。
    SetQBit(QBit(49))
    SetAward(Award(17))
end)

RegisterGlobalEvent(171, nil, function()
    if not IsQBitSet(QBit(97)) then
        evt.SetMessage("虽然我必须要摧毁你的世界，但是我该做的都已经做了。在大灾变结束之前，我没有别的任务让我不能和你讲话。不过，这也不能够持续到永远。没有事情可以持续到永远。\n有些时候，问题会创造出更多的问题来。有些时候他们反而可以提供解答。不知道我的问题可以提供给你什么样的信息？")
        evt.SetNPCTopic(22, 0, 164) -- 爱斯卡顿 topic 0: 谜题一
        evt.SetNPCTopic(22, 1, 165) -- 爱斯卡顿 topic 1: 谜题二
        evt.SetNPCTopic(22, 2, 166) -- 爱斯卡顿 topic 2: 谜题三
        evt.SetNPCTopic(22, 3, 0) -- 爱斯卡顿 topic 3 cleared
        return
    end
    evt.SetMessage("我的主人创造我是让我成为知识的保管者，并非给予者。但是，也许你们可以通过这些问题知道更多的知识。我已经把我所有知道的问题都告诉了你们，你们必须要看看自己有些什么。也许你们应该对这些答案提出进一步的问题才对。\n\n“监狱”代表着有犯人。谁？“里面”？在什么里面？还有“蛋”，什么样的蛋？鸟的蛋？也许是形状像是蛋的物品？")
end)

RegisterGlobalEvent(172, nil, function()
    evt.SetMessage("在这个动荡的时代，有很多掠食者可能会入侵这个地方。我已经驱赶走了很多的土匪，还有更糟糕的……索格的巡逻队曾经误闯过这里，我杀死了大部分，但是还有一些逃掉了。我想他们可能会成群结队地跑回来。")
    evt.SetNPCTopic(57, 2, 173) -- 坦尼斯 topic 2: 加入
end)

RegisterGlobalEvent(173, nil, function()
    evt.SetMessage("不行！一定有人得留在这里，守卫巢穴不受野蛮人的入侵。在你拯救了我的同胞之后再回来找我，那时我也许可以加入你们。")
end)

RegisterGlobalEvent(174, nil, function()
    evt.SetMessage("黄热病是种会让人残障的传染病，每隔几年就会突然冒出来。通常我们会从主大陆那边进口药物，但是在桥梁被摧毁之后，没有人可以过去买药了！")
    evt.SetNPCTopic(65, 0, 175) -- 埃斯蓝 topic 0: 任务
end)

RegisterGlobalEvent(175, nil, function()
    evt.SetMessage("来，收下这些治愈疾病的卷轴。也许我们至少可以阻止传染病的散布。在外岛的六座小屋都被感染了。如果在各岛屿之间来往的传送门被修复了，你可以把这些卷轴送到那些小屋去。很不幸的，你必须要在旅途上再找到额外三个卷轴才够你使用。")
    SetQBit(QBit(101)) -- 将治愈疾病的卷轴送到匕伤岛外围群岛的六个小屋中。接着回到匕伤岛上去找埃斯蓝。
    evt.SetNPCTopic(65, 0, 176) -- 埃斯蓝 topic 0: 你阻止了传染病吗？
    AddValue(InventoryItem(373), 373)
    AddValue(InventoryItem(373), 373)
    AddValue(InventoryItem(373), 373)
end)
RegisterCanShowTopic(175, function()
    evt._BeginCanShowTopic(175)
    local visible = true
    if IsQBitSet(QBit(108)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(176, nil, function()
    evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
    ClearQBit(QBit(101)) -- 将治愈疾病的卷轴送到匕伤岛外围群岛的六个小屋中。接着回到匕伤岛上去找埃斯蓝。
    AddValue(Gold, 1500)
    evt.ForPlayer(Players.All)
    SetAward(Award(18))
    evt.SetNPCTopic(65, 0, 661) -- 埃斯蓝 topic 0: 海盗劫掠
end)
RegisterCanShowTopic(176, function()
    evt._BeginCanShowTopic(176)
    local visible = true
    if IsQBitSet(QBit(108)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(177, nil, function()
    evt.SetMessage("我听说黄热病又再度开始流行了。通常在主岛上的这个水源是主要疾病的来源。我们通常可以从主大陆上购买一种圣草药剂，用来阻止疫病的流行。但是，由于我们无法前往港口，我们也没办法找到需要的药剂。如果你能够前往主大陆，或许在渡鸦海滨的私枭们会拥有这药剂。如果你可以买到这东西，赶快带回来给我！")
    SetQBit(QBit(109)) -- 找到神选之药剂，并且将它带回去给匕伤岛的蓝贵德。
    evt.SetNPCTopic(66, 0, 178) -- 蓝贵德 topic 0: 你有解毒剂吗？
end)
RegisterCanShowTopic(177, function()
    evt._BeginCanShowTopic(177)
    local visible = true
    if IsQBitSet(QBit(110)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(178, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(616) then
        evt.SetMessage("如果没有圣草药剂，我们没办法把毒素从水井中消除！")
        return
    end
    evt.SetMessage("多谢你！我会把这东西倒进水源中的！")
    RemoveItem(616)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 7500)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 2000)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(109)) -- 找到神选之药剂，并且将它带回去给匕伤岛的蓝贵德。
    ClearQBit(QBit(245))
    SetQBit(QBit(110))
    SetQBit(QBit(1552))
    evt.SetNPCTopic(66, 0, 0) -- 蓝贵德 topic 0 cleared
end)

RegisterGlobalEvent(179, nil, function()
    evt.SetMessage("或许你可以把永恒速度药剂的药材带来给我？只要有了那些药材，我就可以完成我在炼金术上的研究，制造出这种药剂来！我会给予你相当的报酬！")
    SetQBit(QBit(113)) -- 将纯粹速度药剂所需要的药材带给匕伤岛上的系斯妥。
    evt.SetNPCTopic(68, 0, 0) -- 系斯妥 topic 0 cleared
end)
RegisterCanShowTopic(179, function()
    evt._BeginCanShowTopic(179)
    local visible = true
    if IsQBitSet(QBit(113)) then -- 将纯粹速度药剂所需要的药材带给匕伤岛上的系斯妥。
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(180, nil, function()
    evt.SetMessage("黑色药剂是由混合许多基本的药材所获得的。红色的药材包括了柳条浆果、狼之眼、垢鬼血。蓝色的药剂包括了火凤羽、费玛根、陨石片、鬼火心。黄色药材则包括了曼陀罗、龙龟牙、罂粟茎和刺木皮。")
end)

RegisterGlobalEvent(181, nil, function()
    if not evt.CheckItemsCount(200, 204, 4) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(205, 209, 2) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(210, 214, 1) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    evt.SetMessage("这些就是我需要的药材！多谢你！这是你的报酬！")
    evt.RemoveItems(200, 204, 4)
    evt.RemoveItems(205, 209, 2)
    evt.RemoveItems(210, 214, 1)
    ClearQBit(QBit(113)) -- 将纯粹速度药剂所需要的药材带给匕伤岛上的系斯妥。
    SetQBit(QBit(114))
    AddValue(InventoryItem(265), 265)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 1000)
    evt.SetNPCTopic(68, 2, 0) -- 系斯妥 topic 2 cleared
end)
RegisterCanShowTopic(181, function()
    evt._BeginCanShowTopic(181)
    local visible = true
    if IsQBitSet(QBit(113)) then -- 将纯粹速度药剂所需要的药材带给匕伤岛上的系斯妥。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(182, nil, function()
    evt.SetMessage("我认为我已经找到了如何阻止火山毁灭力量的方法了！我找到一个古老的法术，可以将火山推回海中！要完成这个法术的施放，我必须要找到一个被称作蛇之圣像的古物。只要有了这个古物，我就可以完成这个法术。")
    SetQBit(QBit(111)) -- 将被废弃的神庙中所找到的蛇之偶像带回去给匕伤岛的希斯。
    evt.SetNPCTopic(69, 0, 183) -- 希斯 topic 0: 你有偶像吗？
end)
RegisterCanShowTopic(182, function()
    evt._BeginCanShowTopic(182)
    local visible = true
    if IsQBitSet(QBit(112)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(183, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(630) then
        evt.SetMessage("圣像在哪里？别浪费我的时间！")
        return
    end
    evt.SetMessage("多谢你把这个圣像找来给我。很不幸地，在我进一步研究了这个法术之后，我发现它根本没用。不过，这不是你的问题，我还是会付你承诺的报酬的。")
    evt.ForPlayer(Players.All)
    RemoveItem(630)
    AddValue(Experience, 7500)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 2000)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(111)) -- 将被废弃的神庙中所找到的蛇之偶像带回去给匕伤岛的希斯。
    SetQBit(QBit(112))
    SetQBit(QBit(1549))
    evt.SetNPCTopic(69, 0, 0) -- 希斯 topic 0 cleared
end)

RegisterGlobalEvent(184, nil, function()
    evt.SetMessage("在这个地区肆虐的猛狼已经成了旅行者和商人们重大的威胁。阿尔瓦的商人们已经下令要我寻找出色的猎人来猎杀这些动物，并且有效地“降低威胁”。你看起来像是不错的对象！如果你能够杀死巢穴里面的所有猛狼，我会给予你相当的奖赏！")
    SetQBit(QBit(139)) -- 杀死所有渡鸦海滨地区的猛狼，完成任务之后回去渡鸦海滨找马帝刚。
    evt.SetNPCTopic(71, 0, 186) -- 追迹者马帝刚 topic 0: 终于！
end)

RegisterGlobalEvent(185, nil, function()
    evt.SetMessage("你每给我一张猛狼皮，我就会给你250个金币。")
    evt.ForPlayer(Players.All)
    if HasItem(633) then
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 250)
        evt.ForPlayer(Players.All)
        RemoveItem(633)
        return
    end
    evt.SetMessage("你身上已经没有兽皮了，当你找到更多兽皮之后再回来吧！")
end)

RegisterGlobalEvent(186, nil, function()
    evt.SetMessage("你已经杀死了这个区域所有的猛狼！旅行者又都可以安全地四处旅行了，不过，我也必须找其他的工作啦！还是多谢你的帮助！")
    AddValue(Gold, 2500)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 7500)
    ClearQBit(QBit(139)) -- 杀死所有渡鸦海滨地区的猛狼，完成任务之后回去渡鸦海滨找马帝刚。
    SetQBit(QBit(1553))
    evt.SetNPCTopic(71, 0, 0) -- 追迹者马帝刚 topic 0 cleared
end)
RegisterCanShowTopic(186, function()
    evt._BeginCanShowTopic(186)
    local visible = true
    if IsQBitSet(QBit(140)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(187, nil, function()
    if not IsQBitSet(QBit(120)) then
        evt.SetMessage("阿尔瓦的商人公会抓走了我的家人，以便确保我的忠诚。但是，在回去阿尔瓦的路上，他们的车队受到了食人妖和强盗的攻击。食人妖索格抓走了我的家人！他把我的家人带到了他在阿尔瓦地区的要塞中。现在，我被迫必须要替他注意阿尔瓦商人的动向。只要我服从他的命令，我的家人就可以继续活下来。如果我停了下来，他们就会死。你可以替我救出他们来吗？")
        SetQBit(QBit(119)) -- 将艾瑞安・韩特的女儿从阿尔瓦的食人妖要塞中救出。
        return
    end
    evt.SetMessage("我的家人已经回来了，他们告诉我是你救出了他们。告诉阿尔瓦的商人，他们不再需要靠着“协商”来和我做生意了。我会对他们和对你信守诺言，我的船只随时听你的差遣！")
    ClearQBit(QBit(120))
    evt.ForPlayer(Players.All)
    AddValue(Experience, 15000)
    SetQBit(QBit(1551))
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 10000)
    evt.SetNPCTopic(4, 2, 0) -- 艾瑞安・韩特 topic 2 cleared
end)

RegisterGlobalEvent(188, nil, function()
    evt.SetMessage("我固定会送出有关阿尔瓦商人的情报给恐怖海盗史坦力，他人就在雷格那岛上的海盗休息站酒吧中。由于阿尔瓦的商人们已经“争取”到了我的协助，我们必须要送一份假情报给史坦力，避免他起疑。把这份报告拿去给他！")
    SetQBit(QBit(117)) -- 将假的报告带回去给雷格那岛上的海盗休息站酒吧给恐怖海盗史坦力。
    SetQBit(QBit(282))
    AddValue(InventoryItem(602), 602)
    evt.SetNPCTopic(4, 1, 189) -- 艾瑞安・韩特 topic 1: 报告送到了吗？
end)
RegisterCanShowTopic(188, function()
    evt._BeginCanShowTopic(188)
    local visible = true
    if IsQBitSet(QBit(118)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(189, nil, function()
    evt.SetMessage("你把假情报给了史坦力？这至少可以替我们争取一点时间，让他不会对渡鸦海滨和阿尔瓦商人公会的行动起疑。")
    evt.ForPlayer(Players.All)
    AddValue(Experience, 10000)
    evt.SetNPCTopic(4, 1, 299) -- 艾瑞安・韩特 topic 1: 贾丹姆大陆的命运
end)
RegisterCanShowTopic(189, function()
    evt._BeginCanShowTopic(189)
    local visible = true
    if IsQBitSet(QBit(118)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(190, nil, function()
    evt.SetMessage("我听说你正在找寻一份圣草药剂来净化水源。贾丹姆大陆上的走私者拥有各式各样的诡异货物。如果世界上会有任何人拥有这样物品，那就一定是他们了！")
end)
RegisterCanShowTopic(190, function()
    evt._BeginCanShowTopic(190)
    local visible = true
    if IsQBitSet(QBit(109)) then -- 找到神选之药剂，并且将它带回去给匕伤岛的蓝贵德。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(191, nil, function()
    evt.SetMessage("阿尔瓦的黑暗精灵很喜欢蛇龙皮所制作的皮件。只要经过适当的处理和染色，蛇龙皮几乎和黑暗精灵的寿命一样长。")
end)

RegisterGlobalEvent(192, nil, function()
    evt.SetMessage("你每带来一份蛇龙皮，我就愿意付500个金币。")
    evt.ForPlayer(Players.All)
    if HasItem(632) then
        RemoveItem(632)
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 500)
        return
    end
    evt.SetMessage("你已经没有蛇龙皮了！你浪费了我的时间！")
end)

RegisterGlobalEvent(193, nil, function()
    evt.SetMessage("许多年以前，太阳神庙的传奇主教卡米安・特来斯对阴影塔地区的死灵法师公会掀起了一场圣战。公会靠着居住在阴影塔地区的吸血鬼帮助而击败了太阳神庙。卡米安在战斗的时候携带着牧师的圣器“日蚀”盾牌投入战场。当特来斯在最后的战役中被一名血之尊皇击毙之后，这个盾牌也跟着消失了。")
    SetQBit(QBit(127)) -- 替渡鸦海滨的拉西亚斯找到名为日蚀的盾牌。
    evt.SetNPCTopic(73, 0, 194) -- 拉西亚斯 topic 0: 日蚀
end)
RegisterCanShowTopic(193, function()
    evt._BeginCanShowTopic(193)
    local visible = true
    if IsQBitSet(QBit(128)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(194, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(516) then
        evt.SetMessage("日蚀到哪里去了？你找到之后再回来找我！")
        return
    end
    evt.SetMessage("你找到了日蚀这个盾牌了吗？神殿永远感谢你替我们找回了这个重要的神器。请带着我们的祝福继续使用这个盾牌吧！")
    evt.ForPlayer(Players.All)
    AddValue(Experience, 25000)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 2000)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(127)) -- 替渡鸦海滨的拉西亚斯找到名为日蚀的盾牌。
    ClearQBit(QBit(283))
    SetQBit(QBit(128))
    SetQBit(QBit(1550))
    evt.SetNPCTopic(73, 0, 703) -- 拉西亚斯 topic 0: 好好善用日蚀盾牌
end)

RegisterGlobalEvent(195, nil, function()
    evt.SetMessage("蜂王胶是种非常高级的美味食品！地位够高的商人几乎每餐都会享用这种美味的食品。")
end)

RegisterGlobalEvent(196, nil, function()
    evt.SetMessage("我愿意出1000个金币购买黄蜂蜂王胶！")
end)

RegisterGlobalEvent(197, nil, function()
    -- Missing legacy show message text 0
    evt.ForPlayer(Players.All)
    if HasItem(635) then
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 1000)
        evt.ForPlayer(Players.All)
        RemoveItem(635)
        return
    end
    evt.SetMessage("在你找到了黄蜂蜂王胶之后再回来找我！")
end)

RegisterGlobalEvent(198, nil, function()
    if IsQBitSet(QBit(130)) then
        evt.SetMessage("太好了！现在食人妖都已经被杀光，通往渡鸦海滨、铁沙漠和低语森林的道路又再度安全了！请收下我这5000个金币当做奖赏！")
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 5000)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 10000)
        SetAutonote(500)
        ClearQBit(QBit(129)) -- 杀死阿尔瓦峡谷地区和食人妖要塞中的所有食人妖，然后回到阿尔瓦找凯尔顿。
        evt.SetNPCTopic(76, 0, 200) -- 凯尔顿 topic 0: 又可以安全的旅行了！
        return
    elseif IsQBitSet(QBit(129)) then -- 杀死阿尔瓦峡谷地区和食人妖要塞中的所有食人妖，然后回到阿尔瓦找凯尔顿。
        evt.SetMessage("你没有杀死所有的食人妖！如果你不把他们全部都杀光，道路上就没有安全可言！")
    else
        evt.SetMessage("食人妖法师索格和他的部队就在天空出现一道白光的时候出现在这里。他们骚扰此地的居民，并且杀害想要前往阿尔瓦的旅人。如果你们可以杀死所有在附近区域和要塞里面的食人妖，这对阿尔瓦来说将是个福音。当你杀死了所有的食人妖之后，请回来找我，我会给予你适当的奖赏。")
        SetQBit(QBit(129)) -- 杀死阿尔瓦峡谷地区和食人妖要塞中的所有食人妖，然后回到阿尔瓦找凯尔顿。
    end
end)

RegisterGlobalEvent(199, nil, function()
    evt.SetMessage("我愿意付500个金币买你找来的每一个食人妖耳朵。阿尔瓦商人公会负责支付我这方面的花费。")
    evt.ForPlayer(Players.All)
    if HasItem(653) then
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 500)
        evt.ForPlayer(Players.All)
        RemoveItem(653)
        return
    end
    evt.SetMessage("如果你想要钱的话，请带食人妖耳朵来找我！")
end)

RegisterGlobalEvent(200, nil, function()
    evt.SetMessage("太好了！现在道路上的食人妖都已经被消灭了，要塞中再也没有食人妖，通往渡鸦海滨、铁沙漠和低语森林的道路又再度开放了！")
end)

RegisterGlobalEvent(201, nil, function()
    evt.SetMessage("强化运气药剂将会对任何商人来说是个不错的辅助道具。如果一个人的运气值很高，他将可以遇到各种各样的好运！把强化运气药剂的药材带来给我，我将会给你相当丰富的报酬！")
    SetQBit(QBit(115)) -- 将纯粹运气药剂所需要的药材带去给阿尔瓦的瑞汉西。
    evt.SetNPCTopic(74, 0, 0) -- 瑞汉西 topic 0 cleared
end)
RegisterCanShowTopic(201, function()
    evt._BeginCanShowTopic(201)
    local visible = true
    if IsQBitSet(QBit(115)) then -- 将纯粹运气药剂所需要的药材带去给阿尔瓦的瑞汉西。
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(202, nil, function()
    evt.SetMessage("黑色药剂是由混合许多基本的药材所获得的。红色的药材包括了柳条浆果、狼之眼、垢鬼血。蓝色的药剂包括了火凤羽、费玛根、陨石片、鬼火心。黄色药材则包括了曼陀罗、龙龟牙、罂粟茎和刺木皮。")
end)

RegisterGlobalEvent(203, nil, function()
    if not evt.CheckItemsCount(200, 204, 2) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(205, 209, 3) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(210, 214, 3) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    evt.SetMessage("太好了！只要有了这些药材，我就可以做出另外一瓶药剂来。这瓶药剂就是你的奖赏！")
    evt.RemoveItems(200, 204, 2)
    evt.RemoveItems(205, 209, 3)
    evt.RemoveItems(210, 214, 3)
    ClearQBit(QBit(115)) -- 将纯粹运气药剂所需要的药材带去给阿尔瓦的瑞汉西。
    SetQBit(QBit(116))
    AddValue(InventoryItem(264), 264)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 5000)
    evt.SetNPCTopic(74, 2, 0) -- 瑞汉西 topic 2 cleared
end)
RegisterCanShowTopic(203, function()
    evt._BeginCanShowTopic(203)
    local visible = true
    if IsQBitSet(QBit(115)) then -- 将纯粹运气药剂所需要的药材带去给阿尔瓦的瑞汉西。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(204, nil, function()
    evt.SetMessage("黄蜂刺！从治疗感冒到在草药茶里面添加味道，黄蜂刺永远都十分的好用！别相信那些贩卖双足龙角的家伙！只有黄蜂刺的效力最高最强！只要你带黄蜂刺来，我一定会付钱给你！")
end)

RegisterGlobalEvent(205, nil, function()
    evt.SetMessage("你每带一个黄蜂刺来，我就付给你500个金币！")
    evt.ForPlayer(Players.All)
    if HasItem(654) then
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 500)
        evt.ForPlayer(Players.All)
        RemoveItem(654)
        return
    end
    evt.SetMessage("我只会花钱买黄蜂刺！别的东西就别带来烦我了！")
end)

RegisterGlobalEvent(206, nil, function()
    evt.SetMessage("巨魔天性就怕火！当火焰之门打开，吐出火焰的大湖时，有许多同胞就是因为这样而牺牲！没有适当的保护，我们根本无法生存下来！")
end)

RegisterGlobalEvent(207, nil, function()
    evt.SetMessage("这一区的幸存者需要御火药剂！有了这些药剂，我们可以暂时苟延残喘，等到找到新的住所为止！收下这些药剂！不过我也只有这些药剂了！把这些药剂送到铁锈镇最南边的六座屋子去！")
    SetQBit(QBit(142)) -- 将御火药剂送到铁锈镇六个最南边的屋子里面。完成任务之后回去找铁锈镇的贺伯特。
    AddValue(InventoryItem(256), 256)
    AddValue(InventoryItem(256), 256)
    AddValue(InventoryItem(256), 256)
    evt.SetNPCTopic(84, 1, 208) -- 波尔 topic 1: 没有足够的药剂吗？
end)
RegisterCanShowTopic(207, function()
    evt._BeginCanShowTopic(207)
    local visible = true
    if IsQBitSet(QBit(149)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(208, nil, function()
    if not IsQBitSet(QBit(149)) then
        evt.SetMessage("你还没有把御火药剂送到所有的屋子里面去！如果火湖往外扩张，所有的人都会死！")
        return
    end
    evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 1500)
    evt.ForPlayer(Players.All)
    SetAutonote(499)
    ClearQBit(QBit(142)) -- 将御火药剂送到铁锈镇六个最南边的屋子里面。完成任务之后回去找铁锈镇的贺伯特。
    evt.SetNPCTopic(84, 1, 209) -- 波尔 topic 1: 这个村庄应该可以挡的住了。
end)

RegisterGlobalEvent(209, nil, function()
    evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
end)

RegisterGlobalEvent(210, nil, function()
    evt.SetMessage("耐力是让战士继续支撑的力量，至少也会让他倒下的时候不会那么的突然。强化耐力药剂可以让人的耐力大幅提升，进而承受极大的打击！把强化耐力药剂的药材带过来给我，我就会给予你适当的奖赏。")
    SetQBit(QBit(121)) -- 将纯粹耐力药剂的药材带给铁沙漠中的塔力安。
    evt.SetNPCTopic(78, 0, 212) -- 塔力安 topic 0: 你有配方吗？
end)
RegisterCanShowTopic(210, function()
    evt._BeginCanShowTopic(210)
    local visible = true
    if IsQBitSet(QBit(121)) then -- 将纯粹耐力药剂的药材带给铁沙漠中的塔力安。
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(211, nil, function()
    evt.SetMessage("黑色药剂是由混合许多基本的药材所获得的。红色的药材包括了柳条浆果、狼之眼、垢鬼血。蓝色的药剂包括了火凤羽、费玛根、陨石片、鬼火心。黄色药材则包括了曼陀罗、龙龟牙、罂粟茎和刺木皮。")
end)

RegisterGlobalEvent(212, nil, function()
    if not evt.CheckItemsCount(200, 204, 2) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(205, 209, 4) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(210, 214, 1) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    evt.SetMessage("太好了！只要有了这些药材，我就可以做出另外一瓶药剂来。这瓶药剂就是你的奖赏！")
    evt.RemoveItems(200, 204, 2)
    evt.RemoveItems(205, 209, 4)
    evt.RemoveItems(210, 214, 1)
    ClearQBit(QBit(121)) -- 将纯粹耐力药剂的药材带给铁沙漠中的塔力安。
    SetQBit(QBit(122))
    AddValue(InventoryItem(267), 267)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 5000)
    evt.SetNPCTopic(78, 2, 0) -- 塔力安 topic 2 cleared
end)
RegisterCanShowTopic(212, function()
    evt._BeginCanShowTopic(212)
    local visible = true
    if IsQBitSet(QBit(121)) then -- 将纯粹耐力药剂的药材带给铁沙漠中的塔力安。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(213, nil, function()
    evt.SetMessage("克龙之花有许多医药上的用途。它同时也拥有几种与医药并没有太大关系的用途。从这种花朵中，我们可以粹取出一种剧毒，可以有效地杀死飞龙。只要有了这种剧毒，我们应该可以很快地将此地区的飞龙通通杀死。找到这朵花，拿回来给我。我给你的奖赏不会让你失望的。")
    SetQBit(QBit(150)) -- 替绞刑峡谷的卡林最尔找一朵灭龙花。
    evt.SetNPCTopic(87, 0, 214) -- 卡林最尔 topic 0: 有毒！
end)
RegisterCanShowTopic(213, function()
    evt._BeginCanShowTopic(213)
    local visible = true
    if IsQBitSet(QBit(22)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(214, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(636) then
        evt.SetMessage("我请你帮我找克龙之花，你竟然空手回来。你干嘛要浪费我的时间？")
        return
    end
    SetQBit(QBit(151))
    ClearQBit(QBit(150)) -- 替绞刑峡谷的卡林最尔找一朵灭龙花。
    RemoveItem(636)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 1500)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 10000)
    SetAutonote(501)
    evt.SetMessage("绞刑峡谷的飞龙很容易被一种稀有的克龙之花所提炼出来的毒素杀死。但是，这种花朵同时也可以提炼出解毒药剂来。")
    evt.SetNPCTopic(87, 0, 215) -- 卡林最尔 topic 0: 多谢你的帮助！
end)

RegisterGlobalEvent(215, nil, function()
    evt.SetMessage("没错。这就是我所需要的克龙之花，一旦我们提炼出毒液来，我们就应该可以很快地消灭这些飞龙。")
end)

RegisterGlobalEvent(216, nil, function()
    evt.SetMessage("克龙之花有许多医药上的用途。它同时也拥有几种与医药并没有太大关系的用途。从这种花朵中可以粹取出一种可以有效杀死飞龙的剧毒。但这种剧毒的解毒剂也可以通过花瓣来提炼。找到这朵花，拿回来给我。我给你的奖赏不会让你失望的。")
    SetQBit(QBit(152)) -- 替绞刑峡谷龙穴中的巴力安・泪翼找一朵灭龙花。
    evt.SetNPCTopic(89, 0, 217) -- 巴力安・泪翼 topic 0: 有毒！
end)
RegisterCanShowTopic(216, function()
    evt._BeginCanShowTopic(216)
    local visible = true
    if IsQBitSet(QBit(21)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(217, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(636) then
        evt.SetMessage("我请你帮我找克龙之花，你竟然空手回来。你干嘛要浪费我的时间？")
        return
    end
    SetQBit(QBit(153))
    ClearQBit(QBit(152)) -- 替绞刑峡谷龙穴中的巴力安・泪翼找一朵灭龙花。
    RemoveItem(636)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 1500)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 10000)
    SetAutonote(502)
    evt.SetMessage("绞刑峡谷的飞龙很容易被一种稀有的克龙之花所提炼出来的毒素杀死。但是，这种花朵同时也可以提炼出解毒药剂来。")
    evt.SetNPCTopic(89, 0, 218) -- 巴力安・泪翼 topic 0: 多谢你的帮助！
end)

RegisterGlobalEvent(218, nil, function()
    evt.SetMessage("没错。这就是我所需要的克龙之花，一旦我们提炼出解毒剂来，我们就应该不会受到猎龙人所用的剧毒威胁。")
end)

RegisterGlobalEvent(219, nil, function()
    if IsQBitSet(QBit(155)) then
        ClearQBit(QBit(154)) -- 杀死所有绞刑峡谷野外的飞龙，完成任务之后去找绞刑峡谷的阿瓦龙。
        evt.SetMessage("在野外的所有飞龙都被杀死之后，我们可以进入龙穴杀死所有的飞龙了！多谢你帮助我们击败他们！")
        AddValue(Gold, 2500)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 20000)
        SetAutonote(503)
        evt.SetNPCTopic(90, 0, 220) -- 阿瓦龙 topic 0: 终于！
        return
    elseif IsQBitSet(QBit(154)) then -- 杀死所有绞刑峡谷野外的飞龙，完成任务之后去找绞刑峡谷的阿瓦龙。
        evt.SetMessage("你们没有杀光所有的飞龙。情报指出此地还有飞龙出没。在你杀光他们全部之后再回来找我。")
    else
        evt.SetMessage("你想要争取查尔斯・吉柯德的青睐？很简单，你只需要协助他对抗绞刑峡谷的飞龙。如果这个区域和龙穴里面的飞龙都被杀死了，查尔斯・吉柯德一定会对你另眼相看！当他们都死掉之后，回来找我！我会给予你相当的奖赏！")
        SetQBit(QBit(154)) -- 杀死所有绞刑峡谷野外的飞龙，完成任务之后去找绞刑峡谷的阿瓦龙。
    end
end)
RegisterCanShowTopic(219, function()
    evt._BeginCanShowTopic(219)
    local visible = true
    if IsQBitSet(QBit(22)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(220, nil, function()
    evt.SetMessage("你已经杀光了那些害虫！这就是我之前所承诺的奖赏！我会亲自跟吉柯德报告你的努力的！")
end)

RegisterGlobalEvent(221, nil, function()
    if IsQBitSet(QBit(158)) then
        evt.SetMessage("在野外的所有猎龙人都被杀死之后，我们可以进入猎龙人营地杀死所有的猎龙人了！多谢你帮助我们击败他们！")
        AddValue(Gold, 2500)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 20000)
        SetAutonote(504)
        ClearQBit(QBit(157)) -- 杀死所有绞刑峡谷野外地区的猎龙人，完成任务之后去找绞刑峡谷龙穴的杰林・炎眼。
        evt.SetNPCTopic(91, 0, 222) -- 杰林・炎眼 topic 0: 现在一切又都回复原状了！
        return
    elseif IsQBitSet(QBit(157)) then -- 杀死所有绞刑峡谷野外地区的猎龙人，完成任务之后去找绞刑峡谷龙穴的杰林・炎眼。
        evt.SetMessage("你们没有杀光所有的猎龙骑士。情报指出此地还有猎龙人出没。在你杀光他们全部之后再回来找我。")
    else
        evt.SetMessage("你想要获得达夫克劳・红斧的青睐？我们不都是一样吗？如果你能够杀死绞刑峡谷野外所有的猎龙人，我一定会在他面前提到你的功绩。我也会提供给你丰富的奖赏！")
        SetQBit(QBit(157)) -- 杀死所有绞刑峡谷野外地区的猎龙人，完成任务之后去找绞刑峡谷龙穴的杰林・炎眼。
    end
end)
RegisterCanShowTopic(221, function()
    evt._BeginCanShowTopic(221)
    local visible = true
    if IsQBitSet(QBit(21)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(222, nil, function()
    evt.SetMessage("查尔斯・吉柯德的所有猎龙人都已经死了？太好了！我们又可以再度享受绞刑峡谷的宁静了。这就是我之前承诺你的奖赏！我会立刻去参见达夫克劳，告诉他有关你的勇敢表现！")
end)

RegisterGlobalEvent(223, nil, function()
    evt.SetMessage("如果我们要击败这个地区的飞龙，一定要找回胜利之鼓。如果你替我们把胜利之鼓找回来，我会给你非常丰厚的奖赏！")
    SetQBit(QBit(160)) -- 找到传说中的胜利之鼓，完成任务之后去找绞刑峡谷的赛林姆。
    evt.SetNPCTopic(92, 0, 225) -- 赛林姆 topic 0: 鼓在哪里？
end)

RegisterGlobalEvent(224, nil, function()
    evt.SetMessage("胜利之鼓是查尔斯・吉柯德所带来的。它震耳欲聋的声音会让每只听见的飞龙心中都感到无比的恐惧。很不幸的，当查尔斯意图在这里创建营地的时候，胜利之鼓在与蛇龙的战斗中不见了。")
end)

RegisterGlobalEvent(225, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(615) then
        evt.SetMessage("在你找到胜利之鼓之后再回来找我！不要浪费你和我的时间！")
        return
    end
    evt.SetMessage("你带回了胜利之鼓！查尔斯将会非常感谢你的！这是我答应你的奖赏！")
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 1500)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(160)) -- 找到传说中的胜利之鼓，完成任务之后去找绞刑峡谷的赛林姆。
    ClearQBit(QBit(246))
    RemoveItem(615)
    AddValue(Experience, 20000)
    evt.SetNPCTopic(92, 0, 0) -- 赛林姆 topic 0 cleared
end)

RegisterGlobalEvent(226, nil, function()
    evt.SetMessage("死灵法师公会已经找了毁灭之骨好一阵子了。这个威力强大的物品将会让他们发展很多新的法术。如果你能够替我找到这样宝物，并且将它带来给我，我将会给予你梦想中最庞大的奖励！")
    SetQBit(QBit(166)) -- 替阴影塔地区的坦尼林安找到毁灭之骨。
    evt.SetNPCTopic(93, 0, 228) -- 坦尼林安 topic 0: 太好了！
end)

RegisterGlobalEvent(227, nil, function()
    evt.SetMessage("在几乎已经被众人所遗忘的过去，有一名强大的死灵法师萨查力亚几乎征服了全贾丹姆大陆。他对于黑暗类魔法和元素系魔法的研究都结合在黑暗力量的统御之下。他的不死军队协助他奴役所有的种族，包括了阿尔瓦的黑暗精灵。太阳神庙设法规划出攻击萨查力亚的战术，他们结合了太阳神庙中所有牧师的力量，创造出了一柄名为太阳圣剑的武器。神殿的大主教率领着太阳军团队抗萨查力亚的军队。这场战争持续了数年之久，最后太阳军团发现自己已经进入了恐怖的阴影塔地区。太阳神庙的主教一对一地单挑萨查力亚。在激战之后，俩人都壮烈战死了。正当萨查力亚的最后一个法术发出，让主教死亡之前，主教正好将萨查力亚的右臂给砍了下来。太阳圣剑的力量当场就杀死了萨查力亚。之后太阳圣剑和萨查力亚的右臂都同样消失在战后的混乱中。这个手臂中的骨头吸收了极为强大的黑暗力量，因此又被称作毁灭之骨。")
end)

RegisterGlobalEvent(228, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(637) then
        evt.SetMessage("我要你去找毁灭之骨，你什么也没找到！快滚！")
        return
    end
    evt.SetMessage("啊，这就是毁灭之骨！萨查力亚的传说将会继续下去！这就是你的奖赏！")
    AddValue(Gold, 1500)
    ClearQBit(QBit(166)) -- 替阴影塔地区的坦尼林安找到毁灭之骨。
    ClearQBit(QBit(247))
    evt.ForPlayer(Players.All)
    RemoveItem(637)
    AddValue(Experience, 7500)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 7500)
    evt.SetNPCTopic(93, 0, 0) -- 坦尼林安 topic 0 cleared
end)

RegisterGlobalEvent(229, nil, function()
    evt.SetMessage("有人说埃索朵的机关盒受到了诅咒，会让持有者慢慢地发疯。这绝对不是真的！我所有的研究都指出，这个机关盒是贾丹姆大陆上最好玩的游戏，那个愚蠢的魔幻牌纸牌根本不能和他比。根据情报显示，机关盒的最后一个持有者是冉索拉，也就是阴影塔地区的疯狂死灵法师。")
    SetQBit(QBit(162)) -- 替阴影塔的班耐费斯找寻机关盒。
    evt.SetNPCTopic(94, 0, 231) -- 班耐费斯 topic 0: 可以玩上好久了！
end)

RegisterGlobalEvent(230, nil, function()
    evt.SetMessage("我请你去帮我找机关盒，但是你什么都没有带回来。我也不可能给你任何奖赏。快离开吧！")
end)

RegisterGlobalEvent(231, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(613) then
        evt.SetMessage("在你找到机关盒之前我不会再和你谈话！")
        return
    end
    evt.SetMessage("机关盒是我的了！我马上就可以享受无数个小时毫无意义的娱乐！我会给予你承诺的奖赏！")
    AddValue(Gold, 1500)
    ClearQBit(QBit(162)) -- 替阴影塔的班耐费斯找寻机关盒。
    ClearQBit(QBit(249))
    evt.ForPlayer(Players.All)
    RemoveItem(613)
    AddValue(Experience, 15000)
    evt.SetNPCTopic(94, 0, 0) -- 班耐费斯 topic 0 cleared
end)

RegisterGlobalEvent(232, nil, function()
    evt.SetMessage("死灵法师最大的能力就是他的智力！如果没有足够的智力，死灵法师可能会在最需要法力的时候却没有足够的魔法值！如果你能够把强化智力的药剂所需要的药材带来给我，我会把调配出来的药剂送给你！")
    SetQBit(QBit(123)) -- 将纯粹智力药剂所需要的药材带去给阴影塔地区的凯尔文。
    evt.SetNPCTopic(83, 0, 0) -- 凯尔文 topic 0 cleared
end)
RegisterCanShowTopic(232, function()
    evt._BeginCanShowTopic(232)
    local visible = true
    if IsQBitSet(QBit(123)) then -- 将纯粹智力药剂所需要的药材带去给阴影塔地区的凯尔文。
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(233, nil, function()
    evt.SetMessage("数世纪以前，死灵法师公会和太阳神庙之间最大的战役就在此地进行！当时释放出的魔力大到把此地烤成焦黑，直到今天都没有恢复。")
end)

RegisterGlobalEvent(234, nil, function()
    if not evt.CheckItemsCount(200, 204, 1) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(205, 209, 2) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(210, 214, 4) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    evt.SetMessage("你已经遵照协议把药剂的药材带了回来。这是我承诺你的强化智力药剂。")
    evt.RemoveItems(200, 204, 1)
    evt.RemoveItems(205, 209, 2)
    evt.RemoveItems(210, 214, 4)
    ClearQBit(QBit(123)) -- 将纯粹智力药剂所需要的药材带去给阴影塔地区的凯尔文。
    SetQBit(QBit(124))
    AddValue(InventoryItem(266), 266)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 5000)
    evt.SetNPCTopic(83, 2, 0) -- 凯尔文 topic 2 cleared
end)
RegisterCanShowTopic(234, function()
    evt._BeginCanShowTopic(234)
    local visible = true
    if IsQBitSet(QBit(123)) then -- 将纯粹智力药剂所需要的药材带去给阴影塔地区的凯尔文。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(235, nil, function()
    evt.SetMessage("我们想要让一个叫做可布的血之尊皇安息。我们听说阴影塔地区的吸血鬼想要让这个远谷的邪恶复活。在阴影塔地区有一个吸血鬼墓窖，里面有一个坟土之瓶，必须要有这个物品才能够让可布复活。替我们找到这个瓶子，把它带回来给我们。我们会永远感激你，并且给予你适当的奖赏！")
    SetQBit(QBit(164)) -- 找到墓土之瓶，完成任务之后去找阴影塔地区的海林安。
    evt.SetNPCTopic(95, 0, 237) -- 海林安 topic 0: 你拿到装土的瓶子了吗？
end)

RegisterGlobalEvent(236, nil, function()
    evt.SetMessage("可布四处散布他墓窖中的泥土，以防万一。如此他就可以随时接触自己坟墓中的泥土，并且随时迁移自己的墓穴。")
end)

RegisterGlobalEvent(237, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(614) then
        evt.SetMessage("坟土之瓶呢？在你找到它之前别回来找我！")
        return
    end
    evt.SetMessage("啊，一旦我们对这坟土执行了净化之仪式，可布就会永远地安息了。我们非常感激你，这是答应你的奖赏！")
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 1500)
    evt.ForPlayer(Players.All)
    RemoveItem(614)
    ClearQBit(QBit(164)) -- 找到墓土之瓶，完成任务之后去找阴影塔地区的海林安。
    ClearQBit(QBit(248))
    AddValue(Experience, 22000)
    evt.SetNPCTopic(95, 0, 0) -- 海林安 topic 0 cleared
end)

RegisterGlobalEvent(238, nil, function()
    evt.SetMessage("个性是牧师最重要的力量。如果你能够提供给我强化个性药剂的药材，我将会替你酿制这药剂！把药材带来给我吧！")
    SetQBit(QBit(125)) -- 将纯粹个性药剂的药材带给低语森林的卡斯提盖尔。
    evt.SetNPCTopic(88, 0, 0) -- 卡斯提盖尔 topic 0 cleared
end)
RegisterCanShowTopic(238, function()
    evt._BeginCanShowTopic(238)
    local visible = true
    if IsQBitSet(QBit(125)) then -- 将纯粹个性药剂的药材带给低语森林的卡斯提盖尔。
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(239, nil, function()
    evt.SetMessage("黑色药剂是由混合许多基本的药材所获得的。红色的药材包括了柳条浆果、狼之眼、垢鬼血。蓝色的药剂包括了火凤羽、费玛根、陨石片、鬼火心。黄色药材则包括了曼陀罗、龙龟牙、罂粟茎和刺木皮。")
end)

RegisterGlobalEvent(240, nil, function()
    if not evt.CheckItemsCount(200, 204, 1) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(205, 209, 4) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(210, 214, 2) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    evt.SetMessage("啊，你的运气真不错！这是我承诺你的药剂！")
    evt.RemoveItems(200, 204, 1)
    evt.RemoveItems(205, 209, 4)
    evt.RemoveItems(210, 214, 2)
    ClearQBit(QBit(125)) -- 将纯粹个性药剂的药材带给低语森林的卡斯提盖尔。
    SetQBit(QBit(126))
    AddValue(InventoryItem(268), 268)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 5000)
    evt.SetNPCTopic(88, 2, 0) -- 卡斯提盖尔 topic 2 cleared
end)
RegisterCanShowTopic(240, function()
    evt._BeginCanShowTopic(240)
    local visible = true
    if IsQBitSet(QBit(125)) then -- 将纯粹个性药剂的药材带给低语森林的卡斯提盖尔。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(241, nil, function()
    evt.SetMessage("双足翼龙是贾丹姆大陆上四处乱跑的生物中最强悍的对手。远古双足翼龙甚至可以一击杀害最强壮的冒险者。远古双足翼龙的角据说拥有非常多的医药和魔法上的妙用。如果你能够弄到双足翼龙之角，会有许多人愿意支付不小的赏金。")
end)

RegisterGlobalEvent(242, nil, function()
    evt.SetMessage("我愿意付1500个金币！我会把这些角磨碎，卖给全贾丹姆大陆需要的人。我希望有一天能够将这些东西卖到恩洛斯和埃拉西亚去。当然，雷格那海盗也是很大的问题。")
    evt.SetNPCTopic(85, 1, 243) -- 夕维恶斯 topic 1: 1500个金币！
end)

RegisterGlobalEvent(243, nil, function()
    evt.SetMessage("这是给你的1500个金币！")
    evt.ForPlayer(Players.All)
    if HasItem(640) then
        evt.ForPlayer(Players.Member0)
        AddValue(Gold, 500)
        evt.ForPlayer(Players.All)
        RemoveItem(640)
        return
    end
    evt.SetMessage("当你找到更多的双足翼龙角的时候，我会付给你更多的金币！")
end)

RegisterGlobalEvent(244, nil, function()
    evt.SetMessage("精确可以决定在战斗中谁生谁死。如果你不能够击中你的对手，你一定会死的！如果你可以把强化精确药剂所需要的药材带来给我，我就可以替你作出一瓶药剂来。")
    SetQBit(QBit(133))
    evt.SetNPCTopic(77, 0, 0) -- 加文那斯 topic 0 cleared
end)
RegisterCanShowTopic(244, function()
    evt._BeginCanShowTopic(244)
    local visible = true
    if IsQBitSet(QBit(133)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(245, nil, function()
    evt.SetMessage("黑色药剂是由混合许多基本的药材所获得的。红色的药材包括了柳条浆果、狼之眼、垢鬼血。蓝色的药剂包括了火凤羽、费玛根、陨石片、鬼火心。黄色药材则包括了曼陀罗、龙龟牙、罂粟茎和刺木皮。")
end)

RegisterGlobalEvent(246, nil, function()
    if not evt.CheckItemsCount(200, 204, 2) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(205, 209, 1) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    if not evt.CheckItemsCount(210, 214, 4) then
        evt.SetMessage("你的药材没有找全，当你找齐药材之后再来找我吧！")
        return
    end
    evt.SetMessage("啊，药材正确就可以有正确的效果！这是你需要的药剂。")
    evt.RemoveItems(200, 204, 2)
    evt.RemoveItems(205, 209, 1)
    evt.RemoveItems(210, 214, 4)
    ClearQBit(QBit(133))
    SetQBit(QBit(134))
    AddValue(InventoryItem(269), 269)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 5000)
    evt.SetNPCTopic(77, 2, 0) -- 加文那斯 topic 2 cleared
end)
RegisterCanShowTopic(246, function()
    evt._BeginCanShowTopic(246)
    local visible = true
    if IsQBitSet(QBit(133)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(247, nil, function()
    evt.SetMessage("谣传伟大的海盗史坦力从阿尔瓦的商人公会手中偷走了数以百万计的金币。从来没有人能够找到他收藏钱财的地方。有些人说，他甚至没有把这些钱藏在雷格那岛上。")
end)

RegisterGlobalEvent(248, nil, function()
    evt.SetMessage("很多很多年以前，我记得听说过史坦力曾经到残破镇去和食人妖法师索格讨论他所中的一个诅咒。很明显地，他的记忆已在逐渐减退，一定是某位邪恶的法师对他下的诅咒吧！")
end)

RegisterGlobalEvent(249, nil, function()
    if not IsQBitSet(QBit(168)) then
        evt.SetMessage("你还没有找到恐怖海盗史坦力的宝藏！")
        SetQBit(QBit(236)) -- 找到恐怖海盗史坦力的宝藏。
        return
    end
    AddValue(Experience, 15500)
    evt.SetMessage("找到恐怖海盗史坦力宝藏的家伙将会是个富有的人，那个人会是你吗？")
    ClearQBit(QBit(236)) -- 找到恐怖海盗史坦力的宝藏。
    evt.SetNPCTopic(96, 0, 0) -- 独眼 topic 0 cleared
end)

RegisterGlobalEvent(250, nil, function()
    evt.SetMessage("只有匕伤群岛会出产托伯斯克果。在此地，温和的冬天和潮湿的夏天让托伯斯克果可以成长到拥有足够的甜度和汁液。渡鸦海滨的商人愿意付重金来购买托伯斯克果。")
    ClearQBit(QBit(251))
    if IsAtLeast(Gold, 200) then
        if not IsAtLeast(Gold, 200) then
            return
        end
        SubtractValue(Gold, 200)
        AddValue(InventoryItem(643), 643)
        SetQBit(QBit(250))
        SetQBit(QBit(259))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(250, function()
    evt._BeginCanShowTopic(250)
    local visible = true
    if IsQBitSet(QBit(252)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(259)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(251, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(645) then return end
    evt.SetMessage("托伯斯克酒是匕伤群岛上蜥蜴人最喜欢的饮料。有些人认为这种饮料味道相当不错。不管如何，这种饮料都很有利润！")
    RemoveItem(645)
    ClearQBit(QBit(261))
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 557)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 589)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 511)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 577)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 513)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 544)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 511)
        return
    else
        return
    end
end)

RegisterGlobalEvent(252, nil, function()
    evt.SetMessage("托伯斯克果是在渡鸦海滨处理成托伯斯克果汁。阿尔瓦的商人会从这些果汁中提炼出酒来。")
    ClearQBit(QBit(250))
    if IsAtLeast(Gold, 300) then
        if not IsAtLeast(Gold, 300) then
            return
        end
        SubtractValue(Gold, 300)
        AddValue(InventoryItem(644), 644)
        SetQBit(QBit(251))
        SetQBit(QBit(260))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(252, function()
    evt._BeginCanShowTopic(252)
    local visible = true
    if IsQBitSet(QBit(250)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(260)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(253, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(643) then return end
    evt.SetMessage("只有此地会出产托伯斯克果。在此地，温和的冬天和潮湿的夏天让托伯斯克果可以成长到拥有足够的甜度和汁液。渡鸦海滨的商人愿意付重金来购买托伯斯克果，并且处理成托伯斯克果汁。")
    RemoveItem(643)
    ClearQBit(QBit(259))
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 261)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 286)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 237)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 255)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 294)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 273)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 244)
        return
    else
        return
    end
end)

RegisterGlobalEvent(254, nil, function()
    evt.SetMessage("托伯斯克酒是匕伤群岛上蜥蜴人最喜欢的饮料。有些人认为这种饮料味道相当不错。不管如何，这种饮料都很有利润！在你回到岛上的旅程中要小心携带这些瓶子喔！")
    ClearQBit(QBit(251))
    if IsAtLeast(Gold, 500) then
        if not IsAtLeast(Gold, 500) then
            return
        end
        SubtractValue(Gold, 500)
        AddValue(InventoryItem(645), 645)
        SetQBit(QBit(252))
        SetQBit(QBit(261))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(254, function()
    evt._BeginCanShowTopic(254)
    local visible = true
    if IsQBitSet(QBit(251)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(261)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(255, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(644) then return end
    evt.SetMessage("托伯斯克果汁必须和阿尔瓦的水混合，慢慢地发酵出酒精，直到酒窖主人认为这过程已经完成为止。")
    RemoveItem(644)
    ClearQBit(QBit(260))
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 394)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 341)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 351)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 337)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 373)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 355)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 386)
        return
    else
        return
    end
end)

RegisterGlobalEvent(256, nil, function()
    evt.SetMessage("贾丹姆之心木是阴影塔地区的吸血鬼用来建造棺材的原料。心木的坚固材质可以让棺材的主人在白天获得充足的休息，并且可以耐用许多年。")
    ClearQBit(QBit(255))
    if IsAtLeast(Gold, 1000) then
        if not IsAtLeast(Gold, 1000) then
            return
        end
        SubtractValue(Gold, 1000)
        AddValue(InventoryItem(646), 646)
        SetQBit(QBit(253))
        SetQBit(QBit(262))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(256, function()
    evt._BeginCanShowTopic(256)
    local visible = true
    if IsQBitSet(QBit(255)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(262)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(257, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(648) then return end
    evt.SetMessage("风干翻车鱼是太阳神庙的牧师们非常喜爱的美食。他们愿意为了这种有些干扁的咸鱼付相当多的钱。")
    RemoveItem(648)
    ClearQBit(QBit(264))
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 2234)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 2267)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 2250)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 2291)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 2244)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 2285)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 2273)
        return
    else
        return
    end
end)

RegisterGlobalEvent(258, nil, function()
    evt.SetMessage("雷格那的海盗喜欢廉价的珠宝！无法接受死灵法师祝福的护身符正好满足了这个需求。海盗们会付相当多的金钱来购买这些护身符。")
    ClearQBit(QBit(253))
    if IsAtLeast(Gold, 1500) then
        if not IsAtLeast(Gold, 1500) then
            return
        end
        SubtractValue(Gold, 1500)
        AddValue(InventoryItem(647), 647)
        SetQBit(QBit(254))
        SetQBit(QBit(263))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(258, function()
    evt._BeginCanShowTopic(258)
    local visible = true
    if IsQBitSet(QBit(253)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(263)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(259, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(646) then return end
    evt.SetMessage("贾丹姆之心木是阴影塔地区的吸血鬼用来建造棺材的原料。心木的坚固材质可以让棺材的主人在白天获得充足的休息，并且可以耐用许多年。")
    RemoveItem(646)
    ClearQBit(QBit(262))
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 1761)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 1786)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 1637)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 1655)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 1794)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 1773)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 1744)
        return
    else
        return
    end
end)

RegisterGlobalEvent(260, nil, function()
    evt.SetMessage("风干翻车鱼是太阳神庙的牧师们非常喜爱的美食。他们愿意为了这种有些干扁的咸鱼付相当多的钱。")
    ClearQBit(QBit(254))
    if IsAtLeast(Gold, 2000) then
        if not IsAtLeast(Gold, 2000) then
            return
        end
        SubtractValue(Gold, 2000)
        AddValue(InventoryItem(648), 648)
        SetQBit(QBit(255))
        SetQBit(QBit(264))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(260, function()
    evt._BeginCanShowTopic(260)
    local visible = true
    if IsQBitSet(QBit(254)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(264)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(261, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(647) then return end
    evt.SetMessage("雷格那的海盗喜欢廉价的珠宝！无法接受死灵法师祝福的护身符正好满足了这个需求。海盗们会付相当多的金钱来购买这些护身符。")
    RemoveItem(647)
    ClearQBit(QBit(263))
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 1994)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 2041)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 2051)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 2037)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 1973)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 1955)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 2086)
        return
    else
        return
    end
end)

RegisterGlobalEvent(262, nil, function()
    evt.SetMessage("死灵法师所制造的海之银尘有相当大的需求。渡鸦海滨的私枭们会利用这种东西来隐藏他们的船只，这可以提供一段时间的隐形。")
    ClearQBit(QBit(267))
    if IsAtLeast(Gold, 5000) then
        if not IsAtLeast(Gold, 5000) then
            return
        end
        SubtractValue(Gold, 5000)
        AddValue(InventoryItem(649), 649)
        SetQBit(QBit(253))
        SetQBit(QBit(262))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(262, function()
    evt._BeginCanShowTopic(262)
    local visible = true
    if IsQBitSet(QBit(258)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(265)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(263, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(651) then return end
    evt.SetMessage("地面双足翼龙角据说是死灵法师所最需要的药材。这和炼金术士所使用的药材不一样，只有死灵法师公会中最高级的成员才能够使用这种药材。")
    RemoveItem(651)
    ClearQBit(QBit(267))
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 8234)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 8267)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 8250)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 8291)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 8244)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 8285)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 8273)
        return
    else
        return
    end
end)

RegisterGlobalEvent(264, nil, function()
    evt.SetMessage("食人妖法师索格的属下所用的伪造凭证可以从阿尔瓦商人手中领到一些金钱。")
    ClearQBit(QBit(265))
    if IsAtLeast(Gold, 6500) then
        if not IsAtLeast(Gold, 6500) then
            return
        end
        SubtractValue(Gold, 6500)
        AddValue(InventoryItem(650), 650)
        SetQBit(QBit(257))
        SetQBit(QBit(266))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(264, function()
    evt._BeginCanShowTopic(264)
    local visible = true
    if IsQBitSet(QBit(256)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(266)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(265, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(649) then return end
    evt.SetMessage("死灵法师所制造的海之银尘有相当大的需求。渡鸦海滨的私枭们会利用这种东西来隐藏他们的船只，这可以提供一段时间的隐形。")
    RemoveItem(649)
    ClearQBit(QBit(265))
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 6261)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 6286)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 6237)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 6255)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 6294)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 6273)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 6244)
        return
    else
        return
    end
end)

RegisterGlobalEvent(266, nil, function()
    evt.SetMessage("地面双足翼龙角据说是死灵法师所最需要的药材。这和炼金术士所使用的药材不一样，只有死灵法师公会中最高级的成员才能够使用这种药材。")
    ClearQBit(QBit(266))
    if IsAtLeast(Gold, 7500) then
        if not IsAtLeast(Gold, 7500) then
            return
        end
        SubtractValue(Gold, 7500)
        AddValue(InventoryItem(651), 651)
        SetQBit(QBit(258))
        SetQBit(QBit(267))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(266, function()
    evt._BeginCanShowTopic(266)
    local visible = true
    if IsQBitSet(QBit(257)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(267)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(267, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(650) then return end
    evt.SetMessage("食人妖法师索格的属下所用的伪造凭证可以从阿尔瓦商人手中领到一些金钱。")
    RemoveItem(650)
    ClearQBit(QBit(266))
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 7294)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 7241)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 7251)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 7237)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 7273)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 7255)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 7286)
        return
    else
        return
    end
end)

RegisterGlobalEvent(268, nil, function()
    evt.StatusText("空酒桶")
end)

RegisterGlobalEvent(269, nil, function()
    evt.StatusText("力量值永久增加2点")
    AddValue(BaseMight, 2)
    SetAutonote(17)
    evt.ChangeEvent(268)
end)

RegisterGlobalEvent(270, nil, function()
    evt.StatusText("精确值永久增加2点")
    AddValue(BaseAccuracy, 2)
    SetAutonote(21)
    evt.ChangeEvent(268)
end)

RegisterGlobalEvent(271, nil, function()
    evt.StatusText("个性值永久增加2点")
    AddValue(BasePersonality, 2)
    SetAutonote(19)
    evt.ChangeEvent(268)
end)

RegisterGlobalEvent(272, nil, function()
    evt.StatusText("智力值永久增加2点")
    AddValue(BaseIntellect, 2)
    SetAutonote(18)
    evt.ChangeEvent(268)
end)

RegisterGlobalEvent(273, nil, function()
    evt.StatusText("耐力值永久增加2点")
    AddValue(BaseEndurance, 2)
    SetAutonote(20)
    evt.ChangeEvent(268)
end)

RegisterGlobalEvent(274, nil, function()
    evt.StatusText("速度值永久增加2点")
    AddValue(BaseSpeed, 2)
    SetAutonote(22)
    evt.ChangeEvent(268)
end)

RegisterGlobalEvent(275, nil, function()
    evt.StatusText("运气值永久增加2点")
    AddValue(BaseLuck, 2)
    SetAutonote(23)
    evt.ChangeEvent(268)
end)

RegisterGlobalEvent(276, nil, function()
    evt.StatusText("空锅")
end)

RegisterGlobalEvent(277, nil, function()
    evt.StatusText("火系抗性永久增加2点")
    AddValue(FireResistance, 2)
    SetAutonote(24)
    evt.ChangeEvent(276)
end)

RegisterGlobalEvent(278, nil, function()
    evt.StatusText("水系抗性永久增加2点")
    AddValue(WaterResistance, 2)
    SetAutonote(25)
    evt.ChangeEvent(276)
end)

RegisterGlobalEvent(279, nil, function()
    evt.StatusText("风系抗性永久增加2点")
    AddValue(AirResistance, 2)
    SetAutonote(26)
    evt.ChangeEvent(276)
end)

RegisterGlobalEvent(280, nil, function()
    evt.StatusText("土系抗性永久增加2点")
    AddValue(EarthResistance, 2)
    SetAutonote(27)
    evt.ChangeEvent(276)
end)

RegisterGlobalEvent(281, nil, function()
    local randomStep = PickRandomOption(281, 1, {1, 6, 11})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(1, ItemType.Armor_)
    elseif randomStep == 6 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("这儿没什么东西")
        end
        evt.GiveItem(2, ItemType.Armor_)
    elseif randomStep == 11 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedRed, 0)
            evt.StatusText("中毒了！")
        end
        evt.GiveItem(3, ItemType.Armor_)
    end
    evt.ChangeEvent(284)
end)

RegisterGlobalEvent(282, nil, function()
    local randomStep = PickRandomOption(282, 1, {1, 6, 11})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(1, ItemType.Weapon_)
    elseif randomStep == 6 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("这儿没什么东西")
        end
        evt.GiveItem(2, ItemType.Weapon_)
    elseif randomStep == 11 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedRed, 0)
            evt.StatusText("中毒了！")
        end
        evt.GiveItem(3, ItemType.Weapon_)
    end
    evt.ChangeEvent(284)
end)

RegisterGlobalEvent(283, nil, function()
    local randomStep = PickRandomOption(283, 1, {1, 6, 11})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(1, ItemType.Misc)
    elseif randomStep == 6 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("这儿没什么东西")
        end
        evt.GiveItem(2, ItemType.Misc)
    elseif randomStep == 11 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedRed, 0)
            evt.StatusText("中毒了！")
        end
        evt.GiveItem(3, ItemType.Misc)
    end
    evt.ChangeEvent(284)
end)

RegisterGlobalEvent(284, nil, function()
    local randomStep = PickRandomOption(284, 1, {1, 5})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
            return
        end
        evt.StatusText("这儿没什么东西")
    elseif randomStep == 5 then
        evt.StatusText("这儿没什么东西")
    end
end)

RegisterGlobalEvent(285, nil, function()
    local randomStep = PickRandomOption(285, 1, {1, 4, 7})
    if randomStep == 1 then
        AddValue(Food, 3)
        evt.ChangeEvent(0)
        return
    elseif randomStep == 4 then
        AddValue(Food, 2)
        evt.ChangeEvent(0)
        return
    elseif randomStep == 7 then
        AddValue(Food, 1)
        evt.ChangeEvent(0)
        return
    end
end)

RegisterGlobalEvent(286, nil, function()
    local randomStep = PickRandomOption(286, 1, {1, 4, 7})
    if randomStep == 1 then
        AddValue(Food, 4)
        evt.ChangeEvent(0)
        return
    elseif randomStep == 4 then
        AddValue(Food, 3)
        evt.ChangeEvent(0)
        return
    elseif randomStep == 7 then
        AddValue(Food, 2)
        evt.ChangeEvent(0)
        return
    end
end)

RegisterGlobalEvent(287, nil, function()
    AddValue(InventoryItem(655), 655)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(288, nil, function()
    evt.StatusText("空桶")
end)

RegisterGlobalEvent(289, nil, function()
    local randomStep = PickRandomOption(289, 1, {1, 1, 1, 8, 8, 8})
    if randomStep == 1 then
        local randomStep = PickRandomOption(289, 2, {2, 2, 2, 5, 5, 5})
        if randomStep == 2 then
            SetValue(PoisonedYellow, 0)
            evt.StatusText("中毒了！")
        elseif randomStep == 5 then
            SetValue(PoisonedGreen, 0)
            evt.StatusText("喝醉了！")
        end
    elseif randomStep == 8 then
        local randomStep = PickRandomOption(289, 9, {9, 9, 11, 11, 13, 15})
        if randomStep == 9 then
            AddValue(InventoryItem(202), 202)
        elseif randomStep == 11 then
            AddValue(InventoryItem(210), 210)
        elseif randomStep == 13 then
            AddValue(InventoryItem(212), 212)
        elseif randomStep == 15 then
            AddValue(InventoryItem(218), 218)
        end
    end
    evt.ChangeEvent(288)
end)

RegisterGlobalEvent(290, nil, function()
    if IsQBitSet(QBit(108)) then
        evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
        return
    elseif IsQBitSet(QBit(102)) then
        evt.SetMessage("多谢你给我这个卷轴，但此地的其它人并还没有好！请记得把这些卷轴也送给其它有黄热病的人们！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(373) then
            evt.SetMessage("我病的很重，如果没有治愈疾病的卷轴，我一定会因为黄热病而死的！")
            return
        end
        RemoveItem(373)
        SetQBit(QBit(102))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 250)
        if IsQBitSet(QBit(102)) then
            if IsQBitSet(QBit(103)) then
                if IsQBitSet(QBit(104)) then
                    if IsQBitSet(QBit(105)) then
                        if IsQBitSet(QBit(106)) then
                            if IsQBitSet(QBit(107)) then
                                evt.ForPlayer(Players.All)
                                AddValue(Experience, 1500)
                                evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
                                SetQBit(QBit(108))
                                return
                            end
                        end
                    end
                end
            end
        end
        evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
    end
end)
RegisterCanShowTopic(290, function()
    evt._BeginCanShowTopic(290)
    local visible = true
    if IsQBitSet(QBit(101)) then -- 将治愈疾病的卷轴送到匕伤岛外围群岛的六个小屋中。接着回到匕伤岛上去找埃斯蓝。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(291, nil, function()
    if IsQBitSet(QBit(108)) then
        evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
        return
    elseif IsQBitSet(QBit(103)) then
        evt.SetMessage("多谢你给我这个卷轴，但此地的其它人并还没有好！请记得把这些卷轴也送给其它有黄热病的人们！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(373) then
            evt.SetMessage("我病的很重，如果没有治愈疾病的卷轴，我一定会因为黄热病而死的！")
            return
        end
        RemoveItem(373)
        SetQBit(QBit(103))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 250)
        if IsQBitSet(QBit(103)) then
            if IsQBitSet(QBit(102)) then
                if IsQBitSet(QBit(104)) then
                    if IsQBitSet(QBit(105)) then
                        if IsQBitSet(QBit(106)) then
                            if IsQBitSet(QBit(107)) then
                                evt.ForPlayer(Players.All)
                                AddValue(Experience, 1500)
                                evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
                                SetQBit(QBit(108))
                                return
                            end
                        end
                    end
                end
            end
        end
        evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
    end
end)
RegisterCanShowTopic(291, function()
    evt._BeginCanShowTopic(291)
    local visible = true
    if IsQBitSet(QBit(101)) then -- 将治愈疾病的卷轴送到匕伤岛外围群岛的六个小屋中。接着回到匕伤岛上去找埃斯蓝。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(292, nil, function()
    if IsQBitSet(QBit(108)) then
        evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
        return
    elseif IsQBitSet(QBit(104)) then
        evt.SetMessage("多谢你给我这个卷轴，但此地的其它人并还没有好！请记得把这些卷轴也送给其它有黄热病的人们！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(373) then
            evt.SetMessage("我病的很重，如果没有治愈疾病的卷轴，我一定会因为黄热病而死的！")
            return
        end
        RemoveItem(373)
        SetQBit(QBit(104))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 250)
        if IsQBitSet(QBit(104)) then
            if IsQBitSet(QBit(102)) then
                if IsQBitSet(QBit(103)) then
                    if IsQBitSet(QBit(105)) then
                        if IsQBitSet(QBit(106)) then
                            if IsQBitSet(QBit(107)) then
                                evt.ForPlayer(Players.All)
                                AddValue(Experience, 1500)
                                evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
                                SetQBit(QBit(108))
                                return
                            end
                        end
                    end
                end
            end
        end
        evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
    end
end)
RegisterCanShowTopic(292, function()
    evt._BeginCanShowTopic(292)
    local visible = true
    if IsQBitSet(QBit(101)) then -- 将治愈疾病的卷轴送到匕伤岛外围群岛的六个小屋中。接着回到匕伤岛上去找埃斯蓝。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(293, nil, function()
    if IsQBitSet(QBit(108)) then
        evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
        return
    elseif IsQBitSet(QBit(105)) then
        evt.SetMessage("多谢你给我这个卷轴，但此地的其它人并还没有好！请记得把这些卷轴也送给其它有黄热病的人们！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(373) then
            evt.SetMessage("我病的很重，如果没有治愈疾病的卷轴，我一定会因为黄热病而死的！")
            return
        end
        RemoveItem(373)
        SetQBit(QBit(105))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 250)
        if IsQBitSet(QBit(105)) then
            if IsQBitSet(QBit(102)) then
                if IsQBitSet(QBit(103)) then
                    if IsQBitSet(QBit(104)) then
                        if IsQBitSet(QBit(106)) then
                            if IsQBitSet(QBit(107)) then
                                evt.ForPlayer(Players.All)
                                AddValue(Experience, 1500)
                                evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
                                SetQBit(QBit(108))
                                return
                            end
                        end
                    end
                end
            end
        end
        evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
    end
end)
RegisterCanShowTopic(293, function()
    evt._BeginCanShowTopic(293)
    local visible = true
    if IsQBitSet(QBit(101)) then -- 将治愈疾病的卷轴送到匕伤岛外围群岛的六个小屋中。接着回到匕伤岛上去找埃斯蓝。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(294, nil, function()
    if IsQBitSet(QBit(108)) then
        evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
        return
    elseif IsQBitSet(QBit(106)) then
        evt.SetMessage("多谢你给我这个卷轴，但此地的其它人并还没有好！请记得把这些卷轴也送给其它有黄热病的人们！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(373) then
            evt.SetMessage("我病的很重，如果没有治愈疾病的卷轴，我一定会因为黄热病而死的！")
            return
        end
        RemoveItem(373)
        SetQBit(QBit(106))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 250)
        if IsQBitSet(QBit(106)) then
            if IsQBitSet(QBit(102)) then
                if IsQBitSet(QBit(103)) then
                    if IsQBitSet(QBit(104)) then
                        if IsQBitSet(QBit(105)) then
                            if IsQBitSet(QBit(107)) then
                                evt.ForPlayer(Players.All)
                                AddValue(Experience, 1500)
                                evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
                                SetQBit(QBit(108))
                                return
                            end
                        end
                    end
                end
            end
        end
        evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
    end
end)
RegisterCanShowTopic(294, function()
    evt._BeginCanShowTopic(294)
    local visible = true
    if IsQBitSet(QBit(101)) then -- 将治愈疾病的卷轴送到匕伤岛外围群岛的六个小屋中。接着回到匕伤岛上去找埃斯蓝。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(295, nil, function()
    if IsQBitSet(QBit(108)) then
        evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
        return
    elseif IsQBitSet(QBit(107)) then
        evt.SetMessage("多谢你给我这个卷轴，但此地的其它人并还没有好！请记得把这些卷轴也送给其它有黄热病的人们！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(373) then
            evt.SetMessage("我病的很重，如果没有治愈疾病的卷轴，我一定会因为黄热病而死的！")
            return
        end
        RemoveItem(373)
        SetQBit(QBit(107))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 250)
        if IsQBitSet(QBit(107)) then
            if IsQBitSet(QBit(102)) then
                if IsQBitSet(QBit(103)) then
                    if IsQBitSet(QBit(104)) then
                        if IsQBitSet(QBit(105)) then
                            if IsQBitSet(QBit(106)) then
                                evt.ForPlayer(Players.All)
                                AddValue(Experience, 1500)
                                evt.SetMessage("黄热病的流行已经结束了！多谢你的帮助！")
                                SetQBit(QBit(108))
                                return
                            end
                        end
                    end
                end
            end
        end
        evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
    end
end)
RegisterCanShowTopic(295, function()
    evt._BeginCanShowTopic(295)
    local visible = true
    if IsQBitSet(QBit(101)) then -- 将治愈疾病的卷轴送到匕伤岛外围群岛的六个小屋中。接着回到匕伤岛上去找埃斯蓝。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(296, nil, function()
    evt.SetMessage("我的兄弟罗特奈克斯还活着！你又把岩石传送门修好了？！我一定要赶快回到家去，这样我们才可以计划家族未来要如何生存！")
    SetQBit(QBit(138))
    evt.MoveNPC(70, 776) -- 利舌埃斯瑞克 -> 罗特奈克斯的屋子
    evt.SetNPCTopic(70, 0, 297) -- 利舌埃斯瑞克 topic 0: 再次谢谢你！
end)

RegisterGlobalEvent(297, nil, function()
end)
RegisterCanShowTopic(297, function()
    evt._BeginCanShowTopic(297)
    local visible = true
    if IsQBitSet(QBit(134)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(298, nil, function()
    evt.SetMessage("你是新来的吗？告诉艾瑞安・韩特，请他下次派比较称头一点的人来！把报告给我，快滚！你让我想吐了！")
    ClearQBit(QBit(117)) -- 将假的报告带回去给雷格那岛上的海盗休息站酒吧给恐怖海盗史坦力。
    evt.ForPlayer(Players.All)
    RemoveItem(602)
    SetQBit(QBit(1554))
    ClearQBit(QBit(282))
    AddValue(Experience, 20000)
    evt.ForPlayer(Players.Member0)
    AddValue(Gold, 15000)
    evt.SetNPCTopic(108, 0, 0) -- 恐怖海盗史坦力 topic 0 cleared
    evt.MoveNPC(108, 0) -- 恐怖海盗史坦力 -> removed
end)
RegisterCanShowTopic(298, function()
    evt._BeginCanShowTopic(298)
    local visible = true
    if IsQBitSet(QBit(117)) then -- 将假的报告带回去给雷格那岛上的海盗休息站酒吧给恐怖海盗史坦力。
        if HasItem(602) then
            visible = true
            return visible
        else
            visible = false
            return visible
        end
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(299, nil, function()
    if not IsQBitSet(QBit(57)) then
        evt.SetMessage("谁知道贾丹姆大陆现在面对什么样的命运？也许你可以让我们免于毁灭的命运？")
        return
    end
    evt.SetMessage("贾丹姆大陆非常感激你！你已经让我们的世界脱离了彻底毁灭的厄运！")
end)

RegisterGlobalEvent(417, nil, function()
    evt.SetMessage("你可以在渡鸦海滨这座城市中从普多・泰恩处学到专家级的手杖技能。他曾经是是最有潜力的学生之一。")
    SetAutonote(89)
end)

RegisterGlobalEvent(418, nil, function()
    evt.SetMessage("铁锈镇的赛丽雅・斯通是手杖技能的大师，如果你想要的话，她可以教导你有关手杖技能的许多特殊技巧。巨魔的铁锈镇位于铁沙漠中。")
    SetAutonote(90)
end)

RegisterGlobalEvent(419, nil, function()
    evt.SetMessage("宗师级的手杖技能导师崔斯坦・史帝尔瓦特在阴影塔地区的黎明城中。如果你想要获得有关手杖这种武器的宗师级知识，只有他能够帮助你。")
    SetAutonote(91)
end)

RegisterGlobalEvent(420, nil, function()
    evt.SetMessage("你可以在渡鸦海滨城中找爱利・卢欧林学习专家级的长剑技能。她是长剑的专家，可以让你对长剑有更深的了解。")
    SetAutonote(92)
end)

RegisterGlobalEvent(421, nil, function()
    evt.SetMessage("大师级的长剑技能的导师是杰新・卡卓，很不幸地，她认为在猎龙人营地中教导这项技能可以赚得更多。所以，你可以在绞刑峡谷的猎龙人营地中找到她。")
    SetAutonote(93)
end)

RegisterGlobalEvent(422, nil, function()
    evt.SetMessage("长剑技能的宗师级导师是麦友・追龙者，他现在在雷格那岛上教授这项技能。")
    SetAutonote(94)
end)

RegisterGlobalEvent(423, nil, function()
    evt.SetMessage("匕首技能的导师罗瑞・维斯波居住在黑暗精灵的城市阿尔瓦中。快去那边找他。")
    SetAutonote(95)
end)

RegisterGlobalEvent(424, nil, function()
    evt.SetMessage("乔波教导大师级的匕首技能，他居住在渡鸦海滨这座城市中。")
    SetAutonote(96)
end)

RegisterGlobalEvent(425, nil, function()
    evt.SetMessage("卡拉・诺瑟斯是宗师级的匕首导师，通常出现在雷格那岛上训练所有的雷格那海盗使用匕首。由于海盗们付她相当多的学费，她就居住在雷格那岛上。")
    SetAutonote(97)
end)

RegisterGlobalEvent(426, nil, function()
    evt.SetMessage("哈洛・佛斯太克是吉柯德手下最强悍的骑士，他在绞刑峡谷中的猎龙人营地教导专家级的战斧技能。")
    SetAutonote(98)
end)

RegisterGlobalEvent(427, nil, function()
    evt.SetMessage("杰斯普・韩特是大师级的战斧技能导师，他将可以让你学习到许多有关斧头的秘诀，他的家就在靠海的城市渡鸦海滨中。")
    SetAutonote(99)
end)

RegisterGlobalEvent(428, nil, function()
    evt.SetMessage("战斧宗师加瑞克・森杰克在残破镇的巴尔萨煞巢穴中教导宗师级的战斧技能。")
    SetAutonote(100)
end)

RegisterGlobalEvent(429, nil, function()
    evt.SetMessage("麦崔克・陶恩赛佛协助渡鸦海滨的居民抵挡了许多次雷格那海盗的入侵，他的技能和手中的那柄长矛击退了无数次的雷格那海盗。他现在在渡鸦海滨的家中教导专家级的长矛技能。")
    SetAutonote(101)
end)

RegisterGlobalEvent(430, nil, function()
    evt.SetMessage("雅山德拉・惠瑟史密斯是大师级的长矛技能导师，她居住在阿尔瓦商业城中。")
    SetAutonote(102)
end)

RegisterGlobalEvent(431, nil, function()
    evt.SetMessage("雅罗是长矛技能的宗师，她锐利的视力协助她获得了这个等级的技能。她目前正利用自己的技能在匕伤群岛上猎杀那些羽蛇，你可以在匕伤群岛上找到她的踪迹。")
    SetAutonote(103)
end)

RegisterGlobalEvent(432, nil, function()
    evt.SetMessage("席瓦・锐眼是专家级的弓箭技能导师，她的专业教导可以让你获得专家级的弓箭技能。她目前居住在匕伤群岛上的血滴镇中。")
    SetAutonote(104)
end)

RegisterGlobalEvent(433, nil, function()
    evt.SetMessage("大师级的弓箭技能导师欧伯力克・诺斯沃居住在渡鸦海滨的城市中。如果你想要学习大师级的弓箭技能，你必须要去找他才行。")
    SetAutonote(105)
end)

RegisterGlobalEvent(434, nil, function()
    evt.SetMessage("弓箭技能的宗师索力斯居住在黑暗精灵的城市阿尔瓦中。她可以教导你弓箭最终极的技巧。")
    SetAutonote(106)
end)

RegisterGlobalEvent(435, nil, function()
    evt.SetMessage("丽莎・所尔波罗在她位于渡鸦海滨的家中教导专业级的钉锤技能。")
    SetAutonote(107)
end)

RegisterGlobalEvent(436, nil, function()
    evt.SetMessage("罗伯特・晨星是钉锤的大师级导师，他在绞刑峡谷的猎龙人营地中训练骑士。")
    SetAutonote(108)
end)

RegisterGlobalEvent(437, nil, function()
    evt.SetMessage("贺斯沃弟兄是宗师级的钉锤导师，他退休后隐居在沙漠中追求心灵的宁静，他通常出现在铁沙漠中的铁锈镇中。")
    SetAutonote(109)
end)

RegisterGlobalEvent(438, nil, function()
    evt.SetMessage("奎蓝・摩尔曾经和骑士们一起并肩作战，但是他不同意查尔斯・吉柯德杀光所有飞龙的作法。因此，他目前居住在阿尔瓦城中，如果你找得到他，可以从他身上学到盾牌的专家级技巧。")
    SetAutonote(113)
end)

RegisterGlobalEvent(439, nil, function()
    evt.SetMessage("大师级的盾牌技能教师谢尔顿・夜木居住在阴影塔地区的黎明城中。她会教导你用盾的大师级技能。")
    SetAutonote(114)
end)

RegisterGlobalEvent(440, nil, function()
    evt.SetMessage("骑士派林・瑞佛斯通是宗师级的盾牌技能导师，他居住在绞刑峡谷的猎龙人营地中，正在教导查尔斯・吉柯德旗下的骑士如何正确地使用盾牌。")
    SetAutonote(115)
end)

RegisterGlobalEvent(441, nil, function()
    evt.SetMessage("蜥蜴人泰丁是专家级的皮甲技能导师，他的课程能够让你学到很多，目前他居住在匕伤群岛上。")
    SetAutonote(116)
end)

RegisterGlobalEvent(442, nil, function()
    evt.SetMessage("大师级的皮甲导师沙漠斯・荷力菲居住在巴尔萨煞巢穴，也就是牛头人的洞穴之中。牛头人的城市位于残破镇的区域。他可以教导你大师级的皮甲使用技能。")
    SetAutonote(117)
end)

RegisterGlobalEvent(443, nil, function()
    evt.SetMessage("麦瓦力・爱姆斯麦尔是全大陆上最专精于皮甲使用的人，她同时也是宗师级的皮甲技能教导者，她的家就在铁沙漠的铁锈镇中。")
    SetAutonote(118)
end)

RegisterGlobalEvent(444, nil, function()
    evt.SetMessage("托伯伦・佛吉爱特在第一次的海盗战争中协助渡鸦海滨抵抗雷格那人的入侵。为了替守城者打造锁甲，她的打铁铺整整有四个礼拜昼夜不停地运作着。她也是专家级的锁甲技能导师，目前还居住在渡鸦海滨的海港边。")
    SetAutonote(119)
end)

RegisterGlobalEvent(445, nil, function()
    evt.SetMessage("海立安・艾佛斯麦从宗师的手中学到了所有可用的技能，躲到阿尔瓦来教导锁甲技能混饭吃。他是大师级的锁甲技能导师，通常会出现在阿尔瓦。")
    SetAutonote(120)
end)

RegisterGlobalEvent(446, nil, function()
    evt.SetMessage("锁甲的宗师级导师赛林・伯更斗通常在她位于雷格那的家中授课。她会教导你如何善用锁甲的威力。")
    SetAutonote(121)
end)

RegisterGlobalEvent(447, nil, function()
    evt.SetMessage("朋恩在匕伤群岛上教导专家级的钢甲使用技能。")
    SetAutonote(122)
end)

RegisterGlobalEvent(448, nil, function()
    evt.SetMessage("波散恩是第一次海盗战争中最强悍的战士，渡鸦海滨能够守住，都要靠他的强大战力。波散恩和他的同伴们努力抵抗住了第一波的海盗攻击。除了最重的打击之外，钢甲几乎挡住了所有其他的攻击。这位大师级的钢甲技能教师波散恩目前居住在渡鸦海滨的城市中。")
    SetAutonote(123)
end)

RegisterGlobalEvent(449, nil, function()
    evt.SetMessage("赛欣・艾恩法斯特是宗师级的钢甲技能教导者，他也是查尔斯・吉柯德对飞龙的圣战中真正的幕后功臣。如果没有他，这些骑士们早就被打成肉酱了。他目前正在绞刑峡谷的猎龙人营地中教导骑士们。")
    SetAutonote(124)
end)

RegisterGlobalEvent(450, nil, function()
    evt.SetMessage("泰伦・谭普从埃拉西亚逃出来，躲到一个没人知道他过去的地方。他目前在他位于渡鸦海滨的家中教授专家级火系魔法技能。")
    SetAutonote(125)
end)

RegisterGlobalEvent(451, nil, function()
    evt.SetMessage("所罗门・史提尔是火系魔法的大师，他居住在阿尔瓦的宁静城市中。他可以教导你大师级火系魔法技能。")
    SetAutonote(126)
end)

RegisterGlobalEvent(452, nil, function()
    evt.SetMessage("也许出现在铁沙漠中的火元素界传送门可以让你找到他。他将可以教导你火系魔法的宗师级技能。")
    SetAutonote(127)
end)

RegisterGlobalEvent(453, nil, function()
    evt.SetMessage("瑞西在匕伤群岛的家中教授专家级空气魔法技能。")
    SetAutonote(128)
end)

RegisterGlobalEvent(454, nil, function()
    evt.SetMessage("荷力司・暴风眼是空气魔法的大师，他居住在巴尔萨煞巢穴，也就是位于残破镇的区域。")
    SetAutonote(129)
end)

RegisterGlobalEvent(455, nil, function()
    evt.SetMessage("克劳德・耐德龙似乎和风元素之王达成了某项协议，他通过传送门前往风元素界，希望在那边了解他对于空气魔法所有的不解之处。他是空气魔法的宗师，他居住在风元素界的区域中，看来你必须要靠着传送门来抵达他所在的区域。")
    SetAutonote(130)
end)

RegisterGlobalEvent(456, nil, function()
    evt.SetMessage("乌尔布拉契・派德东单枪匹马地阻止了第二次的海盗战争。他冲到海边，正好雷格那海盗开始登陆。他呼唤海水的力量，逼迫雷格那舰队退回到海中。很不幸地，这次的牺牲让他失去了使用魔法的能力。不过，他目前还是专家级的水系魔法老师，居住在渡鸦海滨这座城市中。")
    SetAutonote(131)
end)

RegisterGlobalEvent(457, nil, function()
    evt.SetMessage("葛丽果力・迷雾是水系魔法的大师级教师，他目前居住在铁沙漠的铁锈镇中。他宣称自己准备利用对水系魔法的知识将沙漠变成良田。如果他有时间的话，也许他可以教导你水系魔法的大师级技能。")
    SetAutonote(132)
end)

RegisterGlobalEvent(458, nil, function()
    evt.SetMessage("黑流是水系魔法的宗师级导师，目前出没在水元素界。她对于力量的野心让她想要征服水元素界。她打开了一扇传送门前往水元素界，之后就再也没人听过她的消息。如果她还活着，你可能可以在水元素界找到她的踪影。")
    SetAutonote(133)
end)

RegisterGlobalEvent(459, nil, function()
    evt.SetMessage("奥斯崔恩・葛瑞维克是土系魔法的专家级老师，目前居住在匕伤群岛上的血滴镇中。")
    SetAutonote(134)
end)

RegisterGlobalEvent(460, nil, function()
    evt.SetMessage("土系魔法的大师级教师陶乐熙・塞百物曾经协助了第一次海盗战争的守城者。在一名不知名的空气魔法师的帮助下，她建起了一座黏土墙，逼迫雷格那海盗们逃回海中。她目前居住在阿尔瓦城中。")
    SetAutonote(135)
end)

RegisterGlobalEvent(461, nil, function()
    evt.SetMessage("土系魔法的宗师葛瑞文在完成了他最后的课程之后，遁入了土元素界。谁知道元素界中到底发生了什么事情呢？或许他还活着呢！")
    SetAutonote(136)
end)

RegisterGlobalEvent(462, nil, function()
    evt.SetMessage("史拉顿・何索恩可以让你成为灵魂魔法的专家，他目前住在渡鸦海滨的港口城市中。")
    SetAutonote(137)
end)

RegisterGlobalEvent(463, nil, function()
    evt.SetMessage("灵魂魔法的大师贝索德・科恩通常会出现在绞刑峡谷的猎龙人营地中。他目前正在教导骑士们如何对抗飞龙，如果你运气好的话，或许他会有时间教导你这方面的技能。")
    SetAutonote(138)
end)

RegisterGlobalEvent(464, nil, function()
    evt.SetMessage("来西特・鸦眼是灵魂魔法的宗师级教师。他目前居住在靠近太阳神庙的低语森林中。他在那边继续研究一切有关灵魂魔法的知识。他可以让你对于灵魂魔法的认知提升到宗师级的等级。")
    SetAutonote(139)
end)

RegisterGlobalEvent(465, nil, function()
    evt.SetMessage("商恩・克鲁兰是心智魔法的专家级教师，目前居住在黑暗精灵的都市阿尔瓦之中。")
    SetAutonote(140)
end)

RegisterGlobalEvent(466, nil, function()
    evt.SetMessage("芭芭拉・拉兹是心智魔法的大师，目前他居住在巴尔萨煞巢穴的牛头人都市中，也就是位于残破镇的地区。")
    SetAutonote(141)
end)

RegisterGlobalEvent(467, nil, function()
    evt.SetMessage("吉拉德・梦妖是心智魔法的宗师，目前他加入许多宗师魔法师的行列，他目前和太阳神庙一起合作，开发进一步的知识。他目前居住在靠近太阳神庙的低语森林中，可以教导你使用宗师级的心智魔法。")
    SetAutonote(142)
end)

RegisterGlobalEvent(468, nil, function()
    evt.SetMessage("赛瓦・波斯德是肢体魔法的专家级教师，目前和他的同胞们居住在伊法力海中的匕伤群岛上。")
    SetAutonote(143)
end)

RegisterGlobalEvent(469, nil, function()
    evt.SetMessage("土加・爱林是肢体魔法的大师级教师，目前居住在绞刑峡谷的猎龙人营地中。在那边，他的肢体医疗魔法对于不幸被飞龙所伤害的年轻骑士来说非常有用。")
    SetAutonote(144)
end)

RegisterGlobalEvent(470, nil, function()
    evt.SetMessage("肢体魔法的宗师克理塔斯・雪树就居住在低语森林中，远离尘世的喧嚣和吵杂。只有他可以教导你如何达到肢体魔法的宗师级地位。")
    SetAutonote(145)
end)

RegisterGlobalEvent(471, nil, function()
    evt.SetMessage("阿基巴德・曙光是光明魔法的专家级教师，目前正在伊法力海岸边的渡鸦海滨传授他的技巧。他的父母给了他这个名字，却不知道这刚好和埃拉西亚的死灵法师公会首领的名字一样。阿基巴德希望能够听到自己的名字在光明的历史上被人所传诵，而不是被黑暗界的怪物们礼拜。")
    SetAutonote(146)
end)

RegisterGlobalEvent(472, nil, function()
    evt.SetMessage("卢理那斯・破晓者是光明魔法的大师，他目前居住在低语森林，靠近太阳神庙的地方。如果你能够穿越危险的森林，他就能够让你成为光明魔法的大师。")
    SetAutonote(147)
end)

RegisterGlobalEvent(473, nil, function()
    evt.SetMessage("艾德林・明眼是光明魔法的宗师，目前居住在靠近雷格那岛的地方。他希望能够让海盗们不要再继续行邪恶之道。如果你能够躲过海盗的防卫线，你就可以让他教导你宗师等级的技巧。")
    SetAutonote(148)
end)

RegisterGlobalEvent(474, nil, function()
    evt.SetMessage("帕特温・达肯摩尔是暗黑魔法的专家级教师，他目前居住在阿尔瓦的黑暗精灵城市中。")
    SetAutonote(149)
end)

RegisterGlobalEvent(475, nil, function()
    evt.SetMessage("暗黑魔法的大师卡拉・安伯普尔居住在阴影塔附近的城市中。她和她的老师一样四处旅行，不过目前暂时定居下来，和死灵法师们切磋技巧。")
    SetAutonote(150)
end)

RegisterGlobalEvent(476, nil, function()
    evt.SetMessage("西西克斯・影跑者是宗师级的暗黑魔法教师，目前居住在雷格那岛上。在海盗们出征之前，都会祈求她的祝福。她可以教导你暗黑魔法的宗师级技巧。")
    SetAutonote(151)
end)

RegisterGlobalEvent(477, nil, function()
    evt.SetMessage("其拉・史巴克曼可以教导学生专家级的物品鉴定术，他目前居住在阿尔瓦城中。")
    SetAutonote(161)
end)

RegisterGlobalEvent(478, nil, function()
    evt.SetMessage("爱西恩是物品鉴定术的大师级导师，目前他在阿尔瓦的商人旗下服务，居住在匕伤群岛上。许多旅人会将物品千里迢迢地带来给他鉴定。如果你到他的家里去，也许他会有时间教导你物品鉴定的技能。")
    SetAutonote(162)
end)

RegisterGlobalEvent(479, nil, function()
    evt.SetMessage("艾尔斯伯・络真是物品鉴定术的宗师级导师，目前居住在阴影塔地区的黎明城中。她可以教导你宗师所需要知道的常识。")
    SetAutonote(163)
end)

RegisterGlobalEvent(480, nil, function()
    evt.SetMessage("费许那・汤伯是专家级的经商术教师，原先是在阿尔瓦商人旗下服务，在他退休之后，目前居住在伊法力海中的匕伤群岛上的家中。")
    SetAutonote(164)
end)

RegisterGlobalEvent(481, nil, function()
    evt.SetMessage("费顿・艾佛森是大师级的经商术教师，目前居住在阿尔瓦商业城中。")
    SetAutonote(165)
end)

RegisterGlobalEvent(482, nil, function()
    evt.SetMessage("瑞文・快舌是宗师级的经商术导师，目前居住在渡鸦海滨。由于他在这里可以和各个种族的人彼此协商和交易，所以相当快乐，如果他有时间的话，或许可以教导你宗师级的经商术。")
    SetAutonote(166)
end)

RegisterGlobalEvent(483, nil, function()
    evt.SetMessage("艾凡达・拉兹教导的是专家级的修补术，他目前居住在渡鸦海滨的靠海港口中。")
    SetAutonote(167)
end)

RegisterGlobalEvent(484, nil, function()
    evt.SetMessage("逵克・珍妮是大师级的修补术导师，她目前居住在绞刑峡谷猎龙人聚居处附近的小屋内。")
    SetAutonote(168)
end)

RegisterGlobalEvent(485, nil, function()
    evt.SetMessage("逵斯林・东克是修补术的宗师，他目前居住在低语森林中。太阳神庙认为他的技能非常非常的有用。")
    SetAutonote(169)
end)

RegisterGlobalEvent(486, nil, function()
    evt.SetMessage("曼纳梭尔是匕伤群岛上最强壮的蜥蜴人，也是健身术技能的专家级教师。")
    SetAutonote(170)
end)

RegisterGlobalEvent(487, nil, function()
    evt.SetMessage("肯尼斯・欧特顿是大师级的健身术技能导师，同时也拥有十字军的称号。他目前居住在绞刑峡谷的猎龙人营地中。据说他曾经单枪匹马地将一只龙压倒在地，当然，其它的骑士协助他杀死了这只龙。")
    SetAutonote(171)
end)

RegisterGlobalEvent(488, nil, function()
    evt.SetMessage("米凯尔・史密森是健身术技能的宗师级导师，如果你想要进一步提升自己的健身术技能，请去铁沙漠的铁锈镇找他。")
    SetAutonote(172)
end)

RegisterGlobalEvent(489, nil, function()
    evt.SetMessage("艾顿・普特南是冥想术的专家级教师。如果你去他在渡鸦海滨的住宅，你可以请他教导你。")
    SetAutonote(173)
end)

RegisterGlobalEvent(490, nil, function()
    evt.SetMessage("葛拉琴・耐芙莫尔是冥想术的大师，他负责教导太阳神庙的牧师们冥想术。他住在太阳神庙附近的低语森林中。")
    SetAutonote(174)
end)

RegisterGlobalEvent(491, nil, function()
    evt.SetMessage("蓝诺德・夜行者是冥想术的宗师，也是死灵法师公会中最受尊重的成员之一。他教导所有死灵法师公会成员冥想术，目前居住在阴影塔地区的黎明城中。")
    SetAutonote(175)
end)

RegisterGlobalEvent(492, nil, function()
    evt.SetMessage("希尔克・夜行者是洞察术的专家级导师，目前他居住在阿尔瓦的黑暗精灵城市中。他大部分的时间都花在教导商人们如何发现被秘密隐藏起来的物品，如果你运气好的话，他应该愿意教导你。")
    SetAutonote(176)
end)

RegisterGlobalEvent(493, nil, function()
    evt.SetMessage("海尔加・钢眼是大师级洞察术导师，目前居住在阴影塔地区的黎明城中。死灵法师公会很感谢有他的技能指导。")
    SetAutonote(177)
end)

RegisterGlobalEvent(494, nil, function()
    evt.SetMessage("洞察术的宗师级导师巴兰・栩尔雀儿就住在巴尔萨煞巢穴的牛头人都市中。要学习最高级的技能，你必须要找到他才行。")
    SetAutonote(178)
end)

RegisterGlobalEvent(495, nil, function()
    evt.SetMessage("凯斯瑞・塔兰在他位于铁沙漠的铁锈镇中教导专家级的再生术。")
    SetAutonote(179)
end)

RegisterGlobalEvent(496, nil, function()
    evt.SetMessage("威廉・山普森是大师级的再生术导师，目前居住在低语森林中。他利用太阳神庙的大图书馆来研习有关巨魔的历史文档。")
    SetAutonote(180)
end)

RegisterGlobalEvent(497, nil, function()
    evt.SetMessage("多尾乌许是再生术的宗师，目前他和同胞一起居住在匕伤群岛上的城市中。传说他在和雷格那海盗的战斗中曾经十三次失去了尾巴，每次却又都长出新的尾巴来！")
    SetAutonote(181)
end)

RegisterGlobalEvent(498, nil, function()
    evt.SetMessage("齐旺・维斯特是专家级的陷阱拆卸术导师，目前他在位于匕伤群岛的家中教导这项技能。在附近的人探索神殿废墟的时候，都认为这个技能相当的好用。")
    SetAutonote(182)
end)

RegisterGlobalEvent(499, nil, function()
    evt.SetMessage("凯力・来特芬格是陷阱拆卸术的大师级导师，他在阿尔瓦的家中教导这项技能。如果他觉得你资格符合，那么他也会教导你这项技能。")
    SetAutonote(183)
end)

RegisterGlobalEvent(500, nil, function()
    evt.SetMessage("加拉司・理夫特是陷阱拆卸术的宗师，他在雷格那的小岛上教导这项技能。海盗们都是从他身上学到如何在抢来的货物上设下陷阱。")
    SetAutonote(184)
end)

RegisterGlobalEvent(501, nil, function()
    if HasItem(1493) then
        RemoveItem(1493)
        evt.GiveItem(6, ItemType.Weapon_)
        evt.SetMessage("这件兵器是你们的了。要是你们能给我更多矿石，我就可以打造更多的兵器。")
        return
    elseif HasItem(1492) then
        RemoveItem(1492)
        evt.GiveItem(5, ItemType.Weapon_)
        evt.SetMessage("这件兵器是你们的了。要是你们能给我更多矿石，我就可以打造更多的兵器。")
        return
    elseif HasItem(1491) then
        RemoveItem(1491)
        evt.GiveItem(4, ItemType.Weapon_)
        evt.SetMessage("这件兵器是你们的了。要是你们能给我更多矿石，我就可以打造更多的兵器。")
        return
    elseif HasItem(1490) then
        RemoveItem(1490)
        evt.GiveItem(3, ItemType.Weapon_)
        evt.SetMessage("这件兵器是你们的了。要是你们能给我更多矿石，我就可以打造更多的兵器。")
        return
    elseif HasItem(1489) then
        RemoveItem(1489)
        evt.GiveItem(2, ItemType.Weapon_)
        evt.SetMessage("这件兵器是你们的了。要是你们能给我更多矿石，我就可以打造更多的兵器。")
        return
    elseif HasItem(1488) then
        RemoveItem(1488)
        evt.GiveItem(1, ItemType.Weapon_)
        evt.SetMessage("这件兵器是你们的了。要是你们能给我更多矿石，我就可以打造更多的兵器。")
    else
        evt.SetMessage("你们必须给我更多的矿石来打造兵器，矿石质量越高，兵器就越好。")
    end
end)

RegisterGlobalEvent(502, nil, function()
    if HasItem(1493) then
        RemoveItem(1493)
        evt.GiveItem(6, ItemType.Armor_)
        evt.SetMessage("这件盔甲是你们的了。要是你们能给我更多矿石，我就可以打造更多的盔甲。")
        return
    elseif HasItem(1492) then
        RemoveItem(1492)
        evt.GiveItem(5, ItemType.Armor_)
        evt.SetMessage("这件盔甲是你们的了。要是你们能给我更多矿石，我就可以打造更多的盔甲。")
        return
    elseif HasItem(1491) then
        RemoveItem(1491)
        evt.GiveItem(4, ItemType.Armor_)
        evt.SetMessage("这件盔甲是你们的了。要是你们能给我更多矿石，我就可以打造更多的盔甲。")
        return
    elseif HasItem(1490) then
        RemoveItem(1490)
        evt.GiveItem(3, ItemType.Armor_)
        evt.SetMessage("这件盔甲是你们的了。要是你们能给我更多矿石，我就可以打造更多的盔甲。")
        return
    elseif HasItem(1489) then
        RemoveItem(1489)
        evt.GiveItem(2, ItemType.Armor_)
        evt.SetMessage("这件盔甲是你们的了。要是你们能给我更多矿石，我就可以打造更多的盔甲。")
        return
    elseif HasItem(1488) then
        RemoveItem(1488)
        evt.GiveItem(1, ItemType.Armor_)
        evt.SetMessage("这件盔甲是你们的了。要是你们能给我更多矿石，我就可以打造更多的盔甲。")
    else
        evt.SetMessage("你们必须给我更多的矿石来打造盔甲，矿石质量越高，盔甲就越好。")
    end
end)

RegisterGlobalEvent(503, nil, function()
    if HasItem(1493) then
        RemoveItem(1493)
        evt.GiveItem(6, ItemType.Misc)
        evt.SetMessage("这件物品是你们的了。要是你们能给我更多矿石，我就可以制造更多的物品。")
        return
    elseif HasItem(1492) then
        RemoveItem(1492)
        evt.GiveItem(5, ItemType.Misc)
        evt.SetMessage("这件物品是你们的了。要是你们能给我更多矿石，我就可以制造更多的物品。")
        return
    elseif HasItem(1491) then
        RemoveItem(1491)
        evt.GiveItem(4, ItemType.Misc)
        evt.SetMessage("这件物品是你们的了。要是你们能给我更多矿石，我就可以制造更多的物品。")
        return
    elseif HasItem(1490) then
        RemoveItem(1490)
        evt.GiveItem(3, ItemType.Misc)
        evt.SetMessage("这件物品是你们的了。要是你们能给我更多矿石，我就可以制造更多的物品。")
        return
    elseif HasItem(1489) then
        RemoveItem(1489)
        evt.GiveItem(2, ItemType.Misc)
        evt.SetMessage("这件物品是你们的了。要是你们能给我更多矿石，我就可以制造更多的物品。")
        return
    elseif HasItem(1488) then
        RemoveItem(1488)
        evt.GiveItem(1, ItemType.Misc)
        evt.SetMessage("这件物品是你们的了。要是你们能给我更多矿石，我就可以制造更多的物品。")
    else
        evt.SetMessage("你们必须给我更多的矿石来制造物品，矿石质量越高，物品就越好。")
    end
end)

RegisterGlobalEvent(504, nil, function()
    evt.SetMessage("应该在海岛西面发生信号弹，警告过往船只不要靠近那里。那个地方旋涡密布，暗礁林立，船只到了那儿肯定有去无回。")
end)

RegisterGlobalEvent(505, nil, function()
    evt.SetMessage("小心海岛南部的沼泽地，那里可是龙蝇的安乐窝。")
end)

RegisterGlobalEvent(506, nil, function()
    evt.SetMessage("一片枯树林可能是埋藏财宝的好地方，但有些讨厌的怪兽也会把它当作安家的好地方。")
end)

RegisterGlobalEvent(507, nil, function()
    evt.SetMessage("泰沙・马克是怪物鉴定的专家级教师，目前居住在绞刑峡谷内部的猎龙人营地。她目前正在尝试靠着将不同的飞龙分类来锻链自己的技巧。")
    SetAutonote(191)
end)

RegisterGlobalEvent(508, nil, function()
    evt.SetMessage("马崔克・锐锋是大师级的怪物鉴定术导师，目前居住在低语森林。")
    SetAutonote(192)
end)

RegisterGlobalEvent(509, nil, function()
    evt.SetMessage("布拉肯・石刀是怪物鉴定术的宗师级技能导师，他已经看过了贾丹姆大陆上的所有怪物。目前他在自己位于渡鸦海滨的家中教导这些技能。")
    SetAutonote(193)
end)

RegisterGlobalEvent(510, nil, function()
    evt.SetMessage("骑士诺伯特・杀手是专家级的武器使用术导师，他目前居住在绞刑峡谷的猎龙人营地中。")
    SetAutonote(194)
end)

RegisterGlobalEvent(511, nil, function()
    evt.SetMessage("疤面拉沙庭是武器使用术的大师级导师，目前居住在匕伤群岛上。")
    SetAutonote(195)
end)

RegisterGlobalEvent(512, nil, function()
    evt.SetMessage("杰斯伯・史提尔克夫是武器使用术的宗师级导师，目前他出没在雷格那岛上，教导所有的海盗使用武器。如果你拥有足够的勇气前往雷格那岛，并且在他的课程之下生存，那么你也许会拥有宗师级的相关知识。")
    SetAutonote(196)
end)

RegisterGlobalEvent(513, nil, function()
    if not IsAtLeast(Gold, 1000) then
        evt.SetMessage("看来你们这人还不错，但却是一个穷光蛋。你们要是没钱的话尽管开口好了，老天可不会亏待好人的。")
        evt.SetNPCTopic(461, 0, 0) -- 鲁那斯・萨达 topic 0 cleared
        evt.SetNPCTopic(461, 1, 0) -- 鲁那斯・萨达 topic 1 cleared
        return
    end
    evt.SetMessage("这1000个金币对我们的帮助真是太大了，谢谢你们的慷慨捐赠。")
    if not IsAtLeast(Gold, 1000) then
        return
    end
    SubtractValue(Gold, 1000)
    SetQBit(QBit(761))
    evt.SetNPCTopic(461, 0, 0) -- 鲁那斯・萨达 topic 0 cleared
    evt.SetNPCTopic(461, 1, 0) -- 鲁那斯・萨达 topic 1 cleared
end)

RegisterGlobalEvent(514, nil, function()
    evt.SetMessage("哈，你们这个小气鬼，连一分钱都不给，将来没有好下场的，等着瞧吧。")
    evt.SetNPCTopic(461, 0, 0) -- 鲁那斯・萨达 topic 0 cleared
    evt.SetNPCTopic(461, 1, 0) -- 鲁那斯・萨达 topic 1 cleared
end)

RegisterGlobalEvent(515, nil, function()
    evt.SetMessage("这里是一箱箭头，你们拿去吧。埃拉西亚的海利尔会好好酬谢你们的，快上他那儿去吧。")
    ClearQBit(QBit(764))
    if IsAtLeast(Gold, 200) then
        if not IsAtLeast(Gold, 200) then
            return
        end
        SubtractValue(Gold, 200)
        AddValue(InventoryItem(1494), 1494)
        SetQBit(QBit(762))
        SetQBit(QBit(768))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(515, function()
    evt._BeginCanShowTopic(515)
    local visible = true
    if IsQBitSet(QBit(764)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(768)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(516, nil, function()
    evt.SetMessage("塔必煞・瓦特沙是炼金术技能的专家级导师，她在阿尔瓦商业城中教授弟子。")
    SetAutonote(200)
end)

RegisterGlobalEvent(517, nil, function()
    evt.SetMessage("凯斯瑞・宝石是大师级的炼金术技能导师，他居住在低语森林这个区域中。目前他正在研究该处各种各样的植物。")
    SetAutonote(201)
end)

RegisterGlobalEvent(518, nil, function()
    evt.SetMessage("伊奇是炼金术技能的宗师，他在匕伤群岛的居所中教导有意愿学习的人。他知道所有将药材混合所需要的知识和技巧。")
    SetAutonote(202)
end)

RegisterGlobalEvent(519, nil, function()
    evt.SetMessage("派德拉・密斯瑞是学习术的专家级导师，他居住在低语森林的区域，靠近太阳神庙的地方。")
    SetAutonote(203)
end)

RegisterGlobalEvent(520, nil, function()
    evt.SetMessage("加瑞特・雾春是学习术的大师级教师，她在阴影塔地区的黎明城中教导学生。因为死灵法师公会对她的教导给予相当丰厚的报酬。")
    SetAutonote(204)
end)

RegisterGlobalEvent(521, nil, function()
    evt.SetMessage("汪达・来特史汪是学习术的宗师级导师，他居住在靠近绞刑峡谷的猎龙人营地中。查尔斯・吉柯德希望靠着他让他的骑士们获得战斗上的优势。")
    SetAutonote(205)
end)

RegisterGlobalEvent(522, nil, function()
    evt.SetMessage("佛林・沙达是专家级吸血鬼能力的导师，他目前居住在阴影塔地区的黎明城中。他也是旅行到该处的吸血鬼耳目和庇护所的提供者。")
    SetAutonote(155)
end)

RegisterGlobalEvent(523, nil, function()
    evt.SetMessage("道格拉斯・德斯摩尔是大师级的吸血鬼能力教师，目前居住在阴影塔区域的黎明城中。当他教导了你相关的知识之后，你才能够达到吸血鬼能力大师级别。")
    SetAutonote(156)
end)

RegisterGlobalEvent(524, nil, function()
    evt.SetMessage("虽然没有人能够确定，但是据说佩吉・阿拉尼雅是贾丹姆大陆上的第一个吸血鬼，她也是吸血鬼能力的宗师级导师，目前她的巢穴位于阴影塔中。")
    SetAutonote(157)
end)

RegisterGlobalEvent(525, nil, function()
    evt.SetMessage("费德温・德维禧可以教导你专家级的黑暗精灵能力，你可以在黑暗精灵的阿尔瓦城中找到他。")
    SetAutonote(152)
end)

RegisterGlobalEvent(526, nil, function()
    evt.SetMessage("蓝西・卡佛希尔居住在渡鸦海滨这座滨海的城市中，她可以教导你大师级的黑暗精灵能力。在你从她那边学到相关的知识之后，你才会开始迈向黑暗精灵领袖的伟大道路。")
    SetAutonote(153)
end)

RegisterGlobalEvent(527, nil, function()
    evt.SetMessage("堂・爱格瑞尼尔可以教导你宗师级的黑暗精灵能力，他就居住在阿尔瓦这座城市中。你必须要证明自己的能力才能够获得他的教导，但这一切都是值得的。")
    SetAutonote(154)
end)

RegisterGlobalEvent(528, nil, function()
    evt.SetMessage("伊斯顿是绞刑峡谷少年飞龙队的领袖，他可以指导所有年轻的飞龙学习专家级的飞龙能力。他就居住在绞刑峡谷中的龙穴内。")
    SetAutonote(158)
end)

RegisterGlobalEvent(529, nil, function()
    evt.SetMessage("大师级飞龙能力的教师鄂欣特居住在绞刑峡谷中的龙穴内。他是所有飞龙队伍的领导者，地位仅次于达夫克劳，因此拥有足够的资格和地位教导你相关的知识。")
    SetAutonote(159)
end)

RegisterGlobalEvent(530, nil, function()
    evt.SetMessage("克兰・疤翅居住在绞刑峡谷的龙穴中，他可以教导飞龙宗师级的技能。如果你想要获得宗师级的地位和知识，请去找它。")
    SetAutonote(160)
end)

RegisterGlobalEvent(531, nil, function()
    evt.CastSpell(5, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(532, nil, function()
    evt.CastSpell(36, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(533, nil, function()
    evt.CastSpell(83, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(534, nil, function()
    evt.CastSpell(17, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(535, nil, function()
    evt.CastSpell(25, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(536, nil, function()
    evt.CastSpell(3, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(537, nil, function()
    evt.CastSpell(51, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(538, nil, function()
    evt.CastSpell(8, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(539, nil, function()
    evt.CastSpell(58, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(540, nil, function()
    evt.CastSpell(69, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(541, nil, function()
    evt.CastSpell(38, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(542, nil, function()
    evt.CastSpell(14, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(543, nil, function()
    if IsPlayerBitSet(PlayerBit(31)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualMight, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(31))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(544, nil, function()
    if IsPlayerBitSet(PlayerBit(32)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualEndurance, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(32))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(545, nil, function()
    if IsPlayerBitSet(PlayerBit(33)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualIntellect, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(33))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(546, nil, function()
    if IsPlayerBitSet(PlayerBit(34)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualPersonality, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(34))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(547, nil, function()
    if IsPlayerBitSet(PlayerBit(35)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualAccuracy, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(35))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(548, nil, function()
    if IsPlayerBitSet(PlayerBit(36)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualSpeed, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(36))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(549, nil, function()
    if IsPlayerBitSet(PlayerBit(37)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualLuck, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(37))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(550, nil, function()
    if IsPlayerBitSet(PlayerBit(38)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualMight, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(38))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(551, nil, function()
    if IsPlayerBitSet(PlayerBit(39)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualEndurance, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(39))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(552, nil, function()
    if IsPlayerBitSet(PlayerBit(40)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualIntellect, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(40))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(553, nil, function()
    if IsPlayerBitSet(PlayerBit(41)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualPersonality, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(41))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(554, nil, function()
    if IsPlayerBitSet(PlayerBit(42)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualAccuracy, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(42))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(555, nil, function()
    if IsPlayerBitSet(PlayerBit(43)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualSpeed, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(43))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(556, nil, function()
    if IsPlayerBitSet(PlayerBit(44)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualLuck, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(44))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(557, nil, function()
    if IsPlayerBitSet(PlayerBit(45)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualMight, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(45))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(558, nil, function()
    if IsPlayerBitSet(PlayerBit(46)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualEndurance, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(46))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(559, nil, function()
    if IsPlayerBitSet(PlayerBit(47)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualIntellect, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(47))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(560, nil, function()
    if IsPlayerBitSet(PlayerBit(48)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualPersonality, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(48))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(561, nil, function()
    if IsPlayerBitSet(PlayerBit(49)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualAccuracy, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(49))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(562, nil, function()
    if IsPlayerBitSet(PlayerBit(50)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualSpeed, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(50))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(563, nil, function()
    if IsPlayerBitSet(PlayerBit(51)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualLuck, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(51))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(564, nil, function()
    if IsPlayerBitSet(PlayerBit(52)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualMight, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(52))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(565, nil, function()
    if IsPlayerBitSet(PlayerBit(53)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualEndurance, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(53))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(566, nil, function()
    if IsPlayerBitSet(PlayerBit(54)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualIntellect, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(54))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(567, nil, function()
    if IsPlayerBitSet(PlayerBit(55)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualPersonality, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(55))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(568, nil, function()
    if IsPlayerBitSet(PlayerBit(56)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualAccuracy, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(56))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(569, nil, function()
    if IsPlayerBitSet(PlayerBit(57)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualSpeed, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(57))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(570, nil, function()
    if IsPlayerBitSet(PlayerBit(58)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualLuck, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(58))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(571, nil, function()
    if IsQBitSet(QBit(149)) then
        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
        return
    elseif IsQBitSet(QBit(143)) then
        evt.SetMessage("多谢你给我的药剂！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(256) then
            evt.SetMessage("我对这火海毫无抵抗的能力！我需要御火药剂！")
            return
        end
        RemoveItem(256)
        SetQBit(QBit(143))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 1000)
    end
    if IsQBitSet(QBit(144)) then
        if IsQBitSet(QBit(145)) then
            if IsQBitSet(QBit(146)) then
                if IsQBitSet(QBit(147)) then
                    if IsQBitSet(QBit(148)) then
                        evt.ForPlayer(Players.All)
                        AddValue(Experience, 7500)
                        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
                        SetQBit(QBit(149))
                        return
                    end
                end
            end
        end
    end
    evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
end)
RegisterCanShowTopic(571, function()
    evt._BeginCanShowTopic(571)
    local visible = true
    if IsQBitSet(QBit(142)) then -- 将御火药剂送到铁锈镇六个最南边的屋子里面。完成任务之后回去找铁锈镇的贺伯特。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(572, nil, function()
    if IsQBitSet(QBit(149)) then
        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
        return
    elseif IsQBitSet(QBit(144)) then
        evt.SetMessage("多谢你给我的药剂！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(256) then
            evt.SetMessage("我对这火海毫无抵抗的能力！我需要御火药剂！")
            return
        end
        RemoveItem(256)
        SetQBit(QBit(144))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 1000)
    end
    if IsQBitSet(QBit(143)) then
        if IsQBitSet(QBit(145)) then
            if IsQBitSet(QBit(146)) then
                if IsQBitSet(QBit(147)) then
                    if IsQBitSet(QBit(148)) then
                        evt.ForPlayer(Players.All)
                        AddValue(Experience, 1500)
                        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
                        SetQBit(QBit(149))
                        return
                    end
                end
            end
        end
    end
    evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
end)
RegisterCanShowTopic(572, function()
    evt._BeginCanShowTopic(572)
    local visible = true
    if IsQBitSet(QBit(142)) then -- 将御火药剂送到铁锈镇六个最南边的屋子里面。完成任务之后回去找铁锈镇的贺伯特。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(573, nil, function()
    if IsQBitSet(QBit(149)) then
        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
        return
    elseif IsQBitSet(QBit(145)) then
        evt.SetMessage("多谢你给我的药剂！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(256) then
            evt.SetMessage("我对这火海毫无抵抗的能力！我需要御火药剂！")
            return
        end
        RemoveItem(256)
        SetQBit(QBit(145))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 1000)
    end
    if IsQBitSet(QBit(143)) then
        if IsQBitSet(QBit(144)) then
            if IsQBitSet(QBit(146)) then
                if IsQBitSet(QBit(147)) then
                    if IsQBitSet(QBit(148)) then
                        evt.ForPlayer(Players.All)
                        AddValue(Experience, 1500)
                        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
                        SetQBit(QBit(149))
                        return
                    end
                end
            end
        end
    end
    evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
end)
RegisterCanShowTopic(573, function()
    evt._BeginCanShowTopic(573)
    local visible = true
    if IsQBitSet(QBit(142)) then -- 将御火药剂送到铁锈镇六个最南边的屋子里面。完成任务之后回去找铁锈镇的贺伯特。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(574, nil, function()
    if IsQBitSet(QBit(149)) then
        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
        return
    elseif IsQBitSet(QBit(146)) then
        evt.SetMessage("多谢你给我的药剂！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(256) then
            evt.SetMessage("我对这火海毫无抵抗的能力！我需要御火药剂！")
            return
        end
        RemoveItem(256)
        SetQBit(QBit(146))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 1000)
    end
    if IsQBitSet(QBit(143)) then
        if IsQBitSet(QBit(144)) then
            if IsQBitSet(QBit(145)) then
                if IsQBitSet(QBit(147)) then
                    if IsQBitSet(QBit(148)) then
                        evt.ForPlayer(Players.All)
                        AddValue(Experience, 1500)
                        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
                        SetQBit(QBit(149))
                        return
                    end
                end
            end
        end
    end
    evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
end)
RegisterCanShowTopic(574, function()
    evt._BeginCanShowTopic(574)
    local visible = true
    if IsQBitSet(QBit(142)) then -- 将御火药剂送到铁锈镇六个最南边的屋子里面。完成任务之后回去找铁锈镇的贺伯特。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(575, nil, function()
    if IsQBitSet(QBit(149)) then
        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
        return
    elseif IsQBitSet(QBit(147)) then
        evt.SetMessage("多谢你给我的药剂！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(256) then
            evt.SetMessage("我对这火海毫无抵抗的能力！我需要御火药剂！")
            return
        end
        RemoveItem(256)
        SetQBit(QBit(147))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 1000)
    end
    if IsQBitSet(QBit(143)) then
        if IsQBitSet(QBit(144)) then
            if IsQBitSet(QBit(145)) then
                if IsQBitSet(QBit(146)) then
                    if IsQBitSet(QBit(148)) then
                        evt.ForPlayer(Players.All)
                        AddValue(Experience, 1500)
                        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
                        SetQBit(QBit(149))
                        return
                    end
                end
            end
        end
    end
    evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
end)
RegisterCanShowTopic(575, function()
    evt._BeginCanShowTopic(575)
    local visible = true
    if IsQBitSet(QBit(142)) then -- 将御火药剂送到铁锈镇六个最南边的屋子里面。完成任务之后回去找铁锈镇的贺伯特。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(576, nil, function()
    if IsQBitSet(QBit(149)) then
        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
        return
    elseif IsQBitSet(QBit(148)) then
        evt.SetMessage("多谢你给我的药剂！")
    else
        evt.ForPlayer(Players.All)
        if not HasItem(256) then
            evt.SetMessage("我对这火海毫无抵抗的能力！我需要御火药剂！")
            return
        end
        RemoveItem(256)
        SetQBit(QBit(148))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 1000)
    end
    if IsQBitSet(QBit(143)) then
        if IsQBitSet(QBit(144)) then
            if IsQBitSet(QBit(145)) then
                if IsQBitSet(QBit(146)) then
                    if IsQBitSet(QBit(147)) then
                        evt.ForPlayer(Players.All)
                        AddValue(Experience, 1500)
                        evt.SetMessage("你至少暂时帮我们把末日往后拖延了一阵子，但我们还是必须要找到一个新家才行！不过，还是多谢你替我们把御火药剂送过去！")
                        SetQBit(QBit(149))
                        return
                    end
                end
            end
        end
    end
    evt.SetMessage("多谢你给我这些药，但此地的其它人并还没有好！请记得把这些药也送给他们！")
end)
RegisterCanShowTopic(576, function()
    evt._BeginCanShowTopic(576)
    local visible = true
    if IsQBitSet(QBit(142)) then -- 将御火药剂送到铁锈镇六个最南边的屋子里面。完成任务之后回去找铁锈镇的贺伯特。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(577, nil, function()
    if IsQBitSet(QBit(169)) then
        evt.SetMessage("赏金猎人公会基于服务大众的精神，他们愿意付给一些符合资格的猎人相当数量的赏金；只要他们能够消灭指定的生物和达到指定的数量。要获得赏金猎人老手的称号，你必须至少赚到三万金币的赏金才行。")
        return
    elseif IsQBitSet(QBit(170)) then
        evt.SetMessage("赏金猎人公会基于服务大众的精神，他们愿意付给一些符合资格的猎人相当数量的赏金；只要他们能够消灭指定的生物和达到指定的数量。要获得赏金猎人大师的称号，你必须至少赚到七万金币的赏金才行。")
        return
    elseif IsQBitSet(QBit(171)) then
        evt.SetMessage("你好，赏金猎人大师！赏金猎人公会感谢你替贾丹姆大陆的付出。我们愿意听您的吩咐！")
    else
        evt.SetMessage("赏金猎人公会基于服务大众的精神，他们愿意付给一些符合资格的猎人相当数量的赏金；只要他们能够消灭指定的生物和达到指定的数量。要获得赏金猎人生手的称号，你必须至少赚到一万金币的赏金才行。")
    end
end)

RegisterGlobalEvent(578, nil, function()
    if not evt.IsTotalBountyInRange(10000, 29999) then
        if not evt.IsTotalBountyInRange(30000, 69999) then
            if not evt.IsTotalBountyInRange(70000, 1000000) then
                evt.SetMessage("你还没有获得足够的赏金来让我们晋升你！")
                return
            end
            evt.SetMessage("你目前是赏金猎人大师，这是我们公会最崇高的称号了！")
            if not IsAutonoteSet(498) then
                SetAutonote(498)
                evt.ForPlayer(Players.All)
                AddValue(Experience, 1200000)
                ClearQBit(QBit(170))
                SetQBit(QBit(171))
            end
            ClearAutonote(497)
            evt.SetNPCTopic(109, 2, 0) -- 布莱恩・康兰 topic 2 cleared
            evt.SetNPCTopic(110, 2, 0) -- 卡哈利・伊凡诺 topic 2 cleared
            return
        end
        evt.SetMessage("你目前是赏金猎人老手，没有足够的赏金点数被晋升为大师。")
        if IsAutonoteSet(497) then return end
        SetAutonote(497)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 80000)
        ClearQBit(QBit(169))
        SetQBit(QBit(170))
        ClearAutonote(496)
        return
    end
    evt.SetMessage("你目前是赏金猎人生手，没有足够的赏金点数被晋升为老手。")
    if IsAutonoteSet(496) then return end
    SetAutonote(496)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 40000)
    SetQBit(QBit(169))
end)

RegisterGlobalEvent(580, nil, function()
    evt.SetMessage("要成为“魔幻牌”的霸主，你必须在贾丹姆大陆地面上、下的所有酒吧里面赢得一次的胜利。有十一个酒吧有举办“魔幻牌”的竞赛。当你完成了这项壮举之后，回来找我领取奖赏。")
    SetQBit(QBit(173)) -- 在全世界的所有十一间酒吧中于魔幻牌的游戏中获胜，然后回去找渡鸦海滨的汤克・蓝天鹅。
    evt.SetNPCTopic(222, 0, 0) -- 汤克・蓝天鹅 topic 0 cleared
end)

RegisterGlobalEvent(581, nil, function()
    if IsQBitSet(QBit(19)) then
        evt.SetMessage("在你把龙葵灯炉送到死灵法师公会手上之后，他们已经在与太阳神庙的战争中占了上风。这个宝物的魔法会创造出永久性的黑暗，环绕着阴影塔地区。在这阴影的屏蔽之下，吸血鬼可以日夜不停地保护这块土地。公会则可以趁机驱使大群的骷髅人、僵尸和其它的不死生物对抗神殿的部队。我所收到的每一份报告都指出这场战争越来越靠近太阳神庙的门槛了。")
        return
    elseif IsQBitSet(QBit(20)) then
        evt.SetMessage("因为你已经摧毁了死灵法师公会的骷髅转换器，太阳神庙已经占了战争的上风。这个装置所制造出来的骷髅就无法继续加入战斗。没有了这些力量，死灵法师的部队在牧师的步步进逼下溃不成军。我所收到的每份报告都指出，这场战争越来越接近死灵法师公会的门槛。")
    else
        evt.SetMessage("他们就如同光明与黑暗两个光谱上的极端一样，死灵法师公会和太阳神庙之间的关系一直都不好，但现在是他们公开宣战的时段。奥斯卡・提尔宣称他看见了不寻常的启示，督促他将这股污染贾丹姆大陆的力量从世界上彻底消除。\n两群人都不是在我们的大陆上土生土长的。公会基地在阴影塔区域，第一个，也是唯一的太阳神庙则是在低语森林。")
    end
end)

RegisterGlobalEvent(582, nil, function()
    if IsQBitSet(QBit(21)) then
        evt.SetMessage("看来查尔斯・吉柯德在绞刑峡谷的狩猎行动几乎已经把飞龙都杀光了。我很确定他们完成任务之后该处会变得比较安全。但是，我也很难想像贾丹姆大陆如果没有了飞龙会是什么样子。")
        return
    elseif IsQBitSet(QBit(22)) then
        evt.SetMessage("由于你替达夫克劳・红斧找回了它传承的下一代，你让它可以不受拘束地攻击查尔斯・吉柯德的营地。猎龙人是靠着各个击破的战术来对付他们的敌人。他们根本没办法应付大规模的飞龙攻击！不用说，该处的龙产品数量已经大幅地减少了。真可惜，他们本来都可以靠这项出产赚很多钱的。")
    else
        evt.SetMessage("著名的屠龙者，从埃拉西亚来的查尔斯・吉柯德在绞刑峡谷指挥一场规模庞大的狩猎。这可不是什么野猎的旅程。事实上，这是我所听过最大规模的狩猎行动。猎人在峡谷中设立了一个永久性的基地，贩卖龙皮、龙蛋、幼龙和其它的物品。绞刑峡谷自古到今都是大量飞龙聚集的地方。但是吉柯德的猎人效率惊人，我想飞龙们可能已经面对灭绝的命运。")
    end
end)

RegisterGlobalEvent(583, nil, function()
    if not IsQBitSet(QBit(23)) then
        evt.SetMessage("位于残破镇的巴尔萨煞巢穴的牛头人是个骄傲的文明。他们前一阵子击败沃里的霜雪巨人后变得更加独立。因为他们更加确定自己单独承担任何任务的能力。不过，我已经告诉过公会，他们是非常不错的盟友，不管在面对危机和贸易时都一样。")
        return
    end
    evt.SetMessage("在你救出了巴尔萨煞巢穴的牛头人之后，你已经让他们对你授与无比的信任。即使在危机结束之后，公会和他们的贸易可能性将会大幅提升。一旦危机解除，我想利润将会大幅提升，这都多亏你的努力。")
end)

RegisterGlobalEvent(584, nil, function()
    if not IsQBitSet(QBit(2)) then
        evt.SetMessage("由于我们的桥梁都已经被火山给摧毁了，我们现在没办法回去了！更由于我们没办法抵达港口，因此跟主大陆完全断绝了联络。")
        return
    end
    evt.SetMessage("你修复了岩石传送门吗？我们都非常感激你。如果能够安全地通过废庙就好了！好吧，至少我们目前可以试着从这边前往该处的港口。")
end)

RegisterGlobalEvent(585, nil, function()
    if not IsQBitSet(QBit(2)) then
        evt.SetMessage("我们曾经靠着这些桥梁在各岛屿间自由来往。当火山爆发的时候，这些桥梁都被摧毁了。许多家族都被困在外岛上。我们甚至不知道居住在该地的同胞是否还活着。")
        return
    end
    evt.SetMessage("在岩石传送门修复之后，我们至少可以去外岛地区看看，找找可能的生还者。我们很感激你替我们修好了这个传送门。")
end)

RegisterGlobalEvent(586, nil, function()
    if not IsQBitSet(QBit(2)) then
        evt.SetMessage("最北边岛上的港口是我们匕伤群岛唯一前往主大陆的方法。由于桥梁都被摧毁了，我们就没办法前往港口，而从渡鸦海滨来的人也没办法到达血滴镇！")
        return
    end
    evt.SetMessage("我们现在可以去港口了？但是我们还必须先穿过废弃的神殿。不过，无论如何，还是要感谢你的帮忙。")
end)

RegisterGlobalEvent(587, nil, function()
    evt.SetMessage("你知道我曾经被他们俘虏过六年的时间吗？一开始，我以为他们是地狱来的恶魔，但现在我比较不能确定了。他们看起来的确很像恶魔，但行为却不像。不，我想他们也许只是另外一种怪物种族，就像食人妖或是大耳怪一样。不过，不管他们是不是恶魔，我都很高兴他们已经被杀光了！")
end)

RegisterGlobalEvent(588, nil, function()
    evt.SetMessage("凯瑟琳和我曾经和这些元素之王打过交道。我从来不相信他们，现在看来我是正确的。他们曾经是我们对抗克里根人的盟友，但几个月后，我们竟然在这边和他们作战！不管怎么样，我都无法理解他们帮助我们或是攻击我们的原因。也许“善变”和“不可信任”是很适合他们的两个形容词。")
end)

RegisterGlobalEvent(589, nil, function()
    evt.SetMessage("我必须说我很期待回到恩洛斯的家乡。我已经好久没有看过自己的故乡和我的儿子尼可拉王子。当我上次看到他的时候，他只不过是个小孩，但是现在他已经快变成大人了。韩福瑞爵士是个不错的摄政王，但我的故乡已经太久没有国王的管理了。")
end)

RegisterGlobalEvent(590, nil, function()
    evt.SetMessage("当我们击败了埃拉西亚的克里根人之后，我将自己的王位让给了我的一位将军，摩根・坎道尔。我让他选择埃拉西亚下一个适任的领袖。我知道这看起来像是很大的牺牲，但我可是恩洛斯的第一个皇后。当大灾变降临的时候，我们正好要回到故乡去，这场天灾地变则是将我们吸引了过来。")
end)

RegisterGlobalEvent(591, nil, function()
    evt.SetMessage("克里根人？我很确定他们已经都被消灭了。在我们杀死了魔王路西法之后，我的部下彻底搜索了他的巢穴，调查任何可能的生命迹象。我们完全没有找到。这个世界上的克里根人已经全都被消灭了。")
end)

RegisterGlobalEvent(592, nil, function()
    evt.SetMessage("我在对抗克里根人的战争中曾经和元素们并肩作战。我认为他们忠诚、服从。我知道罗兰德不同意我的想法，但是我不认为他们的敌意就是多变。不，我认为有其他的因素驱使他们攻击我们，也许是魔法？你应该跟我们的智者萨索尔谈谈。他已经研究毁灭者的水晶一段时间了。我很确定他现在应该已经找到了一些理论依据才对。")
end)

RegisterGlobalEvent(594, nil, function()
    if HasItem(691) then
        RemoveItem(691)
        evt.GiveItem(6, ItemType.Weapon_)
        evt.SetMessage("这是你的武器，如果你找到了更多的矿石。我很愿意替你制造更多的武器。")
        return
    elseif HasItem(690) then
        RemoveItem(690)
        evt.GiveItem(5, ItemType.Weapon_)
        evt.SetMessage("这是你的武器，如果你找到了更多的矿石。我很愿意替你制造更多的武器。")
        return
    elseif HasItem(689) then
        RemoveItem(689)
        evt.GiveItem(4, ItemType.Weapon_)
        evt.SetMessage("这是你的武器，如果你找到了更多的矿石。我很愿意替你制造更多的武器。")
        return
    elseif HasItem(688) then
        RemoveItem(688)
        evt.GiveItem(3, ItemType.Weapon_)
        evt.SetMessage("这是你的武器，如果你找到了更多的矿石。我很愿意替你制造更多的武器。")
        return
    elseif HasItem(687) then
        RemoveItem(687)
        evt.GiveItem(2, ItemType.Weapon_)
        evt.SetMessage("这是你的武器，如果你找到了更多的矿石。我很愿意替你制造更多的武器。")
        return
    elseif HasItem(686) then
        RemoveItem(686)
        evt.GiveItem(1, ItemType.Weapon_)
        evt.SetMessage("这是你的武器，如果你找到了更多的矿石。我很愿意替你制造更多的武器。")
    else
        evt.SetMessage("你们必须给我更多的矿石来打造兵器，矿石质量越高，兵器就越好。")
    end
end)

RegisterGlobalEvent(595, nil, function()
    if HasItem(691) then
        RemoveItem(691)
        evt.GiveItem(6, ItemType.Armor_)
        evt.SetMessage("这是你的盔甲，如果你找到了更多的矿石。我很愿意替你制造更多的盔甲。")
        return
    elseif HasItem(690) then
        RemoveItem(690)
        evt.GiveItem(5, ItemType.Armor_)
        evt.SetMessage("这是你的盔甲，如果你找到了更多的矿石。我很愿意替你制造更多的盔甲。")
        return
    elseif HasItem(689) then
        RemoveItem(689)
        evt.GiveItem(4, ItemType.Armor_)
        evt.SetMessage("这是你的盔甲，如果你找到了更多的矿石。我很愿意替你制造更多的盔甲。")
        return
    elseif HasItem(688) then
        RemoveItem(688)
        evt.GiveItem(3, ItemType.Armor_)
        evt.SetMessage("这是你的盔甲，如果你找到了更多的矿石。我很愿意替你制造更多的盔甲。")
        return
    elseif HasItem(687) then
        RemoveItem(687)
        evt.GiveItem(2, ItemType.Armor_)
        evt.SetMessage("这是你的盔甲，如果你找到了更多的矿石。我很愿意替你制造更多的盔甲。")
        return
    elseif HasItem(686) then
        RemoveItem(686)
        evt.GiveItem(1, ItemType.Armor_)
        evt.SetMessage("这是你的盔甲，如果你找到了更多的矿石。我很愿意替你制造更多的盔甲。")
    else
        evt.SetMessage("你们必须给我更多的矿石来打造盔甲，矿石质量越高，盔甲就越好。")
    end
end)

RegisterGlobalEvent(596, nil, function()
    if HasItem(691) then
        RemoveItem(691)
        evt.GiveItem(6, ItemType.Misc)
        evt.SetMessage("这是你的道具，如果你找到了更多的矿石。我很愿意替你制造更多的道具。")
        return
    elseif HasItem(690) then
        RemoveItem(690)
        evt.GiveItem(5, ItemType.Misc)
        evt.SetMessage("这是你的道具，如果你找到了更多的矿石。我很愿意替你制造更多的道具。")
        return
    elseif HasItem(689) then
        RemoveItem(689)
        evt.GiveItem(4, ItemType.Misc)
        evt.SetMessage("这是你的道具，如果你找到了更多的矿石。我很愿意替你制造更多的道具。")
        return
    elseif HasItem(688) then
        RemoveItem(688)
        evt.GiveItem(3, ItemType.Misc)
        evt.SetMessage("这是你的道具，如果你找到了更多的矿石。我很愿意替你制造更多的道具。")
        return
    elseif HasItem(687) then
        RemoveItem(687)
        evt.GiveItem(2, ItemType.Misc)
        evt.SetMessage("这是你的道具，如果你找到了更多的矿石。我很愿意替你制造更多的道具。")
        return
    elseif HasItem(686) then
        RemoveItem(686)
        evt.GiveItem(1, ItemType.Misc)
        evt.SetMessage("这是你的道具，如果你找到了更多的矿石。我很愿意替你制造更多的道具。")
    else
        evt.SetMessage("你们必须给我更多的矿石来制造物品，矿石质量越高，物品就越好。")
    end
end)

RegisterGlobalEvent(597, nil, function()
    if IsQBitSet(QBit(174)) then
        evt.SetMessage("恭喜你！你已经成为了“魔幻牌”的霸主！奖品就在我屋子外面的宝箱里面等待着你。")
        ClearQBit(QBit(173)) -- 在全世界的所有十一间酒吧中于魔幻牌的游戏中获胜，然后回去找渡鸦海滨的汤克・蓝天鹅。
        ClearQBit(QBit(174))
        evt.ForPlayer(Players.All)
        AddValue(Experience, 50000)
        SetQBit(QBit(175))
        SetAward(Award(41))
        evt.SetNPCGreeting(222, 0) -- 汤克・蓝天鹅 greeting cleared
        evt.SetNPCTopic(222, 1, 0) -- 汤克・蓝天鹅 topic 1 cleared
    elseif IsQBitSet(QBit(173)) then -- 在全世界的所有十一间酒吧中于魔幻牌的游戏中获胜，然后回去找渡鸦海滨的汤克・蓝天鹅。
        evt.SetMessage("你必须要赢得所有的十一个酒吧中的比赛。在你完成之前，你没有办法成为“魔幻牌”霸主。")
    else
        evt.SetMessage("要成为“魔幻牌”的霸主，你必须在贾丹姆大陆地面上、下的所有酒吧里面赢得一次的胜利。有十一个酒吧有举办“魔幻牌”的竞赛。当你完成了这项壮举之后，回来找我领取奖赏。")
        SetQBit(QBit(173)) -- 在全世界的所有十一间酒吧中于魔幻牌的游戏中获胜，然后回去找渡鸦海滨的汤克・蓝天鹅。
    end
end)

RegisterGlobalEvent(598, nil, function()
    if not IsAtLeast(DisarmTrapSkill, 1) then
        SetValue(DiseasedYellow, 0)
        evt.StatusText("你说你会找到我要的奶酪，但是你现在竟然空手而回！别浪费我宝贵的时间！把独角兽奶酪、艾顿布理奶酪、登达克奶酪带回来给我！在你找到之前别回来！")
        return
    end
    evt.SummonItem(35, 4010, 7736, 544, 1000, 1, false)
    evt.SummonItem(36, 4010, 7736, 544, 1000, 1, false)
    evt.SummonItem(37, 4010, 7736, 544, 1000, 1, false)
    evt.SummonItem(38, 4010, 7736, 544, 1000, 1, false)
    evt.SummonItem(39, 4010, 7736, 544, 1000, 1, false)
    evt.StatusText("我已经走遍了全世界去品尝各式各样的奶酪。我的工作几乎已经完成了，但是我还有三种奶酪没有品尝过。他们是独角兽奶酪、艾顿布理奶酪、登达克奶酪。如果谁能够替我找到这些传说中美味无比的宝物，我一定会给予重酬！")
end)

RegisterGlobalEvent(654, nil, function()
    if not IsQBitSet(QBit(179)) then
        evt.SetMessage("从我小的时候，我就知道自己和奶酪有着特殊的关连。我的第一个记忆就是从母亲手上啃食刚从农庄中弄出来的奶酪！从那一天开始我就知道自己对于奶酪会产生强烈的热情，会想要体验一切味觉的极致，踏遍整个世界，只为了寻找各种稀少和珍贵的奶酪。这，就是我的宿命。")
        return
    end
    evt.SetMessage("在吃过你带给我的奶酪之后，我现在已经吃过了所有世界知名的奶酪。现在，除了我之外，没有人可以自称为世界上最伟大的奶酪品尝者了！没有人可以跟我争夺这项荣耀了！哈哈哈……")
end)

RegisterGlobalEvent(655, nil, function()
    evt.SetMessage("这世界上没有比沃里的奶酪大师更投入奶酪制作的人了。虽然沃里的霜雪巨人在一般人的眼光中算是蛮族，但他们有相当的文明发展潜力，至少以他们的奶酪制作来说是这样的。你知道吗？他们拥有四十二种不同口味的奶酪！")
end)

RegisterGlobalEvent(656, nil, function()
    if not IsQBitSet(QBit(176)) then -- 找到一块独角兽奶酪，并且带回去交给阿尔瓦的阿萨尔・福罗马哥。
        evt.SetMessage("我已经走遍了全世界去品尝各式各样的奶酪。我的工作几乎已经完成了，但是我还有三种奶酪没有品尝过。他们是独角兽奶酪、艾顿布理奶酪、登达克奶酪。如果谁能够替我找到这些传说中美味无比的宝物，我一定会给予重酬！")
        SetQBit(QBit(176)) -- 找到一块独角兽奶酪，并且带回去交给阿尔瓦的阿萨尔・福罗马哥。
        SetQBit(QBit(177)) -- 找到一块艾顿布理奶酪，并且带回去交给阿尔瓦的阿萨尔・福罗马哥。
        SetQBit(QBit(178)) -- 找到一块登达克奶酪，并且带回去交给阿尔瓦的阿萨尔・福罗马哥。
        return
    end
    evt.ForPlayer(Players.All)
    if HasItem(658) then
        if HasItem(659) then
            if HasItem(660) then
                evt.SetMessage("太好了！把所有的奶酪给我！我一定要吃吃看！\n啊……嚼嚼……独角兽奶酪，味道太精致了……嗯嗯，艾顿布理，烟熏味相当的不错……登达克……味道就不怎么好了，对吧？\n你帮我完成了贾丹姆大陆的奶酪品尝之旅！我死也甘愿了！我太感激你了！这是我答应给你的报酬！")
                evt.ForPlayer(Players.Member0)
                AddValue(Gold, 25000)
                evt.ForPlayer(Players.All)
                AddValue(Experience, 20000)
                RemoveItem(658)
                RemoveItem(659)
                RemoveItem(660)
                SetAward(Award(42))
                ClearQBit(QBit(176)) -- 找到一块独角兽奶酪，并且带回去交给阿尔瓦的阿萨尔・福罗马哥。
                ClearQBit(QBit(177)) -- 找到一块艾顿布理奶酪，并且带回去交给阿尔瓦的阿萨尔・福罗马哥。
                ClearQBit(QBit(178)) -- 找到一块登达克奶酪，并且带回去交给阿尔瓦的阿萨尔・福罗马哥。
                SetQBit(QBit(179))
                evt.SetNPCTopic(254, 2, 0) -- 阿萨尔・福罗马哥 topic 2 cleared
                return
            elseif HasItem(658) then
                evt.SetMessage("很好，你已经找到一部份我要的奶酪了，但是我想要一次品尝所有的奶酪，以便彻底地分辨出他们的味道来。在你找到所有的奶酪之后再来找我。你先暂时把你所找到的奶酪带走，我想我抵抗不了这些奶酪的诱惑，可能会一不小心把他们全都吃光！")
                return
            elseif HasItem(659) then
                evt.SetMessage("很好，你已经找到一部份我要的奶酪了，但是我想要一次品尝所有的奶酪，以便彻底地分辨出他们的味道来。在你找到所有的奶酪之后再来找我。你先暂时把你所找到的奶酪带走，我想我抵抗不了这些奶酪的诱惑，可能会一不小心把他们全都吃光！")
                return
            elseif HasItem(660) then
                evt.SetMessage("很好，你已经找到一部份我要的奶酪了，但是我想要一次品尝所有的奶酪，以便彻底地分辨出他们的味道来。在你找到所有的奶酪之后再来找我。你先暂时把你所找到的奶酪带走，我想我抵抗不了这些奶酪的诱惑，可能会一不小心把他们全都吃光！")
            else
                evt.SetMessage("你说你会找到我要的奶酪，但是你现在竟然空手而回！别浪费我宝贵的时间！把独角兽奶酪、艾顿布理奶酪、登达克奶酪带回来给我！在你找到之前别回来！")
            end
            return
        elseif HasItem(658) then
            evt.SetMessage("很好，你已经找到一部份我要的奶酪了，但是我想要一次品尝所有的奶酪，以便彻底地分辨出他们的味道来。在你找到所有的奶酪之后再来找我。你先暂时把你所找到的奶酪带走，我想我抵抗不了这些奶酪的诱惑，可能会一不小心把他们全都吃光！")
            return
        elseif HasItem(659) then
            evt.SetMessage("很好，你已经找到一部份我要的奶酪了，但是我想要一次品尝所有的奶酪，以便彻底地分辨出他们的味道来。在你找到所有的奶酪之后再来找我。你先暂时把你所找到的奶酪带走，我想我抵抗不了这些奶酪的诱惑，可能会一不小心把他们全都吃光！")
            return
        elseif HasItem(660) then
            evt.SetMessage("很好，你已经找到一部份我要的奶酪了，但是我想要一次品尝所有的奶酪，以便彻底地分辨出他们的味道来。在你找到所有的奶酪之后再来找我。你先暂时把你所找到的奶酪带走，我想我抵抗不了这些奶酪的诱惑，可能会一不小心把他们全都吃光！")
        else
            evt.SetMessage("你说你会找到我要的奶酪，但是你现在竟然空手而回！别浪费我宝贵的时间！把独角兽奶酪、艾顿布理奶酪、登达克奶酪带回来给我！在你找到之前别回来！")
        end
        return
    elseif HasItem(658) then
        evt.SetMessage("很好，你已经找到一部份我要的奶酪了，但是我想要一次品尝所有的奶酪，以便彻底地分辨出他们的味道来。在你找到所有的奶酪之后再来找我。你先暂时把你所找到的奶酪带走，我想我抵抗不了这些奶酪的诱惑，可能会一不小心把他们全都吃光！")
        return
    elseif HasItem(659) then
        evt.SetMessage("很好，你已经找到一部份我要的奶酪了，但是我想要一次品尝所有的奶酪，以便彻底地分辨出他们的味道来。在你找到所有的奶酪之后再来找我。你先暂时把你所找到的奶酪带走，我想我抵抗不了这些奶酪的诱惑，可能会一不小心把他们全都吃光！")
        return
    elseif HasItem(660) then
        evt.SetMessage("很好，你已经找到一部份我要的奶酪了，但是我想要一次品尝所有的奶酪，以便彻底地分辨出他们的味道来。在你找到所有的奶酪之后再来找我。你先暂时把你所找到的奶酪带走，我想我抵抗不了这些奶酪的诱惑，可能会一不小心把他们全都吃光！")
    else
        evt.SetMessage("你说你会找到我要的奶酪，但是你现在竟然空手而回！别浪费我宝贵的时间！把独角兽奶酪、艾顿布理奶酪、登达克奶酪带回来给我！在你找到之前别回来！")
    end
end)

RegisterGlobalEvent(657, nil, function()
    evt.SetMessage("陌生人出现的那天晚上，也就是这些诡异水晶出现的同一个晚上。我只看见那个陌生人的身影一眼，那看起来似乎没有多大的威胁。当他召唤出水晶的时候，我并不在镇广场上，所以我并没有看见激射入天空的光芒。这真是恐怖的一夜。")
end)

RegisterGlobalEvent(658, nil, function()
    evt.SetMessage("一个流浪者走进镇上。有几个流氓想要从他身上抢走一些小东西。但那人根本不理他们。他手腕轻轻一振，所有的人就都跌倒在他面前。然后他就走到镇中央，召唤来你今天所看到的那个巨大的水晶。")
end)

RegisterGlobalEvent(659, nil, function()
    evt.SetMessage("在黑暗精灵中有一句俗语，“必须要有人活着才能够把记忆留存下去。”水晶突然出现在我们镇中央的那个景象将会留存很长的一段时间。我们有很多人都看见了那个景象。召唤来水晶的人并没有跟我们说任何的话。当他看着我们的时候，似乎他的眼中和心中都只有同情和怜悯。")
end)

RegisterGlobalEvent(660, nil, function()
    evt.SetMessage("当那个法师来到镇上的时候，我并没有多想。这是渡鸦海滨，任何人在贾丹姆大陆上旅行都几乎会经过的地方。我想我应该更注意他一些的。看起来他似乎在镇上造成了相当的混乱。")
end)

RegisterGlobalEvent(661, nil, function()
    evt.SetMessage("雷格那海盗拥有整个大海。没有人可以对抗他们！几年以前，有一些渔船的船长认为自己可以前往埃拉西亚寻求救兵来对付这些海盗。后来我们却再也没有听过他们的消息。")
end)

RegisterGlobalEvent(662, nil, function()
    evt.SetMessage("雷格那人是贾丹姆大陆附近海域上最糟糕的流氓。他们让这个大陆上的人们无法和埃拉西亚和恩洛斯的人们贸易。我们有什么选择呢？即使连阿尔瓦的商人公会都无法召集够大的舰队来对付他们。谣传私枭们找到了方法可以躲过这些海盗的阻挡。")
end)

RegisterGlobalEvent(663, nil, function()
    evt.SetMessage("雷格那人称自己属于无尽之海的帝国。这只不过是虚张声势而已。他们只不过是流氓和强盗而已。当然，你千万别跟他们说这句话是我说的！")
end)

RegisterGlobalEvent(664, nil, function()
    evt.SetMessage("过去几周以来，食人妖和强盗似乎在贾丹姆大陆的各主要干道间四处劫掠。日子真是越来越难过了。海上有雷格那海盗，路上又有这些该死的强盗，我们根本没有任何方法可以旅行嘛！")
end)

RegisterGlobalEvent(665, nil, function()
    evt.SetMessage("曾经有几名战士成群结队地准备对付那些在渡鸦海滨道路附近兴建要塞的食人妖。这是我们第一次听说他们在西南方建造的要塞。从要塞完成之后，往西和往南的道路就都变得不安全了。")
end)

RegisterGlobalEvent(666, nil, function()
    evt.SetMessage("贾丹姆大陆的走私者也许被人视作神秘的传言，但我可不这么认为。阿尔瓦商人似乎能够将少量的货物运送到埃拉西亚和恩洛斯去。但是他们没有自己的船只。这看起来似乎证明了走私者的存在。但是，他们为什么要替这些商人工作就让我不能理解了。")
end)

RegisterGlobalEvent(667, nil, function()
    evt.SetMessage("鼠人！他们是最糟糕的生物！他们日夜不停地在我们的垃圾堆里面乱挖！老是在黑暗中鬼鬼祟祟地乱跑！太阳升起之后他们就通通不见了。真是让我浑身起鸡皮疙瘩！")
end)

RegisterGlobalEvent(668, nil, function()
    evt.SetMessage("居住在这里东南方的独眼巨人一直都是铁锈镇最大的威胁！但是，这座城镇原先可以抵挡任何种类的攻击。他们数量不多的时候没什么好担心的，但是，如果他们在沙漠中出其不意地突袭你，你就很难逃过一劫！")
end)

RegisterGlobalEvent(669, nil, function()
    evt.SetMessage("火焰之湖是个让我们意料外的状况。它就像是野火一般地在村庄的东半边扩散。我们很幸运，因为它的扩散已经减缓下来了。但是我依然很怀疑我们到底还可以撑多久。")
end)

RegisterGlobalEvent(670, nil, function()
    evt.SetMessage("我们必须要找个新的居住地才行！没有任何的生物可以在这样的环境底下生存。即使是独眼巨人都准备要搬迁了。谣传我们过去是从别的地方搬迁到这里来的。传说中也提到了该处是个丰饶、翠绿的地方。真希望真的有这个地方存在。")
end)

RegisterGlobalEvent(671, nil, function()
    evt.SetMessage("阿尔瓦和阴影塔地区的商人愿意贩卖贾丹姆大陆上所有你能够想到的矿石。他们可以利用矿石打造更多的物品，也因此愿意用这些物品换取更多的矿石。")
end)

RegisterGlobalEvent(672, nil, function()
    evt.SetMessage("你知道吗？据说时光金库在渡鸦海滨创建之前就存在了，这座城镇根本就是绕着该金库所创建的。金库里面应该藏着索恩帝王的财富。许多人来到这个地方想要开启该金库，但是都失败了。")
end)

RegisterGlobalEvent(673, nil, function()
    evt.SetMessage("光是吉柯德就够让我们伤脑筋了。现在竟然又出了艾欣格和老罗伯这两个叛徒！他们认为可以靠着将部族四处扩散而重建我们的种族，并且聚集自己的部落。愚蠢！他们的所作所为只不过是让我们的数量更为分散，让我们的力量更为减弱而已。雅达克则是逃到了铁沙漠去，除了他们三个之外，我不知道还有其它飞龙离开了这个地方。")
end)

RegisterGlobalEvent(674, nil, function()
    evt.SetMessage("虽然绞刑峡谷地区是飞龙密度最高的地方，但是据说其它的地方也在进行飞龙的狩猎。举例来说，谣传铁沙漠中有一只巨大的古老飞龙。其它的飞龙似乎躲藏在残破镇的恶地中。")
end)

RegisterGlobalEvent(675, nil, function()
    evt.SetMessage("当查尔斯・吉柯德带着我们从埃拉西亚渡海而来的时候，我们曾经航过雷格那岛。当我们第一次看到贾丹姆大陆的土地时，我发现了一个好兆头：一只巨大无比的飞龙朝向该处飞去。我真希望可以狠狠地刺上它一矛！那是我所看过最大的飞龙！")
end)

RegisterGlobalEvent(676, nil, function()
    evt.SetMessage("没错，当毁灭者走进渡鸦海滨的时候，我就在现场！我当时正在打铁铺请铁匠磨利我的小刀。他走过人群之中，彷佛君临天下。有群人远远地跟踪着他。其中一个人丢出一块石头，但它彷佛击中魔法防护罩一样地弹开了。他似乎根本没注意到。稍后，我听到镇中央广场传来一阵爆炸。我跑去看，但毁灭者已经离开了，该处只剩下水晶和尸体。")
end)

RegisterGlobalEvent(677, nil, function()
    evt.SetMessage("没错，我看见了“毁灭者”，这还真是个不错的名字！我以为他是名富有的商人，看起来是个相当容易撂倒的家伙，因此我……我试着抢走他的东西。我跑到他前头，躲在巷子里面想要偷袭他。当他走过去的时候，我扑上去！但这真是一个大错误，我甚至连碰都没有碰到他！我一靠近，就立刻被他的魔法给弹了开来。事实上，我被弹过一座屋子，飞到隔壁的街上去了！")
end)

RegisterGlobalEvent(678, nil, function()
    evt.SetMessage("那个该死的鼠人，也就是那些什么伊普的牧师，只会制造麻烦而已。他们不像神职人员，只是一群小偷而已！我警告你们，当他们靠近的时候，千万小心自己身上的财物。他们会偷走任何没有钉在地上的东西。")
end)

RegisterGlobalEvent(679, nil, function()
    evt.SetMessage("如果你想要寻找奶酪，我建议你去伊普教堂找找看。你知道的，老鼠喜欢奶酪。鼠人也是一样。据说他们在每座神殿里面都有一大堆的奶酪。")
end)

RegisterGlobalEvent(680, nil, function()
    evt.SetMessage("除了我们所面对的一大堆问题之外，统治这个领域的元素之王也跟着失踪了。他是拥有强大力量的生物，一定可以抵抗驱使我们的这种黑暗的魔法。")
end)

RegisterGlobalEvent(681, nil, function()
    evt.SetMessage("我希望我自己了解到底发生了什么事情。那原本是和平常一样宁静的一天，这个空间原本十分的祥和。突然之间每个人都开始疯狂地嚎叫，胸中充满了欲望，想要破坏你们的贾丹姆大陆。即使是现在，我的土元素同胞们也在齐心一致地将这个空间推进你们的世界中。")
end)

RegisterGlobalEvent(682, nil, function()
    evt.SetMessage("也许我没有被这种疯病影响的原因是我身上带着有此地的元素之王所送给我的护身符。据说是他和其它的元素之王联手创造了你们的世界。如果他在这边，他一定可以阻止这场疯狂的暴乱，但他不见了！当我们最需要它的时候，元素之王怎么会不见了呢！")
end)

RegisterGlobalEvent(683, nil, function()
    evt.SetMessage("很明显的是魔法的力量让我们这个风元素界陷入了完全的疯狂中。当这个疯病出现的时候，一切立刻陷入了混乱之中。所有受到影响的生物都放下手边的事情，开始狂乱地嚎叫。这真是一场恐怖的暴动！我们之中只有极少数还保持了清醒的神智。一天又一天，我们的世界慢慢地被这种混乱的力量给吞食。")
end)

RegisterGlobalEvent(684, nil, function()
    evt.SetMessage("我对于魔法还算有相当的研究。很明显地拥有难以想像力量的魔法影响了水元素界。我自己非常想要知道到底为什么会发生这样的事情。很明显的，如果不是绝对必要，没有人会冒险使用这样的力量。我只知道水元素界目前正在和你们的世界作战。从那之后，我就完全找不出合理的解释了！")
end)

RegisterGlobalEvent(685, nil, function()
    evt.SetMessage("我―我的家―发―发生了什么事情？所―所有的人―都疯了！更糟糕的是，我―我们的统治者―失踪了！没―没有了他―我们就死定了！")
end)

RegisterGlobalEvent(686, nil, function()
    evt.SetMessage("我从你的眼中就可以看出来，这个地方糟糕透了。但是我必须说实话，这里本来不是这样的。在那股疯狂力量来袭之前，我们本来都生活在和平与祥和的状况下。但是，突然有一天，我们的大王消失了，疯狂的力量也跟着来袭。也许他的消失带来了这个疯病？也许是这样的，因为我记忆中他似乎从来没有离开过这个地方。")
end)

RegisterGlobalEvent(687, nil, function()
    evt.SetMessage("虽然此地的大部分生物都受到疯狂力量的影响，但是他们依旧是相当聪明的敌人。我也知道他们目前正在你们的世界上征战。而且，他们并非是在疯狂中设计这一切。在那群疯狂的生物中，拥有最强战术头脑的生物规划了一切的战术。他们现在就正聚集在传送门边，准备一举攻下你们的世界。")
end)

RegisterGlobalEvent(688, nil, function()
    if not IsQBitSet(QBit(19)) then
        evt.SetMessage("真希望我可以加入你们，但是和太阳神庙的战争占据了我们全部的时间，也许等到这一切结束吧！")
        return
    end
    evt.SetMessage("现在，在我们和太阳神庙之间的争执已经似乎结束的时候，山德罗说死灵法师公会的成员可以把注意力转移到其它地方去。从我到达贾丹姆大陆之后，我就没有看过除了阴影塔之外的地区。也许……你们会需要我的帮忙？")
    evt.SetNPCTopic(278, 0, 617) -- 海瓦提亚・代佛贝罗 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(689, nil, function()
    if not IsQBitSet(QBit(20)) then
        evt.SetMessage("真希望我可以。很不幸的，我们正在和邪恶的死灵法师公会宣战。所有太阳神庙的资源，包括我自己，都全心投入在其上。")
        return
    end
    evt.SetMessage("是的！我很愿意加入你们。因为现在我们对抗死灵法师公会的圣战是如此地顺利，我想我在这边没有什么事情可以作了。如果你愿意接受我的话，我们就可以一起去冒险。")
    evt.SetNPCTopic(279, 0, 618) -- 瓦瑞西 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(690, nil, function()
    if not IsQBitSet(QBit(21)) then
        evt.SetMessage("和你们走？我可不愿意。我为什么要和一群菜鸟一起旅行？别开玩笑了。你能够提供给我什么猎龙的生涯所不能够提供的呢？")
        return
    end
    evt.SetMessage("和你冒险？我当然愿意。事实上，在查尔斯・吉柯德离开前，他刚好还跟我说过这件事情。“如果联盟的英雄出现在你面前，你应该要考虑和他们一起走。”很明显地，他对你们的评价很高。对我来说，有他的评价就够了。我们可以走了吗？")
    evt.SetNPCTopic(280, 0, 619) -- 耐力克斯・巫瑞尔 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(691, nil, function()
    if not IsQBitSet(QBit(34)) then
        evt.SetMessage("和你们一起离开？我很想要，但是我必须留在这里，因为我是这里唯一的老经验战士了。我必须要留在这里保护大家。")
        return
    end
    evt.SetMessage("没错，这听起来相当有趣。虽然村人们需要我保护他们，但是，我想如果我跟你们一起去的话，可能才更能够保护他们。如果大灾变不赶快结束，我的同胞们会全部完蛋。我应该尽一切可能去阻止他们。")
    evt.SetNPCTopic(281, 0, 620) -- 赛斯瑞克・系索朋 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(692, nil, function()
    if not IsQBitSet(QBit(34)) then
        evt.SetMessage("加入你的队伍？我必须要拒绝你。虽然你替我的同胞作了非常多的服务，但是我对你的领导能力还不太有信心。我想要对抗大灾变，但是我不确定你的方法是正确的。")
        return
    end
    evt.SetMessage("加入你的队伍？我当然很愿意。你们不只替我的同胞解决了很大的难题，很明显地，你们成功与否，更会决定这个世界是否继续存在。")
    evt.SetNPCTopic(282, 0, 621) -- 瑞欧耐尔 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(693, nil, function()
    if not IsQBitSet(QBit(34)) then
        evt.SetMessage("我看得出来你们也是冒险者。但是……说实话，虽然我对你们的潜力很有信心，但是你们并不是我所看过最有经验的队伍。如果你们能经历更多的“磨练”，我想我会对你更有信心。")
        return
    end
    evt.SetMessage("别以为你们的丰功伟业没人注意到！很明显你们是目前最受人注意的冒险队伍。如果你们愿意让我加入的话……我当然愿意加入你。")
    evt.SetNPCTopic(283, 0, 622) -- 艾瑞克・史塔拉尔 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(694, nil, function()
    if not IsQBitSet(QBit(34)) then
        evt.SetMessage("不行。我是有一点身份地位的吸血鬼。说得明白一点，我想要的是冒险，不是照顾小孩，你们的技巧还不足以和我匹配，我懒得教导你们这些菜鸟。")
        return
    end
    evt.SetMessage("没问题！太棒了。你就是我在找寻的冒险伙伴，我已经听说了很多有关你的事迹！")
    evt.SetNPCTopic(284, 0, 623) -- 因佛史塔斯 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(695, nil, function()
    if not IsQBitSet(QBit(34)) then
        evt.SetMessage("我想还是算了吧！在我仔细打量了你们一下之后，我发现你们的能力不足，我需要的是比较强悍有经验的冒险伙伴。")
        return
    end
    evt.SetMessage("你们的确符合我的要求，如果你们愿意的话，我会加入你们。")
    evt.SetNPCTopic(285, 0, 624) -- 布尔斯通 topic 0: 加入
end)

RegisterGlobalEvent(696, nil, function()
    if not IsQBitSet(QBit(38)) then
        evt.SetMessage("你一定是在开玩笑吧！我是一名威名远播的骑士。我怎么可能会和你这种名不见经传的家伙一起旅行呢？喔，也许会很好玩啦，但是我还要顾及自己的声誉呢。")
        return
    end
    evt.SetMessage("我觉得这个点子相当不错。嗯嗯，好的！开阔的空气和环境正是我所需要的。我已经在猎龙上花了太久的时间了，开始觉得有些无聊。男人必须随时转换工作才行。如果你们愿意的话，我会和你们一起走。")
    evt.SetNPCTopic(288, 0, 627) -- 坦帕斯 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(697, nil, function()
    if not IsQBitSet(QBit(38)) then
        evt.SetMessage("加入你们？哈哈，我这种身份地位的人干嘛要加入你们？")
        return
    end
    evt.SetMessage("听起来真是太棒了！从我听说的状况看起来，你们应该有机会可以成功。如果有了我的帮忙，你们就一定会成功了。我们要出发了吗？我一向很愿意让自己的传奇再度加倍。")
    evt.SetNPCTopic(289, 0, 628) -- 索恩・石下 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(698, nil, function()
    if not IsQBitSet(QBit(38)) then
        evt.SetMessage("是的，冒险是相当不错的事情。事实上，我自己还经历过很多次。让我告诉你其中几次比较精彩的……啊，我这才想到，原来你是在建议我和你一起冒险！这是个不错的建议……但是，我要怎么样顾及情面呢？你们的经验不够。恐怕我和你们一起旅行会很无聊的。")
        return
    end
    evt.SetMessage("啊，“冒险”。我最近的确比较缺乏这样东西。在我们和霜雪巨人的战争结束之后，我的任务就变成了训练我们的战士。对了，你不会刚好需要人和你一起旅行吧？也许我可以和你一起旅行。我有很多技巧对你有很大的帮助，而且我的斧头非常利喔！")
    evt.SetNPCTopic(290, 0, 629) -- 乌布理契 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(699, nil, function()
    if not IsQBitSet(QBit(38)) then
        evt.SetMessage("虽然我刚经过一场冬眠，看起来也许不怎么样。但是，你知道吗？和你说话的是目前世界上最伟大的吸血鬼之一。和你们一起走？我可不这么认为。你们这种菜鸟只会成为我的负担而已，我最好自己一个人去旅行比较好。")
        return
    end
    evt.SetMessage("啊，你们建议我自己去见见世面。这个建议相当不错，我的确已经休息够了。太好了，如果你愿意接受我的话，我们就可以一起去旅行。")
    evt.SetNPCTopic(292, 0, 631) -- 阿图瑞斯・维瑞塔斯 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(700, nil, function()
    if not IsQBitSet(QBit(38)) then
        evt.SetMessage("加入你们？真是太愚蠢了，我已经带着身上这么多跳蚤旅行了，不需要再加上你们这些寄生虫了。快滚！")
        return
    end
    evt.SetMessage("加入你们？哈！我真是敬佩你们的大胆。没错……非常敬佩。嗯，最近有这种胆子的人不多了，我愿意和你们一起走。")
    evt.SetNPCTopic(293, 0, 632) -- 永恒土洛斯 topic 0: 加入
end)

RegisterGlobalEvent(701, nil, function()
    evt.SetMessage("弹指家族的墓穴是我们村庄的墓穴中最底层的几家。由于我们的家族拥有许多的荣耀，因此我们是最大的。那地方并不好找，我自己也曾经不小心迷过路！当我迷路的时候，我发现只要自己一直把手放在右边的墙上，最后就会到达该处。")
end)

RegisterGlobalEvent(702, nil, function()
    evt.SetMessage("你找到盾牌了吗？找回“日蚀”这个盾牌对太阳神庙来说是很重要的一件事情，你一定得帮帮我们！")
end)
RegisterCanShowTopic(702, function()
    evt._BeginCanShowTopic(702)
    local visible = true
    if IsQBitSet(QBit(128)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(703, nil, function()
    evt.SetMessage("多谢你们替我们找回“日蚀”！希望在你的冒险中它能够给予你们足够的帮助！")
end)

RegisterGlobalEvent(706, nil, function()
    if not IsQBitSet(QBit(59)) then
        evt.SetMessage("很抱歉，我是喜欢冒险。但是你们和我差太远了。")
        return
    end
    evt.SetMessage("当然，为什么不要呢？我已经准备好要走了，只是得先准备一下装备才行！让公会看看到底谁行谁不行！")
    evt.SetNPCTopic(270, 0, 609) -- 卡蓝雅・麦莫瑞亚 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(707, nil, function()
    if not IsQBitSet(QBit(59)) then
        evt.SetMessage("不……不行，我的冒险生涯已经结束了。即使有人要我重新开始，也会是和别的伙伴。容我实说，你们的经验实在太过不足了一些，我很难想像自己和你们一起旅行的样子。")
        return
    end
    evt.SetMessage("好，听起来好极了！如果你们愿意的话，我会和你们走！")
    evt.SetNPCTopic(271, 0, 610) -- 麦兰德 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(708, nil, function()
    if not IsQBitSet(QBit(59)) then
        evt.SetMessage("我可不这么想！为什么我要和你这种人一起旅行？也许你听错了我的名字，“赛尔鹏”？是的，就是那个赛尔鹏。不管你们要干嘛，我都没兴趣！")
        return
    end
    evt.SetMessage("是的，我们一定会组成一个很好的队伍！我们已经完成了那么多丰功伟业，未来一定有更多的事业等待我们去完成！如果你愿意的话，我愿意和你一起走。")
    evt.SetNPCTopic(275, 0, 614) -- 杰斯波・赛尔鹏 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(709, nil, function()
    if not IsQBitSet(QBit(67)) then
        evt.SetMessage("我告诉你，在这样的时节，诚实的商人实在赚不到钱哪！你看看，我们之前的确需要应付食人妖强盗，但是现在他们竟然大胆到就在阿尔瓦附近建造要塞！没有车队可以往西走去低语森林。最糟糕的是，我的生意大多是在该地的太阳神庙中！")
        return
    end
    evt.SetMessage("你消灭了那座要塞中的食人妖，这实在帮了我们大忙！现在我的车队可以自由前往低语森林了！我非常感激你，我的钱包也是！")
end)

RegisterGlobalEvent(710, nil, function()
    evt.SetMessage("我们在阿尔瓦的确有黄蜂，而且还相当地大。但我们容忍他们是有原因的。我有许多顾客喜欢黄蜂的相关产品。如果你想要在这笔生意中参一脚，维尔顿是这行中相当出名的仲介商。他就住在这里，我听说他最近正准备要筹集一大笔的黄蜂刺。")
end)

RegisterGlobalEvent(711, nil, function()
    evt.SetMessage("没有多少人知道这件事情，但是龙的确是可以训练的。这就有点像训练野马一样，只不过你需要更多的特殊道具和魔法。这座要塞外面的驯龙就是我的明证。现在他们对我们很忠诚，但是将来我会把控制权交给我们的顾客，埃拉西亚的贵族芬尼斯・绿林。当然，这得等到他付钱之后才行。")
end)

RegisterGlobalEvent(712, nil, function()
    evt.SetMessage("冉索拉是个奇怪的家伙。也许死灵法师公会的家伙都有点奇怪，但她真的是非常的疯狂。我听说其他的公会成员拒绝和她一起工作，因为她的实验实在太恐怖了。但是，他们依旧珍惜她邪恶的天份。为了让她在附近工作，他们就在镇外替她建了一个实验室。")
end)

RegisterGlobalEvent(713, nil, function()
    evt.SetMessage("在大部分的情况下，死灵法师对当地的吸血鬼都拥有相当的管辖权。但是，有个地方是你绝对不想去的！他们都集体睡在公会北边的一个墓窖里。如果你去那边的话，请千万小心。因为他们的地域概念相当的清楚！")
end)

RegisterGlobalEvent(714, nil, function()
    evt.SetMessage("死灵法师公会？嘿，我觉得他们很棒。你们应该看看他们来这边之前的状况，一片死寂！现在我们这边有吸血鬼、骷髅人和各种各样的不死生物。现在这个地方看起来活跃多了！")
end)

RegisterGlobalEvent(715, nil, function()
    evt.SetMessage("你也应该可以想像，我的生意变得很好。当然，死灵法师公会几乎把我所有的客人都变成了骷髅和僵尸，但是吸血鬼的生意可不会断！你也想要参一脚吗？镇上有个木材商人麦兰德，他想要低语森林的木材。如果你能够把木材运过去，他会付相当不错的报酬。")
end)

RegisterGlobalEvent(716, nil, function()
    evt.SetMessage("最近狩猎变得相当困难，但是我们还是必须要狩猎才有饭吃！昨天我沿着火湖的西岸走，发现有一条隧道似乎穿过了火湖。不过，我并没有进去。那隧道里面充满了垢鬼和各种各样的怪物，就像我们村庄四周一样。")
end)

RegisterGlobalEvent(717, nil, function()
    evt.SetMessage("即使像我们这种住在这里的家伙也会迷路。如果你迷路了，请跟着那些漂浮的指路石走。啊啊……我脑中又被疯狂的力量……给占据了！")
end)

RegisterGlobalEvent(718, nil, function()
    evt.SetMessage("啊，我很高兴是你们在拯救世界。我是说，总得要有人作吧。至于我呢，我是那种喜欢安逸生活的人。只要我有鱼竿和小船，我找不到理由要去辛苦工作。祝你们好运！")
end)

RegisterGlobalEvent(719, nil, function()
    evt.SetMessage("那个史坦力啊，那可是个相当不错的雷格那人！我听说是他和那个什么叫做豺狼索格的食人妖还是什么东西的达成的协议。现在我们海上有海盗船，路上又有强盗四处乱跑。我告诉你，雷格那帝国目前真是如日中天啊，只要有恐怖海盗史坦力在为我们努力，我们一定会继续这样下去的！")
end)

RegisterGlobalEvent(720, nil, function()
    evt.SetMessage("喔，当然，我们雷格那人喜欢竞争。我指的是那些走私者。不过，我也知道恐怖海盗史坦力正在想办法阻止这些状况。我听说他绑架了艾瑞安・韩特的一家人，以便让这件事情作个了结。")
end)

RegisterGlobalEvent(721, nil, function()
    evt.SetMessage("是啊，我知道那个什么“恐怖”海盗史坦力最近是这附近的英雄，但是啊，呸！他的确替雷格那作了很多事情，但是大多数都是为了他自己！我听说他最近在干的每一笔买卖中抽成，而且这些买卖数量很多！我只想知道他到底把财宝放在哪里。我猜也许不是在雷格那上。我可不愿意让其它人把那些宝物挖出来！")
end)

RegisterGlobalEvent(722, nil, function()
    evt.SetMessage("我想到一个计划可以找出那些隐藏的财宝。在你冲进来之前，我正在研究一个可以侦测地底下黄金的法术。如果我成功了，我计划找只龙载我飞越传说中史坦力埋藏宝藏的残破镇一带。我的法术将会找到那些财宝，让我变成超级有钱的人！")
end)

RegisterGlobalEvent(723, nil, function()
    evt.SetMessage("你指的是北边的那个地方吗？我们都不愿意和它有所牵扯！里面闹鬼！")
end)

RegisterGlobalEvent(724, nil, function()
    evt.SetMessage("我不知道他们在干嘛，但是我听说附近有些鼠人。我在晚上会听到有各种各样搔爬和吱吱叫的声音。在早上的时候，所有没有锁上或是钉起来的东西都会被偷光光。如果我知道那个什么伊普教堂在什么地方，我一定会去找他们好好谈谈……")
end)

RegisterGlobalEvent(725, nil, function()
    evt.SetMessage("我本来和我的同事们在新形成的湖旁边寻找被从地底下冲出来的宝物。我们认为我们发现了洪水的来源，在湖的正中央有个传送门。我们没有船，所以我们不能够去看看。但即使从岸边也看得出来，那个传送门似乎通往一个有很多水的世界。")
end)

RegisterGlobalEvent(726, nil, function()
    evt.SetMessage("如果你们没去过那个要塞，你们应该先去那个地方。从你的情报上你应该知道，那座要塞只是用来愚弄外人的。你必须要前往那个新月形岛上的真正要塞。你必须要从你地图上的那个地下信道走过去才行。")
end)

RegisterGlobalEvent(727, nil, function()
    evt.SetMessage("我知道你们在贾丹姆大陆上的人都叫我们海盗，但是，其实我们是隶属于一个帝国的。贾丹姆大陆上的家伙不承认有我们的存在，不付税，这又不是我们的错。因为他们不付钱，我们必须要自己去收钱才行。事实上，我们比较喜欢这个方式，因为这样我们就不用真正去统治整个大陆。")
end)

RegisterGlobalEvent(728, nil, function()
    if not IsQBitSet(QBit(19)) then
        evt.SetMessage("我们吸血鬼一般来说不能够在白天出没，但是死灵法师公会的谭特创造了一个法宝来处理这个状况。吸血鬼只要配戴着龙葵护身符，就可以自由自在地在白天行走。很遗憾的，护身符的数量并不多。我自己就没有，因此在白天必须要躲在屋内才行。")
        return
    end
    evt.SetMessage("在正常状况下，我们这些吸血鬼的确需要谭特的龙葵护身符才能够在白天行动，但是在你带回了龙葵灯炉之后，夜晚从此笼罩了阴影塔地区。现在我们不需要配戴护身符，只要待在这个区域里面就可以自由行动了。")
end)

RegisterGlobalEvent(729, nil, function()
    evt.SetMessage("虽然这不是我的风格，但是附近的人都很喜欢配戴各种各样的珠宝。他们说这是流行，但我觉得这太过俗气。如果你有什么珠宝要卖，请找此地的帕佛谈谈。他是这里负责处理这些怪异商品的家伙。")
end)

RegisterGlobalEvent(730, nil, function()
    evt.SetMessage("你在找翻车鱼吗？抱歉，我帮不上忙。还真是不巧，我上个礼拜还有一大箱的翻车鱼，但是帕佛刚好把它都买走了。也许你可以从他那边买到一些。")
end)

RegisterGlobalEvent(731, nil, function()
    evt.SetMessage("我们楼下有个小仓库。你们可以自由利用该处的箱子来储藏多馀的装备。如果你不想要带着东西到处乱跑，就储藏在这里吧！")
end)

RegisterGlobalEvent(732, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(4)) then
        if not IsQBitSet(QBit(24)) then
            evt.SetMessage("我看到了一个景象，是你将一封信从渡鸦海滨的艾尔加・费尔蒙手上交到艾瑞安・韩特的手上。他也是渡鸦海滨的走私商人领袖。在这一切完成之后，你又回到费尔蒙身边。这个景象的结局非常的模糊，你应该没有完全过完这些影像。不过，你的命运就是要完成这些事情。")
            SetAutonote(235)
            return
        end
        if not IsQBitSet(QBit(12)) then
            evt.SetMessage("我不需要我的预知能力就能够知道你接下来该作些什么。照着费尔蒙要求的去作，去找巴斯沈・卢德林，也就是阿尔瓦商人公会的会长。他目前人在阿尔瓦中。")
            SetAutonote(236)
            return
        end
        if IsQBitSet(QBit(62)) then
            if not IsQBitSet(QBit(59)) then
                evt.SetMessage("很明显的，你必须要将巨魔欧瓦都带到阿尔瓦的商人公会去。")
                SetAutonote(239)
                return
            end
            if IsQBitSet(QBit(34)) then
                if IsQBitSet(QBit(57)) then
                    evt.SetMessage("不知道你听说了没有，雷格那海盗正在攻击渡鸦海滨。这座城必须要在战火下疏散。在议会回来指导你下一步的工作之前，你必须要杀死这些海盗，避免他们继续威胁此地的人民。")
                    SetAutonote(246)
                    return
                elseif IsQBitSet(QBit(37)) then
                    if not IsQBitSet(QBit(38)) then
                        evt.SetMessage("现在你已经弄沉了雷格那的舰队。请回去找你的联盟议会寻求指示。他们会指引你下一步该进行些什么。")
                        SetAutonote(247)
                        return
                    end
                    if IsQBitSet(QBit(92)) then
                        if IsQBitSet(QBit(45)) then
                            if IsQBitSet(QBit(47)) then
                                if IsQBitSet(QBit(228)) then
                                    evt.SetMessage("平衡已经恢复了。现在你的命运已经达成了，我再也不能够指引你了。我的视线只能够看到和平衡有关系的未来。你现在要作什么都看你自己了。祝你好运，贾丹姆大陆的英雄！")
                                    SetAutonote(256)
                                    return
                                elseif IsQBitSet(QBit(56)) then
                                    evt.SetMessage("快去找萨索尔！因为他是这场平衡游戏中的一个棋子，命运的下一步就是应该让你和他会面。")
                                    SetAutonote(255)
                                else
                                    evt.SetMessage("在我的预知能力中，你必须要找到四名元素之王，并且将它们从监狱中释放出来。他们的监狱就在毁灭者的世界，也就是界间之地。")
                                    SetAutonote(254)
                                end
                                return
                            elseif IsQBitSet(QBit(235)) then
                                evt.SetMessage("你已经和毁灭者谈过了，但却无法从他的口中获知足够的线索来解决你未来的谜题，你必须要再回去才能够知道足够的线索。")
                                SetAutonote(253)
                            else
                                evt.SetMessage("你的命运就是必须通过渡鸦海滨的水晶传送门。它将会带你前往界间之地，在那里你会找到元素大灾变的起源。")
                                SetAutonote(252)
                            end
                            return
                        elseif HasItem(606) then
                            if HasItem(607) then
                                if HasItem(608) then
                                    if not HasItem(609) then
                                        evt.SetMessage("很显然的，你必须要照着萨索尔的指示来作。前往四个元素界，并且在每个元素界找到当地的元素之心。")
                                        SetAutonote(250)
                                        return
                                    end
                                    evt.SetMessage("你现在已经拥有了四个元素之心，你应该带四个元素之心去渡鸦海滨找当地的智者萨索尔。")
                                    SetAutonote(251)
                                    return
                                end
                            end
                            evt.SetMessage("很显然的，你必须要照着萨索尔的指示来作。前往四个元素界，并且在每个元素界找到当地的元素之心。")
                            SetAutonote(250)
                            return
                        else
                            evt.SetMessage("很显然的，你必须要照着萨索尔的指示来作。前往四个元素界，并且在每个元素界找到当地的元素之心。")
                            SetAutonote(250)
                            return
                        end
                    elseif IsQBitSet(QBit(91)) then -- 和艾恩法斯特王朝的智者萨索尔请教有关渡鸦海滨水晶的问题。
                        evt.SetMessage("我看见了在你的现在和未来之间有一个很重要的连结还没有完成。请找出住在渡鸦海滨的智者萨索尔来。他将会告诉你接下来该怎么作。")
                        SetAutonote(249)
                    else
                        evt.SetMessage("你必须和艾恩法斯特王朝的皇家智者萨索尔谈话，他就住在渡鸦海滨这里。")
                        SetAutonote(248)
                    end
                    return
                elseif IsQBitSet(QBit(36)) then -- 把雷格那的舰队弄沉，回到渡鸦海滨的议会报告。
                    evt.SetMessage("你必须要照着议会的指示来进行工作，找到前往雷格那港口的方法，弄沉当地的舰队。")
                    SetAutonote(245)
                else
                    evt.SetMessage("我看见了在你的现在和未来之间有一个很重要的连结还没有完成。你必须要回到渡鸦海滨商人公会之家的议会处听取他们的意见。他们将会派遣你到下一个需要你的地方去。")
                    SetAutonote(244)
                end
                return
            elseif IsQBitSet(QBit(23)) then
                if IsQBitSet(QBit(19)) then
                    if IsQBitSet(QBit(21)) then
                        evt.SetMessage("你在寻找盟友的工作上表现得相当好，现在该是你听取这些盟友意见的时候了。请到渡鸦海滨的商人公会之家里面，寻求他们所组成的议会之意见。")
                        SetAutonote(243)
                        return
                    elseif IsQBitSet(QBit(22)) then
                        evt.SetMessage("你在寻找盟友的工作上表现得相当好，现在该是你听取这些盟友意见的时候了。请到渡鸦海滨的商人公会之家里面，寻求他们所组成的议会之意见。")
                        SetAutonote(243)
                    else
                        evt.SetMessage("在宇宙万物的平衡之间出了问题，我花了好长一段时间才知道了原因。在绞刑峡谷中的骑士和飞龙之间出现了冲突。你必须要选择一方来协助，阻止这场战争。")
                        SetAutonote(242)
                    end
                    return
                elseif IsQBitSet(QBit(20)) then
                    if IsQBitSet(QBit(21)) then
                        evt.SetMessage("你在寻找盟友的工作上表现得相当好，现在该是你听取这些盟友意见的时候了。请到渡鸦海滨的商人公会之家里面，寻求他们所组成的议会之意见。")
                        SetAutonote(243)
                        return
                    elseif IsQBitSet(QBit(22)) then
                        evt.SetMessage("你在寻找盟友的工作上表现得相当好，现在该是你听取这些盟友意见的时候了。请到渡鸦海滨的商人公会之家里面，寻求他们所组成的议会之意见。")
                        SetAutonote(243)
                    else
                        evt.SetMessage("在宇宙万物的平衡之间出了问题，我花了好长一段时间才知道了原因。在绞刑峡谷中的骑士和飞龙之间出现了冲突。你必须要选择一方来协助，阻止这场战争。")
                        SetAutonote(242)
                    end
                else
                    evt.SetMessage("在宇宙万物的平衡之间出了问题，我花了好长一段时间才知道了原因。这是由于低语森林的太阳神庙的牧师，以及阴影塔的死灵法师之间的战争。你必须要选择一方来协助，阻止这场战争。")
                    SetAutonote(241)
                end
            else
                evt.SetMessage("我今天看穿了非常远的距离，但是在时间方面则没有什么崭获。我看见了巴尔萨煞巢穴的牛头人们遭遇到了极大的灾祸，我感应到你的命运和他们的命运是相关连的，你必须要将它们从危难中救出来。")
                SetAutonote(240)
            end
            return
        elseif IsQBitSet(QBit(25)) then -- 找到一个目击火湖形成的证人，并且将它带回阿尔瓦的商人公会。
            evt.SetMessage("在我昨天晚上的梦中，我看见你在铁沙漠中旅行，寻找目击大灾变期间火湖形成的目击证人。")
            SetAutonote(238)
        else
            evt.SetMessage("我看见了在你的现在和未来之间有一个很重要的连结还没有完成。你必须要回去找巴斯沈・卢德林，继续和他的对话。他将会告诉你下一步应该要怎么作。")
            SetAutonote(237)
        end
        return
    elseif IsQBitSet(QBit(3)) then -- 将达德洛斯的信送给渡鸦海滨商人之家中的艾德加・费尔蒙
        evt.SetMessage("嗯嗯……我今天没办法看得太远，因为乙太今天的浓度实在太浓了。我只能看到，你必须要把达德洛斯给予你的信件交给商人艾尔加・费尔蒙。费尔蒙就居住在渡鸦海滨这座城市中。")
        SetAutonote(234)
    else
        evt.SetMessage("你是受雇于阿尔瓦的商人吗？那么我想你应该和达德洛斯谈谈。我的天眼通告诉我他就在匕伤群岛上。")
        SetAutonote(233)
    end
end)

RegisterGlobalEvent(733, nil, function()
    evt.ForPlayer(Players.Member0)
    if IsQBitSet(QBit(1537)) then
        evt.SetMessage("考瑞告诉过我有关石化蜥蜴的诅咒。她交代我可以晋升你队伍中的黑暗精灵为黑暗精灵长。")
        ClearQBit(QBit(39)) -- 找到考瑞・黑王座，然后回去低语森林，将她所在的位置告诉丹提理安。
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 8) then
                SetValue(ClassId, 9)
                SetQBit(QBit(1537))
            else
                SetAward(Award(20))
            end
        end
        return
    elseif HasAward(Award(20)) then
        evt.SetMessage("考瑞告诉过我有关石化蜥蜴的诅咒。她交代我可以晋升你队伍中的黑暗精灵为黑暗精灵长。")
        ClearQBit(QBit(39)) -- 找到考瑞・黑王座，然后回去低语森林，将她所在的位置告诉丹提理安。
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 8) then
                SetValue(ClassId, 9)
                SetQBit(QBit(1537))
            else
                SetAward(Award(20))
            end
        end
    else
        evt.SetMessage("在你找到考瑞・黑王座之前，你不能够获得晋升！找到她，她就会让你晋升。在你找到她，回到商人公会之后，我很愿意帮你队伍中的任何黑暗精灵晋升为黑暗精灵长。")
    end
end)

RegisterGlobalEvent(734, nil, function()
    evt.ForPlayer(Players.Member0)
    if IsQBitSet(QBit(1538)) then
        evt.SetMessage("在瓦洛格离开之前，他交代我将你们队伍中的所有巨魔晋升为战斗巨魔。恭喜你们，也多谢你帮我们找到新家园！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 38) then
                SetValue(ClassId, 39)
                SetQBit(QBit(1538))
            else
                SetQBit(QBit(1539))
            end
        end
        return
    elseif IsQBitSet(QBit(1539)) then
        evt.SetMessage("在瓦洛格离开之前，他交代我将你们队伍中的所有巨魔晋升为战斗巨魔。恭喜你们，也多谢你帮我们找到新家园！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 38) then
                SetValue(ClassId, 39)
                SetQBit(QBit(1538))
            else
                SetQBit(QBit(1539))
            end
        end
    else
        evt.SetMessage("在你找到古代巨魔之家之前你不能够晋升！")
    end
end)

RegisterGlobalEvent(735, nil, function()
    evt.ForPlayer(Players.Member0)
    if IsQBitSet(QBit(1540)) then
        evt.SetMessage("多谢你帮我们找到艾邦斯特屠龙枪！我可以将你队伍中的所有人晋升为勇士！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 16) then
                SetValue(ClassId, 19)
                SetQBit(QBit(1540))
            else
                SetQBit(QBit(1541))
            end
        end
        ClearQBit(QBit(70)) -- 找到布拉森・暴风枪以及那柄黑木之矛。完成任务之后去绞刑峡谷找连恩・暴风枪，并且将黑木之矛交给查尔斯・吉科德。
        return
    elseif IsQBitSet(QBit(1541)) then
        evt.SetMessage("多谢你帮我们找到艾邦斯特屠龙枪！我可以将你队伍中的所有人晋升为勇士！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 16) then
                SetValue(ClassId, 19)
                SetQBit(QBit(1540))
            else
                SetQBit(QBit(1541))
            end
        end
        ClearQBit(QBit(70)) -- 找到布拉森・暴风枪以及那柄黑木之矛。完成任务之后去绞刑峡谷找连恩・暴风枪，并且将黑木之矛交给查尔斯・吉科德。
    else
        evt.SetMessage("在你证明了自己的能力之前无法晋升为勇士！")
    end
end)

RegisterGlobalEvent(736, nil, function()
    evt.ForPlayer(Players.Member0)
    if IsQBitSet(QBit(1543)) then
        evt.SetMessage("你们已经证明了自己的能力，我将会把你们队伍中的飞龙晋升为神龙！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 10) then
                SetValue(ClassId, 11)
                SetQBit(QBit(1543))
            else
                SetQBit(QBit(1544))
            end
        end
        return
    elseif IsQBitSet(QBit(1544)) then
        evt.SetMessage("你们已经证明了自己的能力，我将会把你们队伍中的飞龙晋升为神龙！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 10) then
                SetValue(ClassId, 11)
                SetQBit(QBit(1543))
            else
                SetQBit(QBit(1544))
            end
        end
    else
        evt.SetMessage("你还没证明自己的能力！在你对猎龙人造成重大打击之前，你们都不会获得晋升！")
    end
end)

RegisterGlobalEvent(737, nil, function()
    evt.ForPlayer(Players.Member0)
    if IsQBitSet(QBit(1546)) then
        evt.SetMessage("我们永远都欢迎你！我当然愿意将你们队伍中的牧师晋升为太阳主教！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 4) then
                SetValue(ClassId, 6)
                SetQBit(QBit(1546))
            else
                SetAward(Award(31))
            end
        end
        return
    elseif HasAward(Award(31)) then
        evt.SetMessage("我们永远都欢迎你！我当然愿意将你们队伍中的牧师晋升为太阳主教！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 4) then
                SetValue(ClassId, 6)
                SetQBit(QBit(1546))
            else
                SetAward(Award(31))
            end
        end
    else
        evt.SetMessage("在你找回太阳预言之前，你不能够晋升为太阳主教！")
    end
end)

RegisterGlobalEvent(738, nil, function()
    evt.ForPlayer(Players.Member0)
    if IsQBitSet(QBit(1548)) then
        evt.SetMessage("啊，你回来替自己的队友寻求晋升吗？我并没有忘记你们寻找凯尔的失落之书的功绩！你们队伍中所有的死灵法师都可以晋升为巫妖。请让每个死灵法师都拥有一个巫妖之瓶。")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 44) then
                if not HasItem(628) then
                    evt.SetMessage("你找到了凯尔的失落之书，但是你没有转换仪式所需要的巫妖之瓶！当你替队伍中的每个死灵法师都找到一个巫妖之瓶的时候再回来找我！")
                    return
                end
            end
        end
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 44) then
                SetValue(ClassId, 45)
                SetQBit(QBit(1548))
                RemoveItem(628)
            else
                SetAward(Award(35))
            end
        end
        return
    elseif HasAward(Award(35)) then
        evt.SetMessage("啊，你回来替自己的队友寻求晋升吗？我并没有忘记你们寻找凯尔的失落之书的功绩！你们队伍中所有的死灵法师都可以晋升为巫妖。请让每个死灵法师都拥有一个巫妖之瓶。")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 44) then
                if not HasItem(628) then
                    evt.SetMessage("你找到了凯尔的失落之书，但是你没有转换仪式所需要的巫妖之瓶！当你替队伍中的每个死灵法师都找到一个巫妖之瓶的时候再回来找我！")
                    return
                end
            end
        end
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 44) then
                SetValue(ClassId, 45)
                SetQBit(QBit(1548))
                RemoveItem(628)
            else
                SetAward(Award(35))
            end
        end
    else
        evt.SetMessage("你们还没有找回凯尔的失落之书，在你找回那本书之前，你们无法晋升！去找维崔那斯・泰尔沙尔谈谈！")
    end
end)

RegisterGlobalEvent(739, nil, function()
    evt.ForPlayer(Players.Member0)
    if IsQBitSet(QBit(1547)) then
        evt.SetMessage("你们队伍中的所有吸血鬼都会被晋升为血之尊皇！我不会忘记你们寻回可布遗骸的功绩！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 40) then
                SetValue(ClassId, 41)
                SetQBit(QBit(1547))
            else
                SetAward(Award(33))
            end
        end
        return
    elseif HasAward(Award(33)) then
        evt.SetMessage("你们队伍中的所有吸血鬼都会被晋升为血之尊皇！我不会忘记你们寻回可布遗骸的功绩！")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 40) then
                SetValue(ClassId, 41)
                SetQBit(QBit(1547))
            else
                SetAward(Award(33))
            end
        end
    else
        evt.SetMessage("你还没有找到可布，在那之前我拒绝让你晋升！快离开！")
    end
end)

RegisterGlobalEvent(740, nil, function()
    evt.ForPlayer(Players.Member0)
    if IsQBitSet(QBit(1545)) then
        evt.SetMessage("马苏尔的子民感激你。你队伍中的所有牛头人将被晋升为牛头领主。")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 20) then
                SetValue(ClassId, 21)
                SetQBit(QBit(1545))
            else
                SetAward(Award(29))
            end
        end
        return
    elseif HasAward(Award(29)) then
        evt.SetMessage("马苏尔的子民感激你。你队伍中的所有牛头人将被晋升为牛头领主。")
        for _, player in ipairs({Players.Member0, Players.Member1, Players.Member2, Players.Member3, Players.Member4}) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 20) then
                SetValue(ClassId, 21)
                SetQBit(QBit(1545))
            else
                SetAward(Award(29))
            end
        end
    else
        evt.SetMessage("你们还没有找到巴尔萨煞之斧！你们不值得获得晋升！")
    end
end)

RegisterGlobalEvent(741, nil, function()
    evt.SetMessage("我的父亲派你来拯救我？非常感谢你。我会回到我父亲身边，让他知道你的努力。")
    evt.ForPlayer(Players.All)
    AddValue(Experience, 5000)
    evt.SetNPCTopic(102, 0, 0) -- 伊拉贝尔・韩特 topic 0 cleared
    ClearQBit(QBit(119)) -- 将艾瑞安・韩特的女儿从阿尔瓦的食人妖要塞中救出。
    SetQBit(QBit(120))
end)
RegisterCanShowTopic(741, function()
    evt._BeginCanShowTopic(741)
    local visible = true
    if IsQBitSet(QBit(119)) then -- 将艾瑞安・韩特的女儿从阿尔瓦的食人妖要塞中救出。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(742, nil, function()
    if not IsQBitSet(QBit(37)) then
        evt.SetMessage("我还没办法和你们一起旅行！我宁愿加入其它的商队。在你们经历过更多事物之后再回来找我。")
        return
    end
    evt.SetMessage("我记得你！凯尔之书非常有用，能够和你一起旅行是我的荣幸！")
    evt.SetNPCTopic(61, 0, 625) -- 维崔那斯・塔尔希尔 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(743, nil, function()
    if not IsQBitSet(QBit(37)) then
        evt.SetMessage("我还没办法和你们一起旅行！我宁愿加入其它的队伍。在你们经历过更多事物之后再回来找我。我现在宁愿先作些研究。")
        return
    end
    evt.SetMessage("当然！和你们一起旅行是我的荣幸！")
    evt.SetNPCTopic(50, 0, 626) -- 代为瑞许・其佛龙 topic 0: 加入队员清单事件
end)

RegisterGlobalEvent(744, nil, function()
    evt.SetMessage("冒险者们，你们已经帮了我们很大的忙。我替我的子民们感谢你们。请记得巴尔萨煞巢穴的牛头人永远感激你们。我们永远欢迎你。")
    evt.SetNPCTopic(57, 0, 613) -- 坦尼斯 topic 0: 加入队员清单事件
    evt.SetNPCTopic(57, 1, 0) -- 坦尼斯 topic 1 cleared
    evt.SetNPCTopic(57, 2, 0) -- 坦尼斯 topic 2 cleared
end)

RegisterGlobalEvent(751, nil, function()
    evt.SetMessage("如果你们获胜了，我会把埃拉西亚风景最美的城堡赏给你们。这个地方就在图拉利昂森林边上，处于精灵族和人类领地的交界之处，虽然地势有点高，但宽敞得很，而且通风良好，你们一定会喜欢这个地方的。说实话我真舍不得这个城堡，但现在该是我回报人民的时候了。")
end)
RegisterCanShowTopic(751, function()
    evt._BeginCanShowTopic(751)
    local visible = true
    if IsQBitSet(QBit(519)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(752, nil, function()
    evt.SetMessage("寻宝比赛有趣吧？你们答应为我解决这个小麻烦我真得谢谢你们。即使你们没有赢得胜利，我也希望你们能觉得参加比赛本身是一种乐趣。我想“公平竞争，同舟共济”才是这项比赛的宗旨。")
end)
RegisterCanShowTopic(752, function()
    evt._BeginCanShowTopic(752)
    local visible = true
    if IsQBitSet(QBit(519)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(753, nil, function()
    evt.SetMessage("祝贺你们！你们现在是哈蒙代尔城堡的新主人了。把它交给你们我也就放心了。以后就由你们来掌管城堡的一切事务。（马克汉姆写了一份合同）在这里签个字吧，对，就在这儿。好了，一切全办妥了，再次祝贺你们，城堡的新主人！")
    evt.SetNPCTopic(340, 2, 754) -- 马克汉姆爵士 topic 2: 你的船
    ClearQBit(QBit(1683))
    SetQBit(QBit(529))
    evt.ForPlayer(Players.All)
    AddValue(Experience, 1000)
    SetAward(Award(1))
    evt.SetNPCGroupNews(52, 56)
end)
RegisterCanShowTopic(753, function()
    evt._BeginCanShowTopic(753)
    local visible = true
    if IsQBitSet(QBit(519)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(754, nil, function()
    evt.SetMessage("我已经在港口专为你们准备了一艘船把你们送到哈蒙代尔，如果收拾好了就快点上船吧。")
    SetQBit(QBit(527))
    evt.SetNPCTopic(350, 0, 783) -- 威廉姆・达维斯 topic 0: 解开缆绳
    evt.SetNPCTopic(340, 2, 0) -- 马克汉姆爵士 topic 2 cleared
    evt.SetNPCGreeting(340, 0) -- 马克汉姆爵士 greeting cleared
end)

RegisterGlobalEvent(755, nil, function()
    evt.SetMessage("你们好，我负责鉴定你们赢得比赛所需要获取的物品。你们要给我一顶漂亮帽子，一瓶红色药剂，一张长弓，一个贝壳，一件乐器，还有月亮神庙里的一块地砖。你们要把所有这些东西都带来，我才能宣布你们为优胜者。")
end)

RegisterGlobalEvent(756, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(520)) then
        goto step_10
    end
    if HasItem(222) then
        ClearQBit(QBit(513)) -- 找到一瓶红色药剂，然后交给翡翠岛的竞赛组织者。
        AddValue(Experience, 500)
        SetQBit(QBit(520))
        RemoveItem(222)
        evt.SetMessage("找这个东西竟然花了你们这么长时间！几乎所有的参赛者都已经把红色药剂交给我了，这可是最容易找的东西了，但你们毕竟找到它了，我可以把它从物品单上划去了。")
        return
    end
    goto step_10
    ::step_10::
    if IsQBitSet(QBit(521)) then
        goto step_20
    end
    if HasItem(1437) then
        ClearQBit(QBit(514)) -- 找到一枚贝壳，然后交给翡翠岛的竞赛组织者。
        RemoveItem(1437)
        SetQBit(QBit(521))
        AddValue(Experience, 500)
        evt.SetMessage("多漂亮的贝壳啊，一定是从塞莉那里买的吧。这是真正翡翠岛上的贝壳。我可以把它从物品单上划去了。")
        return
    end
    goto step_20
    ::step_20::
    if IsQBitSet(QBit(522)) then
        goto step_30
    end
    if HasItem(845) then
        evt.SetMessage("对，就是这张长弓。你们干得真不错。我可以把它从物品单上划去了。")
        RemoveItem(845)
        ClearQBit(QBit(515)) -- 找到一张长弓，然后交给翡翠岛的竞赛组织者。
        AddValue(Experience, 500)
        SetQBit(QBit(522))
        return
    end
    goto step_30
    ::step_30::
    if IsQBitSet(QBit(523)) then
        goto step_40
    end
    if HasItem(1438) then
        evt.SetMessage("你们是真正的勇士，我没有料到这么快就能把地砖带回来。这确实是月亮神庙里的地砖，可以把它从物品单上划去了。")
        RemoveItem(1438)
        ClearQBit(QBit(516)) -- 找到一块地砖，然后交给翡翠岛的竞赛组织者。
        AddValue(Experience, 500)
        SetQBit(QBit(523))
        return
    end
    goto step_40
    ::step_40::
    if IsQBitSet(QBit(524)) then
        goto step_50
    end
    if HasItem(1434) then
        evt.SetMessage("嗯，你们找到拨弦琴了，可以把它从物品单上划去了，快去找其它几样东西吧！")
        RemoveItem(1434)
        ClearQBit(QBit(517)) -- 找到一件乐器，然后交给翡翠岛的竞赛组织者。
        AddValue(Experience, 500)
        SetQBit(QBit(524))
        return
    end
    goto step_50
    ::step_50::
    if IsQBitSet(QBit(525)) then
        goto step_60
    end
    if HasItem(1433) then
        evt.SetMessage("你们已经找到了漂亮帽子，还剩其它几样东西，再加把劲啊！")
        RemoveItem(1433)
        ClearQBit(QBit(518)) -- 找到一顶漂亮帽子，然后交给翡翠岛的竞赛组织者。
        AddValue(Experience, 500)
        SetQBit(QBit(525))
        return
    end
    goto step_81
    ::step_60::
    if IsQBitSet(QBit(513)) then -- 找到一瓶红色药剂，然后交给翡翠岛的竞赛组织者。
        goto step_81
    end
    if IsQBitSet(QBit(514)) then -- 找到一枚贝壳，然后交给翡翠岛的竞赛组织者。
        goto step_81
    end
    if IsQBitSet(QBit(515)) then -- 找到一张长弓，然后交给翡翠岛的竞赛组织者。
        goto step_81
    end
    if IsQBitSet(QBit(516)) then -- 找到一块地砖，然后交给翡翠岛的竞赛组织者。
        goto step_81
    end
    if IsQBitSet(QBit(517)) then -- 找到一件乐器，然后交给翡翠岛的竞赛组织者。
        goto step_81
    end
    if IsQBitSet(QBit(518)) then -- 找到一顶漂亮帽子，然后交给翡翠岛的竞赛组织者。
        goto step_81
    end
    goto step_73
    do return end
    ::step_73::
    SetQBit(QBit(519))
    evt.SetMessage("好，六样东西都找齐了，你们是这次比赛的优胜者！看来你们可以去马克汉姆爵士那儿领赏了，我的任务也算完成了。")
    evt.SetNPCTopic(341, 0, 0) -- 裁判托马斯 topic 0 cleared
    evt.SetNPCTopic(341, 1, 0) -- 裁判托马斯 topic 1 cleared
    evt.MoveNPC(341, 0) -- 裁判托马斯 -> removed
    evt.SetNPCTopic(340, 1, 0) -- 马克汉姆爵士 topic 1 cleared
    evt.SetNPCGreeting(345, 124) -- 马尔维克先生 greeting 124
    do return end
    ::step_81::
    evt.SetMessage("很抱歉，比赛要找的东西你们一样也没有带来。我不是贬低你们的能力，但你们身上的东西没有一件是比赛所要找的。")
end)

RegisterGlobalEvent(757, nil, function()
    evt.SetMessage("我敬佩你们的决心和勇气。只要比赛还没有决出优胜者，你们就还有机会去赢得胜利。")
    evt.SetNPCTopic(342, 0, 758) -- 向导马格莉特 topic 0: 翡翠岛
end)

RegisterGlobalEvent(758, nil, function()
    evt.SetMessage("欢迎来到翡翠岛！我是你们在这个岛上的向导。我会向你们介绍这里的风土人情和本次竞赛的详细内容。你们在岛上最好安分守己点，免得发生不愉快的事。")
end)

RegisterGlobalEvent(759, nil, function()
    evt.SetMessage("比赛规则很简单。谁能第一个把所有物品找到并交给裁判托马斯，就是胜利者。参赛者要找到一顶漂亮帽子，一瓶红色药剂，一张长弓，一个贝壳，一件乐器，还有月亮神庙里的一块地砖。")
end)
RegisterCanShowTopic(759, function()
    evt._BeginCanShowTopic(759)
    local visible = true
    if IsQBitSet(QBit(519)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(760, nil, function()
    evt.SetMessage("你们就是参加马克汉姆爵士寻宝竞赛的参赛者吗？多神气啊！我是唱歌的。我唱给马克汉姆爵士的侍卫们听，唱给你们这些参赛者听，唱给所有爱听我的歌的人听，为他们带来轻松和快乐。")
end)

RegisterGlobalEvent(761, nil, function()
    evt.SetMessage("我有一些乐器，但身上只带了把拨弦琴。虽然有点旧了，也不如其它乐器保存得好，但我还是很爱惜它。")
end)

RegisterGlobalEvent(762, nil, function()
    evt.ForPlayer(Players.All)
    evt.SetMessage("你们说你们参加寻宝比赛需要找一件乐器，不妨买我的拨弦琴吧。不过它陪伴我这么长时间了，我真有点舍不得。你们得出500个金币才能买它，愿不愿意？")
    evt.SetNPCTopic(343, 2, 763) -- 诗人埃莉萨 topic 2: 500个金币买拨弦琴
end)
RegisterCanShowTopic(762, function()
    evt._BeginCanShowTopic(762)
    local visible = true
    evt.ForPlayer(Players.All)
    if HasItem(1434) then
        visible = false
        return visible
    else
        if IsQBitSet(QBit(524)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(763, nil, function()
    if not IsAtLeast(Gold, 500) then
        evt.SetMessage("你们连500个金币也没有，可别想来骗我的拨弦琴。")
        return
    end
    if not IsAtLeast(Gold, 500) then
        return
    end
    SubtractValue(Gold, 500)
    AddValue(InventoryItem(1434), 1434)
    evt.SetMessage("这把琴归你们了，你们可得好好收藏它哦！现在我身上一件伴奏的乐器也没有了，不能给人唱歌，只好去给人讲故事了。")
    evt.SetNPCItem(343, 1434, 0)
    evt.SetNPCTopic(343, 2, 0) -- 诗人埃莉萨 topic 2 cleared
    evt.SetNPCTopic(343, 1, 0) -- 诗人埃莉萨 topic 1 cleared
end)

RegisterGlobalEvent(764, nil, function()
    evt.SetMessage("我总爱在这里眺望大海，大海的景色可比镇子里强多了，多美啊！")
end)

RegisterGlobalEvent(765, nil, function()
    evt.SetMessage("我有一些漂亮的贝壳要卖，这可是翡翠岛上独有的贝壳，你们想买吗？每个贝壳只要100个金币。")
    evt.SetNPCTopic(344, 1, 766) -- 塞莉 topic 1: 100个金币买贝壳
end)

RegisterGlobalEvent(766, nil, function()
    if not IsAtLeast(Gold, 100) then
        evt.SetMessage("连100个金币也没有，我可不能卖给你们，毕竟我要靠它吃饭啊！")
        return
    end
    if not IsAtLeast(Gold, 100) then
        return
    end
    SubtractValue(Gold, 100)
    AddValue(InventoryItem(1437), 1437)
    evt.SetMessage("这贝壳归你们了，希望看到它就能使你们想起翡翠岛之旅。")
end)

RegisterGlobalEvent(767, nil, function()
    evt.SetMessage("我们认为以后谁能掌管哈蒙代尔城堡谁就能有机会主宰未来。我的来意不说你们也知道，是为了将来早作打算。")
end)
RegisterCanShowTopic(767, function()
    evt._BeginCanShowTopic(767)
    local visible = true
    if IsQBitSet(QBit(519)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(768, nil, function()
    evt.SetMessage("我先自我介绍一下，我叫马尔维克。干我们这一行的常自嘲为“未来投机者”。你们一上岛我就开始注意你们了，我发现你们的为人处事和人生目标和我们挺投缘的。我奉命把这根连珠火球魔杖送给你们，希望在这场比赛里能助你们一臂之力，不过将来你们可得报答我们哦。怎么样，答不答应？")
    evt.SetNPCTopic(345, 0, 769) -- 马尔维克先生 topic 0: 接受权杖
    evt.SetNPCTopic(345, 1, 770) -- 马尔维克先生 topic 1: 拒绝接受权杖
end)
RegisterCanShowTopic(768, function()
    evt._BeginCanShowTopic(768)
    local visible = true
    if IsQBitSet(QBit(519)) then
        visible = false
        return visible
    else
        if HasItem(947) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(769, nil, function()
    evt.SetMessage("好极了，将来我或我们圈子里的某个人会来找你们请求帮助的，到时候你们可不能翻脸不认帐。这根连珠火球魔杖你们拿去，我不再多说了，不然别人该起疑心了。")
    SetQBit(QBit(526))
    SetAutonote(257)
    evt.SetNPCItem(345, 947, 0)
    evt.SetNPCTopic(345, 0, 767) -- 马尔维克先生 topic 0: 哈蒙代尔
    evt.SetNPCTopic(345, 1, 0) -- 马尔维克先生 topic 1 cleared
    evt.SetNPCGreeting(345, 122) -- 马尔维克先生 greeting 122
end)
RegisterCanShowTopic(769, function()
    evt._BeginCanShowTopic(769)
    local visible = true
    if IsQBitSet(QBit(519)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(770, nil, function()
    evt.SetMessage("我尊重你的决定。不过我是一个有耐心的人，我会给你个机会，直到竞赛的胜者被宣布。")
    evt.SetNPCTopic(345, 0, 767) -- 马尔维克先生 topic 0: 哈蒙代尔
    evt.SetNPCTopic(345, 1, 768) -- 马尔维克先生 topic 1: 提议
end)
RegisterCanShowTopic(770, function()
    evt._BeginCanShowTopic(770)
    local visible = true
    if IsQBitSet(QBit(519)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(771, nil, function()
    evt.SetMessage("啊，你们已经拿到漂亮帽子了，咱们做个交易如何？你们把帽子交出来，我们就给你们些保命的忠告？")
    evt.SetNPCTopic(346, 0, 773) -- 绍尔・沙克斯 topic 0: 把帽子给绍尔
    evt.SetNPCTopic(346, 1, 774) -- 绍尔・沙克斯 topic 1: 保留帽子
end)
RegisterCanShowTopic(771, function()
    evt._BeginCanShowTopic(771)
    local visible = true
    if HasItem(1433) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(772, nil, function()
    evt.SetMessage("这座神庙可是个凶险的地方，你们在里面可得处处小心，时刻提防，不然连死了也不知道是怎么回事。")
end)

RegisterGlobalEvent(773, nil, function()
    evt.SetMessage("伙计，你们真识相，把帽子交出来了。")
    evt.ForPlayer(Players.All)
    RemoveItem(1433)
    evt.SetNPCTopic(346, 0, 0) -- 绍尔・沙克斯 topic 0 cleared
    evt.SetNPCTopic(346, 1, 775) -- 绍尔・沙克斯 topic 1: 我警告你
    evt.SetNPCItem(346, 1433, 1)
end)

RegisterGlobalEvent(774, nil, function()
    evt.SetMessage("你们要为你们的行为付出代价。")
    evt.SetNPCTopic(346, 0, 0) -- 绍尔・沙克斯 topic 0 cleared
    evt.SetNPCTopic(346, 1, 0) -- 绍尔・沙克斯 topic 1 cleared
    evt.SetMonGroupBit(54, MonsterBits.Hostile, 1)
end)

RegisterGlobalEvent(775, nil, function()
    evt.SetMessage("你们怎么不听我的话，我早说过那地方很危险。趁我现在还没兴趣向你们要些别的东西，你们快走吧！")
end)

RegisterGlobalEvent(776, nil, function()
    evt.SetMessage("看来你们是拒绝我的提议了，好吧，咱们的买卖到此为止了。")
    evt.SetNPCTopic(345, 2, 0) -- 马尔维克先生 topic 2 cleared
end)
RegisterCanShowTopic(776, function()
    evt._BeginCanShowTopic(776)
    local visible = true
    if IsQBitSet(QBit(519)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(777, nil, function()
    evt.SetMessage("你们好，你们也是参赛者吧？有没有兴趣用红色药剂来换顶帽子啊，这样对我们大家都有好处。")
    evt.SetNPCTopic(347, 0, 780) -- 布兰特・费兰 topic 0: 用药剂交换帽子
    evt.SetNPCTopic(347, 1, 781) -- 布兰特・费兰 topic 1: 保留药剂
    evt.SetNPCTopic(347, 2, 0) -- 布兰特・费兰 topic 2 cleared
end)
RegisterCanShowTopic(777, function()
    evt._BeginCanShowTopic(777)
    local visible = true
    if HasItem(222) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(778, nil, function()
    evt.SetMessage("参赛者中最野蛮无耻的一伙正埋伏在月亮神庙。看来他们准备在那里伏击想进入神庙的其它参赛对手。")
end)

RegisterGlobalEvent(779, nil, function()
    evt.SetMessage("我知道配制蓝色药剂的方法，但对红色药剂却不熟悉。只要把蓝色草药放入空瓶子，蓝色药剂就制成了。大概红色药剂的制法也差不多，不过我从来没试过。听说如果配制药剂方法不当会闯大祸的。")
end)

RegisterGlobalEvent(780, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(222) then
        evt.SetMessage("开玩笑吧，你们连红色药剂也没有？是不是以为我们不会给你们帽子？")
        evt.SetNPCTopic(347, 0, 0) -- 布兰特・费兰 topic 0 cleared
        evt.SetNPCTopic(347, 1, 778) -- 布兰特・费兰 topic 1: 歹徒
        evt.SetNPCTopic(347, 2, 779) -- 布兰特・费兰 topic 2: 蓝色药剂
        return
    end
    evt.SetMessage("好极了，你们真够朋友！这顶帽子归你们了，药剂我拿走。这样我们都可以得到比赛所要找的东西了。")
    RemoveItem(222)
    evt.ForPlayer(Players.Current)
    AddValue(InventoryItem(1433), 1433)
    evt.SetNPCItem(347, 1433, 0)
    evt.SetNPCItem(347, 222, 1)
    evt.SetNPCGroupNews(53, 57)
    evt.SetNPCTopic(347, 0, 0) -- 布兰特・费兰 topic 0 cleared
    evt.SetNPCTopic(347, 1, 778) -- 布兰特・费兰 topic 1: 歹徒
    evt.SetNPCTopic(347, 2, 779) -- 布兰特・费兰 topic 2: 蓝色药剂
end)

RegisterGlobalEvent(781, nil, function()
    evt.SetMessage("你们怎么回事，不肯合作吗？好吧，以后你们永远别想得到我们的帮助。")
    evt.SetNPCTopic(347, 0, 777) -- 布兰特・费兰 topic 0: 用帽子交换药剂？
    evt.SetNPCTopic(347, 1, 778) -- 布兰特・费兰 topic 1: 歹徒
    evt.SetNPCTopic(347, 2, 779) -- 布兰特・费兰 topic 2: 蓝色药剂
end)

RegisterGlobalEvent(782, nil, function()
    evt.SetMessage("对不起，只有比赛的优胜者才能命令这艘船启航。")
end)

RegisterGlobalEvent(783, nil, function()
    evt.SetMessage("祝贺你们，干得真不错，伙计！现在我们向哈蒙代尔前进！")
    ClearQBit(QBit(528)) -- 找到有关失踪的参赛者的线索，然后交给翡翠岛的竞赛组织者。
    evt.SetNPCTopic(340, 3, 0) -- 马克汉姆爵士 topic 3 cleared
    AddValue(History(1), 0)
    AddValue(History(2), 0)
    evt.MoveNPC(340, 215) -- 马克汉姆爵士 -> 马克汉姆爵士的房间
    evt.SetNPCGreeting(340, 320) -- 马克汉姆爵士 greeting 320
    evt.MoveToMap(-17331, 12547, 465, 1024, 0, 0, 0, 0, "7out02.odm") -- 哈蒙代尔
end)

RegisterGlobalEvent(784, nil, function()
    evt.SetMessage("注意了，谁能告诉我有关失踪的参赛者们的消息，我会奖赏1000个金币。")
    evt.SetNPCTopic(340, 3, 785) -- 马克汉姆爵士 topic 3: 失踪的参赛者
    SetQBit(QBit(528)) -- 找到有关失踪的参赛者的线索，然后交给翡翠岛的竞赛组织者。
end)

RegisterGlobalEvent(785, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1460) then
        evt.SetMessage("还没有失踪者的消息吗？")
        return
    end
    evt.SetMessage("岛上真有龙吗？是不是指岛上到处都是的龙蝇。我早警告过人们要想太太平平过日子，就得离那个洞穴远点。")
    RemoveItem(1460)
    SetAward(Award(2))
    AddValue(Experience, 1000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 1000)
    SubtractValue(ReputationInCurrentLocation, 5)
    ClearQBit(QBit(528)) -- 找到有关失踪的参赛者的线索，然后交给翡翠岛的竞赛组织者。
    evt.SetNPCTopic(340, 3, 0) -- 马克汉姆爵士 topic 3 cleared
end)

RegisterGlobalEvent(786, nil, function()
    evt.SetMessage("嗯，我想起是有些陌生人曾在龙穴附近逗留过，但没注意到他们是否进去了。从此以后再没有看见过他们。一定是他们感到这里太危险，及时退回去了。")
end)

RegisterGlobalEvent(787, nil, function()
    evt.SetMessage("我屋子后的洞穴可不是什么废庙，它是翡翠岛上的巨龙“冷血莫卡莱克”呆的地方。它对不速之客很不客气，你们最好别上那里去。废庙就埋在我屋子南面的小山上，你们可以从山顶的洞口进去。")
end)

RegisterGlobalEvent(788, nil, function()
    evt.SetMessage("龙蝇近来在岛的西北面猖獗肆虐，去那里的仓库存放物品可是件危险的事。龙蝇虽然不是厉害无比，但它们飞行迅速，有的龙蝇还会喷射火焰，你们可别把它们不当一回事。")
end)

RegisterGlobalEvent(789, nil, function()
    evt.SetMessage("翡翠岛的巨龙住在东北面的龙穴里。它不喜欢不速之客，我可不敢上那儿去。我们向它进贡，它保护我们的镇子不受海盗和外人的袭击。")
end)

RegisterGlobalEvent(790, nil, function()
    evt.SetMessage("你们是参加寻宝比赛的参赛者？要是这样我可不会带你们去龙穴，莫卡莱克对外人可不怎么友好。那些失踪的人肯定以为它的洞穴是个废庙，贸然闯入，都成了它的点心了。")
end)

RegisterGlobalEvent(791, nil, function()
    evt.SetMessage("我还见过别的参赛者，他们有些人真是无礼至极。有一伙人特别下流无耻，我看见他们向岛的北面去了，却再也没见他们回来过。我对参赛者们总是特别注意，更希望他们之中善良的人能够赢得比赛，这样将来对大家都有好处。")
end)

RegisterGlobalEvent(792, nil, function()
    evt.SetMessage("你们已经决定不再要我提供关于翡翠岛的信息了吗？要是你们以后想再要听我的忠告，请到双叶旅店里找我并选择“开始指导”。")
    SetQBit(QBit(529))
    evt.SetNPCTopic(342, 2, 793) -- 向导马格莉特 topic 2: 开始指导
    evt.MoveNPC(342, 239) -- 向导马格莉特 -> 双叶旅店
end)

RegisterGlobalEvent(793, nil, function()
    evt.SetMessage("你们要我告诉你们关于翡翠岛的信息吗？你们要是以后对这些信息不感兴趣了，请选择“结束指导”。")
    ClearQBit(QBit(529))
    evt.SetNPCTopic(342, 2, 792) -- 向导马格莉特 topic 2: 结束指导
    evt.MoveNPC(342, 0) -- 向导马格莉特 -> removed
end)

RegisterGlobalEvent(794, nil, function()
    evt.SetMessage("法律可以判定谁有罪，谁无罪。我可以决定谁可以被称为神偷，谁只是个小偷。你们只要把马克汉姆爵士庄园里的那个漂亮花瓶偷来，我就封你们为神偷。")
    SetQBit(QBit(530)) -- 进入马克汉姆在泰塔利亚的府邸，偷走那儿的花瓶，回到埃拉西亚的下水道，把花瓶交给比尔・拉斯克。
    evt.SetNPCTopic(354, 0, 795) -- 比尔・拉斯克 topic 0: 神偷
end)

RegisterGlobalEvent(795, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1426) then
        evt.SetMessage("一般的小偷见什么偷什么，但神偷只偷我指定的东西。如果行动失败了，我可不会给什么封号。把马克汉姆爵士的那个漂亮花瓶偷来给我，我将把你们之中的窃贼提拔为神偷，不是窃贼的授予荣誉神偷称号。")
        return
    end
    evt.SetMessage("干得好，把这个花瓶偷来可需要高超的技术。我授予你们神偷的称号，这点报酬是你们应得的，拿去吧。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 34) then
            SetValue(ClassId, 35)
            SetQBit(QBit(1560))
            AddValue(Experience, 30000)
        else
            SetQBit(QBit(1561))
            AddValue(Experience, 15000)
        end
    end
    evt.ForPlayer(Players.All)
    RemoveItem(1426)
    evt.ForPlayer(Players.Current)
    ClearQBit(QBit(724))
    AddValue(Gold, 5000)
    ClearQBit(QBit(530)) -- 进入马克汉姆在泰塔利亚的府邸，偷走那儿的花瓶，回到埃拉西亚的下水道，把花瓶交给比尔・拉斯克。
    evt.SetNPCTopic(354, 0, 796) -- 比尔・拉斯克 topic 0: 密探
end)

RegisterGlobalEvent(796, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("你们的下一个任务可有点难度。看来密探比神偷更适合完成这个任务。现在死灵法师和我们之间的战争已经到了最关键的阶段。我接到命令必须捣毁他们硕果仅存的6号哨塔，使其丧失战斗力。杀光里面的守兵是无济于事的，死灵法师只会派更多的队伍来防守哨塔。唯一的办法就是派人偷偷潜入那里，把在塔顶哨口里的顶门石移到塔楼底层的房间里去。那块石头就在塔顶一堵墙对面的房间里，用一根绳子系着。你们只要完成任务，我们一旦发动进攻，他们不能关上大门，这样部队就可以长驱直入了。那个哨塔就在死灵法师领地的南部。如果你们能完成这项任务，你们就无愧于密探的称号了。")
        SetQBit(QBit(531)) -- 潜入迪雅的6号哨塔，把塔顶的顶门石移到塔的底层，然后回埃拉西亚下水道见比尔・拉斯克。
        evt.SetNPCTopic(354, 0, 797) -- 比尔・拉斯克 topic 0: 密探
    elseif IsQBitSet(QBit(612)) then
        evt.SetMessage("你们既然已经选择了黑暗之路，我就不能提拔你们了。也许杀手会向你们传授一些知识，听说在迪雅有一个杀手。")
    else
        evt.SetMessage("你们还没有作出进一步的选择。你们必须尽快决定向哪个方向发展，是光明之路还是黑暗之路。如果你们选择光明之路，那么还可以回到我这里完成你们的修炼。")
    end
end)

RegisterGlobalEvent(797, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(532)) then
        evt.SetMessage("干得太棒了，你们这次行动的成功将在未来的战斗中挽救数百人的生命。鉴于你们的功绩，我将你们之中的神偷提拔为密探，荣誉神偷提拔为荣誉密探!这里还有一笔奖金，你们拿去吧。")
        for _, player in ipairs(PartyMembers()) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 35) then
                SetValue(ClassId, 37)
                SetQBit(QBit(1562))
                AddValue(Experience, 80000)
            else
                SetQBit(QBit(1563))
                AddValue(Experience, 40000)
            end
        end
        AddValue(Gold, 15000)
        ClearQBit(QBit(531)) -- 潜入迪雅的6号哨塔，把塔顶的顶门石移到塔的底层，然后回埃拉西亚下水道见比尔・拉斯克。
        evt.ForPlayer(Players.All)
        evt.SetNPCTopic(354, 0, 0) -- 比尔・拉斯克 topic 0 cleared
        evt.SetNPCGreeting(354, 154) -- 比尔・拉斯克 greeting 154
    elseif HasItem(0) then
        evt.SetMessage("嗯…这块顶门石必须移到塔楼的底层去，可不能放在这个地方。快回去把石头放到应该放的地方去。")
        return
    elseif IsQBitSet(QBit(568)) then
        evt.SetMessage("嗯，光把顶门石从塔顶移开可不行。你们把它放什么地方去了？如果石头没放到塔楼底层，我们的计划就前功尽弃了！快回6号哨塔，把石头放到应该放的地方去。")
    else
        evt.SetMessage("我交给你们的任务你们还没完成呢！记住，你们只有把6号哨塔顶层的顶门石放到塔楼底层，才算圆满完成任务，不然的话我是不会提拔你们的。")
    end
end)

RegisterGlobalEvent(798, nil, function()
    if IsAtLeast(EnduranceBonus, 50) then return end
    SetValue(EnduranceBonus, 50)
    evt.StatusText("精神振奋（耐力暂时增加50点）")
end)

RegisterGlobalEvent(799, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("你们既然已经选择了光明之路，就当不成杀手了，我可不能传授你们什么东西。还是做密探去吧，这样人会变得善良些。")
        return
    elseif IsQBitSet(QBit(1560)) then
        if not IsQBitSet(QBit(612)) then
            evt.SetMessage("我能够把一个普通的神偷训练成为冷血无情的杀手。不过我得看看你们是否有这方面的气质和天赋。你们得尽快在光明之路和黑暗之路之间作出选择。如果你们决定投身邪派，那么上我这儿来吧，我会训练你们的。")
            return
        end
        evt.SetMessage("哦，你们要成为杀手，好吧，不过我只能把你们之中的神偷提拔为杀手，而且你们还得完成我交给你们的任务，以证明你们的忠诚和能力，不然就别来浪费我的时间了。我接到命令，必须干掉埃利诺・卡米尔这个臭女人。她原来也是我们一伙的，现在她竟然投靠了我们的敌人，泄露了不少机密，真是太可恶了。她就住在塞莱斯特的通天院，把她从埃拉西亚蒸发掉，这个任务就交给你们了。记住完成任务后别忘了把她身上的匕首带回来，有了它作证据我就可以提拔你们了。")
        SetQBit(QBit(533)) -- 去塞莱斯特的通天院干掉卡米尔，把她身上的匕首交给迪雅的塞克尼特・恩德斯。
        evt.SetNPCTopic(355, 1, 800) -- 塞克尼特・恩德斯 topic 1: 杀手
    elseif IsQBitSet(QBit(1561)) then
        if not IsQBitSet(QBit(612)) then
            evt.SetMessage("我能够把一个普通的神偷训练成为冷血无情的杀手。不过我得看看你们是否有这方面的气质和天赋。你们得尽快在光明之路和黑暗之路之间作出选择。如果你们决定投身邪派，那么上我这儿来吧，我会训练你们的。")
            return
        end
        evt.SetMessage("哦，你们要成为杀手，好吧，不过我只能把你们之中的神偷提拔为杀手，而且你们还得完成我交给你们的任务，以证明你们的忠诚和能力，不然就别来浪费我的时间了。我接到命令，必须干掉埃利诺・卡米尔这个臭女人。她原来也是我们一伙的，现在她竟然投靠了我们的敌人，泄露了不少机密，真是太可恶了。她就住在塞莱斯特的通天院，把她从埃拉西亚蒸发掉，这个任务就交给你们了。记住完成任务后别忘了把她身上的匕首带回来，有了它作证据我就可以提拔你们了。")
        SetQBit(QBit(533)) -- 去塞莱斯特的通天院干掉卡米尔，把她身上的匕首交给迪雅的塞克尼特・恩德斯。
        evt.SetNPCTopic(355, 1, 800) -- 塞克尼特・恩德斯 topic 1: 杀手
    else
        evt.SetMessage("要是你们想找人学习高级的盗窃技术，那你们可找对人了。不过你们得首先成为神偷或是荣誉神偷，这样我就可以传艺了。去找盗贼大师吧，他就在埃拉西亚的下水道里。")
        return
    end
end)

RegisterGlobalEvent(800, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1342) then
        evt.SetMessage("没有匕首，我怎么知道卡米尔死没死。快把证据拿来，我就能授予你们杀手称号了。")
        return
    end
    evt.SetMessage("嗯，活干得不错。（他仔细端详着匕首，叹了口气）我曾经深爱过她，可最终理智战胜了感情，不过我实在不忍心自己亲自下手，谢谢你们了，从现在起，你们之中的神偷就是杀手了，我会传你们几手绝活的。这点酬金你们拿去吧。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 35) then
            SetValue(ClassId, 36)
            SetQBit(QBit(1564))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1565))
            AddValue(Experience, 40000)
        end
    end
    AddValue(Gold, 15000)
    ClearQBit(QBit(725))
    ClearQBit(QBit(533)) -- 去塞莱斯特的通天院干掉卡米尔，把她身上的匕首交给迪雅的塞克尼特・恩德斯。
    AddValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(355, 1, 0) -- 塞克尼特・恩德斯 topic 1 cleared
    evt.SetNPCGreeting(355, 157) -- 塞克尼特・恩德斯 greeting 157
end)

RegisterGlobalEvent(801, nil, function()
    evt.SetMessage("哈，你们想成为十字军？是啊，人人都想尝尝做英雄的滋味，一定很风光吧！不过要想成为十字军，得杀一条龙。我就知道有条名叫劳斯莱克的巨龙，它就住在泰塔利亚的一个洞穴里，经常骚扰附近的百姓。估计今年它肯定待在洞穴里。由于这条龙凶残无比，我决定跟你们一块去，一路上可以给你们一些指点。快走吧，这个家伙已经死到临头了。")
    evt.SetNPCTopic(356, 0, 802) -- 查尔斯・科切特爵士 topic 0: 十字军
    evt.MoveNPC(356, 0) -- 查尔斯・科切特爵士 -> removed
    SetQBit(QBit(534)) -- 到泰塔利亚杀死巨龙劳斯莱克，然后去找查尔斯・科切特。
    evt.SetNPCGreeting(356, 159) -- 查尔斯・科切特爵士 greeting 159
    SetQBit(QBit(1684))
end)

RegisterGlobalEvent(802, nil, function()
    evt.ForPlayer(Players.All)
    if not IsQBitSet(QBit(535)) then
        evt.SetMessage("你们必须完成任务，我才能授予你们十字军称号。")
        return
    end
    evt.SetMessage("哈，巨龙完蛋了！鉴于你们立下大功一件，我授予你们十字军的称号。本来我应该留下来和你们一起庆祝胜利，可惜还有些要紧的事要办，后会有期了，十字军们！")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 26) then
            SetValue(ClassId, 27)
            SetQBit(QBit(1590))
            AddValue(Experience, 30000)
        else
            SetQBit(QBit(1591))
            AddValue(Experience, 15000)
        end
    end
    ClearQBit(QBit(534)) -- 到泰塔利亚杀死巨龙劳斯莱克，然后去找查尔斯・科切特。
    ClearQBit(QBit(1684))
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.ForPlayer(Players.All)
    evt.MoveNPC(356, 941) -- 查尔斯・科切特爵士 -> 科切特的住处
    evt.SetNPCTopic(356, 0, 803) -- 查尔斯・科切特爵士 topic 0: 英雄
    evt.SetNPCGreeting(356, 158) -- 查尔斯・科切特爵士 greeting 158
end)

RegisterGlobalEvent(803, nil, function()
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("很高兴你们能选择光明之路，十字军们！有件事要麻烦你们，一位名叫埃莉斯・哈格的善良姑娘被绑架了。绑匪名叫威廉姆・塞塔格，他把人关在他的塔里了。如果你们能手刃这个家伙，救出可怜的姑娘，你们就可以成为英雄。")
        evt.SetNPCTopic(356, 0, 804) -- 查尔斯・科切特爵士 topic 0: 英雄
        SetQBit(QBit(536)) -- 把埃莉斯・哈格从迪雅的威廉姆的塔里救出来，然后去找查尔斯・科切特。
        evt.SetNPCGreeting(356, 158) -- 查尔斯・科切特爵士 greeting 158
        evt.MoveNPC(393, 1158) -- 埃莉斯・哈格 -> 埃莉斯・哈格
    elseif IsQBitSet(QBit(612)) then
        evt.SetMessage("我没功夫和你们多废话，你们这群流氓！你们既然已经选择了黑暗之路，还来找我干什么，去找你们的同路货吧，他们会有兴趣训练你们的。")
    else
        evt.SetMessage("啊，原来是十字军来了！我知道你们急于想立功，以便学习英雄的本领。但你们得先作出一个慎重的决定，只有选择了光明之路，我才能帮助你们完成心愿。还是拿定主意再来找我吧。")
    end
end)

RegisterGlobalEvent(804, nil, function()
    if not IsQBitSet(QBit(1685)) then
        evt.SetMessage("十字军们，这件任务可是十万火急啊！你们不把姑娘救出来，我可不能授予你们英雄称号。")
        return
    end
    evt.SetMessage("你们成功了，我知道你们行的，真为你们骄傲。你们把埃莉斯从威廉姆・塞塔格的魔爪中救了出来，伸张正义，铲除邪恶，真是太了不起了。（查尔斯放声大笑）好了，你们已经完成了任务，证明了你们的能力，我宣布你们为埃拉西亚的英雄。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 27) then
            SetValue(ClassId, 28)
            SetQBit(QBit(1592))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1593))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(536)) -- 把埃莉斯・哈格从迪雅的威廉姆的塔里救出来，然后去找查尔斯・科切特。
    ClearQBit(QBit(1685))
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.MoveNPC(393, 941) -- 埃莉斯・哈格 -> 科切特的住处
    evt.SetNPCGreeting(356, 161) -- 查尔斯・科切特爵士 greeting 161
    evt.SetNPCTopic(356, 0, 0) -- 查尔斯・科切特爵士 topic 0 cleared
end)

RegisterGlobalEvent(805, nil, function()
    if IsQBitSet(QBit(611)) then
        if not IsQBitSet(QBit(537)) then
            evt.SetMessage("救命啊！威廉姆绑架了我，把我囚禁在这个塔里。请把我救出去吧，这个鬼地方我一刻也不想呆了。")
            SetQBit(QBit(537))
            SetQBit(QBit(1685))
            return
        end
        evt.SetMessage("你们把我从威廉姆的魔爪中救了出来，真是太感谢你们了。")
        return
    elseif IsQBitSet(QBit(612)) then
        if not IsQBitSet(QBit(537)) then
            evt.SetMessage("对不起，请问你们是谁？嗨，别碰我，救命！")
            SetQBit(QBit(537))
            SetQBit(QBit(1685))
            return
        end
        evt.SetMessage("你们把我带哪儿去？我的家族可是很庞大的，你们要是不让我走，会有很多人要你们好看！")
    else
        evt.SetMessage("你们本来不可能马上看到这个。要是你们真的看过它，得告诉伯瑞安这个任务委派错了。你们要么做好人，去完成英雄的任务，要么做坏人，去完成恶棍的任务，可现在你们既没有选择光明之路也没有选择黑暗之路，哪一边的人都不是。")
    end
end)

RegisterGlobalEvent(806, nil, function()
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("既然你们如此诚心诚意，我本来想答应传授你们为非作歹的本领。不过你们既然已经选择了光明之路，看来和我们邪派无缘了，我可什么都不能传授你们了。")
        return
    elseif IsQBitSet(QBit(612)) then
        evt.SetMessage("让我们谈正事吧。你们应该知道我是埃拉西亚最臭名昭著的大魔头。要成为魔头也不容易，必须煞费苦心地干几件惊天动地的大事才能证明自己的邪恶，希望你们有信心迎接挑战。本来我想花几年功夫好好调教你们，让你们了解魔头本领的精髓，可惜我最近要事缠身，没这么多闲功夫。不过我有一个速成法，有个血统高贵的贵族小姐名叫埃莉斯・哈格，你们去把她从格芬哈格城堡抓来，关进我的塔楼。一旦你们完成这个任务，我会把你们之中的十字军提拔为魔头，其他人授予荣誉魔头称号。")
        if IsQBitSet(QBit(1590)) then
            SetQBit(QBit(538)) -- 到格芬哈特城堡绑架埃莉斯・哈格，并将她带到迪雅的威廉姆的塔里。
            evt.SetNPCTopic(357, 0, 807) -- 威廉姆・塞塔格 topic 0: 魔头
            evt.MoveNPC(393, 1158) -- 埃莉斯・哈格 -> 埃莉斯・哈格
        elseif IsQBitSet(QBit(1591)) then
            SetQBit(QBit(538)) -- 到格芬哈特城堡绑架埃莉斯・哈格，并将她带到迪雅的威廉姆的塔里。
            evt.SetNPCTopic(357, 0, 807) -- 威廉姆・塞塔格 topic 0: 魔头
            evt.MoveNPC(393, 1158) -- 埃莉斯・哈格 -> 埃莉斯・哈格
        else
            evt.SetMessage("你们竟然连十字军也不是，别来浪费我的时间了，等你们得到十字军称号再来找我学习魔头的本领吧。")
            return
        end
    else
        evt.SetMessage("在你们决定向我拜师学艺以前，你们必须在光明之路和黑暗之路间作出选择。如果选择黑暗之路，你们可以来找我，我会传授你们圣武士的本领。")
        return
    end
end)

RegisterGlobalEvent(807, nil, function()
    if not IsQBitSet(QBit(1685)) then
        evt.SetMessage("埃莉斯带来了吗，连绑架个人这点小事都不会办，真没有出息。你们得加一把劲了！")
        return
    end
    evt.SetMessage("干得棒极了！你们在这次行动中显示了非凡的勇气和高超的本领，竟然把这么位漂亮高贵的小姐抓来了。你们的所作所为完全配得上魔头和荣誉魔头的称号。你们现在可以在埃拉西亚为所欲为了，整个大陆将臣服在你们脚下。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 27) then
            SetValue(ClassId, 29)
            SetQBit(QBit(1594))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1595))
            AddValue(Experience, 40000)
        end
    end
    AddValue(Gold, 10000)
    ClearQBit(QBit(538)) -- 到格芬哈特城堡绑架埃莉斯・哈格，并将她带到迪雅的威廉姆的塔里。
    AddValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(357, 0, 0) -- 威廉姆・塞塔格 topic 0 cleared
    evt.SetNPCGreeting(357, 165) -- 威廉姆・塞塔格 greeting 165
    ClearQBit(QBit(1685))
end)

RegisterGlobalEvent(808, nil, function()
    evt.SetMessage("啊，几乎所有的年轻僧侣都想升职为沙弥，让我来告诉你们如何能够实现这个愿望。你们到拜尔德斯去，那里有一个坟墓具有神奇的魔力，显得与众不同，你们很容易认出来。你们在这个坟墓边先喝水，然后静默冥想。这样你们就可以升职为沙弥了。")
    SetQBit(QBit(539)) -- 在拜尔德斯找到冥想之地。
    evt.SetNPCTopic(377, 0, 809) -- 巴斯洛缪・海墨尔 topic 0: 沙弥
end)

RegisterGlobalEvent(809, nil, function()
    evt.SetMessage("你们还没有把该做的完成呢！等你们完成了使命再来找我吧。")
end)

RegisterGlobalEvent(810, nil, function()
    evt.SetMessage("（巴斯洛缪・海墨尔诚挚地对你们说）祝贺你们，年轻人。你们要记住，顿悟是一项需要不断增进提高的技能，能够顿悟并不是目的，而只是修炼的开始。你们需要不断使这项本领精益求精。好了，我把你们之中的僧侣提拔为沙弥，其他人授予荣誉沙弥称号。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 22) then
            SetValue(ClassId, 23)
            SetQBit(QBit(1572))
            AddValue(Experience, 30000)
        else
            SetQBit(QBit(1573))
            AddValue(Experience, 15000)
        end
    end
    ClearQBit(QBit(539)) -- 在拜尔德斯找到冥想之地。
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(377, 0, 811) -- 巴斯洛缪・海墨尔 topic 0: 智者
    evt.SetNPCTopic(394, 0, 0) -- 巴斯洛缪・海墨尔 topic 0 cleared
end)

RegisterGlobalEvent(811, nil, function()
    if IsQBitSet(QBit(612)) then
        evt.SetMessage("很抱歉，我不能再教你们什么了，你们得另找位大师学艺。")
        return
    elseif IsQBitSet(QBit(611)) then
        evt.SetMessage("你们想继续在埃拉西亚铲除邪恶，匡扶正义，真是太好了，这样你们可以在光明之路上更进一步。你们的任务是扫平羊鸣教的残余势力，打败羊鸣教的高级神甫后回来见我，我会把你们提拔为智者。")
        SetQBit(QBit(540)) -- 到埃里的羊鸣教神庙铲除羊鸣教高级神甫，然后回到哈蒙代尔找巴斯洛缪・海墨尔。
        evt.SetNPCTopic(377, 0, 812) -- 巴斯洛缪・海墨尔 topic 0: 智者
    else
        evt.SetMessage("现在你们的人生道路面临重大抉择。你们只有选择光明之路，我才能传授你们本领。")
        return
    end
end)

RegisterGlobalEvent(812, nil, function()
    evt.ForPlayer(Players.All)
    if not IsQBitSet(QBit(755)) then
        evt.SetMessage("羊鸣教的神庙还在那儿，他们的高级神甫还活得好好的。别气馁，继续加把劲，只要你们完成任务，我就提拔你们为智者。")
        return
    end
    evt.SetMessage("干得漂亮，这下羊鸣教在埃拉西亚彻底土崩瓦解了。我现在把你们之中的沙弥提拔为智者，荣誉沙弥提拔为荣誉智者。记住你们所完成的只是顿悟的一个阶段而已，你们必须终生坚持冥想，苦思，顿悟，永不松懈，方可得成正果。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 23) then
            SetValue(ClassId, 24)
            SetQBit(QBit(1574))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1575))
            AddValue(Experience, 40000)
        end
    end
    AddValue(Gold, 7500)
    ClearQBit(QBit(540)) -- 到埃里的羊鸣教神庙铲除羊鸣教高级神甫，然后回到哈蒙代尔找巴斯洛缪・海墨尔。
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(377, 0, 0) -- 巴斯洛缪・海墨尔 topic 0 cleared
    evt.SetNPCGreeting(377, 167) -- 巴斯洛缪・海墨尔 greeting 167
end)

RegisterGlobalEvent(813, nil, function()
    if IsQBitSet(QBit(1572)) then
        if IsQBitSet(QBit(611)) then
            evt.SetMessage("（斯丹芬尼嘲笑）你们想向我拜师学艺？瞧你们这笨手笨脚的样子，我的兵器都快被你们磕坏了。快滚吧，不让我可真要教训教训你们了。")
            return
        elseif IsQBitSet(QBit(612)) then
            evt.SetMessage("我的一个手下交给我一份密码，破解这份密码的关键词隐藏在一份魔法卷轴中。你们要成为忍者，就必须潜入魔法学院，找出波浪魔法卷轴中的关键词，解开这份密码。然后你们要按照密码上提供的信息行动，它会告诉你们如何进入宗师坟墓，那个坟墓就在埃拉西亚的南面。（斯丹芬尼递给你们一张纸片）这就是要破译的密码。")
            SetQBit(QBit(541)) -- 到布拉卡达沙漠中的魔法学院破解密码，找到尼格的坟墓，然后进入坟墓彻底搜查一下。任务完成后去地狱城找斯丹芬尼・山德。
            evt.SetNPCTopic(378, 0, 814) -- 斯丹芬尼・山德 topic 0: 忍者
            AddValue(InventoryItem(1503), 1503)
            SetQBit(QBit(727))
        else
            evt.SetMessage("尽管你们已经达到了沙弥等级，但我担心你们学得太杂，无法对我传授的本领全身心投入。你们首先得抛弃以前所学的跳梁小丑般的鬼魅伎俩，才能学习我威力无比的本领。.")
            return
        end
    elseif IsQBitSet(QBit(1573)) then
        if IsQBitSet(QBit(611)) then
            evt.SetMessage("（斯丹芬尼嘲笑）你们想向我拜师学艺？瞧你们这笨手笨脚的样子，我的兵器都快被你们磕坏了。快滚吧，不让我可真要教训教训你们了。")
            return
        elseif IsQBitSet(QBit(612)) then
            evt.SetMessage("我的一个手下交给我一份密码，破解这份密码的关键词隐藏在一份魔法卷轴中。你们要成为忍者，就必须潜入魔法学院，找出波浪魔法卷轴中的关键词，解开这份密码。然后你们要按照密码上提供的信息行动，它会告诉你们如何进入宗师坟墓，那个坟墓就在埃拉西亚的南面。（斯丹芬尼递给你们一张纸片）这就是要破译的密码。")
            SetQBit(QBit(541)) -- 到布拉卡达沙漠中的魔法学院破解密码，找到尼格的坟墓，然后进入坟墓彻底搜查一下。任务完成后去地狱城找斯丹芬尼・山德。
            evt.SetNPCTopic(378, 0, 814) -- 斯丹芬尼・山德 topic 0: 忍者
            AddValue(InventoryItem(1503), 1503)
            SetQBit(QBit(727))
        else
            evt.SetMessage("尽管你们已经达到了沙弥等级，但我担心你们学得太杂，无法对我传授的本领全身心投入。你们首先得抛弃以前所学的跳梁小丑般的鬼魅伎俩，才能学习我威力无比的本领。.")
            return
        end
    else
        evt.SetMessage("年轻人求知欲强固然很好，但我可不教没有经验的学生。你们只有达到沙弥的等级，并且天资聪慧，我才会传艺给你们。要想知道谁能使你们成为沙弥吗？你们不妨去找巴斯洛缪・海墨尔，他会把这些基本技能传授给你们的。")
        return
    end
end)

RegisterGlobalEvent(814, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(754)) then
        evt.SetMessage("干得漂亮，你们这次行动如此出色，我除了称赞还能说什么呢。我现在把你们之中的沙弥提拔为忍者，其他人授予荣誉忍者称号。你们从坟墓里带回来的东西就作为战利品奖赏给你们，毕竟这只是次小考验而已，你们要经历的风浪还多着呢！")
        for _, player in ipairs(PartyMembers()) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 23) then
                SetValue(ClassId, 25)
                SetQBit(QBit(1576))
                AddValue(Experience, 80000)
            else
                SetQBit(QBit(1577))
                AddValue(Experience, 40000)
            end
        end
        ClearQBit(QBit(541)) -- 到布拉卡达沙漠中的魔法学院破解密码，找到尼格的坟墓，然后进入坟墓彻底搜查一下。任务完成后去地狱城找斯丹芬尼・山德。
        SubtractValue(ReputationInCurrentLocation, 10)
        evt.ForPlayer(Players.All)
        evt.SetNPCTopic(378, 0, 0) -- 斯丹芬尼・山德 topic 0 cleared
        evt.SetNPCGreeting(378, 170) -- 斯丹芬尼・山德 greeting 170
    elseif IsQBitSet(QBit(569)) then
        evt.SetMessage("你们既然已经破解了密码，为什么不按照上面说的做。我再说一遍，坟墓在埃拉西亚南面，你们得完成任务然后回来向我报告，要是失败了，就不用回来了。这次行动对你们来说“不成功，便成仁”。")
    else
        evt.SetMessage("（山德叹气）你们这些笨蛋，我再重复一遍。密码就是波浪魔法卷轴中的关键词，你们到魔法学院去，肯定能找到这份卷轴。我不管你们使用什么手段，暗杀，地遁，计策，随你们的便。我要的是结果，别再找什么借口了，这次一定要成功。")
    end
end)

RegisterGlobalEvent(815, nil, function()
    if IsQBitSet(QBit(1584)) then
        if IsQBitSet(QBit(611)) then
            evt.SetMessage("一些年以前，图拉利昂森林里有个炼金术士打造了一张完美之弓用来见证精灵族和人类所订立的和平条约，使双方能够和平相处。但在向埃拉西亚进发的途中，埃里的泰坦巨人抢走了这张完美之弓。这帮蠢货又不会射箭，要这张弓有什么用。它们一定把弓放在他们的营地里了。开弓放箭是我们的老本行，我们自然有义务把完美之弓夺回来，那可是件旷世罕见的兵器啊！你们的任务就是去把完美之弓夺回来，顺便教训教训这帮家伙，连没用的东西都要偷，真是可恶。如果你们顺利完成任务，我会把你们之中高级射手提拔为神箭手，其他人授予荣誉神箭手称号。")
            SetQBit(QBit(542)) -- 在埃里的泰坦城堡中找到完美之弓，把它交给哈蒙代尔的劳伦斯・马克。
            evt.SetNPCTopic(379, 0, 816) -- 劳伦斯・马克 topic 0: 神箭手
        elseif IsQBitSet(QBit(612)) then
            evt.SetMessage("你们既然已经选择了黑暗之路，还来找我干什么。我可不会传授你们本领，省得将来为虎作伥，助纣为虐。")
        else
            evt.SetMessage("你们已经成为高级射手，还想晋升为神箭手？虽然你们理想远大，但我的要求非常严格，只提拔那些真正有恒心，有毅力，而且本领超群的英雄好汉。你们再慎重考虑考虑，如果你们决心坚定不移地选择光明之路，可以再来找我，我会帮助你们实现理想的。")
        end
        return
    elseif IsQBitSet(QBit(1585)) then
        if IsQBitSet(QBit(611)) then
            evt.SetMessage("一些年以前，图拉利昂森林里有个炼金术士打造了一张完美之弓用来见证精灵族和人类所订立的和平条约，使双方能够和平相处。但在向埃拉西亚进发的途中，埃里的泰坦巨人抢走了这张完美之弓。这帮蠢货又不会射箭，要这张弓有什么用。它们一定把弓放在他们的营地里了。开弓放箭是我们的老本行，我们自然有义务把完美之弓夺回来，那可是件旷世罕见的兵器啊！你们的任务就是去把完美之弓夺回来，顺便教训教训这帮家伙，连没用的东西都要偷，真是可恶。如果你们顺利完成任务，我会把你们之中高级射手提拔为神箭手，其他人授予荣誉神箭手称号。")
            SetQBit(QBit(542)) -- 在埃里的泰坦城堡中找到完美之弓，把它交给哈蒙代尔的劳伦斯・马克。
            evt.SetNPCTopic(379, 0, 816) -- 劳伦斯・马克 topic 0: 神箭手
        elseif IsQBitSet(QBit(612)) then
            evt.SetMessage("你们既然已经选择了黑暗之路，还来找我干什么。我可不会传授你们本领，省得将来为虎作伥，助纣为虐。")
        else
            evt.SetMessage("你们已经成为高级射手，还想晋升为神箭手？虽然你们理想远大，但我的要求非常严格，只提拔那些真正有恒心，有毅力，而且本领超群的英雄好汉。你们再慎重考虑考虑，如果你们决心坚定不移地选择光明之路，可以再来找我，我会帮助你们实现理想的。")
        end
    else
        evt.SetMessage("我确实可以把弓箭手系列职业人员提拔为神箭手。可是你们还没有达到要求，连高级射手也不是，我没法提拔你们，还是回去加紧准备，等达到要求再来找我吧。")
    end
end)

RegisterGlobalEvent(816, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1344) then
        evt.SetMessage("还没有拿到完美之弓吗？不要紧，慢慢来，时间还多着呢。对付这帮凶残无比的家伙，得讲究策略，不能一味猛攻，多动动脑子，你们一定会成功的。")
        return
    end
    evt.SetMessage("你们把完美之弓夺回来了，真了不起！这张弓作为奖赏就送给你们了，我先得把它稍加改造，让你们使用起来更加得心应手。你们一定要用它来保护埃拉西亚的人民百姓。现在我把你们之中的高级射手提拔为神箭手，其他人授予荣誉神箭手称号。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 1) then
            SetValue(ClassId, 2)
            SetQBit(QBit(1586))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1587))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(542)) -- 在埃里的泰坦城堡中找到完美之弓，把它交给哈蒙代尔的劳伦斯・马克。
    AddValue(InventoryItem(1345), 1345)
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    if HasItem(1344) then
        RemoveItem(1344)
    end
    evt.SetNPCTopic(379, 0, 0) -- 劳伦斯・马克 topic 0 cleared
    evt.SetNPCGreeting(379, 172) -- 劳伦斯・马克 greeting 172
end)

RegisterGlobalEvent(817, nil, function()
    evt.SetMessage("（喘气）你们想成为高级射手，那可不容易。你们不仅要弓箭射得准，而且还要精通魔法。你们的任务是去红矮人矿井一趟，那里有两种不同的怪物，一种刀枪不入，只有魔法才可以伤害它们，另一种魔法对它们不起作用，要对付它们只有用兵器。在矿井下面走到底你们会找到矮人族所制造的升降梯，这是连接矿井地上和地下的唯一通路。你们必须把所有的怪兽都赶到矿井地下，然后把升降梯的吊索换上这根快断的，这根吊索只能坚持一个小时，不过这点时间已足够你们脱险回到地上了。完成任务后再上我这儿来吧，我会提拔你们为高级射手。")
    AddValue(InventoryItem(1451), 1451)
    SetQBit(QBit(543)) -- 将布拉卡达沙漠中红色矮人矿井的升降机破坏，然后去找埃里的斯第格・斯尼克。
    SetQBit(QBit(728))
    evt.SetNPCTopic(380, 0, 818) -- 斯第格・斯尼克 topic 0: 高级射手
end)

RegisterGlobalEvent(818, nil, function()
    if not IsQBitSet(QBit(570)) then
        evt.SetMessage("你们还没有把升降机毁了。只有完成了任务，我才可以提拔你们为高级射手。")
        return
    end
    evt.SetMessage("你们干得真不错，竟然这么快就完成了任务。怪兽们都被埋在地底下，再也不会出来危害我们矮人族了。你们已经显示了非凡的武艺和高超的魔法技能，我现在提拔你们之中的弓箭手为高级射手，其他人授予荣誉高级射手称号。祝贺你们！")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 0) then
            SetValue(ClassId, 1)
            SetQBit(QBit(1584))
            AddValue(Experience, 30000)
        else
            SetQBit(QBit(1585))
            AddValue(Experience, 15000)
        end
    end
    ClearQBit(QBit(543)) -- 将布拉卡达沙漠中红色矮人矿井的升降机破坏，然后去找埃里的斯第格・斯尼克。
    AddValue(Gold, 7500)
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(380, 0, 819) -- 斯第格・斯尼克 topic 0: 狙击手
end)

RegisterGlobalEvent(819, nil, function()
    if IsQBitSet(QBit(612)) then
        evt.SetMessage("什么，你们要成为狙击手。这里有个任务要你们去干。在泰坦巨人的营地里有一张完美之弓。这是精灵族送给人类的礼物以平息他们之间连绵不断的战争冲突。（斯尼克大师摇着头）混蛋，什么和平礼物，真让我恶心！不过这张弓对我们来说可是件宝物，你们只要能把完美之弓拿回来，我就提拔你们为狙击手，你们要对付泰坦巨人可得小心些，千万不能硬拼，鸡蛋碰石头可没有什么好下场。")
        SetQBit(QBit(544)) -- 在埃里的泰坦城堡中找到完美之弓，把它交给埃里的斯第格・斯尼克。
        evt.SetNPCTopic(380, 0, 820) -- 斯第格・斯尼克 topic 0: 狙击手
    elseif IsQBitSet(QBit(611)) then
        evt.SetMessage("既然你们已经选择了光明之路，就别想成为狙击手了，我可不愿教个徒弟伏击时会傻乎乎地先向敌人示警。你们还是去找劳伦斯・马克吧，说不定他有法子帮你们，我可无能为力。")
    else
        evt.SetMessage("想要成为狙击手，好啊！但我不知道你们有没有恒心。要做一名出色的狙击手，必须风餐露宿，跋山涉水，人会变得面目憔悴，铁石心肠。如果你们选择了黑暗之路，我会传授你们本领的。")
    end
end)

RegisterGlobalEvent(820, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1344) then
        evt.SetMessage("怎么又失败了？（斯尼克大师咆哮着）咱们把话说明白了，没有完美之弓，别想升职。")
        return
    end
    evt.SetMessage("你们把完美之弓带回来了！好极了！很久以来没人敢上泰坦巨人那里去偷完美之弓，你们真是太伟大了。这张完美之弓就给你们了，我会对它稍加改进，让你们使用更加得心应手。我现在提拔你们之中的高级射手为狙击手，其他人授予荣誉狙击手称号！说实话，我可没料到你们会成功。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 1) then
            SetValue(ClassId, 3)
            SetQBit(QBit(1588))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1589))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(544)) -- 在埃里的泰坦城堡中找到完美之弓，把它交给埃里的斯第格・斯尼克。
    AddValue(InventoryItem(1345), 1345)
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    if HasItem(1344) then
        RemoveItem(1344)
    end
    evt.SetNPCTopic(380, 0, 0) -- 斯第格・斯尼克 topic 0 cleared
    evt.SetNPCGreeting(380, 174) -- 斯第格・斯尼克 greeting 174
end)

RegisterGlobalEvent(821, nil, function()
    if IsQBitSet(QBit(1566)) then
        if IsQBitSet(QBit(612)) then
            evt.SetMessage("提拔你们为勇士，真是痴心妄想！我可不会和你们这帮选择了黑暗之路的家伙打交道，趁我还没有发脾气，快滚吧！")
            return
        elseif IsQBitSet(QBit(611)) then
            evt.SetMessage("你们要成为勇士，就一定要参加竞技大会。要达到勇士的等级必须经受血与火的洗礼，这一切得靠你们自己的努力。你们必须去竞技场赢得五次骑士级别的挑战，然后我才能提拔你们为勇士。")
            SetQBit(QBit(545)) -- 赢得五场竞技场挑战的胜利，然后回到布拉卡达沙漠中找立德・罗文。
            evt.SetNPCTopic(381, 0, 822) -- 立德・罗文 topic 0: 勇士
        else
            evt.SetMessage("看得出你们很想成为勇士，但我不知道是否帮得上忙？你们只有坚定选择了光明之路，我才能够提拔你们。")
            return
        end
    elseif IsQBitSet(QBit(1567)) then
        if IsQBitSet(QBit(612)) then
            evt.SetMessage("提拔你们为勇士，真是痴心妄想！我可不会和你们这帮选择了黑暗之路的家伙打交道，趁我还没有发脾气，快滚吧！")
            return
        elseif IsQBitSet(QBit(611)) then
            evt.SetMessage("你们要成为勇士，就一定要参加竞技大会。要达到勇士的等级必须经受血与火的洗礼，这一切得靠你们自己的努力。你们必须去竞技场赢得五次骑士级别的挑战，然后我才能提拔你们为勇士。")
            SetQBit(QBit(545)) -- 赢得五场竞技场挑战的胜利，然后回到布拉卡达沙漠中找立德・罗文。
            evt.SetNPCTopic(381, 0, 822) -- 立德・罗文 topic 0: 勇士
        else
            evt.SetMessage("看得出你们很想成为勇士，但我不知道是否帮得上忙？你们只有坚定选择了光明之路，我才能够提拔你们。")
            return
        end
    else
        evt.SetMessage("不错，要成为勇士你们只有来找我。但你们首先得达到豪侠等级。你们只有达到豪侠等级，并且选择光明之路，我才能告诉你们如何成为勇士。")
        return
    end
end)

RegisterGlobalEvent(822, nil, function()
    if not IsAtLeast(ArenaWinsKnight, 5) then
        evt.SetMessage("你们还没有在竞技大会上赢得五场比赛，没有达到升职为勇士的要求。记住，你们必须赢得五次骑士级别的挑战，才能达到升职要求。")
        return
    end
    evt.SetMessage("祝贺你们在竞技大会上大获全胜。我现在提拔你们之中的豪侠为勇士，荣誉豪侠授予荣誉勇士称号。为伸张正义而战斗吧，我的勇士们！")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 17) then
            SetValue(ClassId, 19)
            SetQBit(QBit(1568))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1569))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(545)) -- 赢得五场竞技场挑战的胜利，然后回到布拉卡达沙漠中找立德・罗文。
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(381, 0, 0) -- 立德・罗文 topic 0 cleared
    evt.SetNPCGreeting(381, 176) -- 立德・罗文 greeting 176
end)

RegisterGlobalEvent(823, nil, function()
    evt.SetMessage("豪侠向来以英勇无畏著称，如果你们能在战斗中显示无畏的勇气，我可以提拔你们为豪侠。不过现在的人都是胆小鬼，平时耀武扬威，一到打仗就当逃兵，不知你们是不是这样。其实你们的任务很简单，就是去拜尔德斯中的鬼屋，把那里的亡灵全干掉。")
    SetQBit(QBit(546)) -- 消灭拜尔德斯的鬼屋中所有的亡灵怪物，然后回到埃拉西亚找福瑞德里克・奥格。
    evt.SetNPCTopic(382, 0, 824) -- 福瑞德里克・奥格 topic 0: 豪侠
end)

RegisterGlobalEvent(824, nil, function()
    evt.ForPlayer(Players.All)
    if not IsQBitSet(QBit(652)) then
        evt.SetMessage("怎么，鬼屋里这两个小亡灵就把你们吓成这样了？你们这样的胆小鬼我见得多了！快滚吧，你们这种人根本不配作豪侠。")
        return
    end
    evt.SetMessage("啊，你们这么快就完成任务了，干得真出色。我现在提拔你们之中的骑士为豪侠，其他人授予荣誉豪侠称号，接受这个光荣的称号吧。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 16) then
            SetValue(ClassId, 17)
            SetQBit(QBit(1566))
            AddValue(Experience, 30000)
        else
            SetQBit(QBit(1567))
            AddValue(Experience, 15000)
        end
    end
    ClearQBit(QBit(546)) -- 消灭拜尔德斯的鬼屋中所有的亡灵怪物，然后回到埃拉西亚找福瑞德里克・奥格。
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(382, 0, 825) -- 福瑞德里克・奥格 topic 0: 黑骑士
end)

RegisterGlobalEvent(825, nil, function()
    if IsQBitSet(QBit(612)) then
        evt.SetMessage("你们想成为黑骑士，真不错！人们常说坏人都是胆小鬼，真是胡说八道。我们杀人放火，打家劫舍，胆子不大能行吗！你们已经显示了非凡的勇气，达到了豪侠等级，下一个任务要考验你们的胆量和本领，去抢劫精灵宝库。那个地方可是埃拉西亚最大的宝库，警卫特别森严，如果你们能带着宝藏顺利回到这里，我就会提拔你们为黑骑士。")
        SetQBit(QBit(547)) -- 到图拉利昂森林的那文城堡洗劫精灵宝库，然后回埃拉西亚找福瑞德里克・奥格。
        evt.SetNPCTopic(382, 0, 826) -- 福瑞德里克・奥格 topic 0: 黑骑士
    elseif IsQBitSet(QBit(611)) then
        evt.SetMessage("呸！你们这种两面三刀的名门正派，选择了光明之路还来找我干什么，快滚！")
    else
        evt.SetMessage("没错，要成为黑骑士是必须来找我。但你们还没有决定加入我们邪派，还妄想什么黑骑士。等你们决定选择黑暗之路再来找我吧，那时候我会调教你们的。")
    end
end)

RegisterGlobalEvent(826, nil, function()
    if not IsQBitSet(QBit(572)) then
        evt.SetMessage("怎么，抢劫失败了，再去试一次。打起精神，动点脑子，我等着你们的好消息，快去吧。")
        return
    end
    evt.SetMessage("太棒了！我真为你们骄傲。宝藏你们就自己留着吧，这是对你们的奖励。我现在提拔你们之中的豪侠为黑骑士，其他人授予荣誉黑骑士称号。好好干吧，伙计们！")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 17) then
            SetValue(ClassId, 18)
            SetQBit(QBit(1570))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1571))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(547)) -- 到图拉利昂森林的那文城堡洗劫精灵宝库，然后回埃拉西亚找福瑞德里克・奥格。
    AddValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(382, 0, 0) -- 福瑞德里克・奥格 topic 0 cleared
    evt.SetNPCGreeting(382, 178) -- 福瑞德里克・奥格 greeting 178
end)

RegisterGlobalEvent(827, nil, function()
    if IsQBitSet(QBit(1578)) then
        if IsQBitSet(QBit(611)) then
            evt.SetMessage("也许你们能帮我解决这个棘手的难题。游骑领主的职责就是维护埃拉西亚的治安。最近有人把图拉利昂森林里的魔法宝石“古树之心”偷走了。森林从此变得很不太平，游人常在那里遭到袭击。如果不把宝石交回去，它会把到那里的所有人都认为是小偷，不分青红皂白地加以攻击。你们的任务就是找到宝石并把它送到森林中年龄最长的一棵古树那里。然后你们就来找我吧。")
            SetQBit(QBit(548)) -- 去图拉利昂森林与最年长的老树谈话，设法平息森林的愤怒。然后回到布拉卡达找里桑德・斯维特。
            evt.SetNPCTopic(383, 0, 828) -- 里桑德・斯维特 topic 0: 游骑领主
        elseif IsQBitSet(QBit(612)) then
            evt.SetMessage("（里桑德皱眉）你们已经选择了黑暗之路。我可不会教你们任何东西。不然会铸成大错。愿上帝能宽恕你们的罪恶。")
        else
            evt.SetMessage("我挺乐意传授你们本领的，但我不知道你们是否有资格成为游骑领主。要是你们真心诚意选择了光明之路，你们可以再来找我。我会传授你们本领的。")
        end
        return
    elseif IsQBitSet(QBit(1579)) then
        if IsQBitSet(QBit(611)) then
            evt.SetMessage("也许你们能帮我解决这个棘手的难题。游骑领主的职责就是维护埃拉西亚的治安。最近有人把图拉利昂森林里的魔法宝石“古树之心”偷走了。森林从此变得很不太平，游人常在那里遭到袭击。如果不把宝石交回去，它会把到那里的所有人都认为是小偷，不分青红皂白地加以攻击。你们的任务就是找到宝石并把它送到森林中年龄最长的一棵古树那里。然后你们就来找我吧。")
            SetQBit(QBit(548)) -- 去图拉利昂森林与最年长的老树谈话，设法平息森林的愤怒。然后回到布拉卡达找里桑德・斯维特。
            evt.SetNPCTopic(383, 0, 828) -- 里桑德・斯维特 topic 0: 游骑领主
        elseif IsQBitSet(QBit(612)) then
            evt.SetMessage("（里桑德皱眉）你们已经选择了黑暗之路。我可不会教你们任何东西。不然会铸成大错。愿上帝能宽恕你们的罪恶。")
        else
            evt.SetMessage("我挺乐意传授你们本领的，但我不知道你们是否有资格成为游骑领主。要是你们真心诚意选择了光明之路，你们可以再来找我。我会传授你们本领的。")
        end
    else
        evt.SetMessage("（里桑德摇头，微笑）你们心太急了，我只训练有经验的人，等你们达到猎手等级再来找我吧。")
    end
end)

RegisterGlobalEvent(828, nil, function()
    if IsQBitSet(QBit(553)) then
        evt.SetMessage("你们干得好极了，这么快就找到宝石了。森林现在已经风平浪静，游人再也不会遭到袭击了。我现在把你们之中的猎手提拔为游骑领主，荣誉猎手授予荣誉游骑领主称号。")
        for _, player in ipairs(PartyMembers()) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 31) then
                SetValue(ClassId, 33)
                SetQBit(QBit(1580))
                AddValue(Experience, 80000)
            else
                SetQBit(QBit(1581))
                AddValue(Experience, 40000)
            end
        end
        ClearQBit(QBit(548)) -- 去图拉利昂森林与最年长的老树谈话，设法平息森林的愤怒。然后回到布拉卡达找里桑德・斯维特。
        SubtractValue(ReputationInCurrentLocation, 10)
        evt.ForPlayer(Players.All)
        evt.SetNPCTopic(383, 0, 0) -- 里桑德・斯维特 topic 0 cleared
        evt.SetNPCGreeting(383, 180) -- 里桑德・斯维特 greeting 180
    elseif IsQBitSet(QBit(552)) then
        evt.SetMessage("啊，你们已经和老树谈过了，情况你们已经相当了解了吧。现在你们可以去寻找宝石了，找到后直接交给老树，然后再来见我。")
    else
        evt.SetMessage("你们觉得毫无头绪吗？让我来指点你们吧。你们先要找到森林里最古老的一棵树。它就在埃里的匹尔邦特外面。这棵树会说话，你们可以通过它得到一些信息。你们想知道什么，它都会告诉你们的。")
    end
end)

RegisterGlobalEvent(829, nil, function()
    evt.SetMessage("你们想升级就必须完成一个任务。做猎手得对森林的环境了如指掌，而且还必须精通魔法和兵器技能，而神仙是猎手最好的老师。在埃里北面有一个神仙冈，如果你们能在那里找到神仙，他们会把你们之中的游骑兵提拔为猎手，其他人授予荣誉猎手称号。")
    SetQBit(QBit(549)) -- 设法找到神仙冈的秘密出口，然后去里面和仙帝交谈。
    evt.SetNPCTopic(384, 0, 830) -- 埃伯登泽・索渥 topic 0: 猎手
end)

RegisterGlobalEvent(830, nil, function()
    evt.SetMessage("给神仙作弄了吗？哈哈，真好笑（埃伯登泽狂笑）反正我已经告诉你们如何去升级猎手了。快去埃里的神仙冈吧，别再来烦我了。")
end)

RegisterGlobalEvent(831, nil, function()
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("啊！看得出你们是个正人君子，快滚，我一闻到你们的味道就恶心。")
        return
    elseif IsQBitSet(QBit(612)) then
        evt.SetMessage("不甘心做个猎人，还想升级吗？好吧，要成为赏金猎人所要完成的任务比神仙冈的任务容易多了。市政厅正悬赏招募勇士去除掉一个怪物。你们要做的就是想办法把那笔奖金一万个金币拿来，这样我就会提拔你们为赏金猎人了。")
        SetQBit(QBit(550)) -- 设法完成市政厅的赏金任务，赚到10,000个金币，然后回到图拉利昂森林找埃伯登泽・索渥。
        evt.SetNPCTopic(384, 0, 832) -- 埃伯登泽・索渥 topic 0: 赏金猎人
    else
        evt.SetMessage("你们这些人怎么这么糊涂，连正派邪派都不分就来找我了。你们必须尽快决定是选择光明之路还是黑暗之路。要是你们选择了光明之路，就别再来烦我了，咱们分道扬镳。")
        return
    end
end)

RegisterGlobalEvent(832, nil, function()
    if not IsAtLeast(NumBounties, 10000) then
        evt.SetMessage("嗨，你们拿的赏金还不够，你们要得到更多的赏金，去杀更多的怪物。疯狂杀戮也是一种乐趣，你们会觉得很痛快的。")
        return
    end
    evt.SetMessage("啊，赏金拿回来了，那帮蠢货都死光了吧。好了，我现在把你们之中的猎手提拔为赏金猎人，其他人授予赏金猎人称号。你们干得真不错。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 31) then
            SetValue(ClassId, 32)
            SetQBit(QBit(1582))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1583))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(550)) -- 设法完成市政厅的赏金任务，赚到10,000个金币，然后回到图拉利昂森林找埃伯登泽・索渥。
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(384, 0, 0) -- 埃伯登泽・索渥 topic 0 cleared
    evt.SetNPCGreeting(384, 182) -- 埃伯登泽・索渥 greeting 182
end)

RegisterGlobalEvent(833, nil, function()
    evt.SetMessage("啊，你们找到我了。我对上门求教魔法的人总是来者不拒，可惜有些人资质平庸，简直是个废物。好吧，我把你们之中的游骑兵提拔为猎手，其他人授予荣誉猎手称号。能找到我真是你们的福气。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 30) then
            SetValue(ClassId, 31)
            SetQBit(QBit(1578))
            AddValue(Experience, 30000)
        else
            SetQBit(QBit(1579))
            AddValue(Experience, 15000)
        end
    end
    ClearQBit(QBit(549)) -- 设法找到神仙冈的秘密出口，然后去里面和仙帝交谈。
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(384, 0, 831) -- 埃伯登泽・索渥 topic 0: 赏金猎人
    evt.SetNPCTopic(391, 0, 0) -- 仙帝 topic 0 cleared
end)
RegisterCanShowTopic(833, function()
    evt._BeginCanShowTopic(833)
    local visible = true
    if IsQBitSet(QBit(549)) then -- 设法找到神仙冈的秘密出口，然后去里面和仙帝交谈。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(834, nil, function()
    evt.SetMessage("有贼溜进我的身体里把我的心偷走了。葡萄藤说这些盗贼藏在泰塔利亚的雇佣兵行会里。我本来要亲自去找他们，可惜脚下生根，一步都走不了。这件事只能拜托你们了，你们去教训这帮歹徒，把我的心还给我吧。")
    SetQBit(QBit(551)) -- 去泰塔利亚的雇佣兵行会夺回古树之心，把它还给图拉利昂森林里的老树。
    evt.SetNPCTopic(392, 0, 835) -- 古树 topic 0: 古树之心
end)
RegisterCanShowTopic(834, function()
    evt._BeginCanShowTopic(834)
    local visible = true
    if IsQBitSet(QBit(548)) then -- 去图拉利昂森林与最年长的老树谈话，设法平息森林的愤怒。然后回到布拉卡达找里桑德・斯维特。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(835, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1402) then
        evt.SetMessage("哦，整个森林仍旧怒不可遏。葡萄藤说那帮歹徒仍然藏在那里，你们应该尽快去找他们。")
        return
    end
    evt.SetMessage("啊！（老树快乐地说）你们把心拿回来了。整个森林将为之快乐，为之歌唱。我们今晚要吟唱先辈留下来的老歌来庆祝一下，你们留下来和我们一起庆祝吧！")
    RemoveItem(1402)
    ClearQBit(QBit(729))
    AddValue(Experience, 5000)
    ClearQBit(QBit(551)) -- 去泰塔利亚的雇佣兵行会夺回古树之心，把它还给图拉利昂森林里的老树。
    SetQBit(QBit(553))
    evt.SetNPCTopic(392, 0, 0) -- 古树 topic 0 cleared
    evt.SetNPCGreeting(392, 186) -- 古树 greeting 186
    SetAward(Award(23))
    evt.SetMonGroupBit(61, MonsterBits.Hostile, 0)
end)

RegisterGlobalEvent(836, nil, function()
    if IsQBitSet(QBit(1607)) then
        if IsQBitSet(QBit(611)) then
            evt.SetMessage("啊，你们要我指点如何走上光明之路。不过我得事先提醒你们，一旦你们选择了光明之路，就得花费毕生精力全身心地投入修炼，心无旁鹜，永不放弃，你们还是慎重考虑一下吧。布拉卡达南面有个叫做埃弗蒙的小岛。岛上有两个古老的神庙。一个是太阳神庙，一个是月亮神庙。太阳教和月亮教本来是两个势力很大的教派，但由于他们两家势同水火，是天生的死对头，经过连年征战，大家两败俱伤，如今只剩下岛上的这两座神庙了，然而他们仍旧争斗不休。\n太阳神庙是信仰我们光明之路的，我想派你们去助他们一臂之力。你们可以用在执行成为神甫任务时达德拉斯・福克交给你们的航海图，租船下海，到达那个小岛。你们只要捣毁月亮神庙的神坛，他们就会一蹶不振，太阳神庙就可以轻而易举地对付他们了。如果你们顺利完成任务，就可以回我这儿来了。")
            SetQBit(QBit(554)) -- 去埃弗蒙岛捣毁月亮神庙的祭坛，然后回到塞莱斯特找蕾贝卡・迪万。
            evt.SetNPCTopic(385, 0, 837) -- 蕾贝卡・迪万 topic 0: 光明主教
        elseif IsQBitSet(QBit(612)) then
            evt.SetMessage("你们既然已经选择了黑暗之路，还来找我干什么。我可什么也不会教你们的。")
        else
            evt.SetMessage("如果你们要学习光明之路的本领，就得尽快作出选择，遵从我们的信仰，不然我可什么也不能传授你们。")
        end
        return
    elseif IsQBitSet(QBit(1608)) then
        if IsQBitSet(QBit(611)) then
            evt.SetMessage("啊，你们要我指点如何走上光明之路。不过我得事先提醒你们，一旦你们选择了光明之路，就得花费毕生精力全身心地投入修炼，心无旁鹜，永不放弃，你们还是慎重考虑一下吧。布拉卡达南面有个叫做埃弗蒙的小岛。岛上有两个古老的神庙。一个是太阳神庙，一个是月亮神庙。太阳教和月亮教本来是两个势力很大的教派，但由于他们两家势同水火，是天生的死对头，经过连年征战，大家两败俱伤，如今只剩下岛上的这两座神庙了，然而他们仍旧争斗不休。\n太阳神庙是信仰我们光明之路的，我想派你们去助他们一臂之力。你们可以用在执行成为神甫任务时达德拉斯・福克交给你们的航海图，租船下海，到达那个小岛。你们只要捣毁月亮神庙的神坛，他们就会一蹶不振，太阳神庙就可以轻而易举地对付他们了。如果你们顺利完成任务，就可以回我这儿来了。")
            SetQBit(QBit(554)) -- 去埃弗蒙岛捣毁月亮神庙的祭坛，然后回到塞莱斯特找蕾贝卡・迪万。
            evt.SetNPCTopic(385, 0, 837) -- 蕾贝卡・迪万 topic 0: 光明主教
        elseif IsQBitSet(QBit(612)) then
            evt.SetMessage("你们既然已经选择了黑暗之路，还来找我干什么。我可什么也不会教你们的。")
        else
            evt.SetMessage("如果你们要学习光明之路的本领，就得尽快作出选择，遵从我们的信仰，不然我可什么也不能传授你们。")
        end
    else
        evt.SetMessage("你们要成为光明主教，就得先达到神甫等级。去找我的死对头达德拉斯・福克吧，他这人气量倒是不小，即使你们不信仰他的黑暗之路，他也会指点你们如何成为神甫的。")
    end
end)

RegisterGlobalEvent(837, nil, function()
    if not IsQBitSet(QBit(574)) then
        evt.SetMessage("你们必须去埃弗蒙岛把那里月亮教的暗黑神坛摧毁，我才会提拔你们为光明主教。")
        return
    end
    evt.SetMessage("我们正需要你们这种具有非凡勇气和过人本领的人。既然你们已经顺利完成了任务，现在我提拔你们之中的神甫为光明主教，荣誉神甫为荣誉光明主教，感谢你们对太阳教所做的一切。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 5) then
            SetValue(ClassId, 6)
            SetQBit(QBit(1609))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1610))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(554)) -- 去埃弗蒙岛捣毁月亮神庙的祭坛，然后回到塞莱斯特找蕾贝卡・迪万。
    AddValue(Gold, 10000)
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(385, 0, 0) -- 蕾贝卡・迪万 topic 0 cleared
    evt.SetNPCGreeting(385, 188) -- 蕾贝卡・迪万 greeting 188
end)

RegisterGlobalEvent(838, nil, function()
    evt.SetMessage("（福克慈祥地笑着）你们要成为神甫，这个不难，不过得完成一个任务。听说布拉卡达南面有个小岛，上面有座古老的神庙，我找了它已经很久了。埃拉西亚西部的海盗们肯定知道小岛的确切位置。埃拉西亚的皇家舰队都是些废物，至今拿这些海盗没有办法，他们正在潮水洞穴里逍遥快活呢。如果你们能上那儿去把他们的航海图拿来，我会立刻升职你们为神甫。")
    SetQBit(QBit(555)) -- 去泰塔利亚的潮水洞穴找到海盗的地图，然后回到迪雅找达德拉斯・福克。
    evt.SetNPCTopic(386, 0, 839) -- 达德拉斯・福克 topic 0: 神甫
end)

RegisterGlobalEvent(839, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1485) then
        evt.SetMessage("只有埃拉西亚西面潮水洞穴里的地图才会标明小岛的确切位置。你们只要把地图拿来，我一定会把你们提拔为神甫。")
        return
    end
    evt.SetMessage("啊，你们拿到航海图了。（福克看着地图，然后指向一个小岛）对，就是这里。自从一百多年前太阳教和月亮教的大战爆发后，这个小岛就被浓雾笼罩。把地图好好保存着吧，我已经知道了确切位置，就不愁找不到神庙了。现在我把你们之中的牧师提拔为神甫，其他人授予荣誉神甫称号。我真为你们骄傲。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 4) then
            SetValue(ClassId, 5)
            SetQBit(QBit(1607))
            AddValue(Experience, 30000)
        else
            SetQBit(QBit(1608))
            AddValue(Experience, 15000)
        end
    end
    ClearQBit(QBit(555)) -- 去泰塔利亚的潮水洞穴找到海盗的地图，然后回到迪雅找达德拉斯・福克。
    AddValue(Gold, 5000)
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.ForPlayer(Players.All)
    RemoveItem(1485)
    ClearQBit(QBit(730))
    evt.SetNPCTopic(386, 0, 840) -- 达德拉斯・福克 topic 0: 黑暗主教
    SetQBit(QBit(576))
end)

RegisterGlobalEvent(840, nil, function()
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("你们已经选择了光明之路，还来找我干什么。我们之间已经水火不容，趁我现在心情还好，你们快滚吧。")
        return
    elseif IsQBitSet(QBit(612)) then
        evt.SetMessage("（福克冷冷地看着你们）你们想加入黑暗之路，领略我们深奥的魔法。不过我得事先提醒你们，一旦选择了黑暗之路，就得苦心修炼，永无退路。布拉卡达南面有个叫做埃弗蒙的小岛。岛上有两个古老的神庙。一个是太阳神庙，一个是月亮神庙。太阳教和月亮教本来是两个势力很大的教派，但由于他们两家势同水火，是天生的死对头，经过连年征战，大家两败俱伤，如今只剩下岛上的这两座神庙了，然而他们仍旧争斗不休。\n\n月亮神庙是信仰我们黑暗之路的，我想派你们去助他们一臂之力。你们可以用在执行成为神甫任务时我交给你们的地图，租船下海，到达那个小岛。你们只要捣毁太阳神庙的神坛，他们就会一蹶不振，这样月亮神庙就可以轻而易举地对付他们了。如果你们顺利完成任务，就可以回我这儿来了。")
        SetQBit(QBit(556)) -- 去埃弗蒙岛捣毁太阳神庙的祭坛，然后回到迪雅找达德拉斯・福克。
        evt.SetNPCTopic(386, 0, 841) -- 达德拉斯・福克 topic 0: 黑暗主教
    else
        evt.SetMessage("如果你们要学习黑暗之路的本领，就得尽快作出选择，遵从我们的信仰，不然我可什么也不能传授你们。")
        return
    end
end)

RegisterGlobalEvent(841, nil, function()
    if not IsQBitSet(QBit(575)) then
        evt.SetMessage("你们必须去埃弗蒙岛把那里太阳教的光明神坛摧毁，我才会提拔你们为黑暗主教。")
        return
    end
    evt.SetMessage("我们正需要你们这种具有非凡勇气和过人本领的人。既然你们已经顺利完成了任务，现在我提拔你们之中的神甫为黑暗主教，荣誉神甫为荣誉黑暗主教，感谢你们对月亮教所做的一切。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 5) then
            SetValue(ClassId, 7)
            SetQBit(QBit(1611))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1612))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(556)) -- 去埃弗蒙岛捣毁太阳神庙的祭坛，然后回到迪雅找达德拉斯・福克。
    AddValue(Gold, 10000)
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(386, 0, 0) -- 达德拉斯・福克 topic 0 cleared
    evt.SetNPCGreeting(386, 190) -- 达德拉斯・福克 greeting 190
end)

RegisterGlobalEvent(842, nil, function()
    evt.SetMessage("你们要成为法师，就必须完成我交给你们的任务。今年的任务是拼合一个人偶。人偶身体的各个部分散布在从这里到埃里的道路上。你们要把人偶的头颅，身体躯干，四肢都找齐。找人头的时候一定要加倍注意，我有个弟子就是因为没有找到头颅而功亏一篑的。\n\n如果你们把人偶拼好了，就上我这儿来吧，我会提拔你们为法师，并且使人偶复活。好吧，你们该上路了，祝你们好运！")
    SetQBit(QBit(557)) -- 找到人偶肢体的六个部分，把它拼成人形，然后去魔法学院把人偶交给托马斯・格雷。
    SetQBit(QBit(1686))
    evt.SetNPCTopic(387, 0, 843) -- 托马斯・格雷 topic 0: 法师
end)

RegisterGlobalEvent(843, nil, function()
    if IsQBitSet(QBit(586)) then
        evt.SetMessage("（你们自豪地把拼好的人偶交给格雷大师，他赞许地点点头）嗯，干得不错，我现在提拔你们之中的巫师为法师，其他人授予荣誉法师称号。（格雷大师施展魔法激活了人偶）这个复活的人偶归你们了，你们把它带回城堡吧，它会忠诚地保护你们的。")
        for _, player in ipairs(PartyMembers()) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 42) then
                SetValue(ClassId, 43)
                SetQBit(QBit(1619))
                AddValue(Experience, 30000)
            else
                SetQBit(QBit(1620))
                AddValue(Experience, 15000)
            end
        end
        ClearQBit(QBit(557)) -- 找到人偶肢体的六个部分，把它拼成人形，然后去魔法学院把人偶交给托马斯・格雷。
        evt.ForPlayer(Players.All)
        evt.SetNPCTopic(387, 0, 844) -- 托马斯・格雷 topic 0: 大法师
        evt.SetNPCGreeting(395, 199) -- 人偶 greeting 199
        SetQBit(QBit(558))
        ClearQBit(QBit(731))
        ClearQBit(QBit(732))
    elseif IsQBitSet(QBit(585)) then
        evt.SetMessage("（你们自豪地把拼好的人偶交给格雷大师，他赞许地点点头）嗯，干得不错，我现在提拔你们之中的巫师为法师，其他人授予荣誉法师称号。（格雷大师施展魔法激活了人偶）这个复活的人偶归你们了，你们把它带回城堡吧，它会忠诚地保护你们的。")
        for _, player in ipairs(PartyMembers()) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 42) then
                SetValue(ClassId, 43)
                SetQBit(QBit(1619))
                AddValue(Experience, 30000)
            else
                SetQBit(QBit(1620))
                AddValue(Experience, 15000)
            end
        end
        ClearQBit(QBit(557)) -- 找到人偶肢体的六个部分，把它拼成人形，然后去魔法学院把人偶交给托马斯・格雷。
        evt.ForPlayer(Players.All)
        evt.SetNPCTopic(387, 0, 844) -- 托马斯・格雷 topic 0: 大法师
        evt.SetNPCGreeting(395, 199) -- 人偶 greeting 199
        SetQBit(QBit(558))
        ClearQBit(QBit(731))
        ClearQBit(QBit(732))
    else
        evt.SetMessage("你们必须把人偶的每一个部分都找齐才能到我这儿来，我可不能复活残缺不全的人偶。")
        return
    end
end)

RegisterGlobalEvent(844, nil, function()
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("很高兴你们又回来了。人偶这个任务充其量只是个小考验而已，要成为大法师，你们可得花费更多的心血。在我们魔法学院，普渡众生魔法已经失传很久了，这个魔法自从诞生之日起就多灾多难，惹出不少风波。\n\n很久以前，我们就四处派人寻找这个魔法，可惜都没有成功。有人说在某个荒岛上见到过这种魔法，又有人说在某个地穴里发现过它。现在我们已经打听清楚了，它就在地狱城的再生之地里。你们如果能上那里去把这本魔法书带回来，我就提拔你们为大法师。")
        SetQBit(QBit(559)) -- 去地狱城的再生之地找到普渡众生魔法，然后回到魔法学院把它交给托马斯・格雷。
        evt.SetNPCTopic(387, 0, 845) -- 托马斯・格雷 topic 0: 大法师
    elseif IsQBitSet(QBit(612)) then
        evt.SetMessage("你们已经选择了黑暗之路，我什么都不能传授你们。")
    else
        evt.SetMessage("只有选择光明之路才有资格成为大法师。如果你们选择了光明之路，我会传授你们魔法本领的。")
    end
end)

RegisterGlobalEvent(845, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1289) then
        evt.SetMessage("正因为你们与众不同，我才看中你们来完成这项任务。你们可别辜负我，加紧干吧！")
        return
    end
    evt.SetMessage("啊，你们把魔法书带回来了，（格雷大师喜上眉梢）我真为你们骄傲！现在我提拔你们之中的法师为大法师，其他人授予荣誉大法师称号。（格雷施展魔法复制了一本一模一样的魔法书）这本书你们留着吧，好好钻研里面的魔法。这项魔法会在布拉卡达和塞莱斯特广泛流传下去的。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 43) then
            SetValue(ClassId, 46)
            SetQBit(QBit(1621))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1622))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(559)) -- 去地狱城的再生之地找到普渡众生魔法，然后回到魔法学院把它交给托马斯・格雷。
    ClearQBit(QBit(738))
    AddValue(Gold, 10000)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(387, 0, 0) -- 托马斯・格雷 topic 0 cleared
    evt.SetNPCGreeting(387, 192) -- 托马斯・格雷 greeting 192
end)

RegisterGlobalEvent(846, nil, function()
    if IsQBitSet(QBit(1619)) then
        if IsQBitSet(QBit(612)) then
            evt.SetMessage("你们无畏死亡，想成为巫妖？好吧，我可以帮助你们进行永生仪式，不过你们得先完成我的任务。去找一个灵魂之坛。许多年以前在尼根到迪雅的路上有伙法师把整整一船灵魂之坛都偷走了。这些坛子异常牢固，摔不破砸不烂，他们只好把坛子藏起来，想叫我们永远也得不到坛子。\n幸好我们具有把死人点化成亡灵的高超本领，亡灵可比活人强多了，他们记性特别好，而且问什么说什么，老实极了。我们找到一个为法师们埋坛子的家伙，把他变成了亡灵，他就老实交代灵魂之坛藏在了塞莱斯特的迷雾之墙那里了。\n如果你们能把坛子找回来，我就会帮你们做永生仪式，把你们转化为巫妖，快去好好干吧。")
            SetQBit(QBit(560)) -- 去塞莱斯特的净心堂夺回灵魂之坛，然后到地狱城把它交给哈夫・维克。
            evt.SetNPCTopic(388, 0, 847) -- 哈夫・维克 topic 0: 巫妖
        elseif IsQBitSet(QBit(611)) then
            evt.SetMessage("你们已经选择了光明之路，就不可能成为巫妖了。如果进行永生仪式，你们会死掉的。如果你真想死，可以找别人。")
        else
            evt.SetMessage("只有选择黑暗之路才能成为巫妖，你们还没有作出决定，我什么也不能传授你们。等你们选择了黑暗之路再来找我吧。")
        end
        return
    elseif IsQBitSet(QBit(1620)) then
        if IsQBitSet(QBit(612)) then
            evt.SetMessage("你们无畏死亡，想成为巫妖？好吧，我可以帮助你们进行永生仪式，不过你们得先完成我的任务。去找一个灵魂之坛。许多年以前在尼根到迪雅的路上有伙法师把整整一船灵魂之坛都偷走了。这些坛子异常牢固，摔不破砸不烂，他们只好把坛子藏起来，想叫我们永远也得不到坛子。\n幸好我们具有把死人点化成亡灵的高超本领，亡灵可比活人强多了，他们记性特别好，而且问什么说什么，老实极了。我们找到一个为法师们埋坛子的家伙，把他变成了亡灵，他就老实交代灵魂之坛藏在了塞莱斯特的迷雾之墙那里了。\n如果你们能把坛子找回来，我就会帮你们做永生仪式，把你们转化为巫妖，快去好好干吧。")
            SetQBit(QBit(560)) -- 去塞莱斯特的净心堂夺回灵魂之坛，然后到地狱城把它交给哈夫・维克。
            evt.SetNPCTopic(388, 0, 847) -- 哈夫・维克 topic 0: 巫妖
        elseif IsQBitSet(QBit(611)) then
            evt.SetMessage("你们已经选择了光明之路，就不可能成为巫妖了。如果进行永生仪式，你们会死掉的。如果你真想死，可以找别人。")
        else
            evt.SetMessage("只有选择黑暗之路才能成为巫妖，你们还没有作出决定，我什么也不能传授你们。等你们选择了黑暗之路再来找我吧。")
        end
    else
        evt.SetMessage("你们还没有达到法师等级，就想成为巫妖，真是太可笑了。等你们成为法师再来找我吧。")
    end
end)

RegisterGlobalEvent(847, nil, function()
    local hasAllLichJars = true
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if not HasItem(1417) then -- Lich Jar
            hasAllLichJars = false
            break
        end
    end
    if not hasAllLichJars then
        evt.SetMessage("I have no spare Jars with which to perform the Ritual.\nIt is impossible for me to promote you until you return with the Jars.\nRemember, each one of you must have a Jar to be Promoted.")
        return
    end
    evt.SetMessage("Jars.\nYessss.\nYou have helped us greatly.\nNow for the Ritual.\n[The Lich draws a knife, and approaches you]\nThis won't hurt a bit!\n[The ritual actually hurts quite a bit, and takes several hours to complete.\nWhen it is over, the Lich speaks again]\nSo, now it is done.\nThose among you who were Wizards are now most certainly Liches.\nThose who were not, have my gratitude for returning the jars, and I will call you \"Honorary Liches\".\nRemember, Liches must keep their Soul Jars with them at all times while they travel.\nYou cannot be separated from your Jar for long, or you will die a real death.")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 43) then
            SetValue(ClassId, 45)
            SetQBit(QBit(1623)) -- Promoted to Lich
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1624)) -- Promoted to Honorary Lich
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(560)) -- Retrieve the lich jars from the Proving Grounds in Celeste and bring them back to Halfgild Wynac in the Pit.
    ClearQBit(QBit(741)) -- Lich Jar (Empty) - I lost it
    AddValue(Gold, 7500)
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    while HasItem(1417) do -- Lich Jar
        RemoveItem(1417) -- Lich Jar
    end
    evt.SetNPCTopic(388, 0, 0) -- Halfgild Wynac topic 0 cleared
    evt.SetNPCGreeting(388, 194) -- Halfgild Wynac greeting 194

end)

RegisterGlobalEvent(848, nil, function()
    evt.SetMessage("要升级为高级德鲁伊其实挺简单的。你们必须在我们建立的三个古老神庙里祈祷，它们分别在泰塔利亚、埃弗蒙岛和埃里。你们不仅要在神庙中央被石圈围着的祭坛中央祈祷，还得在神庙周围走一走，视察一下有什么情况。只要你们把这些事都能一一完成，我会升级你们为高级德鲁伊。")
    SetQBit(QBit(561)) -- 去泰塔利亚、埃弗蒙岛和埃里三个地方分别找到石圈，然后到图拉利昂森林找安东尼・格林。
    evt.SetNPCTopic(389, 0, 849) -- 安东尼・格林 topic 0: 高级德鲁伊
end)

RegisterGlobalEvent(849, nil, function()
    if IsQBitSet(QBit(562)) then
        evt.SetMessage("啊，三个神庙你们都去过了，它们在你们身上都留下了印记。为了表彰你们的功绩，现在我升级你们之中的德鲁伊为高级德鲁伊，其他人授予荣誉高级德鲁伊称号。")
        for _, player in ipairs(PartyMembers()) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 12) then
                SetValue(ClassId, 13)
                SetQBit(QBit(1613))
                AddValue(Experience, 30000)
            else
                SetQBit(QBit(1614))
                AddValue(Experience, 15000)
            end
        end
        ClearQBit(QBit(561)) -- 去泰塔利亚、埃弗蒙岛和埃里三个地方分别找到石圈，然后到图拉利昂森林找安东尼・格林。
        SubtractValue(ReputationInCurrentLocation, 5)
        evt.ForPlayer(Players.All)
        evt.SetNPCTopic(389, 0, 850) -- 安东尼・格林 topic 0: 大德鲁伊
    elseif IsQBitSet(QBit(563)) then
        evt.SetMessage("啊，你们已经在一个神庙祈祷过了，不错。不过只有在三个神庙都祈祷过，我才能升级你们为高级德鲁伊。记住，必须在三个神庙祈祷。")
        return
    elseif IsQBitSet(QBit(564)) then
        evt.SetMessage("啊，你们已经在一个神庙祈祷过了，不错。不过只有在三个神庙都祈祷过，我才能升级你们为高级德鲁伊。记住，必须在三个神庙祈祷。")
        return
    elseif IsQBitSet(QBit(565)) then
        evt.SetMessage("啊，你们已经在一个神庙祈祷过了，不错。不过只有在三个神庙都祈祷过，我才能升级你们为高级德鲁伊。记住，必须在三个神庙祈祷。")
    else
        evt.SetMessage("你们先得去神庙祈祷，我才能升级你们为高级德鲁伊。")
    end
end)

RegisterGlobalEvent(850, nil, function()
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("要成为大德鲁伊，你们要为埃拉西亚做一件惊天动地的大事。石头城是矮人族的坟地，他们的国王佐卡尔四世也长眠在那里。他是在保卫石头城，抗击尼根侵略的时候英勇牺牲的。他的尸体至今仍散落在城堡中，未能妥善安葬。\n你们的任务就是找到他的尸骨，放入他的棺材里。这样国王可以在天堂安息了，埃拉西亚人民也就放心了。如果你们顺利完成这个任务，我会为你们举行提升仪式，封你们为大德鲁伊。")
        SetQBit(QBit(566)) -- 去石头城与尼根之间的隧道里找到矮人国王的尸骨，把它带到拜尔德斯妥善安葬，然后到图拉利昂森林找安东尼・格林。
        evt.SetNPCTopic(389, 0, 851) -- 安东尼・格林 topic 0: 大德鲁伊
    elseif IsQBitSet(QBit(612)) then
        evt.SetMessage("原来你们选择了黑暗之路，我真后悔以前把你们提拔为高级德鲁伊。你们本来就不是个好东西，我怎么就没有看出来呢！快滚吧，我不想再看见你们。")
    else
        evt.SetMessage("我只提拔选择光明之路的高级德鲁伊，等你们选择了光明之路再来找我吧。")
    end
end)

RegisterGlobalEvent(851, nil, function()
    if not IsQBitSet(QBit(577)) then
        evt.SetMessage("尽管这个任务难度很高，但你们要升级为大德鲁伊就必须完成它。记住，你们一定要把留在从石头城到尼根之间地道里的国王尸骨带回拜尔德斯的矮人坟地，放入他的棺材里。只有完成这个任务，我才可以举行提升仪式升级你们为大德鲁伊。")
        return
    end
    evt.SetMessage("（格林大师见你们完成了任务，变得喜气洋洋）啊，你们完成了任务，国王的灵魂可以在天堂安息了，整个埃拉西亚正为之高兴呢！\n提升仪式已经完成，现在我把你们之中的高级德鲁伊升级为大德鲁伊，其他人授予荣誉大德鲁伊称号，人民会记住你们的功绩的。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 13) then
            SetValue(ClassId, 15)
            SetQBit(QBit(1615))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1616))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(566)) -- 去石头城与尼根之间的隧道里找到矮人国王的尸骨，把它带到拜尔德斯妥善安葬，然后到图拉利昂森林找安东尼・格林。
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    evt.SetNPCTopic(389, 0, 0) -- 安东尼・格林 topic 0 cleared
    evt.SetNPCGreeting(389, 196) -- 安东尼・格林 greeting 196
end)

RegisterGlobalEvent(852, nil, function()
    if IsQBitSet(QBit(1613)) then
        if IsQBitSet(QBit(612)) then
            evt.SetMessage("要成为邪术师说难也不难。只要你们具有这方面的天赋，就可以不费吹灰之力地学习我们的本领，让我看看你们有没有这方面的天赋。（他拿起一个玲珑剔透的水晶球仔细观察）啊，看来你们果然有这方面的天赋，不过在升级为邪术师以前必须完成一个任务，去和龙打交道。\n\n你们必须找到一只龙蛋，把它带回我这里。我可以施展魔法马上把蛋孵化，幼龙诞生后会在你们身上留下印记，使你们拥有龙的力量。听说在巨人领地的龙穴里就有一个龙蛋，不过你们可得小心龙妈妈，她可是个很厉害的家伙。")
            SetQBit(QBit(567)) -- 去巨人领地的龙穴找龙蛋，然后把它带回尼根见托尔・安文。
            evt.SetNPCTopic(390, 0, 853) -- 托尔・安文 topic 0: 邪术师
        elseif IsQBitSet(QBit(611)) then
            evt.SetMessage("嗯（仔细端详着你们），你们怎么选择了光明之路，我都能闻出你们身上正义的气味了。一加入光明之路，就是和黑暗之路分道扬镳，我们邪术师的本领你们一招也别想学了，快滚吧。")
        else
            evt.SetMessage("我们邪术师都是选择黑暗之路的人，你们要是想加入我们，就必须献身黑暗之路，不然我可无能为力。")
        end
        return
    elseif IsQBitSet(QBit(1614)) then
        if IsQBitSet(QBit(612)) then
            evt.SetMessage("要成为邪术师说难也不难。只要你们具有这方面的天赋，就可以不费吹灰之力地学习我们的本领，让我看看你们有没有这方面的天赋。（他拿起一个玲珑剔透的水晶球仔细观察）啊，看来你们果然有这方面的天赋，不过在升级为邪术师以前必须完成一个任务，去和龙打交道。\n\n你们必须找到一只龙蛋，把它带回我这里。我可以施展魔法马上把蛋孵化，幼龙诞生后会在你们身上留下印记，使你们拥有龙的力量。听说在巨人领地的龙穴里就有一个龙蛋，不过你们可得小心龙妈妈，她可是个很厉害的家伙。")
            SetQBit(QBit(567)) -- 去巨人领地的龙穴找龙蛋，然后把它带回尼根见托尔・安文。
            evt.SetNPCTopic(390, 0, 853) -- 托尔・安文 topic 0: 邪术师
        elseif IsQBitSet(QBit(611)) then
            evt.SetMessage("嗯（仔细端详着你们），你们怎么选择了光明之路，我都能闻出你们身上正义的气味了。一加入光明之路，就是和黑暗之路分道扬镳，我们邪术师的本领你们一招也别想学了，快滚吧。")
        else
            evt.SetMessage("我们邪术师都是选择黑暗之路的人，你们要是想加入我们，就必须献身黑暗之路，不然我可无能为力。")
        end
    else
        evt.SetMessage("尽管我很乐意传授你们邪术师的本领，可惜你们功力还不到家，连高级德鲁伊也不是。等你们成为高级德鲁伊再来找我吧。")
    end
end)

RegisterGlobalEvent(853, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1449) then
        evt.SetMessage("你们别无选择，只有找到龙蛋我才能提拔你们为邪术师。到巨人领地的龙穴去碰碰运气吧，说不定那里有龙蛋。")
        return
    end
    evt.SetMessage("（惊奇地望着你们）啊，你们拿到龙蛋了。一百多年来只有你们成功了，简直可以名垂青史。哦，我的魔法书在哪里，啊，原来在这儿。（他对龙蛋轻拍三下，念了个咒语，龙蛋破了，一只小龙蹒跚地爬了出来）看，它多可爱啊。祝贺你们，现在我提拔你们之中的高级德鲁伊为邪术师，荣誉高级德鲁伊授予荣誉邪术师称号，你们真了不起。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 13) then
            SetValue(ClassId, 14)
            SetQBit(QBit(1617))
            AddValue(Experience, 80000)
        else
            SetQBit(QBit(1618))
            AddValue(Experience, 40000)
        end
    end
    ClearQBit(QBit(567)) -- 去巨人领地的龙穴找龙蛋，然后把它带回尼根见托尔・安文。
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    RemoveItem(1449)
    ClearQBit(QBit(739))
    evt.SetNPCTopic(390, 0, 0) -- 托尔・安文 topic 0 cleared
    evt.SetNPCGreeting(389, 198) -- 安东尼・格林 greeting 198
    SetQBit(QBit(1687))
end)

RegisterGlobalEvent(854, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(578)) then
        goto step_15
    end
    if HasItem(1441) then
        SetQBit(QBit(578))
        RemoveItem(1441)
        ClearQBit(QBit(737))
        evt.SetMessage("你们找到人偶的身体躯干了。")
        return
    end
    goto step_15
    ::step_15::
    if IsQBitSet(QBit(579)) then
        goto step_24
    end
    if HasItem(1444) then
        RemoveItem(1444)
        ClearQBit(QBit(736))
        SetQBit(QBit(579))
        evt.SetMessage("你们找到人偶的左腿了。")
        return
    end
    goto step_24
    ::step_24::
    if IsQBitSet(QBit(580)) then
        goto step_33
    end
    if HasItem(1445) then
        evt.SetMessage("你们找到人偶的右腿了。")
        RemoveItem(1445)
        ClearQBit(QBit(735))
        SetQBit(QBit(580))
        return
    end
    goto step_33
    ::step_33::
    if IsQBitSet(QBit(581)) then
        goto step_42
    end
    if HasItem(1447) then
        evt.SetMessage("你们找到人偶的左臂了。")
        RemoveItem(1447)
        ClearQBit(QBit(734))
        SetQBit(QBit(581))
        return
    end
    goto step_42
    ::step_42::
    if IsQBitSet(QBit(582)) then
        goto step_51
    end
    if HasItem(1446) then
        evt.SetMessage("你们找到人偶的右臂了。")
        RemoveItem(1446)
        ClearQBit(QBit(733))
        SetQBit(QBit(582))
        return
    end
    goto step_51
    ::step_51::
    if IsQBitSet(QBit(583)) then
        goto step_71
    end
    if IsQBitSet(QBit(584)) then
        goto step_71
    end
    if HasItem(1443) then
        evt.SetMessage("你们找到人偶的头颅了。")
        RemoveItem(1443)
        ClearQBit(QBit(731))
        SetQBit(QBit(583))
        return
    end
    goto step_61
    ::step_61::
    if IsQBitSet(QBit(583)) then
        goto step_71
    end
    if IsQBitSet(QBit(584)) then
        goto step_71
    end
    if HasItem(1442) then
        evt.SetMessage("你们找到人偶的头颅了。")
        RemoveItem(1442)
        ClearQBit(QBit(732))
        SetQBit(QBit(584))
        return
    end
    goto step_92
    ::step_71::
    if IsQBitSet(QBit(578)) then
        goto step_73
    end
    goto step_92
    ::step_73::
    if IsQBitSet(QBit(579)) then
        goto step_75
    end
    goto step_92
    ::step_75::
    if IsQBitSet(QBit(580)) then
        goto step_77
    end
    goto step_92
    ::step_77::
    if IsQBitSet(QBit(581)) then
        goto step_79
    end
    goto step_92
    ::step_79::
    if IsQBitSet(QBit(582)) then
        goto step_81
    end
    goto step_92
    ::step_81::
    if IsQBitSet(QBit(583)) then
        SetQBit(QBit(586))
        evt.SetMessage("好了，人偶的各个部分你们都已经找到了，快去格雷大师那里把人偶复活吧。")
        evt.SetNPCTopic(395, 1, 0) -- 人偶 topic 1 cleared
        return
    end
    if IsQBitSet(QBit(584)) then
        SetQBit(QBit(585))
        evt.SetMessage("好了，人偶的各个部分你们都已经找到了，快去格雷大师那里把人偶复活吧。")
        evt.SetNPCTopic(395, 1, 0) -- 人偶 topic 1 cleared
        return
    end
    goto step_92
    ::step_92::
    evt.SetMessage("你们还没有找到所有的人偶肢体。")
end)
RegisterCanShowTopic(854, function()
    evt._BeginCanShowTopic(854)
    local visible = true
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(585)) then
        visible = false
        return visible
    else
        if IsQBitSet(QBit(586)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(855, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(1442) then
        RemoveItem(1442)
        ClearQBit(QBit(732))
        evt.ForPlayer(Players.Current)
        AddValue(InventoryItem(1443), 1443)
        SetQBit(QBit(731))
        ClearQBit(QBit(583))
        SetQBit(QBit(584))
        evt.SetMessage("你们把人偶那个表情正常的头部拆下来，换上这个表情扭曲的。")
        return
    elseif HasItem(1443) then
        RemoveItem(1443)
        ClearQBit(QBit(731))
        evt.ForPlayer(Players.Current)
        AddValue(InventoryItem(1442), 1442)
        SetQBit(QBit(732))
        ClearQBit(QBit(584))
        SetQBit(QBit(583))
        evt.SetMessage("你们把人偶那个表情扭曲的头部拆下来，换上这个表情正常的。")
    else
        evt.SetMessage("你们不可能知道这件事的。你们连人偶的头都没有，怎么能办下面的事，这是绝对不可能的。你们去告诉伯瑞安，他把事情搞砸了，瞧我怎么收拾他。")
    end
end)
RegisterCanShowTopic(855, function()
    evt._BeginCanShowTopic(855)
    local visible = true
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(583)) then
        if HasItem(1442) then
            visible = true
            return visible
        else
            visible = false
            return visible
        end
    else
        if IsQBitSet(QBit(584)) then
            if HasItem(1443) then
                visible = true
                return visible
            else
                visible = false
                return visible
            end
        else
            visible = false
            return visible
        end
    end
end)

RegisterGlobalEvent(856, nil, function()
    if not IsQBitSet(QBit(647)) then
        evt.SetMessage("我认为跟这些大耳怪多废话简直是白费功夫，不如给他们些厉害看看。")
        return
    end
    evt.SetMessage("感谢你们终于把这些讨厌的家伙都赶走了，现在我们可以开始重建家园的计划了。我们必须找一些既精通伐木造屋，又和我们交情不错的人来帮忙，看来唯一胜任的只有石头城的矮人族了。这个城堡就在南面拜尔德斯，它的入口位于那里中央最大的一座山上。")
    evt.ForPlayer(Players.All)
    AddValue(Experience, 5000)
    ClearQBit(QBit(587)) -- 把哈蒙代尔城堡里面的怪物消灭干净，然后去镇子上的客栈找管家。
    SetAward(Award(3))
    evt.MoveNPC(397, 1169) -- 管家 -> 加冕殿
    evt.SetNPCTopic(397, 0, 0) -- 管家 topic 0 cleared
    evt.SetNPCGreeting(397, 201) -- 管家 greeting 201
    SetQBit(QBit(658)) -- 去拜尔德斯的石头城和矮人交谈，设法使它们帮助你修复哈蒙代尔城堡。
end)

RegisterGlobalEvent(857, nil, function()
    evt.SetMessage("啊，你们是哈蒙代尔的新主人，见到你们真是太荣幸了。你们要我们帮你们修复城堡，我们当然乐意效劳，不过我们想先麻烦你们一下，帮我一个小忙。美杜莎女妖霸占了我们在布拉卡达东面的矿井，还把我们一些人变成了石头。这帮该死的女妖真是太可恶了，你们能帮我们去教训她们一下吗？\n\n你们要做的就是把这些丹药浇到石像上，这样我们的人就可以变回人形。如果你们完成这个任务，我们会修复你们的城堡的。快去吧，不过你们得小心那里的狮鹫啊。")
    SetQBit(QBit(588)) -- 营救红矮人矿井的矮人，然后到拜尔德斯的石头城找矮人国王。
    ClearQBit(QBit(658)) -- 去拜尔德斯的石头城和矮人交谈，设法使它们帮助你修复哈蒙代尔城堡。
    AddValue(InventoryItem(1431), 1431)
    SetQBit(QBit(742))
    evt.SetNPCTopic(398, 0, 858) -- 贺斯法九世 topic 0: 营救矮人
end)

RegisterGlobalEvent(858, nil, function()
    if IsQBitSet(QBit(1688)) then
        if IsQBitSet(QBit(1689)) then
            if IsQBitSet(QBit(1690)) then
                if IsQBitSet(QBit(1691)) then
                    if IsQBitSet(QBit(1692)) then
                        if IsQBitSet(QBit(1693)) then
                            if not IsQBitSet(QBit(1694)) then
                                evt.SetMessage("什么，我们交给你们的事还没办好。咱们事先说好的，你们先为我们办事，我们才会为你们效劳。")
                                return
                            end
                            evt.SetMessage("啊，你们这么快就完成任务回来了，真是太好了。感谢你们，哈蒙代尔的主人。现在我的手下已经全部准备就绪，只等你们一声令下，我们就可以开工修复城堡了。你们是我们永远的朋友，我们随时乐意为你们效劳。\n嗯，还有一件事要告诉你们，你们现在是埃拉西亚的名人了，许多地方的领主已经开始注意你们了，他们会纷纷派遣使节和你们联系，你们可要好自为知啊。")
                            AddValue(History(4), 0)
                            AddValue(Gold, 5000)
                            ClearQBit(QBit(588)) -- 营救红矮人矿井的矮人，然后到拜尔德斯的石头城找矮人国王。
                            SubtractValue(ReputationInCurrentLocation, 5)
                            evt.ForPlayer(Players.All)
                            SetAward(Award(4))
                            AddValue(Experience, 12500)
                            RemoveItem(1431)
                            ClearQBit(QBit(742))
                            SetQBit(QBit(610))
                            ClearQBit(QBit(1688))
                            evt.MoveNPC(399, 0) -- 德根・凯尔丁 -> removed
                            evt.MoveNPC(406, 1169) -- 艾伦・洛克威 -> 加冕殿
                            evt.MoveNPC(407, 1169) -- 埃兰・汉尼 -> 加冕殿
                            ClearQBit(QBit(1689))
                            ClearQBit(QBit(1690))
                            ClearQBit(QBit(1691))
                            ClearQBit(QBit(1692))
                            ClearQBit(QBit(1693))
                            ClearQBit(QBit(1694))
                            evt.SetNPCTopic(398, 0, 0) -- 贺斯法九世 topic 0 cleared
                            evt.SetNPCGreeting(398, 203) -- 贺斯法九世 greeting 203
                            return
                        end
                    end
                end
            end
        end
    end
    evt.SetMessage("什么，我们交给你们的事还没办好。咱们事先说好的，你们先为我们办事，我们才会为你们效劳。")
end)

RegisterGlobalEvent(859, nil, function()
    SetQBit(QBit(1688))
    evt.SetNPCGreeting(399, 204) -- 德根・凯尔丁 greeting 204
end)
RegisterCanShowTopic(859, function()
    evt._BeginCanShowTopic(859)
    local visible = true
    if HasItem(1476) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(860, nil, function()
    SetQBit(QBit(1689))
    evt.SetNPCGreeting(400, 205) -- 杰森・凯尔丁 greeting 205
end)
RegisterCanShowTopic(860, function()
    evt._BeginCanShowTopic(860)
    local visible = true
    if HasItem(1476) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(861, nil, function()
    SetQBit(QBit(1690))
    evt.SetNPCGreeting(401, 205) -- 劳莱尔・凯尔丁 greeting 205
end)
RegisterCanShowTopic(861, function()
    evt._BeginCanShowTopic(861)
    local visible = true
    if HasItem(1476) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(862, nil, function()
    SetQBit(QBit(1691))
    evt.SetNPCGreeting(402, 205) -- 弗斯・凯尔丁 greeting 205
end)
RegisterCanShowTopic(862, function()
    evt._BeginCanShowTopic(862)
    local visible = true
    if HasItem(1476) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(863, nil, function()
    SetQBit(QBit(1692))
    evt.SetNPCGreeting(403, 205) -- 瑞德・凯尔丁 greeting 205
end)
RegisterCanShowTopic(863, function()
    evt._BeginCanShowTopic(863)
    local visible = true
    if HasItem(1476) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(864, nil, function()
    SetQBit(QBit(1693))
    evt.SetNPCGreeting(404, 205) -- 索尔・凯尔丁 greeting 205
end)
RegisterCanShowTopic(864, function()
    evt._BeginCanShowTopic(864)
    local visible = true
    if HasItem(1476) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(865, nil, function()
    SetQBit(QBit(1694))
    evt.SetNPCGreeting(405, 205) -- 阿尔文・凯尔丁 greeting 205
end)
RegisterCanShowTopic(865, function()
    evt._BeginCanShowTopic(865)
    local visible = true
    if HasItem(1476) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(866, nil, function()
    if not IsQBitSet(QBit(600)) then
        evt.SetMessage("王后凯瑟琳陛下想尽快与你们会面。自从埃拉西亚大战爆发后，王后陛下一直住在斯坦德威克的格芬哈特城堡。这个王国所有的诸侯上任后都要去朝见王后，这已形成惯例。你们的事迹已经在埃拉西亚广为流传，王后特别赏识你们，要亲眼见一见你们这些埃拉西亚的大英雄。")
        return
    end
    if not IsQBitSet(QBit(593)) then
        evt.SetMessage("听说凯瑟琳王后已经接见过你们了，希望你们能给她留个好印象。")
        return
    end
    evt.SetMessage("你们的营救行动完成得很出色，王后对你们非常满意。劳伦已经脱险了，这下帕尔森再也不能有恃无恐了。只要哈蒙代尔的争端一结束，王后就会封赏你们的。")
end)

RegisterGlobalEvent(867, nil, function()
    evt.SetMessage("王后告诉我是你们及时揭露了帕尔森准备暗地里突袭埃拉西亚的阴谋，你们真是我们王国的大忠臣啊！哈蒙代尔交给你们掌管，我们也就放心了。现在我们共同的敌人就是精灵族的帕尔森这个坏蛋，让我们一起努力除掉这个逆贼。")
end)
RegisterCanShowTopic(867, function()
    evt._BeginCanShowTopic(867)
    local visible = true
    if IsQBitSet(QBit(594)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(868, nil, function()
    evt.SetMessage("（艾尔伦高兴得叫起来）啊，你们拿到格芬哈特的号角了，真是太伟大了。这个东西很久以前就莫名其妙地失踪了，肯定是被我们的敌人偷走了，真是谢谢你们能把它完璧归赵。")
    AddValue(Gold, 5000)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 10000)
    RemoveItem(1436)
    ClearQBit(QBit(591)) -- 去图拉利昂森林设法夺回格芬哈特号角，把它交给你要帮助的一方。
    SetQBit(QBit(596))
    evt.SetNPCTopic(406, 2, 0) -- 艾伦・洛克威 topic 2 cleared
end)
RegisterCanShowTopic(868, function()
    evt._BeginCanShowTopic(868)
    local visible = true
    if HasItem(1436) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(869, nil, function()
    evt.SetMessage("我从凯瑟琳王后那里得知你们提供假冒囚犯的事。（艾尔伦夫人毕恭毕敬地行了个礼）你们骗人的伎俩实在太高明，我再也不会被你们道貌岸然的外表所蒙骗了，请你们出去。")
end)
RegisterCanShowTopic(869, function()
    evt._BeginCanShowTopic(869)
    local visible = true
    if IsQBitSet(QBit(595)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(870, nil, function()
    if not IsQBitSet(QBit(601)) then
        evt.SetMessage("尽管哈蒙代尔现在不属于埃里的领土，但我们的国王，埃里的最高统治者帕尔森一直认为哈蒙代尔应当是我们的。关于这片土地的纠纷由来已久，反正是埃拉西亚很久以前就无耻地从我们手里骗取了这个地方，我们不把它夺回来是不会善罢甘休的。我们主人要在图拉利昂森林的匹尔邦特和你们见面，你们快去吧，一定会觉得不虚此行的。")
        return
    end
    if not IsQBitSet(QBit(592)) then
        evt.SetMessage("我奉命通知你们去和我们的国王帕尔森会面。我希望你们明白我们才是哈蒙代尔的真正统治者。")
        return
    end
    evt.SetMessage("我听说你们成功地潜入利文斯德要塞偷取了城堡的设计图。我们已经研究过了，这份设计图对我们攻取城堡非常有用。我代表整个埃里感谢你们。")
end)

RegisterGlobalEvent(871, nil, function()
    evt.SetMessage("你们不仅拒绝了埃拉西亚的要求，没把密探劳伦・斯蒂尔搭救出狱，还向他们提供了一个假囚犯，透露的情报尽是胡说八道。你们干得真是太出色了，埃里的人民感谢你们。")
end)
RegisterCanShowTopic(871, function()
    evt._BeginCanShowTopic(871)
    local visible = true
    if IsQBitSet(QBit(595)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(872, nil, function()
    evt.SetMessage("你们拿到格芬哈特的号角了！自从上次我们袭击埃拉西亚后，这个东西就不见了，一定是被他们的人偷走的。真是谢谢你们能把它带回来。")
    AddValue(Gold, 5000)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 10000)
    RemoveItem(1436)
    ClearQBit(QBit(591)) -- 去图拉利昂森林设法夺回格芬哈特号角，把它交给你要帮助的一方。
    SetQBit(QBit(597))
    evt.SetNPCTopic(407, 2, 0) -- 埃兰・汉尼 topic 2 cleared
end)
RegisterCanShowTopic(872, function()
    evt._BeginCanShowTopic(872)
    local visible = true
    if HasItem(1436) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(873, nil, function()
    evt.SetMessage("我们已经开始怀疑是你们交给我们假的要塞设计图才导致这次我们战役的失败。国王现在正大发脾气。要是真是这样的话，我们以后不知还会吃多少苦头。（埃兰露出职业外交家的伪装的微笑）好了，不管这是不是真的，我们的关系到此结束，以前的事就一笔勾销吧！（大使会心地微笑起来）")
end)
RegisterCanShowTopic(873, function()
    evt._BeginCanShowTopic(873)
    local visible = true
    if IsQBitSet(QBit(594)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(874, nil, function()
    evt.SetMessage("你们就是马克汉姆举办的那个荒唐的寻宝比赛的优胜者。说实话，要不是矮人族国王拼命为你们说好话，我可根本看不上你们。你们一定是帮了他的大忙，不然按他的脾气，理也不会理你们。不过我还是认为耳听为虚，眼见为实，你们要是有真才实学，自然会脱颖而出的，我们等着瞧吧。\n眼下就有一件事让你们来证明自己的能力。几天前我有一个密探在图拉利昂森林不幸被捕了，他的名字叫劳伦・斯蒂尔，被关在匹尔邦特的一个洞穴里。敌人威胁说要是在一个月内不答应他们提出的条件，就会把他处死。如果你们能把他营救出来，我会封赏你们的。")
    evt.SetNPCTopic(408, 0, 875) -- 凯瑟琳王后 topic 0: 战俘
    SetQBit(QBit(590)) -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
    SetQBit(QBit(600))
    SetValue(Counter(1), 0)
end)

RegisterGlobalEvent(875, nil, function()
    if IsAtLeast(Counter(1), 672) then
        evt.SetMessage("唉，可怜的劳伦光荣殉职了。埃里的这帮家伙说得出做得出，我们没有答应他们的条件，他们就无耻地杀死了劳伦。你们不用费功夫找他了，他已经上天堂了。")
        evt.SetNPCTopic(408, 0, 0) -- 凯瑟琳王后 topic 0 cleared
        evt.SetNPCTopic(408, 1, 0) -- 凯瑟琳王后 topic 1 cleared
        ClearQBit(QBit(1695))
        ClearQBit(QBit(1696))
        ClearQBit(QBit(590)) -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
        ClearQBit(QBit(607)) -- 去埃拉西亚的格芬哈特城堡，把假冒的劳伦交给凯瑟琳王后。
        evt.SetMessage("（凯瑟琳王后站起来微笑着）你们真是太出色了，为我解决了一个大难题。（凯瑟琳转向劳伦）能见到你我真是十分高兴，我还以为你回不来了。现在你的身份已经暴露，不再适合作密探这一行了，还是做我的外交官吧。怎么样？考虑考虑吧。至于我们的英雄们，哈，我要对你们致以最诚挚的感谢，并奖励你们5000金币。")
        ClearQBit(QBit(590)) -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
        SetQBit(QBit(593))
        evt.ForPlayer(Players.Current)
        AddValue(BankGold, 5000)
        SubtractValue(ReputationInCurrentLocation, 5)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 10000)
        SetQBit(QBit(1556))
        evt.SetNPCTopic(408, 0, 0) -- 凯瑟琳王后 topic 0 cleared
        evt.SetNPCTopic(408, 1, 0) -- 凯瑟琳王后 topic 1 cleared
        ClearQBit(QBit(1695))
        ClearQBit(QBit(1696))
        return
    elseif IsQBitSet(QBit(1695)) then
        evt.SetMessage("（凯瑟琳王后站起来微笑着）你们真是太出色了，为我解决了一个大难题。（凯瑟琳转向劳伦）能见到你我真是十分高兴，我还以为你回不来了。现在你的身份已经暴露，不再适合作密探这一行了，还是做我的外交官吧。怎么样？考虑考虑吧。至于我们的英雄们，哈，我要对你们致以最诚挚的感谢，并奖励你们5000金币。")
        ClearQBit(QBit(590)) -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
        SetQBit(QBit(593))
        evt.ForPlayer(Players.Current)
        AddValue(BankGold, 5000)
        SubtractValue(ReputationInCurrentLocation, 5)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 10000)
        SetQBit(QBit(1556))
        evt.SetNPCTopic(408, 0, 0) -- 凯瑟琳王后 topic 0 cleared
        evt.SetNPCTopic(408, 1, 0) -- 凯瑟琳王后 topic 1 cleared
        ClearQBit(QBit(1695))
        ClearQBit(QBit(1696))
        return
    elseif IsQBitSet(QBit(1696)) then
        evt.SetMessage("（凯瑟琳王后站起来微笑着）你们真是太出色了，为我解决了一个大难题。（凯瑟琳转向假扮的劳伦）能见到你我真是十分高兴，我还以为你回不来了。现在你的身份已经暴露，不再适合作密探这一行了。还是做我的外交官吧。怎么样？考虑考虑吧。至于我们的英雄们，哈，我要对你们致以最诚挚的感谢。")
        ClearQBit(QBit(590)) -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
        ClearQBit(QBit(607)) -- 去埃拉西亚的格芬哈特城堡，把假冒的劳伦交给凯瑟琳王后。
        SetQBit(QBit(595))
        AddValue(ReputationInCurrentLocation, 5)
        evt.ForPlayer(Players.All)
        SetQBit(QBit(1557))
        evt.SetNPCTopic(408, 0, 0) -- 凯瑟琳王后 topic 0 cleared
        evt.SetNPCTopic(408, 1, 0) -- 凯瑟琳王后 topic 1 cleared
        ClearQBit(QBit(1695))
        ClearQBit(QBit(1696))
    else
        evt.SetMessage("劳伦的生命已经是危在旦夕。我也不可能答应精灵方面提出的条件，不然会牺牲更多无辜的生命。快去营救他吧，去晚了就来不及了。")
        return
    end
end)

RegisterGlobalEvent(876, nil, function()
    evt.SetMessage("（凯瑟琳王后脸都白了）什么，你们终于承认欺骗了我。你们这些无耻的家伙，卫兵，把他拉出去斩首。")
    ClearQBit(QBit(1695))
    ClearQBit(QBit(1696))
    ClearQBit(QBit(590)) -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
    ClearQBit(QBit(607)) -- 去埃拉西亚的格芬哈特城堡，把假冒的劳伦交给凯瑟琳王后。
    SetQBit(QBit(602))
    evt.SetNPCTopic(408, 0, 0) -- 凯瑟琳王后 topic 0 cleared
    evt.SetNPCTopic(408, 1, 0) -- 凯瑟琳王后 topic 1 cleared
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        SetValue(Eradicated, 1)
    end
end)
RegisterCanShowTopic(876, function()
    evt._BeginCanShowTopic(876)
    local visible = true
    if IsQBitSet(QBit(1696)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(877, nil, function()
    evt.SetMessage("帕尔森国王要你们来偷取利文斯德要塞的设计图？嗯，（凯瑟琳转向她的一个侍卫）给我画一张假的要塞设计图，可要画得象一点。（又转向你们）既然他要设计图，那么我们就大方点给他就是了。你们就把假的设计图给他吧，他一定会对你们感激不尽的。（过了一会儿侍卫把假的设计图交给你们）你们必须快点把设计图交给他，看来他们马上会发动进攻了。")
    evt.SetNPCTopic(408, 2, 878) -- 凯瑟琳王后 topic 2: 利文斯德
    SetQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
    AddValue(InventoryItem(1508), 1508)
    ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
end)
RegisterCanShowTopic(877, function()
    evt._BeginCanShowTopic(877)
    local visible = true
    if IsQBitSet(QBit(589)) then -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
        if IsQBitSet(QBit(604)) then
            visible = false
            return visible
        else
            if IsAtLeast(Counter(2), 672) then
                visible = false
                return visible
            else
                visible = true
                return visible
            end
        end
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(878, nil, function()
    if IsQBitSet(QBit(594)) then
        evt.SetMessage("他对那张设计图一点也没有怀疑，真是太好了。我已经命令利文斯德的守军严阵以待，就等着给他们一点利害瞧瞧。至于你们，我会奖赏给你们5000金币。")
        SubtractValue(ReputationInCurrentLocation, 5)
        ClearQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
        ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
        evt.ForPlayer(Players.All)
        AddValue(Experience, 5000)
        evt.ForPlayer(Players.Current)
        AddValue(BankGold, 5000)
        evt.SetNPCTopic(408, 2, 0) -- 凯瑟琳王后 topic 2 cleared
        evt.SetNPCTopic(408, 3, 0) -- 凯瑟琳王后 topic 3 cleared
    elseif IsQBitSet(QBit(603)) then
        evt.SetMessage("国王轻而易举地识破这是张假地图，这怎么可能？（王后捶胸顿足，后悔不已）我怎么会派你们这帮窝囊废去办这么重要的事，算我瞎了眼，你们快滚吧。")
        evt.ForPlayer(Players.All)
        RemoveItem(1508)
        RemoveItem(1507)
        ClearQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
        ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
        evt.SetNPCTopic(408, 2, 0) -- 凯瑟琳王后 topic 2 cleared
        evt.SetNPCTopic(408, 3, 0) -- 凯瑟琳王后 topic 3 cleared
        return
    elseif IsAtLeast(Counter(2), 672) then
        evt.SetMessage("看来帕尔森国王已经等不及看你们的设计图了，他已经开始发动进攻。你们也不用去把设计图交给他了，这已经无济于事了。")
        RemoveItem(1508)
        RemoveItem(1507)
        evt.SetNPCTopic(408, 2, 0) -- 凯瑟琳王后 topic 2 cleared
        evt.SetNPCTopic(408, 3, 0) -- 凯瑟琳王后 topic 3 cleared
        ClearQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
        ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
    else
        evt.SetMessage("你们必须赶在他们发动进攻之前把要塞的设计图交给他们，不然我们煞费苦心制订的计划可要泡汤了。快去吧，我等着你们的好消息。")
    end
end)

RegisterGlobalEvent(879, nil, function()
    evt.SetMessage("（王后听着你们津津有味地诉说怎样溜进利文斯德要塞，偷走真的设计图，还杀了不少守卫，不禁勃然大怒）你们真是我见到的最无耻下流的家伙，卫兵，把他们拉出去斩首。")
    RemoveItem(1507)
    RemoveItem(1508)
    ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
    ClearQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
    evt.SetNPCTopic(408, 2, 0) -- 凯瑟琳王后 topic 2 cleared
    evt.SetNPCTopic(408, 3, 0) -- 凯瑟琳王后 topic 3 cleared
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        SetValue(Eradicated, 1)
    end
end)
RegisterCanShowTopic(879, function()
    evt._BeginCanShowTopic(879)
    local visible = true
    if HasItem(1507) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(880, nil, function()
    evt.SetMessage("啊，我们的大英雄，你们竟然找到了号角，真是太好了，我们还以为永远也见不到它了呢！作为酬谢，我们会在你们的银行户头里存上5000金币的酬金以表达我们的感激之情。")
    AddValue(BankGold, 5000)
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 10000)
    RemoveItem(1436)
    ClearQBit(QBit(591)) -- 去图拉利昂森林设法夺回格芬哈特号角，把它交给你要帮助的一方。
    SetQBit(QBit(596))
    evt.SetNPCTopic(408, 4, 0) -- 凯瑟琳王后 topic 4 cleared
end)
RegisterCanShowTopic(880, function()
    evt._BeginCanShowTopic(880)
    local visible = true
    if HasItem(1436) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(881, nil, function()
    evt.SetMessage("欢迎，你们就是那个愚蠢的马克汉姆委派的所谓哈蒙代尔的新主人吧。你们要明白，迟早有一天我会把哈蒙代尔并入我们埃里的领土，它本来就是我们的地方，只不过被埃拉西亚暂时霸占了而已。至于你们吗，得看你们自己的表现了，如果忠心投靠我们，我自然会让你们在这个职位上继续舒舒服服的坐下去，但如果你们胆敢反抗我，那可是死路一条。\n\n（帕尔森国王亲切地微笑）开个玩笑而已，你们当然是帮我们的。不过我怎么才能相信你们是真心效忠我们呢？俗话说得好：人心隔肚皮，做事两难知。眼下我有个任务交给你们去完成，以证明你们的忠诚。你们要去利文斯德要塞，偷取那里的要塞设计图。这个要塞座落在我们与埃拉西亚之间，地势险要，防守坚固。你们只要潜入城堡，把它的设计图偷来，不仅可以表明你们的忠诚，还有一大笔赏金等着你们。不过你们得快点，我只给一个月的时间，过期不候。")
    evt.SetNPCTopic(409, 0, 882) -- 精灵王 topic 0: 利文斯德
    SetQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
    SetQBit(QBit(601))
    SetValue(Counter(2), 0)
end)

RegisterGlobalEvent(882, nil, function()
    if not IsAtLeast(Counter(2), 672) then
        evt.ForPlayer(Players.All)
        if HasItem(1507) then
            evt.SetMessage("（你们把设计图交给帕尔森，他眉开眼笑）真是太谢谢你们了，这张设计图对我们来说可是至关重要。我已经把5000金币存入你们的银行户头了，只要这一战能够大获全胜，我们整个王国都会对你们感激不尽的。")
            ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
            ClearQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
            SetQBit(QBit(592))
            evt.ForPlayer(Players.Current)
            AddValue(BankGold, 5000)
            SubtractValue(ReputationInCurrentLocation, 5)
            evt.ForPlayer(Players.All)
            AddValue(Experience, 10000)
            SetQBit(QBit(1558))
            evt.SetNPCTopic(409, 0, 0) -- 精灵王 topic 0 cleared
            evt.SetNPCTopic(409, 1, 0) -- 精灵王 topic 1 cleared
            RemoveItem(1507)
            RemoveItem(1508)
            return
        elseif HasItem(1508) then
            evt.SetMessage("（你们把假的设计图交给帕尔森，他眉开眼笑）真是太谢谢你们了，这张设计图对我们来说可是至关重要。只要这一战能够大获全胜，我们整个王国都会对你们感激不尽的。")
            ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
            ClearQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
            SetQBit(QBit(594))
            AddValue(ReputationInCurrentLocation, 5)
            evt.ForPlayer(Players.All)
            SetQBit(QBit(1559))
            evt.SetNPCTopic(409, 0, 0) -- 精灵王 topic 0 cleared
            evt.SetNPCTopic(409, 1, 0) -- 精灵王 topic 1 cleared
            RemoveItem(1508)
            RemoveItem(1507)
        else
            evt.SetMessage("那张设计图我可是很快就要的，你们要是拖得时间太长了，我们即使得不到图纸也会发动进攻的。记住，你们只有一个月的期限。")
            return
        end
        return
    end
    evt.SetMessage("一个月的期限已经到了，你们还没有把设计图偷来。毕竟你们为这件事费了不少心血，我们得感谢你们，不过我们现在不再需要这个东西了。")
    evt.SetNPCTopic(409, 0, 0) -- 精灵王 topic 0 cleared
    evt.SetNPCTopic(409, 1, 0) -- 精灵王 topic 1 cleared
    RemoveItem(1507)
    RemoveItem(1508)
    ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
    ClearQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
    evt.SetMessage("（你们把设计图交给帕尔森，他眉开眼笑）真是太谢谢你们了，这张设计图对我们来说可是至关重要。我已经把5000金币存入你们的银行户头了，只要这一战能够大获全胜，我们整个王国都会对你们感激不尽的。")
    ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
    ClearQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
    SetQBit(QBit(592))
    evt.ForPlayer(Players.Current)
    AddValue(BankGold, 5000)
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 10000)
    SetQBit(QBit(1558))
    evt.SetNPCTopic(409, 0, 0) -- 精灵王 topic 0 cleared
    evt.SetNPCTopic(409, 1, 0) -- 精灵王 topic 1 cleared
    RemoveItem(1507)
    RemoveItem(1508)
end)

RegisterGlobalEvent(883, nil, function()
    evt.SetMessage("什么，这张设计图竟然是假的，看来你们明目张胆要背叛我。（国王不耐烦地挥了挥手）卫兵，把他拉出去砍头。")
    RemoveItem(1508)
    RemoveItem(1507)
    ClearQBit(QBit(606)) -- 去图拉利昂森林的那文城堡，把伪造的要塞设计图交给帕尔森国王。
    ClearQBit(QBit(589)) -- 设法拿到利文斯德要塞的设计图，然后到图拉利昂森林的那文城堡找帕尔森国王。
    SetQBit(QBit(603))
    evt.SetNPCTopic(409, 0, 0) -- 精灵王 topic 0 cleared
    evt.SetNPCTopic(409, 1, 0) -- 精灵王 topic 1 cleared
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        SetValue(Eradicated, 1)
    end
end)
RegisterCanShowTopic(883, function()
    evt._BeginCanShowTopic(883)
    local visible = true
    if HasItem(1508) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(884, nil, function()
    evt.SetMessage("这个臭王后想要对付我！（国王眉头紧锁，然后又舒展开来）有了，我手下有个人和你们要救的劳伦模样长得很象，你们就把我的人代替劳伦领到王后那里去，她对手下不是很熟悉，肯定不会识破的。这样假劳伦只要胡说八道一番，就不怕她不上当。（国王把那个假劳伦召进来）你们可要小心从事，千万别让她识破我们的计划。")
    evt.SetNPCTopic(409, 2, 885) -- 精灵王 topic 2: 密探
    SetQBit(QBit(607)) -- 去埃拉西亚的格芬哈特城堡，把假冒的劳伦交给凯瑟琳王后。
    SetQBit(QBit(1696))
    ClearQBit(QBit(590)) -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
end)
RegisterCanShowTopic(884, function()
    evt._BeginCanShowTopic(884)
    local visible = true
    if IsQBitSet(QBit(590)) then -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
        if IsQBitSet(QBit(605)) then
            visible = false
            return visible
        else
            if IsAtLeast(Counter(1), 672) then
                visible = false
                return visible
            else
                visible = true
                return visible
            end
        end
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(885, nil, function()
    if IsQBitSet(QBit(595)) then
        evt.SetMessage("假劳伦已经成为了王后的部下，这下他准会兴风作浪，大干一番的。真是谢谢你们的大力协助，我会把5000个金币作为酬金存入你们的银行户头。")
        ClearQBit(QBit(607)) -- 去埃拉西亚的格芬哈特城堡，把假冒的劳伦交给凯瑟琳王后。
        SubtractValue(ReputationInCurrentLocation, 5)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 5000)
        evt.ForPlayer(Players.Current)
        AddValue(BankGold, 5000)
        evt.SetNPCTopic(409, 2, 0) -- 精灵王 topic 2 cleared
        evt.SetNPCTopic(409, 3, 0) -- 精灵王 topic 3 cleared
    elseif IsQBitSet(QBit(602)) then
        evt.SetMessage("是你们向王后告发了假囚犯的事？我简直不敢相信自己的耳朵，你们这些白痴，快滚吧，我永远也不想见到你们。")
        evt.ForPlayer(Players.All)
        ClearQBit(QBit(1696))
        ClearQBit(QBit(1695))
        ClearQBit(QBit(607)) -- 去埃拉西亚的格芬哈特城堡，把假冒的劳伦交给凯瑟琳王后。
        evt.SetNPCTopic(409, 2, 0) -- 精灵王 topic 2 cleared
        evt.SetNPCTopic(409, 3, 0) -- 精灵王 topic 3 cleared
        return
    elseif IsAtLeast(Counter(1), 672) then
        evt.SetMessage("处决劳伦的日子已经过了，你们也不必把假劳伦交给王后了，这样做太危险，她很容易就会识破的。这个人现在已经没用了。")
        ClearQBit(QBit(1696))
        ClearQBit(QBit(1695))
        evt.SetNPCTopic(409, 2, 0) -- 精灵王 topic 2 cleared
        evt.SetNPCTopic(409, 3, 0) -- 精灵王 topic 3 cleared
        ClearQBit(QBit(607)) -- 去埃拉西亚的格芬哈特城堡，把假冒的劳伦交给凯瑟琳王后。
        ClearQBit(QBit(590)) -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
    else
        evt.SetMessage("你们一定要赶在我们宣布的处决劳伦的日期前把假劳伦带到王后那里，不然她会起疑心的。她对我的脾气很了解，说到做到，决定的事不容有半分更改。")
    end
end)

RegisterGlobalEvent(886, nil, function()
    evt.SetMessage("（国王静静听你们诉说对埃里犯下的种种罪行，等你们说完后他伸了个懒腰，笑嘻嘻地对你们说）看来你们说的故事都是真的了，那好吧，卫兵，把他们拖出去斩首。")
    ClearQBit(QBit(1695))
    ClearQBit(QBit(1696))
    ClearQBit(QBit(590)) -- 去图拉利昂森林中的洞穴内设法把劳伦・斯迪尔搭救出来，然后把他带回埃拉西亚见凯瑟琳王后。
    ClearQBit(QBit(607)) -- 去埃拉西亚的格芬哈特城堡，把假冒的劳伦交给凯瑟琳王后。
    evt.SetNPCTopic(409, 2, 0) -- 精灵王 topic 2 cleared
    evt.SetNPCTopic(409, 3, 0) -- 精灵王 topic 3 cleared
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        SetValue(Eradicated, 1)
    end
end)
RegisterCanShowTopic(886, function()
    evt._BeginCanShowTopic(886)
    local visible = true
    if IsQBitSet(QBit(1695)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(887, nil, function()
    evt.SetMessage("啊，是号角，是你们找到的。我们正为如何应付人类的进攻而发愁呢，想不到你们却帮了我们大忙。我们会在你们的银行户头里存入5000金币以表达我们的感激之情。")
    AddValue(BankGold, 5000)
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 10000)
    RemoveItem(1436)
    ClearQBit(QBit(591)) -- 去图拉利昂森林设法夺回格芬哈特号角，把它交给你要帮助的一方。
    SetQBit(QBit(597))
    evt.SetNPCTopic(409, 4, 0) -- 精灵王 topic 4 cleared
end)
RegisterCanShowTopic(887, function()
    evt._BeginCanShowTopic(887)
    local visible = true
    if HasItem(1436) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(888, nil, function()
    if not IsQBitSet(QBit(610)) then
        evt.SetMessage("我给你们的唯一忠告就是尽快修复城堡。但我可不管你们怎样去筹备修复城堡所需要的足够人力和财力，要知道，那可得花一大笔钱，只有王公贵族们才有钱搞这么大的工程。其实这是一个先有鸡还是先有蛋的老问题了，你们要高人一等就必须有权有势，而你们必须先有权有势才会显得高人一等。\n说明白点吧，你们要是想保住哈蒙代尔的领导权，就必须干些惊天动地的大事，以证明自己并不是个光捡天上掉下来的馅饼的暴发户。你们要让别人知道，自己是这里真正的主宰。")
        return
    end
    evt.SetMessage("从前，埃拉西亚的人类和埃里的精灵族势如水火，为了哈蒙代尔打得不可开交。作为这里的法官，我自然有义务把他们双方都拉到谈判桌上商讨如何结束战争。两方面势力上都势均力敌，谁都战胜不了谁。（法官靠近你们，压低嗓音）跟你们说实话吧，其实谁赢了我都不在乎。他们就象两个淘气的孩子在争夺一个玩具，没有人真的想要哈蒙代尔，只是要和对方作对罢了。\n\n现在你们可以有自己的主意，选择到底是帮哪一方。每一种选择都会有不同的结果。不过你们要记住，他们对谁掌管哈蒙代尔都不会在乎的，所以你们首先想到的应该是保护自己和哈蒙代尔的百姓。好了，你们可以走了，希望我们这次谈话的内容你们对谁都别说。")
end)

RegisterGlobalEvent(890, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(1436) then
        evt.SetMessage("你们能把号角找到并带给我，真是太好了。这下我就可以用它来帮助人类和精灵族战争中的弱者，使两家势均力敌，从而早日结束战争。太谢谢你们了。")
        SetQBit(QBit(659))
        AddValue(Experience, 12500)
        RemoveItem(1436)
        ClearQBit(QBit(591)) -- 去图拉利昂森林设法夺回格芬哈特号角，把它交给你要帮助的一方。
        evt.SetNPCTopic(413, 2, 0) -- 仲裁人格瑞 topic 2 cleared
    end
end)
RegisterCanShowTopic(890, function()
    evt._BeginCanShowTopic(890)
    local visible = true
    if HasItem(1436) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(891, nil, function()
    ClearQBit(QBit(1697))
    evt.MoveNPC(416, 244) -- 仲裁人费尔维泽 -> 宾至如归旅店
    evt.MoveNPC(417, 0) -- 仲裁人斯利恩 -> removed
    evt.SetNPCGreeting(416, 219) -- 仲裁人费尔维泽 greeting 219
    evt.SetNPCGreeting(417, 217) -- 仲裁人斯利恩 greeting 217
    SetQBit(QBit(1698))
    evt.SetMessage("英明的选择，你们一定不会后悔的，相信我。我早知道你们会这样做的，瞧，我连行李也准备好了，就等着你们下命令了。你们只要把我带到哈蒙代尔我的新家，剩下的事我会解决的。")
    evt.SetNPCTopic(417, 0, 0) -- 仲裁人斯利恩 topic 0 cleared
    evt.SetNPCTopic(416, 0, 893) -- 仲裁人费尔维泽 topic 0: 我选中你了！
end)

RegisterGlobalEvent(892, nil, function()
    evt.ForPlayer(Players.All)
    if not IsQBitSet(QBit(622)) then
        evt.SetMessage("首先你们得去艾恩法斯特爵士那里完成他交给你们的任务。一旦你们完成了任务，证明了你们的忠诚和本领，他会更加信任你们的。")
        return
    end
    if not IsQBitSet(QBit(623)) then
        evt.SetMessage("艾恩法斯特阁下的每个大臣也会各交给你们一项任务。你们必须一一出色地完成它们。你们要与卡斯托、达克・谢德和马克西姆多谈两句，以获得更多的情报，完成这些任务对我们将来的行动可是非常有用的。")
        return
    end
    if not IsQBitSet(QBit(624)) then
        evt.SetMessage("艾恩法斯特阁下的每个大臣也会各交给你们一项任务。你们必须一一出色地完成它们。你们要与卡斯托、达克・谢德和马克西姆多谈两句，以获得更多的情报，完成这些任务对我们将来的行动可是非常有用的。")
        return
    end
    if not IsQBitSet(QBit(625)) then
        evt.SetMessage("艾恩法斯特阁下的每个大臣也会各交给你们一项任务。你们必须一一出色地完成它们。你们要与卡斯托、达克・谢德和马克西姆多谈两句，以获得更多的情报，完成这些任务对我们将来的行动可是非常有用的。")
        return
    end
    if not IsQBitSet(QBit(630)) then
        evt.SetMessage("托尔伯蒂有一个很重要的任务交给你们去完成，你们一定要精心准备，不能有半点闪失，要知道，每一次执行任务都是在拿性命赌博啊。")
        return
    end
    if not IsQBitSet(QBit(632)) then
        evt.SetMessage("必须把诺菲克斯和克里根人的余党一网打尽。你们快去巨人领地，他们在那里有个巢穴。你们一定要把他们斩尽杀绝，不留一个活口。")
        return
    end
    if not IsQBitSet(QBit(633)) then
        evt.SetMessage("你们要去找一艘曾经把卡斯托和他的手下带到这片大陆的船，它可能在埃里西面的海里，一路上可要小心啊。")
        return
    end
    evt.SetMessage("快把振荡器交给卡斯托，这件事十万火急，稍有延误就会酿成大祸。")
end)

RegisterGlobalEvent(893, nil, function()
    ClearQBit(QBit(1698))
    evt.MoveNPC(417, 243) -- 仲裁人斯利恩 -> 怪物旅店
    evt.MoveNPC(416, 0) -- 仲裁人费尔维泽 -> removed
    evt.SetNPCGreeting(417, 216) -- 仲裁人斯利恩 greeting 216
    evt.SetNPCGreeting(416, 220) -- 仲裁人费尔维泽 greeting 220
    SetQBit(QBit(1697))
    evt.SetMessage("英明的选择，你们一定不会后悔的，相信我。我早知道你们会这样做的，瞧，我连行李也准备好了，就等着你们下命令了。你们只要把我带到哈蒙代尔我的新家，剩下的事我会解决的。")
    evt.SetNPCTopic(416, 0, 0) -- 仲裁人费尔维泽 topic 0 cleared
    evt.SetNPCTopic(417, 0, 891) -- 仲裁人斯利恩 topic 0: 我选中你了！
end)

RegisterGlobalEvent(894, nil, function()
    evt.ForPlayer(Players.All)
    if not IsQBitSet(QBit(626)) then
        evt.SetMessage("首先你们要去找住在塞莱斯特的格文・马格努斯，并接受他的考验。一旦你们顺利完成任务，他会告诉你们如何成为主宰埃拉西亚大局的人物。")
        return
    end
    if not IsQBitSet(QBit(627)) then
        evt.SetMessage("盖文手下每一个大臣都会交给你们一个任务。你们要与瑞瑟雷克特、卡格汉、克拉格・汉克多谈两句以获得更多的情报，你们必须把他们交给你们的任务一一完成，这关系到埃拉西亚将来的命运。")
        return
    end
    if not IsQBitSet(QBit(628)) then
        evt.SetMessage("盖文手下每一个大臣都会交给你们一个任务。你们要与瑞瑟雷克特、卡格汉、克拉格・汉克多谈两句以获得更多的情报，你们必须把他们交给你们的任务一一完成，这关系到埃拉西亚将来的命运。")
        return
    end
    if not IsQBitSet(QBit(629)) then
        evt.SetMessage("盖文手下每一个大臣都会交给你们一个任务。你们要与瑞瑟雷克特、卡格汉、克拉格・汉克多谈两句以获得更多的情报，你们必须把他们交给你们的任务一一完成，这关系到埃拉西亚将来的命运。")
        return
    end
    if not IsQBitSet(QBit(631)) then
        evt.SetMessage("智者罗伯特有一个相当重要的任务要你们去完成，它决定我们今后行动的成败与否。你们一定要谨慎从事，不能有半点马虎，成败在此一举啊！")
        return
    end
    if not IsQBitSet(QBit(632)) then
        evt.SetMessage("为了我们的计划能够顺利实施，必须把克里根族和他们的首领诺菲克斯一网打尽。你们可以在巨人领地找到他们的巢穴。")
        return
    end
    if not IsQBitSet(QBit(633)) then
        evt.SetMessage("瑞瑟雷克特和他的手下是坐船来到这片大陆的，如今这艘船就在埃里西面的海里。你们要找到那艘船，并把振荡器带回来，一路上可要小心啊！")
        return
    end
    evt.SetMessage("快把振荡器交给瑞瑟雷克特，这件事十万火急，稍有延误就会酿成大祸。")
end)

RegisterGlobalEvent(895, nil, function()
    evt.SetMessage("这项考验要求你们安全地从迷雾之墙的前门进去，后门出来。我使用“门”这个字也许不大贴切，你们见了就会知道这是怎样一扇门了。在此过程中你们不能使用任何武器，一旦你们杀死一人，此项行动即告失败。如果你们能成功通过这次考验，就可以加入我们光明魔法行会，祝你们好运。")
    SetQBit(QBit(613)) -- 穿过迷雾之墙并且不杀一人，事成之后去塞莱斯特的光辉城堡找格文・马格努斯。
    ClearQBit(QBit(664)) -- 使用布拉卡达的远距离传送器进入塞莱斯特，到光辉城堡和格文・马格努斯交谈。
    evt.SetNPCTopic(418, 0, 896) -- 格文・玛格努斯 topic 0: 净心堂
end)

RegisterGlobalEvent(896, nil, function()
    if not IsQBitSet(QBit(614)) then
        evt.SetMessage("听仔细了，你们必须安全地从迷雾之墙的前门进去，后门出来，并且不得杀死任何人。你们只有顺利做到这一点，才可以上我这儿来。")
        return
    end
    evt.SetMessage("你们已经通过考验了，你们真了不起，我还没有看见一个人能象你们这样这么快就完成了这个任务。我的大臣们现在想见见你们，他们就在塞莱斯特东面的四间屋子里。再次祝贺你们，我的勇士们。")
    ClearQBit(QBit(613)) -- 穿过迷雾之墙并且不杀一人，事成之后去塞莱斯特的光辉城堡找格文・马格努斯。
    evt.SetNPCTopic(418, 0, 0) -- 格文・玛格努斯 topic 0 cleared
    AddValue(History(10), 0)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 50000)
    SetQBit(QBit(626))
    SetAward(Award(6))
    evt.SetNPCGreeting(418, 223) -- 格文・玛格努斯 greeting 223
    evt.MoveNPC(419, 1062) -- 瑞瑟雷克特 -> 客栈
    evt.MoveNPC(420, 1063) -- 克拉格・汉克 -> 客栈
    evt.MoveNPC(421, 1064) -- 卡格汉爵士 -> 客栈
    evt.MoveNPC(422, 1065) -- 智者罗伯特 -> 客栈
    evt.SetNPCGreeting(419, 226) -- 瑞瑟雷克特 greeting 226
    evt.SetNPCGreeting(420, 229) -- 克拉格・汉克 greeting 229
    evt.SetNPCGreeting(421, 232) -- 卡格汉爵士 greeting 232
    evt.SetNPCGreeting(422, 235) -- 智者罗伯特 greeting 235
    SetQBit(QBit(1605))
end)

RegisterGlobalEvent(897, nil, function()
    evt.SetMessage("我们需要你们的帮助。你们要到暗黑神庙去一趟。那里是我们的死对头死灵法师供奉那块圣坛碎片的地方。你们要想方设法把那块碎片拿来，这可是个相当棘手的任务，你们可得多费点功夫。你们还要把另一块圣坛碎片也拿来给我，它就供奉在我们的光明神庙里，你们是我们的朋友，神庙里的人不会麻烦你们的，但你们也不得伤害任何人。等把两块碎片配齐了，你们再上我这里来吧。")
    SetQBit(QBit(615)) -- 分别去塞莱斯特的光明神庙和地狱城的暗黑神庙收集到圣坛碎片，把它们交给塞莱斯特光辉城堡里的瑞瑟雷克特。
    evt.SetNPCTopic(419, 0, 898) -- 瑞瑟雷克特 topic 0: 暗黑神庙
end)
RegisterCanShowTopic(897, function()
    evt._BeginCanShowTopic(897)
    local visible = true
    if IsQBitSet(QBit(626)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(898, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(1478) then
        if not HasItem(1479) then
            evt.SetMessage("啊，你们已经找到我们的那块圣坛碎片了，不过另一块还在暗黑神庙。等你们把两块圣坛碎片都配齐了再上我这儿来吧，我会使它们完整如初的。")
            return
        end
        evt.SetMessage("我早就知道你们会成功的。（你们把两块圣坛碎片递给她，她把碎片拼合在一起，施展魔法向裂缝处一指，立刻变得严丝合缝，完好如初了）由于你们的帮助，我们的行动已经迈出了关键的一步。也许在我们的计划实现以前还得麻烦你们，有你们这么一个出色的助手实在是我们的幸运。十分感谢你们，我们不会忘记你们的，让我们以后有机会能一起分享胜利的喜悦。")
        RemoveItem(1478)
        RemoveItem(1479)
        ClearQBit(QBit(744))
        ClearQBit(QBit(745))
        AddValue(History(12), 0)
        AddValue(Experience, 50000)
        evt.SetNPCTopic(419, 0, 0) -- 瑞瑟雷克特 topic 0 cleared
        ClearQBit(QBit(615)) -- 分别去塞莱斯特的光明神庙和地狱城的暗黑神庙收集到圣坛碎片，把它们交给塞莱斯特光辉城堡里的瑞瑟雷克特。
        SetQBit(QBit(627))
        SetAward(Award(19))
        evt.SetNPCGreeting(419, 227) -- 瑞瑟雷克特 greeting 227
        evt.ForPlayer(Players.Current)
        SubtractValue(ReputationInCurrentLocation, 5)
    elseif HasItem(1479) then
        evt.SetMessage("你们干得真不错，把暗黑神庙里的那块圣坛碎片拿来了，不过你们还要去塞莱斯特的光明神庙拿我们的那块，快去吧。")
    else
        evt.SetMessage("你们还没有把两块圣坛碎片都配齐，不过不要灰心，再想想办法，慢慢来。虽说此次行动越快越好，但操之过急，反而欲速则不达，甚至可能在暗黑神庙丢了性命。你们不但要分别从暗黑神庙和光明神庙收集到两块圣坛碎片，还要平安地返回我这里。")
    end
end)

RegisterGlobalEvent(899, nil, function()
    evt.SetMessage("我们的计划已经快要大功告成了。不过还有个小麻烦，我们必须先铲除克里根族。他们常被人称作魔鬼，野兽，曾经在埃拉西亚猖獗一时。虽然如今他们的势力日渐衰落，已经没有从前猖狂了，但仍对我们构成不小的威胁，谁知道他们哪一天又会东山再起，重新在这个世界作威作福。为了使我们的计划能够成功实施，当务之急就是把这伙魔鬼一网打尽，根除后患。\n虽然你们本领高强，但还不足以单枪匹马挑战整个克里根族。他们的克星是我们的死对头死灵法师，这些蠢货对那些巫师的魔法几乎毫无还手之力，而我们的魔法就不是那么有效了。你们必须潜入他们的老巢干掉克里根族的首领诺菲克斯，这样就可以永绝后患，使克里根人土崩瓦解。还有一个情报也许对你们有用。邪术师曾经从他们那里的火山处挖了条地道，直接通向巨人领地--克里根族的老巢。你们说不定可以从地道进去。")
    SetQBit(QBit(616)) -- 去巨人领地的星座之地杀死诺菲克斯，然后到塞莱斯特的光辉城堡找瑞瑟雷克特。
    evt.SetNPCTopic(419, 1, 900) -- 瑞瑟雷克特 topic 1: 打击恶魔
end)
RegisterCanShowTopic(899, function()
    evt._BeginCanShowTopic(899)
    local visible = true
    if IsQBitSet(QBit(631)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(900, nil, function()
    if not IsQBitSet(QBit(617)) then
        evt.SetMessage("我想这件任务并非十万火急，但你们也不要把时间拖得太长，万一邪术师一时兴起，把地道给封了，那可就大事不妙了。所以希望你们当机立断，果断采取行动，出其不意地把这伙魔鬼连根铲除。记住，邪术师已经从他们的火山处挖了条地道通向克里根族的巢穴，你们可以通过地道发动进攻。")
        return
    end
    evt.ShowMovie("\"mm3 people good\"", true)
    evt.SetMessage("你们真是太伟大了！你们不仅除掉了这帮魔鬼，还救出了相传死去多年的罗兰德国王，真是太出人意料了。你们的功绩将会永垂青史，我真为你们骄傲，为埃拉西亚能拥有你们这样的勇士而庆幸。")
    AddValue(Gold, 50000)
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 500000)
    ClearQBit(QBit(616)) -- 去巨人领地的星座之地杀死诺菲克斯，然后到塞莱斯特的光辉城堡找瑞瑟雷克特。
    SetQBit(QBit(632))
    evt.SetNPCTopic(419, 1, 919) -- 瑞瑟雷克特 topic 1: 最终任务
    SetAward(Award(21))
end)

RegisterGlobalEvent(901, nil, function()
    evt.SetMessage("我们在泰塔利亚的盟友告诉我们最近几个月他们不断有人不是莫名其妙的失踪，就是离奇地死于非命，这其中肯定有什么古怪。我对此事也非常关心，看来大概是吸血鬼在作恶。不过最近我实在太忙，抽不出空亲自调查此事，但为了向盟友有个交代，只能麻烦你们代劳了。你们一定要仔细调查，我想这次吸血鬼肆虐，并不会象表面那么简单，说不定背后还有什么大阴谋。")
    SetQBit(QBit(618)) -- 去泰塔利亚探索酒窖，然后到塞莱斯特的光辉城堡找克拉格・汉克。
    evt.SetNPCTopic(420, 0, 902) -- 克拉格・汉克 topic 0: 吸血鬼
end)
RegisterCanShowTopic(901, function()
    evt._BeginCanShowTopic(901)
    local visible = true
    if IsQBitSet(QBit(626)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(902, nil, function()
    if not IsQBitSet(QBit(619)) then
        evt.SetMessage("你们应该加紧寻找吸血鬼，我想它肯定在泰塔利亚附近游荡。")
        return
    end
    evt.SetMessage("啊，你们干得真不错，调查的结果正如我所料。既然吸血鬼已经除掉了，泰塔利亚也该太平两天了。凯瑟琳王后也为此事向你们深表谢意，并且已经亲自去布拉卡达进一步加强与他们之间的团结合作。")
    AddValue(Gold, 20000)
    AddValue(History(13), 0)
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 50000)
    SetAward(Award(22))
    evt.SetNPCTopic(420, 0, 0) -- 克拉格・汉克 topic 0 cleared
    evt.SetNPCGreeting(420, 230) -- 克拉格・汉克 greeting 230
    ClearQBit(QBit(618)) -- 去泰塔利亚探索酒窖，然后到塞莱斯特的光辉城堡找克拉格・汉克。
    SetQBit(QBit(628))
end)

RegisterGlobalEvent(903, nil, function()
    evt.SetMessage("死灵法师都是把他们的灵魂放在灵魂之坛里才能够延续他们邪恶的生命，他们把灵魂之坛藏在他们的行会城堡里。你们的任务就是趁他们毫无防备之际以迅雷不及掩耳的速度一举把灵魂之坛夺过来。记住千万不要在城堡里滞留太久，不然他们的援兵就会赶到，那时候你们就麻烦了。这次行动必须一击成功，全身而退。如果不成功的话，他们必然会加强守卫，到那时候就难以下手了。如果你们拿到灵魂之坛，必须立刻赶来见我，我们会处理这些东西的。")
    SetQBit(QBit(620)) -- 去地狱城的黄昏城堡抢夺灵魂之坛，并把它们交给塞莱斯特的范・卡格汉。
    evt.SetNPCTopic(421, 0, 904) -- 卡格汉爵士 topic 0: 灵魂之坛
end)
RegisterCanShowTopic(903, function()
    evt._BeginCanShowTopic(903)
    local visible = true
    if IsQBitSet(QBit(626)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(904, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1404) then
        evt.SetMessage("在采取行动以前你们必须考虑周全，务必一次成功，不然下次再去，他们的守卫就不会那么松懈了。")
        return
    end
    evt.SetMessage("（卡格汉好奇地看着灵魂之坛，好象隔着玻璃看一条毒蛇）这就是灵魂之坛吗？我还以为是什么神奇的东西，原来就是几个破坛子。你们这次行动非常出色，我要让这些坛子永远消失。")
    RemoveItem(1404)
    ClearQBit(QBit(743))
    AddValue(History(11), 0)
    AddValue(Experience, 50000)
    ClearQBit(QBit(620)) -- 去地狱城的黄昏城堡抢夺灵魂之坛，并把它们交给塞莱斯特的范・卡格汉。
    SetQBit(QBit(629))
    evt.SetNPCTopic(421, 0, 0) -- 卡格汉爵士 topic 0 cleared
    evt.SetNPCGreeting(421, 233) -- 卡格汉爵士 greeting 233
    SetAward(Award(24))
    evt.ForPlayer(Players.Current)
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.SetNPCGreeting(427, 251) -- 阿基巴德・艾恩法斯特 greeting 251
    evt.MoveNPC(427, 0) -- 阿基巴德・艾恩法斯特 -> removed
    evt.SetNPCTopic(427, 1, 0) -- 阿基巴德・艾恩法斯特 topic 1 cleared
end)

RegisterGlobalEvent(905, nil, function()
    evt.SetMessage("我们的死对头是阿基巴德手下那些死灵法师。他们每个人身上都有一块控制晶片，只有拿到这个东西我们的计划才能成功。看来他们谁都不会心甘情愿地把控制晶片交出来，我们只好另想办法了。你们的任务就是想办法从他们之中的一个人身上拿到控制晶片，我们已经探听清楚了，最容易下手的是一个叫托尔伯蒂的，他不象其他人护卫众多，防守森严，而是孤身一人住在地狱城的别墅里。你们要想方设法潜入地狱城，从他身上得到控制晶片。和他交手你们得千万小心，不要被他的柔弱的外表所迷惑，他可是个很不容易对付的对手。如果你们拿到控制晶片，马上回来交给我，这样我们的计划就快大功告成了，到时候会向你们透露真相的。")
    SetQBit(QBit(621)) -- 去地狱城杀死托尔伯蒂，把他身上的控制晶片交给塞莱斯特的智者罗伯特。
    evt.SetNPCTopic(422, 0, 906) -- 智者罗伯特 topic 0: 托尔伯蒂
end)
RegisterCanShowTopic(905, function()
    evt._BeginCanShowTopic(905)
    local visible = true
    if IsQBitSet(QBit(626)) then
        if IsQBitSet(QBit(627)) then
            if IsQBitSet(QBit(628)) then
                if IsQBitSet(QBit(629)) then
                    visible = true
                    return visible
                else
                    visible = false
                    return visible
                end
            else
                visible = false
                return visible
            end
        else
            visible = false
            return visible
        end
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(906, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1477) then
        evt.SetMessage("你们要加紧寻找托尔伯蒂。他曾经扬言没有人能够伤他半根毫毛，我们现在就想给他点利害瞧瞧。你们要想办法把控制晶片夺过来，能够不伤他性命那最好不过，不然的话就索性把他干掉，快去吧。")
        return
    end
    evt.SetMessage("（罗伯特拿着控制晶片）你们又成功了！我们就快大功告成了。我知道你们有许多问题想问个明白，快去瑞瑟雷克特那里吧，只要再为她完成一个任务，她就会把我们的计划和盘托出的。她现在正和格文・马格努斯在光辉城堡的宫殿里呢！")
    RemoveItem(1477)
    AddValue(History(22), 0)
    AddValue(Experience, 250000)
    ClearQBit(QBit(621)) -- 去地狱城杀死托尔伯蒂，把他身上的控制晶片交给塞莱斯特的智者罗伯特。
    SetQBit(QBit(631))
    SetAward(Award(25))
    evt.SetNPCTopic(419, 3, 973) -- 瑞瑟雷克特 topic 3: 榴弹枪宗师
    evt.SetNPCTopic(420, 1, 972) -- 克拉格・汉克 topic 1: 榴弹枪大师
    evt.SetNPCTopic(421, 1, 971) -- 卡格汉爵士 topic 1: 榴弹枪专家
    evt.SetNPCGreeting(422, 0) -- 智者罗伯特 greeting cleared
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.MoveNPC(419, 220) -- 瑞瑟雷克特 -> 加冕殿
    evt.SetNPCTopic(422, 0, 950) -- 智者罗伯特 topic 0: 榴弹枪
end)

RegisterGlobalEvent(907, nil, function()
    evt.SetMessage("我们需要你们的帮助。你们要到光明神庙去一趟。那里是我们的死对头光明法师供奉圣坛碎片的地方。你们要想方设法把那块圣坛碎片拿来。这个任务真是太简单了，这帮家伙只知道救死扶伤，治病救人，根本不会花时间去修炼致人死命的魔法，你们去拿圣坛碎片可谓轻而易举。如果准备好了，就赶快出发吧。\n\n你们还要把另一块圣坛碎片也拿来给我，它就供奉在我们的暗黑神庙里。你们是我们的朋友，神庙里的人不会找你们麻烦的，不过你们要是觉得自己功力不够，想增加点经验值的话不妨拿神庙里的人开刀，他们都是些无足轻重的小人物，而且很多人具有自我恢复的能力，所以你们尽管痛下杀手，不必留情。杀人可是件很爽的事哦！")
    SetQBit(QBit(634)) -- 分别去塞莱斯特的光明神庙和地狱城的暗黑神庙收集到圣坛碎片，把它们交给地狱城里的卡斯托。
    evt.SetNPCTopic(423, 0, 908) -- 卡斯托 topic 0: 光明神庙
end)
RegisterCanShowTopic(907, function()
    evt._BeginCanShowTopic(907)
    local visible = true
    if IsQBitSet(QBit(622)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(908, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(1478) then
        if not HasItem(1479) then
            evt.SetMessage("嗯，你们去了那么长时间，我还以为你们在光明神庙完蛋了呢！现在你们拿到他们的那块圣坛碎片了，可我们那一块还没拿到。快去暗黑神庙吧，把两块碎片配齐了送到我这儿来，我会使它们完好如初的。")
            return
        end
        evt.SetMessage("好极了！（卡斯托把两块圣坛碎片拼在一起，施展魔法，只见一道白光闪过，它们变得严丝合缝）好了，我们计划的第一步算是完成了，阿基巴德真是没有看错人啊！")
        RemoveItem(1478)
        RemoveItem(1479)
        ClearQBit(QBit(744))
        ClearQBit(QBit(745))
        AddValue(History(20), 0)
        AddValue(Experience, 50000)
        evt.SetNPCTopic(423, 0, 0) -- 卡斯托 topic 0 cleared
        ClearQBit(QBit(634)) -- 分别去塞莱斯特的光明神庙和地狱城的暗黑神庙收集到圣坛碎片，把它们交给地狱城里的卡斯托。
        SetQBit(QBit(623))
        SetAward(Award(19))
        evt.SetNPCGreeting(423, 227) -- 卡斯托 greeting 227
    elseif HasItem(1479) then
        evt.SetMessage("不错，你们拿到我们的那块圣坛碎片了，可光明神庙里的那一块还没到手。你们把两块圣坛碎片都拿到再来找我吧，我会把它们拼好的。")
    else
        evt.SetMessage("还没有拿到那两块圣坛碎片？想不到你们竟然这样没用。其实太简单了，你们只要径直闯进去，把魔法乱放一气，还没死的补他两家伙，不就完了。快去放手干吧，我可等得不耐烦了。")
    end
end)

RegisterGlobalEvent(909, nil, function()
    evt.SetMessage("我们的计划就快大功告成了，不过还有点小麻烦。你们知道克里根族吗，就是那些常被人称作魔鬼，野兽的那些家伙。他们和我们约好要瓜分这个王国。他们之所以这样做，是因为如今他们势单力薄，已经掀不起什么风浪了。如果有朝一日他们东山再起，会六亲不认地铲除任何反对势力，真要到那个时候，这个王国尽是死人，我们还找谁发号施令，说不定还自身难保呢。所以我们必须先下手为强，趁早除掉这些碍手碍脚家伙。你们的任务就是潜入他们的老巢，干掉他们的头领诺菲克斯。尼根的邪术师曾经挖了条地道从火山直接通向他们盘踞的巨人领地的老巢，你们可以从这条地道进去发动进攻。")
    SetQBit(QBit(635)) -- 去巨人领地的星座之地杀死诺菲克斯，然后到地狱城找卡斯托。
    evt.SetNPCTopic(423, 1, 910) -- 卡斯托 topic 1: 打击恶魔
end)
RegisterCanShowTopic(909, function()
    evt._BeginCanShowTopic(909)
    local visible = true
    if IsQBitSet(QBit(630)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(910, nil, function()
    if not IsQBitSet(QBit(617)) then
        evt.SetMessage("你们动作能不能快点，把这伙恶魔干掉就完事了。阿基巴德是答应会派援军的，可是时间来不及了。要知道，这帮家伙生孩子的本事比老鼠还大，你们越是这样等下去，他们的人数就越多，到时候有你们忙的，还不快点去。")
        return
    end
    evt.ShowMovie("\"mm3 people evil\"", true)
    evt.SetMessage("你们真是太棒了，现在我们夺取世界的计划的最大障碍已经被扫除了，我们就是天下的主宰了！（卡斯托背着手哈哈大笑）啊哈哈哈哈哈！干得太出色了。至于你们把罗兰德国王放走这件事我们也不再追究了，要知道，我们本来可以把他作为讨价还价的重要筹码。（他耸了耸肩）大概你们当时别无选择吧，不过不论怎样，今天真让我高兴。")
    AddValue(Gold, 50000)
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 500000)
    ClearQBit(QBit(635)) -- 去巨人领地的星座之地杀死诺菲克斯，然后到地狱城找卡斯托。
    SetQBit(QBit(632))
    evt.SetNPCTopic(423, 1, 921) -- 卡斯托 topic 1: 最终任务
    SetAward(Award(21))
end)

RegisterGlobalEvent(911, nil, function()
    evt.SetMessage("阿基巴德要我们去为死灵法师找一个能弄到灵魂之坛的地方。死灵法师就靠这些坛子来放自己的灵魂，进行永生仪式，只有这样他们才能得到永生，可是最近我们这些坛子都快用完了。如今要成为死灵法师的人越来越多，我们要是再搞不到灵魂之坛，恐怕有些人真的要寿终正寝了。天下只有邪术师会制作灵魂之坛，你们的任务就是去和他们商量商量，问他们要些灵魂之坛。要是他们不肯，那你们只有动武硬抢了，你们不必害怕，一切麻烦有我来应付。")
    SetQBit(QBit(636)) -- 去桑达非斯山从邪术师那里抢夺灵魂之坛，然后把它们交给地狱城的马克西姆。
    evt.SetNPCTopic(424, 0, 912) -- 马克西姆 topic 0: 灵魂之坛
end)
RegisterCanShowTopic(911, function()
    evt._BeginCanShowTopic(911)
    local visible = true
    if IsQBitSet(QBit(622)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(912, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1404) then
        evt.SetMessage("你们去拿灵魂之坛可别不好意思，只要能达到目的，可以不择一切手段，甚至不惜和他们撕破脸。既然我们可以为了价钱和他们谈判，自然也可以为了和平和他们讨价还价，没什么大不了的，最多死几个人罢了。")
        return
    end
    evt.SetMessage("（马克西姆惊喜地看着灵魂之坛）你们干得太棒了。真不知道你们怎么把它们搞到手的，真是了不起。")
    RemoveItem(1404)
    ClearQBit(QBit(743))
    AddValue(History(18), 0)
    AddValue(Experience, 50000)
    ClearQBit(QBit(636)) -- 去桑达非斯山从邪术师那里抢夺灵魂之坛，然后把它们交给地狱城的马克西姆。
    SetQBit(QBit(624))
    SetAward(Award(24))
    evt.SetNPCTopic(424, 0, 0) -- 马克西姆 topic 0 cleared
    evt.SetNPCGreeting(424, 242) -- 马克西姆 greeting 242
    evt.ForPlayer(Players.Current)
    SubtractValue(ReputationInCurrentLocation, 5)
end)

RegisterGlobalEvent(913, nil, function()
    evt.SetMessage("阿基巴德有新的任务交给你们。要你们铲除科兰克实验室里盘踞的怪兽，并摧毁那里的远距离传输防护盾。这个实验室就在图拉利昂森林的匹尔邦特东面一个小岛上。你们可要小心那些怪兽，它们可是科兰克亲手制造的，虽然有的外形和普通的野兽差不多，可是却具有超强的力量。实验室里的东西你们喜欢的可以随便拿，阿基巴德只对那个实验室感兴趣。一旦防护盾被摧毁，他就可以施展时空之门魔法把死灵法师和仪器设备都运到实验室去了。")
    SetQBit(QBit(637)) -- 破坏科兰克实验室里的魔法防御系统，然后到地狱城找达克・谢德。
    evt.SetNPCTopic(425, 0, 914) -- 达克・谢德 topic 0: 科兰克的实验室
end)
RegisterCanShowTopic(913, function()
    evt._BeginCanShowTopic(913)
    local visible = true
    if IsQBitSet(QBit(622)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(914, nil, function()
    if not IsQBitSet(QBit(638)) then
        evt.SetMessage("交给你们这么简单的任务，还不快去。我再说一遍，听仔细了。实验室在图拉利昂森林的匹尔邦特东面一个小岛上，你们要进去把远距离防护盾摧毁，把怪兽都干掉。听懂了吗！快滚吧。")
        return
    end
    evt.SetMessage("能看到你们平安回来真让人高兴。说实话，我们还从来没看到过象你们这样又能干又守信的盟友，非常感谢你们的帮助。")
    AddValue(History(21), 0)
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 50000)
    ClearQBit(QBit(637)) -- 破坏科兰克实验室里的魔法防御系统，然后到地狱城找达克・谢德。
    SetQBit(QBit(625))
    evt.SetNPCTopic(425, 0, 0) -- 达克・谢德 topic 0 cleared
    evt.SetNPCGreeting(425, 245) -- 达克・谢德 greeting 245
    SetAward(Award(26))
end)

RegisterGlobalEvent(915, nil, function()
    evt.SetMessage("和阿基巴德一样，马格努斯国王手下大臣也都有表明身份的控制晶片，我们必须把这玩意儿搞到手。目标已经选好了，是个叫智者罗伯特的倒霉鬼。我的手下已经有人潜入他的住宅，把他住的屋子的锁弄坏了，他们竟然懒得把锁修好，这真是天赐良机。你们的任务就是潜入城堡拿到控制晶片，把它带给我们，杀不杀他随你们的便。")
    SetQBit(QBit(639)) -- 去塞莱斯特杀死智者罗伯特，然后到地狱城找托尔伯蒂。
    evt.SetNPCTopic(426, 0, 916) -- 托尔伯蒂 topic 0: 智者罗伯特
end)
RegisterCanShowTopic(915, function()
    evt._BeginCanShowTopic(915)
    local visible = true
    if IsQBitSet(QBit(622)) then
        if IsQBitSet(QBit(623)) then
            if IsQBitSet(QBit(624)) then
                if IsQBitSet(QBit(625)) then
                    visible = true
                    return visible
                else
                    visible = false
                    return visible
                end
            else
                visible = false
                return visible
            end
        else
            visible = false
            return visible
        end
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(916, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1477) then
        evt.SetMessage("怎么了，不要告诉我你们准备放弃了。不错，他是挺利害的，可也不是什么顶尖高手，以你们目前的功力，完全可以把他收拾了。这么一个简单的任务，是我特意留给你们让你们立功的，想不到你们这么没出息。")
        return
    end
    evt.SetMessage("（托尔伯蒂拿着控制晶片）这下我们的计划马上要大功告成了。我知道你们很想知道全部计划的真相，卡斯托还没有交代清楚吧。不过我也不能说得太多，天机不可泄露。反正我可以告诉你们，一旦我们成功了，你们的职位就不仅仅是个哈蒙代尔城堡的小领主了，等着瞧吧，好戏还在后头呢！要找卡斯托，你们可以去黄昏城堡的宫殿看看。")
    RemoveItem(1477)
    AddValue(History(23), 0)
    AddValue(Experience, 250000)
    ClearQBit(QBit(639)) -- 去塞莱斯特杀死智者罗伯特，然后到地狱城找托尔伯蒂。
    SetQBit(QBit(630))
    SetAward(Award(27))
    evt.SetNPCTopic(423, 3, 973) -- 卡斯托 topic 3: 榴弹枪宗师
    evt.SetNPCTopic(424, 1, 972) -- 马克西姆 topic 1: 榴弹枪大师
    evt.SetNPCTopic(425, 1, 971) -- 达克・谢德 topic 1: 榴弹枪专家
    evt.SetNPCGreeting(426, 0) -- 托尔伯蒂 greeting cleared
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.SetNPCTopic(426, 0, 950) -- 托尔伯蒂 topic 0: 榴弹枪
end)

RegisterGlobalEvent(917, nil, function()
    evt.SetMessage("这个考验很简单。地狱城附近有个叫再生之地的地方，那里面净是些怪兽，而且现在越来越多，能把它们捉来做奴隶倒是再合适不过了。你们要做的就是进入那个地方，杀开一条血路，从另一头的出口出来就行了。这些怪兽都是些凶残狡猾的家伙，你们可千万不要对它们手下留情。如果你们能活着回来，我就接纳你们为暗黑魔法行会的成员。")
    SetQBit(QBit(640)) -- 顺利穿过再生之地，回地狱城找阿基巴德。
    ClearQBit(QBit(663)) -- 从迪雅的地狱城大厅进入地狱城，到那里的黄昏城堡和阿基巴德交谈。
    evt.SetNPCTopic(427, 0, 918) -- 阿基巴德・艾恩法斯特 topic 0: 再生之地
end)
RegisterCanShowTopic(917, function()
    evt._BeginCanShowTopic(917)
    local visible = true
    if IsQBitSet(QBit(611)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(918, nil, function()
    if not IsQBitSet(QBit(641)) then
        evt.SetMessage("我真怀疑你们有没有资格成为我们的盟友，连这么简单的考验都通不过，以后碰到大风大浪怎么办！你们到底是胆子太小，还是本领太差了，我真搞不懂，看来我应该另选盟友了。")
        return
    end
    evt.SetMessage("你们干得真不错，现在我的手下可以心服口服了，他们还会争先恐后地向你们分派任务呢！他们就住在地狱城西面的四间屋子里。快去吧，要知道，他们给的报酬可是很丰厚的。")
    AddValue(History(17), 0)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 50000)
    SetAward(Award(28))
    ClearQBit(QBit(640)) -- 顺利穿过再生之地，回地狱城找阿基巴德。
    SetQBit(QBit(622))
    evt.SetNPCTopic(427, 0, 0) -- 阿基巴德・艾恩法斯特 topic 0 cleared
    evt.SetNPCGreeting(427, 252) -- 阿基巴德・艾恩法斯特 greeting 252
    evt.MoveNPC(423, 1079) -- 卡斯托 -> 客栈
    evt.MoveNPC(424, 1071) -- 马克西姆 -> 客栈
    evt.MoveNPC(425, 1078) -- 达克・谢德 -> 客栈
    evt.MoveNPC(426, 1070) -- 托尔伯蒂 -> 客栈
    evt.SetNPCGreeting(423, 238) -- 卡斯托 greeting 238
    evt.SetNPCGreeting(424, 241) -- 马克西姆 greeting 241
    evt.SetNPCGreeting(425, 244) -- 达克・谢德 greeting 244
    evt.SetNPCGreeting(426, 247) -- 托尔伯蒂 greeting 247
    SetQBit(QBit(1606))
end)

RegisterGlobalEvent(919, nil, function()
    evt.SetMessage("看来真相大白的时候到了。老实告诉你们吧，我们要你们完成这些任务，就是为了收集物品，能够打开时空之门，去寻找我们的祖先创造的伟大文明。不幸的是，我们族人中有些败类也想到了这个主意。他们是想回到寂静时代以前，重建天堂铸造厂，打造上古神器，运到现在这个世界来靠它们征服全世界。为了能抢先打开时空之门，我们展开激烈的竞争，幸好最终还是我们先得手了。\n不过我们还少了振荡器这一样东西，如果找不到它，我们会前功尽弃。我知道有一艘叫林肯号的船上就有一个振荡器，我们就是乘这艘船才来到你们这片大陆的。这艘船在埃里西面的海里。你们只有穿上我们的潜水服才能上船，这些衣服就在宫殿外面的箱子里。还有一件事，你们只有卸下身上所有的装备潜水服才会起作用。快去船上把振荡器拿回来吧，我们现在就守在门口等着收拾那些败类。")
    SetQBit(QBit(642)) -- 去埃里西面的海里进入林肯号，找到船上的振荡器，把它交给塞莱斯特的瑞瑟雷克特。
    evt.SetNPCTopic(419, 1, 920) -- 瑞瑟雷克特 topic 1: 最终任务
end)

RegisterGlobalEvent(920, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(783)) then
        evt.SetMessage("啊，你们这么快就回来了。噢，这就是振荡器。快，和我们一起打开通往古代文明之路吧。")
        return
    elseif HasItem(1407) then
        SetQBit(QBit(783))
        RemoveItem(1407)
        ClearQBit(QBit(747))
        ClearQBit(QBit(748))
        evt.SetNPCTopic(419, 1, 0) -- 瑞瑟雷克特 topic 1 cleared
        evt.ShowMovie("\"Endgame 1 Good\"", true)
        evt.SetNPCGroupNews(61, 84)
        evt.SetNPCGroupNews(62, 84)
        evt.SetNPCGroupNews(63, 84)
        evt.SetNPCGroupNews(64, 84)
        evt.SetNPCGroupNews(65, 84)
        evt.SetNPCGroupNews(66, 84)
        evt.SetNPCGroupNews(67, 84)
        evt.SetNPCGroupNews(68, 84)
        evt.SetNPCGroupNews(69, 86)
        evt.SetNPCGroupNews(70, 86)
        evt.SetNPCGroupNews(71, 86)
        evt.SetNPCGroupNews(72, 86)
        evt.SetNPCGroupNews(73, 86)
        evt.SetNPCGroupNews(74, 84)
        evt.SetNPCGroupNews(75, 84)
        evt.SetNPCGroupNews(76, 84)
        evt.SetNPCGroupNews(77, 84)
        evt.SetNPCGroupNews(78, 84)
        evt.SetNPCGroupNews(79, 84)
        evt.SetNPCGroupNews(80, 84)
        evt.SetNPCGroupNews(81, 84)
        evt.SetNPCGroupNews(82, 84)
        evt.SetNPCGroupNews(83, 84)
    else
        evt.SetMessage("别忘了你们要上林肯号，就必须得穿我们的潜水服。它们就在宫殿外面的箱子里，林肯号在埃里西面的大海里，快去吧，记住把振荡器拿回来。")
    end
end)

RegisterGlobalEvent(921, nil, function()
    evt.SetMessage("看来我们就快大功告成了。就在你们四处奔波，费尽心机地完成我们交给你们的任务的时候，我们为了争夺能重建传说中的天堂铸造厂的宝物，和我们以前的盟友反目成仇，展开了一场激战。我们的对手就是马格努斯国王手下的四个光明法师。他们想得到宝物是为了重建通往古代伟大文明的时空之门。本来我们双方可以互相合作，各取所需，可是他们却妄想建立一个和平安详的世界，说什么上古神器不能用来发动邪恶的战争，简直胡说八道，对这种人就得好好教训教训他们。可你们就不同了，你们会永远站在我们这一边，成为我们永远的朋友。\n\n不过我们还少了振荡器这一样东西，如果找不到它，我们可会前功尽弃。我知道有一艘叫林肯号的船上就有一个振荡器，我们就是乘这艘船才来到你们这片大陆的。这艘船就在埃里西面的海里，你们只有穿上我们的潜水服才能上船，这些衣服就在宫殿外面的箱子里。还有一件事，你们只有卸下身上所有的装备潜水服才会起作用。快去船上把振荡器拿回来吧，我们统治全世界的日子就要到了。")
    AddValue(History(27), 0)
    SetQBit(QBit(643)) -- 去埃里西面的海里进入林肯号，找到船上的振荡器，把它交给地狱城的卡斯托。
    evt.SetNPCTopic(423, 1, 922) -- 卡斯托 topic 1: 最终任务
end)

RegisterGlobalEvent(922, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1407) then
        evt.SetMessage("记住，你们要上林肯号，就得穿上潜水服，它就在宫殿外面的箱子里。林肯号在埃里西面的大海里，快去吧，别浪费时间。")
        return
    end
    RemoveItem(1407)
    ClearQBit(QBit(643)) -- 去埃里西面的海里进入林肯号，找到船上的振荡器，把它交给地狱城的卡斯托。
    ClearQBit(QBit(748))
    evt.SetNPCTopic(423, 1, 0) -- 卡斯托 topic 1 cleared
    SetQBit(QBit(783))
    evt.ShowMovie("\"Endgame 2 Evil\"", true)
    evt.SetNPCGroupNews(61, 85)
    evt.SetNPCGroupNews(62, 85)
    evt.SetNPCGroupNews(63, 85)
    evt.SetNPCGroupNews(64, 85)
    evt.SetNPCGroupNews(65, 85)
    evt.SetNPCGroupNews(66, 85)
    evt.SetNPCGroupNews(67, 87)
    evt.SetNPCGroupNews(68, 87)
    evt.SetNPCGroupNews(69, 85)
    evt.SetNPCGroupNews(70, 85)
    evt.SetNPCGroupNews(71, 85)
    evt.SetNPCGroupNews(72, 85)
    evt.SetNPCGroupNews(73, 85)
    evt.SetNPCGroupNews(74, 87)
    evt.SetNPCGroupNews(75, 87)
    evt.SetNPCGroupNews(76, 87)
    evt.SetNPCGroupNews(77, 85)
    evt.SetNPCGroupNews(78, 85)
    evt.SetNPCGroupNews(79, 85)
    evt.SetNPCGroupNews(80, 85)
    evt.SetNPCGroupNews(81, 85)
    evt.SetNPCGroupNews(82, 85)
    evt.SetNPCGroupNews(83, 85)
end)

RegisterGlobalEvent(923, nil, function()
    evt.MoveToMap(-6784, -2832, 1649, 512, 0, 0, 0, 0, "t01.blv") -- 光明神庙
end)

RegisterGlobalEvent(924, nil, function()
    evt.MoveToMap(0, -4059, 513, 512, 0, 0, 0, 0, "t02.blv") -- 暗黑神庙
end)

RegisterGlobalEvent(925, nil, function()
    evt.SetMessage("托马斯・格雷是魔法学院的长老。你们要是想升职为法师或荣誉法师，可以去找他。他就住在我的屋子后面。")
end)

RegisterGlobalEvent(926, nil, function()
    evt.SetMessage("加入我们的魔法学院吧，这样你们就可以随心所欲地学习每个魔法商店里的魔法了。你们只要付5000个金币就可以成为我们学院的成员，有效期为六个月。记住，我们魔法商店里的魔法每个星期会更换一次。")
    evt.SetNPCTopic(620, 1, 927) -- 埃利克・斯维罗 topic 1: 书店
end)
RegisterCanShowTopic(926, function()
    evt._BeginCanShowTopic(926)
    local visible = true
    if IsQBitSet(QBit(657)) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(927, nil, function()
    if not IsAtLeast(Gold, 5000) then
        evt.SetMessage("你们的金币不够――要想糊弄我们法师是没用的。")
        return
    end
    evt.SetMessage("好了，你们现在是我们魔法学院的成员了，记住有效期为六个月。快去前面的魔法商店看看有什么你们感兴趣的魔法吧。")
    SetQBit(QBit(657))
    if not IsAtLeast(Gold, 5000) then
        return
    end
    SubtractValue(Gold, 5000)
    evt.SetNPCTopic(620, 1, 0) -- 埃利克・斯维罗 topic 1 cleared
end)

RegisterGlobalEvent(928, nil, function()
    evt.SetMessage("你们要把佐卡尔的尸骨安葬到他的坟墓中吗？你们真是艺高人胆大，佐卡尔国王终于可以安息了。他的那个坟墓挺难找的，你们要仔细点，只有一个出口的就是他的坟墓。里面有口空棺，你们可要小心地安葬他啊！")
    AddValue(InventoryItem(1428), 1428)
    SetQBit(QBit(740))
    evt.SetNPCTopic(398, 1, 0) -- 贺斯法九世 topic 1 cleared
end)
RegisterCanShowTopic(928, function()
    evt._BeginCanShowTopic(928)
    local visible = true
    if IsQBitSet(QBit(566)) then -- 去石头城与尼根之间的隧道里找到矮人国王的尸骨，把它带到拜尔德斯妥善安葬，然后到图拉利昂森林找安东尼・格林。
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(929, nil, function()
    evt.SetMessage("我们现在只有靠你们找回神灯了，哈蒙代尔的新主人们。埃拉西亚神庙里的光明神灯是举世罕见的珍宝。其实它并没有什么魔力，但具有鼓舞人心的作用。没有它，埃拉西亚的僧侣们就会人心惶惶，无心修炼。神灯是在石头城运往这里的路上丢失的，我想它肯定在拜尔德斯那个迷宫般蜿蜒曲折的坟墓里，拜托你们把它取回来，多谢了。")
    evt.SetNPCTopic(432, 0, 930) -- 忒林维泽 topic 0: 任务
    SetQBit(QBit(667)) -- 从拜尔德斯找回光明神灯，把它交给哈蒙代尔的忒林维泽。
end)

RegisterGlobalEvent(930, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1450) then
        evt.SetMessage("还没有找到光明神灯吗？它肯定在拜尔德斯的墓地里。")
        return
    end
    evt.SetMessage("太感谢你们了，哈蒙代尔的主人们。神灯回到我们的手中，这下大家又可以专心修炼了。这些酬金是你们应该得的，请拿去吧。")
    RemoveItem(1450)
    SetAward(Award(30))
    AddValue(Experience, 5000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 1000)
    ClearQBit(QBit(667)) -- 从拜尔德斯找回光明神灯，把它交给哈蒙代尔的忒林维泽。
    evt.SetNPCTopic(432, 0, 0) -- 忒林维泽 topic 0 cleared
    evt.SetNPCGreeting(432, 267) -- 忒林维泽 greeting 267
    SubtractValue(ReputationInCurrentLocation, 5)
end)

RegisterGlobalEvent(931, nil, function()
    evt.SetMessage("我的弟弟哈尔代尔上个月去世了，本来尸体打算运到我这里妥善安葬，但在路上突发意外，在尼根他的遗体莫名其妙地不见了，从此再无消息。要是找不到遗体的话，只怕我弟弟在天堂永远不会瞑目的。麻烦你们走一趟探听一下我弟弟的尸体的下落。如果找到的话我必有重金酬谢。")
    evt.SetNPCTopic(433, 0, 932) -- 马吉姆・达斯克 topic 0: 任务
    SetQBit(QBit(668)) -- 去尼根从迷宫里找到哈尔代尔的尸骨，把它交给尼根的马吉姆・达斯克。
end)

RegisterGlobalEvent(932, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1430) then
        evt.SetMessage("你们找到哈尔代尔的尸体了吗？没有尸体他的灵魂就成了无主的孤魂，那该多痛苦啊！麻烦你们再加把劲，把他的遗体找回来吧。")
        return
    end
    evt.SetMessage("谢谢你们把我兄弟的遗体带回来。他曾经是个有前途的邪术师，却早早地结束了生命。现在我已经有了他的尸体，我会试着把他变为巫妖，这样我们又可以一起去寻求力量和荣耀了。")
    RemoveItem(1430)
    SetAward(Award(32))
    AddValue(Experience, 50000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 35000)
    ClearQBit(QBit(668)) -- 去尼根从迷宫里找到哈尔代尔的尸骨，把它交给尼根的马吉姆・达斯克。
    evt.SetNPCTopic(433, 0, 0) -- 马吉姆・达斯克 topic 0 cleared
    evt.SetNPCGreeting(433, 269) -- 马吉姆・达斯克 greeting 269
    SubtractValue(ReputationInCurrentLocation, 5)
end)

RegisterGlobalEvent(933, nil, function()
    evt.SetMessage("主人啊，我实在太不幸了。我从埃里回来的路上遇到一伙强盗，他们把我的财宝一抢而光，最要命的是他们抢走了我的戒指印章。没有这个东西我没法签合同，连生意都不能做了。听说这伙歹徒就盘踞在埃拉西亚东北面的巢穴里，我真想亲自找上门去教训他们，可惜我只是个手无缚鸡之力的商人。我只能请求你们去除强扶弱，为我伸张正义，事成之后我一定会重重酬谢你们的。")
    evt.SetNPCTopic(434, 0, 934) -- 德弗里克・派尔丁 topic 0: 任务
    SetQBit(QBit(669)) -- 去埃拉西亚东北面的强盗洞穴夺回德弗里克・派尔丁的戒指印章，并到哈蒙代尔把戒指还给他。
end)

RegisterGlobalEvent(934, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1408) then
        evt.SetMessage("你们还没有拿到戒指。这伙强盗就在埃拉西亚格芬哈特城堡的南面。快去吧，你们可是我唯一的指望啊！")
        return
    end
    evt.SetMessage("哦，这就是我的戒指。真是谢谢你们了，我的主人！现在我又能做生意了，你们真是我们商人的大恩人啊！")
    RemoveItem(1408)
    SetAward(Award(34))
    AddValue(Experience, 5000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 5000)
    ClearQBit(QBit(669)) -- 去埃拉西亚东北面的强盗洞穴夺回德弗里克・派尔丁的戒指印章，并到哈蒙代尔把戒指还给他。
    evt.SetNPCTopic(434, 0, 0) -- 德弗里克・派尔丁 topic 0 cleared
    evt.MoveNPC(434, 0) -- 德弗里克・派尔丁 -> removed
    SubtractValue(ReputationInCurrentLocation, 5)
end)

RegisterGlobalEvent(935, nil, function()
    evt.SetMessage("啊，你们就是哈蒙代尔城堡的新主人！看起来不怎么象。不过象不象不是我说了算的，老百姓自有评判。我是个历史学家，还是个历史文物的收藏爱好者。听说马克汉姆爵士在这方面和我是同道，他有一件非常珍贵的收藏---帕尔森的羽毛笔。那可不是普通的羽毛笔，结束第一次木材战争时签署匹尔邦特和平协议用的就是这支笔。你们既然能成为哈蒙代尔的主人，和马克汉姆爵士的交情肯定不错。麻烦你们把这封信带给他，他现在已经住在泰塔利亚了。如果爵士看了这封信，能把那支羽毛笔托你们交给我，那真是感激不尽，我一定会让您名垂青史。")
    evt.SetNPCTopic(435, 0, 936) -- 诺伯特・西拉丝 topic 0: 西拉丝的信件
    SetQBit(QBit(670)) -- 去泰塔利亚为诺伯特・西拉丝把一封信转交给马克汉姆爵士。
    AddValue(InventoryItem(1416), 1416)
end)

RegisterGlobalEvent(936, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1405) then
        evt.SetMessage("到底是马克汉姆爵士不给我羽毛笔，还是你们根本没有去见过他。记住，他就住在泰塔利亚，你们一定要帮我这个忙啊！")
        return
    end
    evt.SetMessage("对，这就是签署匹尔邦特协议的孔雀羽毛笔。现在我的收藏可谓十全十美了。我会把这件事载入史书，让你们名垂青史。")
    RemoveItem(1405)
    SetAward(Award(38))
    AddValue(Experience, 5000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 2000)
    ClearQBit(QBit(671)) -- 去埃拉西亚把帕尔森的羽毛笔交给诺伯特・西拉丝。
    evt.SetNPCTopic(435, 0, 0) -- 诺伯特・西拉丝 topic 0 cleared
    evt.SetNPCGreeting(435, 273) -- 诺伯特・西拉丝 greeting 273
    SubtractValue(ReputationInCurrentLocation, 5)
end)

RegisterGlobalEvent(937, nil, function()
    evt.ForPlayer(Players.All)
    evt.SetMessage("这是历史学家诺伯特・西拉丝的信，让我好好看看。（马克汉姆爵士很快扫了一下信）嗯，他要签署匹尔邦特协议的那支羽毛笔。既然他有了协议的原件，把羽毛笔给他倒是未尝不可，他在信里还说要用其它文物来交换。好吧，你们就把羽毛笔带给他吧，不过你们得告诉他，我很快要上他那儿去挑几件我中意的文物。")
    RemoveItem(1416)
    evt.ForPlayer(Players.Current)
    AddValue(InventoryItem(1405), 1405)
    ClearQBit(QBit(670)) -- 去泰塔利亚为诺伯特・西拉丝把一封信转交给马克汉姆爵士。
    SetQBit(QBit(671)) -- 去埃拉西亚把帕尔森的羽毛笔交给诺伯特・西拉丝。
    evt.SetNPCTopic(340, 4, 0) -- 马克汉姆爵士 topic 4 cleared
end)
RegisterCanShowTopic(937, function()
    evt._BeginCanShowTopic(937)
    local visible = true
    evt.ForPlayer(Players.All)
    if HasItem(1416) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(938, nil, function()
    evt.SetMessage("原来你们就是哈蒙代尔城堡的新主人，那么这件事就要麻烦你们了。不过此事如果成功，你们自己也大有好处。在埃里北面的小山底下有个地下大厅，那里是仙帝的领地。以前我为他立下一件大功，他欠我一个人情，现在该是他报答我的时候了。可是那里住的神仙很爱作弄人，我可不敢去，不然准得被他们吓得半死。我现在只有拜托你们去把这封信交给仙帝，他会托付你们把一些东西交给我，你们把它们带回来就行了，到时候我会重重谢你们。你们还可以要仙帝帮忙实现你们的心愿，肯定会不虚此行的。")
    SetQBit(QBit(691)) -- 到埃里的一个小山下面的大厅里把一封信交给仙帝。
    AddValue(InventoryItem(1409), 1409)
    evt.SetNPCTopic(436, 0, 940) -- 乔安・卡里德 topic 0: 任务
end)

RegisterGlobalEvent(939, nil, function()
    evt.ForPlayer(Players.All)
    evt.SetMessage("乔安想要神笛？她自己怎么不来？我明白了，这个胆小鬼可不敢上我这儿来。要拿神笛，你们得用你们身上所有的食物来换，这两天我象是患了贪食症，老是吃不够。")
    RemoveItem(1409)
    AddValue(Experience, 2000)
    evt.ForPlayer(Players.Current)
    AddValue(InventoryItem(1435), 1435)
    evt.SetNPCTopic(391, 1, 0) -- 仙帝 topic 1 cleared
    ClearQBit(QBit(691)) -- 到埃里的一个小山下面的大厅里把一封信交给仙帝。
    SetQBit(QBit(692)) -- 去图拉利昂森林把仙笛交给乔安・卡里德。
    SetValue(Food, 0)
end)
RegisterCanShowTopic(939, function()
    evt._BeginCanShowTopic(939)
    local visible = true
    evt.ForPlayer(Players.All)
    if HasItem(1409) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(940, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1435) then
        evt.SetMessage("记住别忘了把信交给仙帝。没有信，他理也不会理你们。")
        return
    end
    evt.SetMessage("好极了，你们把笛子带回来了，这东西对我来说真是太重要了。这些酬金是你们应得的报酬，你们快收下吧！")
    RemoveItem(1435)
    AddValue(Experience, 5000)
    SetAward(Award(39))
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 1000)
    ClearQBit(QBit(692)) -- 去图拉利昂森林把仙笛交给乔安・卡里德。
    evt.SetNPCTopic(436, 0, 0) -- 乔安・卡里德 topic 0 cleared
    evt.SetNPCGreeting(436, 275) -- 乔安・卡里德 greeting 275
    SubtractValue(ReputationInCurrentLocation, 5)
end)

RegisterGlobalEvent(941, nil, function()
    evt.SetMessage("我们有件小事想麻烦你们。三年以前光辉城堡袭击了我们的哨塔，抢走了一块名贵的挂毯。那个地方守卫非常森严，驻扎了大批大耳怪和邪恶剑手，我的手下根本无法靠近那里。看来只有你们能胜任这个任务，想办法潜入城堡，把那块挂毯夺回来。不过记住，你们只有一个月的时间，超过期限他们就会发现你们的哈蒙代尔城堡，并会立即发动，好了，别浪费时间了，快去快回吧。")
    SetQBit(QBit(694)) -- 到你的盟友所在的城堡偷得挂毯，然后到泰塔利亚把它交给雇佣兵行会的尼尔斯・斯坦利。
    SetValue(Counter(5), 0)
    evt.SetNPCTopic(438, 0, 943) -- 尼尔斯・斯坦利 topic 0: 任务
end)
RegisterCanShowTopic(941, function()
    evt._BeginCanShowTopic(941)
    local visible = true
    if IsQBitSet(QBit(695)) then
        visible = false
        return visible
    else
        if IsQBitSet(QBit(611)) then
            visible = true
            return visible
        else
            visible = false
            return visible
        end
    end
end)

RegisterGlobalEvent(942, nil, function()
    evt.SetMessage("我们需要你们帮个小忙。法师们有一块珍贵的挂毯，是从寂静时代流传下来的一件文物。黄昏城堡派人偷走了这块挂毯。那个地方守卫非常森严，驻扎了大批大耳怪和邪恶剑手，我的手下根本无法靠近那里。看来只有你们能胜任这个任务，想办法潜入城堡，把那块挂毯夺回来。不过记住，你们只有一个月的时间，超过期限他们就会发现你们的哈蒙代尔城堡，并会立即发动，好了，别浪费时间了，快去快回吧。")
    SetQBit(QBit(694)) -- 到你的盟友所在的城堡偷得挂毯，然后到泰塔利亚把它交给雇佣兵行会的尼尔斯・斯坦利。
    SetValue(Counter(5), 0)
    evt.SetNPCTopic(438, 1, 943) -- 尼尔斯・斯坦利 topic 1: 任务
end)
RegisterCanShowTopic(942, function()
    evt._BeginCanShowTopic(942)
    local visible = true
    if IsQBitSet(QBit(695)) then
        visible = false
        return visible
    else
        if IsQBitSet(QBit(612)) then
            visible = true
            return visible
        else
            visible = false
            return visible
        end
    end
end)

RegisterGlobalEvent(943, nil, function()
    evt.ForPlayer(Players.All)
    if IsAtLeast(Counter(5), 672) then
        evt.SetMessage("现在一个月的期限已经过了，那帮匪徒终于发现了你们的小城堡，如今他们正在哈蒙代尔大肆抢劫屠杀，看来你们的全部家当都难保了。这次就当作一个教导你如何守时的教训吧。走吧，去享受这愉快的一天去吧。")
        SetQBit(QBit(695))
        return
    elseif HasItem(1422) then
        evt.SetMessage("好极了，看来你们是值得信赖的朋友，下次我们有事一定再会来找你们的。由于你们的努力，哈蒙代尔城堡终于安然无恙了，我想这是对你们的最高奖赏。")
        RemoveItem(1422)
        AddValue(ReputationInCurrentLocation, 5)
        SetQBit(QBit(702))
        ClearQBit(QBit(694)) -- 到你的盟友所在的城堡偷得挂毯，然后到泰塔利亚把它交给雇佣兵行会的尼尔斯・斯坦利。
        evt.SetNPCTopic(438, 0, 0) -- 尼尔斯・斯坦利 topic 0 cleared
        evt.SetNPCTopic(438, 1, 0) -- 尼尔斯・斯坦利 topic 1 cleared
        evt.SetNPCTopic(438, 2, 0) -- 尼尔斯・斯坦利 topic 2 cleared
    else
        evt.SetMessage("你们还没有拿到挂毯，不过没关系，还有的是时间。在你们完成任务以前可别再来找我了。")
        return
    end
end)

RegisterGlobalEvent(944, nil, function()
    evt.SetMessage("几年前我们在石头城地下挖矿的时候发现了一桩大阴谋。尼根的邪术师竟挖掘了海底地道，想通过地道偷袭埃拉西亚的海岸。由于他们大肆挖掘，致使那里的地层下陷，现在石头城和原来的矮人族墓地比起那块地都高出许多了。在我们的采矿区有一条地道可以通往尼根，但现在那里被洞穴人霸占着。如果你们能帮助我们赶走洞穴人，我们就可以继续采矿了。请你们帮帮我们。")
    SetQBit(QBit(698)) -- 把石头城地下的洞穴人消灭光，然后到石头城找斯巴克・伯恩基德。
    evt.SetNPCTopic(439, 0, 945) -- 斯巴克・伯恩基德 topic 0: 任务
end)

RegisterGlobalEvent(945, nil, function()
    if not evt.CheckMonstersKilled(ActorKillCheck.MonsterId, 411, 0, false) then -- monster 411; all matching actors defeated
        evt.SetMessage("洞穴人还在那个低洼的矿区里逍遥自在。快去把他们赶走吧！")
        return
    end
    if not evt.CheckMonstersKilled(ActorKillCheck.MonsterId, 412, 0, false) then -- monster 412; all matching actors defeated
        evt.SetMessage("洞穴人还在那个低洼的矿区里逍遥自在。快去把他们赶走吧！")
        return
    end
    if not evt.CheckMonstersKilled(ActorKillCheck.MonsterId, 413, 0, false) then -- monster 413; all matching actors defeated
        evt.SetMessage("洞穴人还在那个低洼的矿区里逍遥自在。快去把他们赶走吧！")
        return
    end
    evt.SetMessage("他们逃走了，顺着那条地道滚回尼根去了！真是太好了，我们现在可以开工采矿了，真是太谢谢你们了，这是你们应得的报酬，请收下吧。")
    AddValue(Gold, 2500)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 5000)
    ClearQBit(QBit(698)) -- 把石头城地下的洞穴人消灭光，然后到石头城找斯巴克・伯恩基德。
    SetAward(Award(40))
    evt.SetNPCTopic(439, 0, 0) -- 斯巴克・伯恩基德 topic 0 cleared
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.SetNPCGreeting(439, 279) -- 斯巴克・伯恩基德 greeting 279
end)

RegisterGlobalEvent(946, nil, function()
    evt.SetMessage("我已经得到确切情报，埃拉西亚的凯瑟琳王后正调兵遣将想要进攻迪雅。但由于迪雅地势险要，他们正积极训练狮鹫以在战斗中助他们一臂之力。狮鹫只生活在埃拉西亚和布拉卡达的沙漠里。我需要你们去那两个地方把那些讨厌的狮鹫杀个干净，这样就可以大大推迟他们的进攻计划。")
    SetQBit(QBit(699)) -- 把埃拉西亚和布拉卡达的狮鹫全杀光，然后到迪雅找塞斯・达克森。
    evt.SetNPCTopic(623, 0, 947) -- 塞斯・达克森 topic 0: 任务
end)
RegisterCanShowTopic(946, function()
    evt._BeginCanShowTopic(946)
    local visible = true
    if IsQBitSet(QBit(612)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(947, nil, function()
    if IsQBitSet(QBit(700)) then
        if not IsQBitSet(QBit(701)) then
            evt.SetMessage("你们只消灭了埃拉西亚的狮鹫，布拉卡达沙漠里还有很多，不把它们全部消灭就别来见我。")
            return
        end
        evt.SetMessage("好极了，你们干得真不错。这些酬金你们收下吧，整个迪雅都会感激你们的。")
        ClearQBit(QBit(699)) -- 把埃拉西亚和布拉卡达的狮鹫全杀光，然后到迪雅找塞斯・达克森。
        AddValue(Gold, 5000)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 10000)
        SubtractValue(ReputationInCurrentLocation, 10)
        SetAward(Award(51))
        evt.SetNPCTopic(623, 0, 0) -- 塞斯・达克森 topic 0 cleared
        evt.SetNPCGreeting(623, 281) -- 塞斯・达克森 greeting 281
    elseif IsQBitSet(QBit(701)) then
        if not IsQBitSet(QBit(700)) then
            evt.SetMessage("你们只消灭了布拉卡达沙漠里的狮鹫，埃拉西亚那里还有很多，不把它们全部消灭就别来见我。")
            return
        end
        evt.SetMessage("好极了，你们干得真不错。这些酬金你们收下吧，整个迪雅都会感激你们的。")
        ClearQBit(QBit(699)) -- 把埃拉西亚和布拉卡达的狮鹫全杀光，然后到迪雅找塞斯・达克森。
        AddValue(Gold, 5000)
        evt.ForPlayer(Players.All)
        AddValue(Experience, 10000)
        SubtractValue(ReputationInCurrentLocation, 10)
        SetAward(Award(51))
        evt.SetNPCTopic(623, 0, 0) -- 塞斯・达克森 topic 0 cleared
        evt.SetNPCGreeting(623, 281) -- 塞斯・达克森 greeting 281
    else
        evt.SetMessage("埃拉西亚和布拉卡达沙漠里的狮鹫多着呢！你们一定要把它们消灭干净才能阻止埃拉西亚的进攻。")
        return
    end
end)

RegisterGlobalEvent(948, nil, function()
    evt.SetMessage("我兄弟埃尔隆是个出了名的牌鬼，玩牌简直如痴如醉，已经到了不要命的地步。这种游戏真是害死人啊！如果你们要玩牌的话，必须先找到一副纸牌，不过要找到这样一副牌也挺不容易的。我兄弟为了提高牌技，四处寻访拜师，最近有人在镇子东南面的悬崖洞穴见过他，天知道他去这么危险的地方干什么？\n\n埃尔隆已经有一个星期没回来了，现在活不见人，死不见尸，我真为他担心。如果你们能帮我个忙，打听一下他的下落，我会重重酬谢你们的。")
    SetQBit(QBit(706)) -- 去悬崖洞穴探访达伦・坦普的兄弟的下落，然后回哈蒙代尔把情况告诉他。
    evt.SetNPCTopic(624, 0, 949) -- 达伦・坦普 topic 0: 任务
end)

RegisterGlobalEvent(949, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1453) then
        evt.SetMessage("还没有他的消息。我知道要找他的确很不容易，你们要是有他的消息，别忘了告诉我一声。")
        return
    end
    evt.SetMessage("什么，他死了，哦，我的天啊！对，这是他随时携带的魔幻牌。这东西我不要了，我已经受够了，你们要就拿去吧，玩牌可千万不要上瘾啊，不然埃尔隆就是榜样！这里有点酬金，你们一定要收下，谢谢你们帮我打听到他的下落。")
    AddValue(Experience, 2000)
    evt.ForPlayer(Players.Current)
    ClearQBit(QBit(706)) -- 去悬崖洞穴探访达伦・坦普的兄弟的下落，然后回哈蒙代尔把情况告诉他。
    AddValue(Gold, 750)
    evt.SetNPCTopic(624, 0, 0) -- 达伦・坦普 topic 0 cleared
    SubtractValue(ReputationInCurrentLocation, 5)
end)

RegisterGlobalEvent(1063, nil, function()
    evt.SetMessage("布拉卡达沙漠里的魔法学院里有很多神奇的魔法物品。几年前这个学院遭到迪雅的袭击，他们抢走了一件珍贵的魔法披风，它叫四季披风。光明主教在四季交替时要举行隆重的仪式，必须穿着这件披风。我接受魔法学院的委托，希望你们能帮助我们找到这件披风。据说有人在地狱之厅见过它，你们可以去那里找找看。")
    SetQBit(QBit(707)) -- 去地狱城大厅找到四季披风，然后去布拉卡达沙漠找盖里・查姆。
    evt.SetNPCTopic(625, 0, 1064) -- 盖里・查姆 topic 0: 任务
end)
RegisterCanShowTopic(1063, function()
    evt._BeginCanShowTopic(1063)
    local visible = true
    if IsQBitSet(QBit(611)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(1064, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1440) then
        evt.SetMessage("如果你们能找到四季披风，我们会给你们一大笔酬金的。")
        return
    end
    evt.SetMessage("好极了，你们这么快就找到四季披风了。这些酬金你们收下吧。你们为我们魔法学院做了件大好事，我们会记住你们的。")
    RemoveItem(1440)
    AddValue(Experience, 7500)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 7500)
    ClearQBit(QBit(707)) -- 去地狱城大厅找到四季披风，然后去布拉卡达沙漠找盖里・查姆。
    SetAward(Award(52))
    SubtractValue(ReputationInCurrentLocation, 5)
    evt.SetNPCTopic(625, 0, 0) -- 盖里・查姆 topic 0 cleared
end)

RegisterGlobalEvent(1065, nil, function()
    evt.SetMessage("手杖大师艾尔希・培顿住在布拉卡达沙漠西南面。")
    SetAutonote(323)
end)

RegisterGlobalEvent(1066, nil, function()
    evt.SetMessage("手杖宗师基里安・米斯瑞特住在埃里东北面。")
    SetAutonote(324)
end)

RegisterGlobalEvent(1067, nil, function()
    evt.SetMessage("长剑大师特格・斯莱瑟住在迪雅西面的村子里。")
    SetAutonote(325)
end)

RegisterGlobalEvent(1068, nil, function()
    evt.SetMessage("长剑宗师查德科・唐瑟夫住在哈蒙代尔南面一个叫维尔宁的小村子里。")
    SetAutonote(326)
end)

RegisterGlobalEvent(1069, nil, function()
    evt.SetMessage("匕首大师埃兹诺格・斯莱什住在尼根北部。")
    SetAutonote(327)
end)

RegisterGlobalEvent(1070, nil, function()
    evt.SetMessage("匕首宗师托肯・费斯特住在泰塔利亚的潮水镇里。据说埃拉西亚首都斯坦德威克下水道里的盗贼大师也能传授宗师级的匕首技术。")
    SetAutonote(328)
end)

RegisterGlobalEvent(1071, nil, function()
    evt.SetMessage("战斧大师德林・卡内基住在石头城的东北角上。")
    SetAutonote(329)
end)

RegisterGlobalEvent(1072, nil, function()
    evt.SetMessage("战斧宗师卡恩・斯通科利夫住在泰塔利亚东北方的雪山上。")
    SetAutonote(330)
end)

RegisterGlobalEvent(1073, nil, function()
    evt.SetMessage("长矛大师科拉德林・西尔普住在图拉利昂森林里匹尔邦特东北面。")
    SetAutonote(331)
end)

RegisterGlobalEvent(1074, nil, function()
    evt.SetMessage("长矛宗师希林・法尔科内住在石头城东北角。")
    SetAutonote(332)
end)

RegisterGlobalEvent(1075, nil, function()
    evt.SetMessage("弓箭大师兰希・拉弗赛特住在尼根的东北面。")
    SetAutonote(333)
end)

RegisterGlobalEvent(1076, nil, function()
    evt.SetMessage("弓箭宗师凯德拉克・斯蒂德住在哈蒙代尔的城堡东南面。")
    SetAutonote(334)
end)

RegisterGlobalEvent(1077, nil, function()
    evt.SetMessage("钉锤大师布拉泽・罗斯汉姆住在泰塔利亚的南面。")
    SetAutonote(335)
end)

RegisterGlobalEvent(1078, nil, function()
    evt.SetMessage("钉锤宗师帕特文・费尔本住在迪雅东面大耳怪村里。")
    SetAutonote(336)
end)

RegisterGlobalEvent(1079, nil, function()
    evt.SetMessage("盾牌大师伊斯拉姆・格洛威尔住在泰塔利亚东北面的雪山上。")
    SetAutonote(337)
end)

RegisterGlobalEvent(1080, nil, function()
    evt.SetMessage("盾牌宗师费德文・斯密森住在埃弗蒙岛上。")
    SetAutonote(338)
end)

RegisterGlobalEvent(1081, nil, function()
    evt.SetMessage("皮甲大师拉比萨・尼德伦住在尼根北部。")
    SetAutonote(339)
end)

RegisterGlobalEvent(1082, nil, function()
    evt.SetMessage("皮甲宗师米尔扬・奎克住在图拉利昂森林匹尔邦特城的东部。")
    SetAutonote(340)
end)

RegisterGlobalEvent(1083, nil, function()
    evt.SetMessage("锁甲大师麦德沃里住在埃里的东北部。")
    SetAutonote(341)
end)

RegisterGlobalEvent(1084, nil, function()
    evt.SetMessage("锁甲宗师哈利安・那夫莫尔住在迪雅西北面的大镇子上。")
    SetAutonote(342)
end)

RegisterGlobalEvent(1085, nil, function()
    evt.SetMessage("钢甲大师德坎・富德来特住在埃拉西亚首都斯坦德威克。")
    SetAutonote(343)
end)

RegisterGlobalEvent(1086, nil, function()
    evt.SetMessage("钢甲宗师工匠布朗达住在布拉卡达沙漠中心地带。")
    SetAutonote(344)
end)

RegisterGlobalEvent(1087, nil, function()
    evt.SetMessage("火系魔法大师阿什・坦普住在哈蒙代尔的马厩附近。")
    SetAutonote(345)
end)

RegisterGlobalEvent(1088, nil, function()
    evt.SetMessage("火系魔法宗师布雷泽住在埃拉西亚首都斯坦德威克。")
    SetAutonote(346)
end)

RegisterGlobalEvent(1089, nil, function()
    evt.SetMessage("空气魔法大师瑞斯林・革林斯道住在埃里的东北部。")
    SetAutonote(347)
end)

RegisterGlobalEvent(1090, nil, function()
    evt.SetMessage("空气魔法宗师格利住在布拉卡达沙漠北部。")
    SetAutonote(348)
end)

RegisterGlobalEvent(1091, nil, function()
    evt.SetMessage("水系魔法大师托伯伦・瑞恩谢德住在尼根西南部。")
    SetAutonote(349)
end)

RegisterGlobalEvent(1092, nil, function()
    evt.SetMessage("水系魔法宗师特伦住在哈蒙代尔南面。")
    SetAutonote(350)
end)

RegisterGlobalEvent(1093, nil, function()
    evt.SetMessage("土系魔法大师兰拉・斯通莱特住在图拉利昂森林的匹尔邦特城。")
    SetAutonote(351)
end)

RegisterGlobalEvent(1094, nil, function()
    evt.SetMessage("土系魔法宗师埃兰奇住在迪雅西部。")
    SetAutonote(352)
end)

RegisterGlobalEvent(1095, nil, function()
    evt.SetMessage("灵魂魔法大师希瑟・德姆利忒住在埃拉西亚首都斯坦德威克。")
    SetAutonote(353)
end)

RegisterGlobalEvent(1096, nil, function()
    evt.SetMessage("灵魂魔法宗师本杰明住在图拉利昂森林的匹尔邦特城。")
    SetAutonote(354)
end)

RegisterGlobalEvent(1097, nil, function()
    evt.SetMessage("心智魔法大师米莱斯・菲德文特住在埃里的东北部。")
    SetAutonote(355)
end)

RegisterGlobalEvent(1098, nil, function()
    evt.SetMessage("心智魔法宗师克维尔・布里门住在泰塔利亚东北面的雪山下。")
    SetAutonote(356)
end)

RegisterGlobalEvent(1099, nil, function()
    evt.SetMessage("肢体魔法大师邦布大哥住在泰塔利亚南部。")
    SetAutonote(357)
end)

RegisterGlobalEvent(1100, nil, function()
    evt.SetMessage("肢体魔法宗师坦普斯住在埃里中部海湾里的小岛上。")
    SetAutonote(358)
end)

RegisterGlobalEvent(1101, nil, function()
    evt.SetMessage("物品鉴定术大师萨缪尔・拜森住在布拉卡达沙漠中部。")
    SetAutonote(359)
end)

RegisterGlobalEvent(1102, nil, function()
    evt.SetMessage("物品鉴定术宗师佩吉・布鲁斯文住在图拉利昂森林。")
    SetAutonote(360)
end)

RegisterGlobalEvent(1103, nil, function()
    evt.SetMessage("经商术大师贝特胡德・凯夫希尔住在埃弗蒙岛中最东面的一个小岛上。")
    SetAutonote(361)
end)

RegisterGlobalEvent(1104, nil, function()
    evt.SetMessage("经商术宗师苦行者布里汉姆住在布拉卡达沙漠北面的镇子里。")
    SetAutonote(362)
end)

RegisterGlobalEvent(1105, nil, function()
    evt.SetMessage("修补术大师托马斯・摩尔住在泰塔利亚南部的三角洲上。")
    SetAutonote(363)
end)

RegisterGlobalEvent(1106, nil, function()
    evt.SetMessage("修补术宗师修补匠格里斯住在埃拉西亚的首都斯坦德威克。")
    SetAutonote(364)
end)

RegisterGlobalEvent(1107, nil, function()
    evt.SetMessage("健身术大师汪达・富斯克住在迪雅东面的大耳怪村子里。")
    SetAutonote(365)
end)

RegisterGlobalEvent(1108, nil, function()
    evt.SetMessage("健身术宗师伊万达・托马斯住在尼根东部。")
    SetAutonote(366)
end)

RegisterGlobalEvent(1109, nil, function()
    evt.SetMessage("冥想术大师特萨・格林斯沃德住在布拉卡达沙漠东南部。")
    SetAutonote(367)
end)

RegisterGlobalEvent(1110, nil, function()
    evt.SetMessage("冥想术宗师克因住在埃里中部海湾的小岛上。")
    SetAutonote(368)
end)

RegisterGlobalEvent(1111, nil, function()
    evt.SetMessage("洞察术大师嘉瑞特・多迪斯住在图拉利昂森林中的匹尔邦特城里。")
    SetAutonote(369)
end)

RegisterGlobalEvent(1112, nil, function()
    evt.SetMessage("洞察术宗师佩特拉・克莱利亚住在迪雅西北面的镇子里。")
    SetAutonote(370)
end)

RegisterGlobalEvent(1113, nil, function()
    evt.SetMessage("拆卸术大师李诺德・斯格那住在哈蒙代尔南面的山上。")
    SetAutonote(371)
end)

RegisterGlobalEvent(1114, nil, function()
    evt.SetMessage("拆卸术宗师快嘴斯尔克住在尼根的南部。")
    SetAutonote(372)
end)

RegisterGlobalEvent(1115, nil, function()
    evt.SetMessage("闪躲术大师奥伯瑞克・克雷恩住在埃弗蒙岛最东端的小岛上。")
    SetAutonote(373)
end)

RegisterGlobalEvent(1116, nil, function()
    evt.SetMessage("闪躲术宗师科尼斯・威尔那住在埃拉西亚首都斯坦德威克。")
    SetAutonote(374)
end)

RegisterGlobalEvent(1117, nil, function()
    evt.SetMessage("空手搏斗术大师安伯莱赫特・布劳勒住在埃弗蒙岛最东端的小岛上。")
    SetAutonote(375)
end)

RegisterGlobalEvent(1118, nil, function()
    evt.SetMessage("空手搏斗术宗师诺里斯住在埃拉西亚首都斯坦德威克。")
    SetAutonote(376)
end)

RegisterGlobalEvent(1119, nil, function()
    evt.SetMessage("怪物鉴定术大师吉尼・斯威夫特住在埃里的东北部。")
    SetAutonote(377)
end)

RegisterGlobalEvent(1120, nil, function()
    evt.SetMessage("怪物鉴定术宗师猎人莱文住在哈蒙代尔南部的小村子里。")
    SetAutonote(378)
end)

RegisterGlobalEvent(1121, nil, function()
    evt.SetMessage("武器使用术大师保拉・布莱斯住在埃里东北部。")
    SetAutonote(379)
end)

RegisterGlobalEvent(1122, nil, function()
    evt.SetMessage("武器使用术宗师拉斯特住在欧弗东部。")
    SetAutonote(380)
end)

RegisterGlobalEvent(1123, nil, function()
    evt.SetMessage("偷窃术大师里尼・谢德拉那住在迪雅东部的大耳怪村子里。")
    SetAutonote(381)
end)

RegisterGlobalEvent(1124, nil, function()
    evt.SetMessage("偷窃术宗师夜行者伊夫利住在泰塔利亚南部的三角洲里。")
    SetAutonote(382)
end)

RegisterGlobalEvent(1125, nil, function()
    evt.SetMessage("炼金术大师埃兹贝特・温特斯普恩住在尼根西部。")
    SetAutonote(383)
end)

RegisterGlobalEvent(1126, nil, function()
    evt.SetMessage("炼金术宗师鲁西德・埃普住在埃里中部海湾的小岛上。")
    SetAutonote(384)
end)

RegisterGlobalEvent(1127, nil, function()
    evt.SetMessage("学习术大师道洛希・森加卡住在尼根东南面。")
    SetAutonote(385)
end)

RegisterGlobalEvent(1128, nil, function()
    evt.SetMessage("学习术宗师威廉姆・戴维斯住在埃弗蒙岛最东端的小岛上。")
    SetAutonote(386)
end)

RegisterGlobalEvent(1129, nil, function()
    evt.SetMessage("光明魔法大师晨星海伦娜住在塞莱斯特的云中城里。")
    SetAutonote(387)
end)

RegisterGlobalEvent(1130, nil, function()
    evt.SetMessage("光明魔法宗师格文・玛格努斯住在光辉城堡中的法师殿里。")
    SetAutonote(388)
end)

RegisterGlobalEvent(1131, nil, function()
    evt.SetMessage("暗黑魔法大师塞斯・达克莫住在迪雅地下的地狱城里。")
    SetAutonote(389)
end)

RegisterGlobalEvent(1132, nil, function()
    evt.SetMessage("暗黑魔法宗师阿基巴德住在黄昏城堡的死灵法师殿里。他还经常去科兰克的实验室。")
    SetAutonote(390)
end)

RegisterGlobalEvent(1133, nil, function()
    evt.StatusText("空酒桶")
end)

RegisterGlobalEvent(1134, nil, function()
    evt.StatusText("力量值永久增加2点")
    AddValue(BaseMight, 2)
    SetAutonote(289)
    evt.ChangeEvent(1133)
end)

RegisterGlobalEvent(1135, nil, function()
    evt.StatusText("精确值永久增加2点")
    AddValue(BaseAccuracy, 2)
    SetAutonote(293)
    evt.ChangeEvent(1133)
end)

RegisterGlobalEvent(1136, nil, function()
    evt.StatusText("个性值永久增加2点")
    AddValue(BasePersonality, 2)
    SetAutonote(291)
    evt.ChangeEvent(1133)
end)

RegisterGlobalEvent(1137, nil, function()
    evt.StatusText("智力值永久增加2点")
    AddValue(BaseIntellect, 2)
    SetAutonote(290)
    evt.ChangeEvent(1133)
end)

RegisterGlobalEvent(1138, nil, function()
    evt.StatusText("耐力值永久增加2点")
    AddValue(BaseEndurance, 2)
    SetAutonote(292)
    evt.ChangeEvent(1133)
end)

RegisterGlobalEvent(1139, nil, function()
    evt.StatusText("速度值永久增加2点")
    AddValue(BaseSpeed, 2)
    SetAutonote(294)
    evt.ChangeEvent(1133)
end)

RegisterGlobalEvent(1140, nil, function()
    evt.StatusText("运气值永久增加2点")
    AddValue(BaseLuck, 2)
    SetAutonote(295)
    evt.ChangeEvent(1133)
end)

RegisterGlobalEvent(1141, nil, function()
    evt.StatusText("空锅")
end)

RegisterGlobalEvent(1142, nil, function()
    evt.StatusText("火系抗性永久增加2点")
    AddValue(FireResistance, 2)
    SetAutonote(296)
    evt.ChangeEvent(1141)
end)

RegisterGlobalEvent(1143, nil, function()
    evt.StatusText("水系抗性永久增加2点")
    AddValue(WaterResistance, 2)
    SetAutonote(297)
    evt.ChangeEvent(1141)
end)

RegisterGlobalEvent(1144, nil, function()
    evt.StatusText("风系抗性永久增加2点")
    AddValue(AirResistance, 2)
    SetAutonote(298)
    evt.ChangeEvent(1141)
end)

RegisterGlobalEvent(1145, nil, function()
    evt.StatusText("土系抗性永久增加2点")
    AddValue(EarthResistance, 2)
    SetAutonote(299)
    evt.ChangeEvent(1141)
end)

RegisterGlobalEvent(1146, nil, function()
    local randomStep = PickRandomOption(1146, 1, {1, 6, 11})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(1, ItemType.Armor_)
    elseif randomStep == 6 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(2, ItemType.Armor_)
    elseif randomStep == 11 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedRed, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(3, ItemType.Armor_)
    end
    evt.ChangeEvent(1161)
end)

RegisterGlobalEvent(1147, nil, function()
    local randomStep = PickRandomOption(1147, 1, {1, 6, 11})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(1, ItemType.Weapon_)
    elseif randomStep == 6 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(2, ItemType.Weapon_)
    elseif randomStep == 11 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedRed, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(3, ItemType.Weapon_)
    end
    evt.ChangeEvent(1161)
end)

RegisterGlobalEvent(1148, nil, function()
    local randomStep = PickRandomOption(1148, 1, {1, 6, 11})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(1, ItemType.Misc)
    elseif randomStep == 6 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(2, ItemType.Misc)
    elseif randomStep == 11 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedRed, 0)
            evt.StatusText("患病了！")
        end
        evt.GiveItem(3, ItemType.Misc)
    end
    evt.ChangeEvent(1161)
end)

RegisterGlobalEvent(1161, nil, function()
    local randomStep = PickRandomOption(1161, 1, {1, 5})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病了！")
            return
        end
        evt.StatusText("这儿没什么东西")
    elseif randomStep == 5 then
        evt.StatusText("这儿没什么东西")
    end
end)

RegisterGlobalEvent(1162, nil, function()
    AddValue(Food, 2)
    if not IsAtLeast(DisarmTrapSkill, 1) then
        evt.ChangeEvent(0)
        return
    end
    evt.GiveItem(2, ItemType.Ring_)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1163, nil, function()
    AddValue(Food, 1)
    if not IsAtLeast(DisarmTrapSkill, 1) then
        evt.ChangeEvent(0)
        return
    end
    evt.GiveItem(1, ItemType.Ring_)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1164, nil, function()
    AddValue(InventoryItem(1432), 1432)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1165, nil, function()
    evt.StatusText("空桶")
end)

RegisterGlobalEvent(1166, nil, function()
    local randomStep = PickRandomOption(1166, 1, {1, 1, 1, 8, 8, 8})
    if randomStep == 1 then
        local randomStep = PickRandomOption(1166, 2, {2, 2, 2, 5, 5, 5})
        if randomStep == 2 then
            SetValue(PoisonedYellow, 0)
            evt.StatusText("中毒了！")
        elseif randomStep == 5 then
            SetValue(PoisonedGreen, 0)
            evt.StatusText("喝醉了！")
        end
    elseif randomStep == 8 then
        local randomStep = PickRandomOption(1166, 9, {9, 9, 11, 11, 13, 15})
        if randomStep == 9 then
            AddValue(InventoryItem(1004), 1004)
        elseif randomStep == 11 then
            AddValue(InventoryItem(1019), 1019)
        elseif randomStep == 13 then
            AddValue(InventoryItem(1020), 1020)
        elseif randomStep == 15 then
            AddValue(InventoryItem(1016), 1016)
        end
    end
    evt.ChangeEvent(1165)
end)

RegisterGlobalEvent(1167, nil, function()
    AddValue(InventoryItem(1017), 1017)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1168, nil, function()
    evt.SetMessage("你们就是马克汉姆爵士举办的寻宝竞赛的优胜者！你们赢得比赛有什么奖赏，光一个小小的哈蒙代尔城堡就把你们打发了。我要是你们，就一定会缠着他多要些好处。他就住在泰塔利亚的码头附近。")
end)

RegisterGlobalEvent(1169, nil, function()
    evt.SetMessage("你们在这儿得小心看着你们的钱包。斯坦德威克到处是小偷，是有名的盗贼之都。盗贼大师比尔・拉斯克就住在斯坦德威克下面的下水道里。")
end)

RegisterGlobalEvent(1170, nil, function()
    if not IsQBitSet(QBit(708)) then
        evt.SetMessage("我在退伍前，是负责侦察迪雅的哨塔的侦察兵。要从那个哨塔的正门硬闯进去，简直是送死。可我找到另一个出口，原来这些死灵法师也都是胆小鬼，他们还另有一个小门用来逃命。哈，这些我可方便了。")
        return
    end
    evt.SetMessage("你们找到另一个出口了，看来他们的伏击计划这下泡汤了。怎么样，听我的话没错吧。")
end)
RegisterCanShowTopic(1170, function()
    evt._BeginCanShowTopic(1170)
    local visible = true
    if IsQBitSet(QBit(708)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(531)) then -- 潜入迪雅的6号哨塔，把塔顶的顶门石移到塔的底层，然后回埃拉西亚下水道见比尔・拉斯克。
            visible = true
            return visible
        else
            visible = false
            return visible
        end
    end
end)

RegisterGlobalEvent(1171, nil, function()
    evt.SetMessage("比尔・拉斯克虽然名声不好，可他确实为王室立了不少功劳。有些任务大动干戈也无济于事，但他盗贼大师一旦出马就手到擒来。埃拉西亚王室少不了他，怎么还会抓他呢！")
end)

RegisterGlobalEvent(1172, nil, function()
    if HasItem(1342) then
        evt.SetMessage("真是天遂人愿，这就是叛徒卡米尔应有的下场。")
    elseif IsQBitSet(QBit(1564)) then
        evt.SetMessage("真是天遂人愿，这就是叛徒卡米尔应有的下场。")
    elseif IsQBitSet(QBit(1565)) then
        evt.SetMessage("真是天遂人愿，这就是叛徒卡米尔应有的下场。")
    else
        evt.SetMessage("你们要了解叛徒卡米尔的情况。她本来是我们的一个外交使节，可惜不知道哪一天她听信了光明法师的蛊惑，竟加入了他们一边。现在她正在塞莱斯特悠闲地散步呢！等着瞧吧，这个女人终有一天会倒大霉的。")
        return
    end
end)
RegisterCanShowTopic(1172, function()
    evt._BeginCanShowTopic(1172)
    local visible = true
    if IsQBitSet(QBit(1564)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(1565)) then
            visible = true
            return visible
        else
            if IsQBitSet(QBit(533)) then -- 去塞莱斯特的通天院干掉卡米尔，把她身上的匕首交给迪雅的塞克尼特・恩德斯。
                visible = true
                return visible
            else
                visible = false
                return visible
            end
        end
    end
end)

RegisterGlobalEvent(1173, nil, function()
    evt.SetMessage("想找活干吗？杀手大师就住在迪雅，他会给你们些活干的。这世道该死的人多的是，你们干这行不愁没饭吃。")
end)

RegisterGlobalEvent(1174, nil, function()
    if IsQBitSet(QBit(1564)) then
        evt.SetMessage("你们竟然可以亲手屠龙，简直太伟大了。")
    elseif IsQBitSet(QBit(1565)) then
        evt.SetMessage("你们竟然可以亲手屠龙，简直太伟大了。")
    else
        evt.SetMessage("本来这里的巨龙劳斯莱克只待在南面的小山上觅食小动物，从不骚扰周围的百姓。可是最近它狂性大发，吃了我们精灵族不少人。它的洞穴就在雇佣兵行会西面的山上，它有时会外出猎食，不在洞里。你们要对付它得千万小心，这条龙实在太厉害了。")
        return
    end
end)
RegisterCanShowTopic(1174, function()
    evt._BeginCanShowTopic(1174)
    local visible = true
    if IsQBitSet(QBit(1590)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(1591)) then
            visible = true
            return visible
        else
            if IsQBitSet(QBit(534)) then -- 到泰塔利亚杀死巨龙劳斯莱克，然后去找查尔斯・科切特。
                visible = true
                return visible
            else
                visible = false
                return visible
            end
        end
    end
end)

RegisterGlobalEvent(1175, nil, function()
    evt.SetMessage("你们想成为十字军？这个镇子里可到处都是十字军。镇子中央一所房子的后面住着一个怪人，人们都想见他一面，可他谁也不见。但愿你们运气好，能够见到他。")
end)

RegisterGlobalEvent(1176, nil, function()
    evt.SetMessage("等一下，让我仔细看看。（巫师朝镜子里端详了好一会儿）啊，正是埃莉斯・哈格，她住在格芬哈特城堡。多漂亮的女孩啊！不过我年轻的时候也不比她差。")
end)

RegisterGlobalEvent(1177, nil, function()
    evt.SetMessage("威廉姆・塞塔格可是我们这里最能干的人，他使光明法师们吃尽了苦头，所以他们对他恨之入骨，其实他只是以牙还牙而已。\n你们要拜他为师吗？为了清净，他住在迪雅北面海滩上一个非常隐蔽的地方。尽管他不喜欢不速之客，但有人来拜师他还是不会拒绝的。")
end)

RegisterGlobalEvent(1178, nil, function()
    evt.SetMessage("你们想拜师学艺，去巴斯洛缪・海墨尔那里碰碰运气吧。他住在哈蒙代尔南面的村子里。")
end)

RegisterGlobalEvent(1179, nil, function()
    evt.SetMessage("在红矮人矿盘踞着一伙美杜莎女妖，魔法对她们无能为力，真是些可怕的家伙。谢天谢地她们就待在矿井里，还没有出来作恶。不然就凭我们根本对付不了她们。")
end)

RegisterGlobalEvent(1180, nil, function()
    if HasItem(1332) then
        evt.SetMessage("羊鸣教终于瓦解了。我们真是太感谢你们了，人民不会忘记你们的。")
    elseif IsQBitSet(QBit(1574)) then
        evt.SetMessage("羊鸣教终于瓦解了。我们真是太感谢你们了，人民不会忘记你们的。")
    elseif IsQBitSet(QBit(1575)) then
        evt.SetMessage("羊鸣教终于瓦解了。我们真是太感谢你们了，人民不会忘记你们的。")
    else
        evt.SetMessage("几年前一个名叫羊鸣教的邪教霸占了这个地方。起初由于他们积善行德，免费为老百姓救死扶伤，因此名声大震，广受欢迎。可是不久他们邪恶的本来面目被揭穿后就很少有人去那儿了，而且他们膜拜的邪神似乎也不再青睐他们，于是这个教派日渐衰弱。可是他们如今还盘踞在这里，等待东山再起的那一天。")
        return
    end
end)
RegisterCanShowTopic(1180, function()
    evt._BeginCanShowTopic(1180)
    local visible = true
    if IsQBitSet(QBit(1574)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(1575)) then
            visible = true
            return visible
        else
            if IsQBitSet(QBit(540)) then -- 到埃里的羊鸣教神庙铲除羊鸣教高级神甫，然后回到哈蒙代尔找巴斯洛缪・海墨尔。
                visible = true
                return visible
            else
                visible = false
                return visible
            end
        end
    end
end)

RegisterGlobalEvent(1181, nil, function()
    if HasItem(1332) then
        evt.SetMessage("羊鸣教完蛋了，这下我的羊群该太平了，真是谢谢你们。")
    elseif IsQBitSet(QBit(1574)) then
        evt.SetMessage("羊鸣教完蛋了，这下我的羊群该太平了，真是谢谢你们。")
    elseif IsQBitSet(QBit(1575)) then
        evt.SetMessage("羊鸣教完蛋了，这下我的羊群该太平了，真是谢谢你们。")
    else
        evt.SetMessage("自从羊鸣教到了这里，我养的羊就少了好多，一定是被他们偷去祭神了。要是再这样下去我就要破产了。")
        return
    end
end)
RegisterCanShowTopic(1181, function()
    evt._BeginCanShowTopic(1181)
    local visible = true
    if IsQBitSet(QBit(1574)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(1575)) then
            visible = true
            return visible
        else
            if IsQBitSet(QBit(540)) then -- 到埃里的羊鸣教神庙铲除羊鸣教高级神甫，然后回到哈蒙代尔找巴斯洛缪・海墨尔。
                visible = true
                return visible
            else
                visible = false
                return visible
            end
        end
    end
end)

RegisterGlobalEvent(1182, nil, function()
    evt.SetMessage("这个地方到处都是密探，要是你们不想让别人知道自己写些什么，就非得用密码不可。在这里城堡的图书馆里有本书能破译所有的密码。")
end)

RegisterGlobalEvent(1183, nil, function()
    evt.SetMessage("八年前，据说红矮人矿那里经常有怪兽出没，于是我们派了一队学者去看个究竟。我们发现原来这东西叫粘土怪，它可是做药剂的好材料。兵器对它不起作用，无论刀砍斧劈，它都能马上还原。要对付它们，只有靠魔法。\n")
end)

RegisterGlobalEvent(1184, nil, function()
    evt.SetMessage("在红矮人矿盘踞着一伙美杜莎女妖，魔法对她们无能为力，真是些可怕的家伙。谢天谢地她们就待在矿井里，还没有出来作恶。不然就凭我们根本对付不了她们。")
end)

RegisterGlobalEvent(1185, nil, function()
    evt.SetMessage("你们要是走到南面的维文平原，千万不要去湖中那个堡垒，那里是泰坦巨人的营地，他们可不欢迎不速之客。")
end)

RegisterGlobalEvent(1186, nil, function()
    evt.SetMessage("谁要是精力太旺盛需要发泄，去竞技场角斗倒不错。不过一定要在星期天去驿站，只有那天才有去那里的车。")
end)

RegisterGlobalEvent(1187, nil, function()
    evt.SetMessage("每个星期天竞技场都举行比武大会，你们可以上那里碰碰运气。不过你们的对手可都是些不好惹的家伙。")
end)

RegisterGlobalEvent(1188, nil, function()
    evt.SetMessage("每片坟墓附近都有一幢鬼屋，我们这也一样。西北面就有一个，里面尽是讨厌的游魂。")
end)

RegisterGlobalEvent(1189, nil, function()
    evt.SetMessage("千万别惹那些游魂，它们会强大的灵魂魔法，还可以使你们迅速衰老。")
end)

RegisterGlobalEvent(1190, nil, function()
    evt.SetMessage("很久以前我的祖父曾被招募去挖一条准备撤退时用的地道，这条地道从精灵城堡一直通往图拉利昂洞穴。由于城堡从未被攻占，所以这条地道就从来没有人用过，不过这也应该算是历史上一个伟大的工程了。")
end)

RegisterGlobalEvent(1191, nil, function()
    if not IsQBitSet(QBit(709)) then
        evt.SetMessage("人们总以为精灵就是神仙，其实两者差了十万八千里。其实真正的神仙可不会和人类混在一起。他们生性贪玩、铁石心肠、法术高强、脾气暴躁，如果你们真的想要见见他们，可以去小山下面的大厅。那座山就在村子的西北面，不过你们要从正门进去可得花点功夫。")
        return
    end
    evt.SetMessage("你们竟然成功的进入了神仙冈，以前可从没有人敢这样做，真是太了不起了。")
end)

RegisterGlobalEvent(1192, nil, function()
    if HasItem(1402) then
        evt.SetMessage("森林现在重新恢复了宁静，这要感谢你们所做的一切。老树对你们非常赞赏，还把你们的事迹编成歌谣传唱。")
    elseif IsQBitSet(QBit(1580)) then
        evt.SetMessage("森林现在重新恢复了宁静，这要感谢你们所做的一切。老树对你们非常赞赏，还把你们的事迹编成歌谣传唱。")
    elseif IsQBitSet(QBit(1581)) then
        evt.SetMessage("森林现在重新恢复了宁静，这要感谢你们所做的一切。老树对你们非常赞赏，还把你们的事迹编成歌谣传唱。")
    elseif HasAward(Award(23)) then
        evt.SetMessage("森林现在重新恢复了宁静，这要感谢你们所做的一切。老树对你们非常赞赏，还把你们的事迹编成歌谣传唱。")
    else
        evt.SetMessage("从前我看见有人按照地图的指引，明火执仗地闯入图拉利昂森林，心满意足地拉走了一块绿色的大岩石，有人说他们是泰塔利亚派来的雇佣兵。第二天可不得了，整个森林都发怒了，它们疯狂袭击胆敢进入森林的任何人，如今没人敢去那里。")
        return
    end
end)

RegisterGlobalEvent(1193, nil, function()
    evt.SetMessage("图拉利昂森林里的老树年深日久，都快变成树精了。它们能够发觉有人进入了森林，但只有其中年纪最大的一棵树会和人说话。你们要是想知道更多一些情况，可以去那里找它。它在森林东南面的岛上，比别的树高大得多，很好认的。")
end)

RegisterGlobalEvent(1194, nil, function()
    evt.SetMessage("要是你们想挣点钱花，可以去各个大城市的市政厅接受赏金任务。这些市政厅每个月都会悬赏消灭一种生物，比如吃人的怪兽、邪恶的魔法师或是猖狂的歹徒，反正他们想干掉谁就会出钱招募杀手。重赏之下必有勇夫，你们也可以去试试运气。")
end)

RegisterGlobalEvent(1195, nil, function()
    evt.SetMessage("要是你们厌倦了简单的赏金任务，想要把自己的本领更提高一步，可以去埃里找埃伯登泽・索渥。不过他只向选择黑暗之路的人传授本领。")
end)

RegisterGlobalEvent(1196, nil, function()
    evt.SetMessage("海盗在潮水洞穴为非作歹已经有二十年了。这些年来他们无恶不作，犯下了滔天罪行。你们要是想找他们去算帐，可以到西面的岛上去。")
end)

RegisterGlobalEvent(1197, nil, function()
    if HasItem(1485) then
        evt.SetMessage("你们找到地图了。这下找那些宝藏就容易多了。")
    elseif IsQBitSet(QBit(1607)) then
        evt.SetMessage("你们找到地图了。这下找那些宝藏就容易多了。")
    elseif IsQBitSet(QBit(1608)) then
        evt.SetMessage("你们找到地图了。这下找那些宝藏就容易多了。")
    else
        evt.SetMessage("埃弗蒙岛可是个凶险的地方，它周围到处是旋涡和暗礁，不熟悉地形根本无法上岛。但是海盗们趁火打劫，趁着战乱偷走了埃弗蒙岛的地图，现在地图一定在他们盘踞的洞穴里。")
        return
    end
end)

RegisterGlobalEvent(1198, nil, function()
    if HasItem(1485) then
        evt.SetMessage("你们找到地图了，这下去那个地方就容易多了。不过你们还得处处小心，听说那可是一个被魔法笼罩的地方。")
    elseif IsQBitSet(QBit(1607)) then
        evt.SetMessage("你们找到地图了，这下去那个地方就容易多了。不过你们还得处处小心，听说那可是一个被魔法笼罩的地方。")
    elseif IsQBitSet(QBit(1608)) then
        evt.SetMessage("你们找到地图了，这下去那个地方就容易多了。不过你们还得处处小心，听说那可是一个被魔法笼罩的地方。")
    else
        evt.SetMessage("只要你们有钱，总有船会带你们去埃弗蒙岛。不过没有这个岛的地图，恐怕没人敢陪你们去送死。你们还是先去找地图吧。")
        return
    end
end)

RegisterGlobalEvent(1199, nil, function()
    evt.SetMessage("如果你们不介意泥沼遍地，终日迷雾遮天的话，埃弗蒙岛倒是个景色秀丽的地方。听说岛上到处是游魂和骷髅，但也没干过什么坏事。岛上的月亮教和太阳教也不象前些年那样打得不可开交了，看来他们都已经日渐衰败，成不了什么气候了。")
end)

RegisterGlobalEvent(1200, nil, function()
    evt.SetMessage("我身上可没有什么人偶的肢体，我对这玩艺儿不感兴趣。不过我听说在布拉卡达有些人身上带有人偶肢体的一部分，这个人偶只有拼合完整才有巨大的威力，所以我想他们会很乐意给你们的。")
end)

RegisterGlobalEvent(1201, nil, function()
    evt.SetMessage("你们在布拉卡达看见那些四处瞎逛的人偶了吗？它们都是在魔法学院中修炼的法师的杰作，不赖吧。这些人偶虽然话不多，却非常“嫉恶如仇”。只要有死灵法师或是邪术师踏上我们的土地，人偶们就会奋起进攻。咿咿咿呀！")
end)

RegisterGlobalEvent(1202, nil, function()
    if HasItem(1289) then
        evt.SetMessage("啊，你们找到普渡众生魔法了，真是个奇迹。我以为自己活不到亲眼目睹魔法的这一天了。")
    elseif IsQBitSet(QBit(1621)) then
        evt.SetMessage("啊，你们找到普渡众生魔法了，真是个奇迹。我以为自己活不到亲眼目睹魔法的这一天了。")
    elseif IsQBitSet(QBit(1622)) then
        evt.SetMessage("啊，你们找到普渡众生魔法了，真是个奇迹。我以为自己活不到亲眼目睹魔法的这一天了。")
    else
        evt.SetMessage("我们已经掌握确切消息，失落的普渡众生魔法就在迪雅的地下，确切点说，是在死灵法师们修炼魔法的再生之地里。愿神宽恕我们的罪过吧，看来我们要永远失去它了。")
        return
    end
end)

RegisterGlobalEvent(1203, nil, function()
    if HasItem(1289) then
        evt.SetMessage("现在我们所有的魔法宗师都非常赏识你们，你们为我们教派做了件大好事。")
    elseif IsQBitSet(QBit(1621)) then
        evt.SetMessage("现在我们所有的魔法宗师都非常赏识你们，你们为我们教派做了件大好事。")
    elseif IsQBitSet(QBit(1622)) then
        evt.SetMessage("现在我们所有的魔法宗师都非常赏识你们，你们为我们教派做了件大好事。")
    else
        evt.SetMessage("光明魔法中最神圣的魔法---普渡众生已经失踪了好几个世纪了。这大概是神对我们亵渎神灵，玷污光明教荣誉的惩罚。这些年来我们尽力赎罪，四处派人寻找这个魔法，但每次都功败垂成。我们光明教派的宗师曾经练成过这种魔法，它的威力真是旷古罕见。")
        return
    end
end)

RegisterGlobalEvent(1204, nil, function()
    evt.SetMessage("天下只有尼根的邪术师会制造灵魂之坛，这是他们的独门绝技。可奇怪的是这项技术对他们来说并没有什么用处，而灵魂之坛是我们修炼魔法必需的圣物。这些年来我们巧取豪夺，讨价还价，从他们那里弄来不少坛子，而他们开的价也越来越高，唉，这样下去可怎么办啊！")
end)

RegisterGlobalEvent(1205, nil, function()
    evt.SetMessage("每个死灵法师都想有朝一日成为巫妖。只要有了属于自己的灵魂之坛，经过永生仪式，就可抛弃自己的肉身，让灵魂自由自在地游荡，再也不用忍饥挨饿，再也不怕病魔侵袭，也不用担心受伤流血。人们总说永生仪式是多么的可怕，多么的惨无人道，可是为了灵魂的自由，还有什么不可以牺牲呢？")
end)

RegisterGlobalEvent(1206, nil, function()
    if IsQBitSet(QBit(1613)) then
        evt.SetMessage("你们成功的找到了石圈，得到了它赋予的魔力。不过我希望你们不要把石圈所在的位置说出去，那可是我们的秘密。")
    elseif IsQBitSet(QBit(1614)) then
        evt.SetMessage("你们成功的找到了石圈，得到了它赋予的魔力。不过我希望你们不要把石圈所在的位置说出去，那可是我们的秘密。")
    else
        evt.SetMessage("德鲁伊们很早以前就造了三个石圈，听说那是他们升职为高级德鲁伊时必须在那里举行仪式。石圈所在的地方非常偏僻，你们可得仔细搜寻啊！")
        return
    end
end)

RegisterGlobalEvent(1207, nil, function()
    evt.SetMessage("原来有四个石圈，分别代表了东南西北四个方向和春夏秋冬四个季节。可在尼根的东方石圈在太阳教和月亮教的战争中毁于战火。")
end)

RegisterGlobalEvent(1208, nil, function()
    evt.SetMessage("国王的尸骨确实在这片墓地里，不过这个地方被赋予了魔力，任何擅入者将死无葬身之地。你们只可以挖掘真正埋有国王尸骨的坟墓，其它东西一样都不要碰。")
end)

RegisterGlobalEvent(1209, nil, function()
    evt.SetMessage("这片墓地的道路犹如迷宫，是为了预防盗墓贼的。不过为了方便其他人能进出坟墓举行葬礼，这里每扇门旁边都有一个神秘的金属牌，它是指路用的，有了这个就不会在墓地里迷路了。很多盗贼不知道这个秘密，往往是有来无回。")
end)

RegisterGlobalEvent(1210, nil, function()
    evt.SetMessage("在战争期间我们修建了一条地道从桑达非斯通往巨人领地。在那里我们不仅发现了克里根族，还有很多巨人和龙。既然那里有很多龙穴，龙蛋肯定也不少，不过谁敢上那里去送死呢！")
end)

RegisterGlobalEvent(1211, nil, function()
    evt.SetMessage("我听说在巨人领地有一条奇大无比的龙，附近的巨人和其它龙看见它就逃之夭夭。为了太平，它们还经常向这条巨龙进贡物品，甚至把它奉为神灵。看来这条龙的龙穴里一定有不少宝藏。")
end)

RegisterGlobalEvent(1212, nil, function()
    evt.SetMessage("在太阳教和月亮教的战争中，布拉卡达、泰塔利亚和埃里三个地方祭坛上膜拜的石像同时失踪了。我接受德鲁伊的委托悬赏寻找这些石像，这可是德鲁伊修炼至关重要的圣物。如果谁能找到石像并把它们放回祭坛，我会以重金酬谢。")
    SetQBit(QBit(712)) -- 拿到三个雕像，把它们分别放在布拉卡达、泰塔利亚和埃里的祭坛里，然后到图拉利昂森林找索尔・伦伯拉。
    evt.SetNPCTopic(627, 0, 1213) -- 索尔・伦伯拉 topic 0: 任务
end)

RegisterGlobalEvent(1213, nil, function()
    if IsQBitSet(QBit(713)) then
        if IsQBitSet(QBit(714)) then
            if not IsQBitSet(QBit(715)) then
                evt.SetMessage("你们不但要找到石像，还要把它们放回祭坛，等完成这个任务再来拿赏金吧。")
                return
            end
            evt.SetMessage("干得好极了，德鲁伊对你们非常感谢。这是你们应该得到的报酬，拿去吧。")
            AddValue(Gold, 50000)
            SubtractValue(ReputationInCurrentLocation, 10)
            evt.ForPlayer(Players.All)
            ClearQBit(QBit(712)) -- 拿到三个雕像，把它们分别放在布拉卡达、泰塔利亚和埃里的祭坛里，然后到图拉利昂森林找索尔・伦伯拉。
            AddValue(Experience, 50000)
            SetAward(Award(53))
            evt.SetNPCGreeting(627, 289) -- 索尔・伦伯拉 greeting 289
            evt.SetNPCTopic(627, 0, 0) -- 索尔・伦伯拉 topic 0 cleared
            return
        end
    end
    evt.SetMessage("你们不但要找到石像，还要把它们放回祭坛，等完成这个任务再来拿赏金吧。")
end)

RegisterGlobalEvent(1214, nil, function()
    evt.SetMessage("你们好，我是一个艺术品的收藏家。这两天我正要找一套珍贵的艺术品，包括一幅罗兰德国王的画像，一幅阿基巴德的画像和一幅天使画像。为了得到这套举世罕见的精品画像，我会不惜一切代价。如果你们能找到这三幅画的话，我会重重酬谢你们的。")
    SetQBit(QBit(716)) -- 得到三幅画像，然后带给泰塔利亚的费迪南德・威斯康。
    evt.SetNPCTopic(628, 0, 1215) -- 费迪南德・威斯康 topic 0: 任务
end)

RegisterGlobalEvent(1215, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(1423) then
        if HasItem(1424) then
            if not HasItem(1425) then
                evt.SetMessage("这三件艺术品只有收集在一起才值钱，你们快去找吧！")
                return
            end
            evt.SetMessage("你们干得好极了，为了找到它们我可费了不少心血。这些酬金是你们应该得的，请收下吧。")
            RemoveItem(1423)
            RemoveItem(1424)
            RemoveItem(1425)
            evt.ForPlayer(Players.Current)
            AddValue(Gold, 50000)
            SubtractValue(ReputationInCurrentLocation, 10)
            evt.ForPlayer(Players.All)
            ClearQBit(QBit(716)) -- 得到三幅画像，然后带给泰塔利亚的费迪南德・威斯康。
            AddValue(Experience, 50000)
            SetAward(Award(55))
            evt.SetNPCGreeting(628, 291) -- 费迪南德・威斯康 greeting 291
            evt.SetNPCTopic(628, 0, 0) -- 费迪南德・威斯康 topic 0 cleared
            return
        end
    end
    evt.SetMessage("这三件艺术品只有收集在一起才值钱，你们快去找吧！")
end)

RegisterGlobalEvent(1216, nil, function()
    evt.SetMessage("要成为魔幻牌的冠军，你们必须去埃拉西亚。那里有十三家开设魔幻牌比赛的客栈，你们只有赢得所有的比赛，才能获得这个称号，到那时候你们可以到我这里来领赏。")
    SetQBit(QBit(717)) -- 在十三个客栈玩牌全部获得胜利，然后回埃拉西亚找吉娜・巴尼斯。
    evt.SetNPCTopic(629, 0, 1217) -- 吉娜・巴尼斯 topic 0: 任务
end)

RegisterGlobalEvent(1217, nil, function()
    if not IsQBitSet(QBit(750)) then
        evt.SetMessage("你们必须在所有十三家客栈都赢得胜利，才能成为魔幻牌的冠军。")
        return
    end
    evt.SetMessage("祝贺你们，现在你们已经是玩魔幻牌的冠军。你们的奖赏就在我屋子外面的箱子里，快去拿吧。")
    ClearQBit(QBit(717)) -- 在十三个客栈玩牌全部获得胜利，然后回埃拉西亚找吉娜・巴尼斯。
    AddValue(Gold, 100000)
    SubtractValue(ReputationInCurrentLocation, 10)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 50000)
    SetQBit(QBit(756))
    SetAward(Award(1632))
    evt.SetNPCGreeting(629, 293) -- 吉娜・巴尼斯 greeting 293
    evt.SetNPCTopic(629, 0, 0) -- 吉娜・巴尼斯 topic 0 cleared
end)

RegisterGlobalEvent(1218, nil, function()
    evt.SetMessage("相传矮人族住在哈蒙代尔南面的拜尔德斯，其实他们是住在那里的地底下。拜尔德斯中部三座桥相连的地方就是他们住所的进口。")
end)

RegisterGlobalEvent(1219, nil, function()
    evt.SetMessage("尼根的邪术师修建了一条从他们居住的岛屿通往石头城的地道，所有想去他们那里修炼的人都是通过这条地道去那里的。矮人国王对此大发脾气，甚至要向所有进入石头城的人征收高额的进城费。不过他幸好没有这么做，不然激怒了尼根的邪术师那可不得了。")
end)

RegisterGlobalEvent(1220, nil, function()
    evt.SetMessage("邪术师住在桑达非斯山，那是一个座落在一个大岛上的火山。在最近的战争中，邪术师修建了一条地道用来运送部队，那条地道现在还可以让人通行。")
end)

RegisterGlobalEvent(1221, nil, function()
    evt.SetMessage("在战争中，尼根的邪术师修建了一条从他们居住的岛屿通往石头城的地道，想通过地道出其不意地发动进攻，占领整个大陆。虽然他们的进攻被击退了，但那条地道还留在那里。")
end)

RegisterGlobalEvent(1222, nil, function()
    evt.SetMessage("矮人族住在拜尔德斯的地下。那里有很大一片墓地，安葬着千百年来矮人族的国王和英雄们。那里的坟墓机关密布，密如蛛网，许多坟墓都由远距离传送装置连接。但如果你们仔细观察，会发现墓地的墙上有指路的记号，有了它你们就不会迷路了。")
end)

RegisterGlobalEvent(1223, nil, function()
    if not IsQBitSet(QBit(610)) then
        evt.SetMessage("本来我们在红矮人矿井靠采矿为生，可是美杜莎女妖霸占了这个地方，还把我们的人变成了石头。我们矮人世代以采矿为生，没有了矿井，这叫我们怎么活啊！")
        return
    end
    evt.SetMessage("啊，你们真是埃拉西亚的大英雄。谢谢你们救了我的表弟，人民会记住你们的功绩的。")
end)

RegisterGlobalEvent(1224, nil, function()
    if not IsQBitSet(QBit(610)) then
        evt.SetMessage("布拉卡达把红矮人矿井交给我们，让我们可以在那里采矿。可是美杜莎女妖霸占了这个地方，还把我们的人变成了石头，天知道现在那里被她们糟蹋成什么样子了。矿井就在布拉卡达的东北角。")
        return
    end
    evt.SetMessage("感谢你们把我们的人从美杜莎女妖魔爪中解救出来，石头城的矮人族将永远为你们效劳。")
end)

RegisterGlobalEvent(1225, nil, function()
    if not IsQBitSet(QBit(610)) then
        evt.SetMessage("美杜莎女妖霸占了红矮人矿井，还把我们的人变成了石头。要使他们重新复生全靠你们了，但千万要小心那伙可恶的女妖，她们可不是好对付的。")
        return
    end
    evt.SetMessage("你们拯救了我们的人民，我们对你们感激不尽，重建哈蒙代尔城堡这件事就包在我们身上。")
end)

RegisterGlobalEvent(1226, nil, function()
    evt.SetMessage("你们喜欢这个地方吗？经过矮人族千百年来的建设，这里已经是一座宏伟的地下城了。不过这里的矿已经被采得差不多了，地层深处尽是些快崩塌的地道，你们要是想去那儿得千万小心。")
end)

RegisterGlobalEvent(1227, nil, function()
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("嗨，你们好，我的主人。哈蒙代尔的百姓现在都对你们刮目相看，每个人都相信城堡在你们的治理下将永远繁荣昌盛。")
    elseif IsQBitSet(QBit(612)) then
        evt.SetMessage("嗨，你们好，我的主人。哈蒙代尔的百姓现在都对你们刮目相看，每个人都相信城堡在你们的治理下将永远繁荣昌盛。")
    else
        evt.SetMessage("你们好，尊敬的哈蒙代尔领主。哈蒙代尔的历任主人没有一个人能长久的统治这个城堡，看来你们也一样。你们迟早会卷入埃拉西亚和埃里的明争暗斗，等着瞧吧。")
        return
    end
end)

RegisterGlobalEvent(1228, nil, function()
    evt.SetMessage("哈蒙代尔的人民都很安分守己，所以这里很少发生百姓暴动。但到了官逼民反的地步，人民的怒火就会象火山一样爆发，历史上最著名的人民暴动就发生在这里。不过你们看来不象暴君，只要对老百姓好，他们不会给你们惹事的。")
end)

RegisterGlobalEvent(1229, nil, function()
    if not IsQBitSet(QBit(610)) then
        evt.SetMessage("哈蒙代尔终于有了新主人了。自从战争爆发以来，城堡就没有人掌管了，现在你们来了，百姓们这下该放心了。")
        return
    end
    evt.SetMessage("大耳怪被打跑了，城堡也得到重建，恢复了以前雄伟壮观的样子。自从你们来了后好事就一件接着一件，这下百姓该放心了。")
end)

RegisterGlobalEvent(1230, nil, function()
    evt.SetMessage("为了打赢这场战争，埃里已经耗尽了所有的资源，还不断向人民横征暴敛，我只好搬迁到哈蒙代尔居住，看来这里是唯一没有卷入战争的一方乐土。埃里的国王在战争中挖了条地道通往北方的洞穴，以便在城堡失陷时能够逃命。")
end)

RegisterGlobalEvent(1231, nil, function()
    evt.SetMessage("哈蒙代尔城外有一个岩洞群，那里是匪徒和怪兽盘踞的安乐窝。哈蒙代尔的百姓吃尽了他们的苦头，现在该是向他们算帐的时候了。")
end)

RegisterGlobalEvent(1232, nil, function()
    if not IsQBitSet(QBit(595)) then
        evt.SetMessage("你们在哈蒙代尔到斯坦德威克路上看见那座吊桥了吗？这就是利文斯德要塞，是为了防御精灵族发动突袭而建的。要塞中到处是机关陷井，简直是一座永不陷落的堡垒。")
        return
    end
    evt.SetMessage("我听说由于叛徒的出卖，利文斯德要塞终于陷落了。这下凯瑟琳王后只能割地以换取和平了。")
end)

RegisterGlobalEvent(1233, nil, function()
    if IsQBitSet(QBit(596)) then
        evt.SetMessage("看来战利品落入埃拉西亚手中，听说为了争夺这个东西打了很多年的仗。")
        return
    elseif IsQBitSet(QBit(597)) then
        evt.SetMessage("看来战利品落入埃里手中，听说为了争夺这个东西打了很多年的仗。")
        return
    elseif IsQBitSet(QBit(659)) then
        evt.SetMessage("看来战利品落入阿基巴德手中，听说为了争夺这个东西打了很多年的仗。")
    else
        evt.SetMessage("埃里和埃拉西亚为了争夺一件神器而打了几十年的仗。其实这也不是什么稀奇的东西，又没有什么魔力，就是件战利品而已。十五年前，这件战利品在一次战斗中失踪了，最近又有人发现了这件东西的下落，双方正在分头寻找，看来一场战争又迫在眉睫了。")
        return
    end
end)
RegisterCanShowTopic(1233, function()
    evt._BeginCanShowTopic(1233)
    local visible = true
    if IsQBitSet(QBit(610)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(1234, nil, function()
    if not IsQBitSet(QBit(646)) then
        evt.SetMessage("据说埃拉西亚和埃里已经找了个调解人来解决双方的分歧。这个人就住在哈蒙代尔东面的群星之屋，也许他能给你们些忠告。")
        return
    end
    evt.SetMessage("调解人格瑞意外死亡对我们是个沉重的打击。希望他的继任者能象他一样主持公正，维护正义。")
end)
RegisterCanShowTopic(1234, function()
    evt._BeginCanShowTopic(1234)
    local visible = true
    if IsQBitSet(QBit(610)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(1235, nil, function()
    evt.SetMessage("你们要是毫无头绪，不知下一步该怎么办，可以上群星之屋找调解人帮忙。他就住在哈蒙代尔东面。")
end)

RegisterGlobalEvent(1236, nil, function()
    if IsQBitSet(QBit(611)) then
        evt.SetMessage("看来你们已经作出了自己的选择，希望你们是对的，这样对大家都有好处。")
    elseif IsQBitSet(QBit(612)) then
        evt.SetMessage("看来你们已经作出了自己的选择，希望你们是对的，这样对大家都有好处。")
    else
        evt.SetMessage("住在哈蒙代尔的战争调解人格瑞突然死于非命，看来战争已经迫在眉睫了。到底是帮助埃拉西亚还是埃里，这可是关系到哈蒙代尔安危的大事，你们可要权衡利弊，仔细考虑啊！")
        return
    end
end)
RegisterCanShowTopic(1236, function()
    evt._BeginCanShowTopic(1236)
    local visible = true
    if IsQBitSet(QBit(646)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(1237, nil, function()
    evt.SetMessage("所有住在塞莱斯特的法师要升职为光明法师，必须去被称为迷雾之墙的净心堂接受考验。这种考验与其说是考察武功魔法，不如说是考察道德品质。你们不能在那个迷宫里伤害任何人。")
end)

RegisterGlobalEvent(1238, nil, function()
    evt.SetMessage("塞莱斯特城堡千百年来就是光明教派的根据地。它是由马格努斯二世国王在499年建造的，现在已经成为布拉卡达的中心了。长久以来这座城市一直是人民心目中正义和希望的象征。")
end)

RegisterGlobalEvent(1239, nil, function()
    evt.SetMessage("其实地面上的建筑只是迪雅城的很小一部分，大部分建筑在一个叫做地狱城的地下城里。迪雅北面有个叫地狱之厅的地方，从那里可以进入地狱城。")
end)

RegisterGlobalEvent(1240, nil, function()
    evt.SetMessage("千百年前布拉卡达的法师们建造了塞莱斯特这个城市。它一半建在山里，一半被布拉卡达的迷雾笼罩。要到那里去，你们只有依靠布拉卡达中心的那个远距离传送装置。")
end)

RegisterGlobalEvent(1241, nil, function()
    if not IsQBitSet(QBit(619)) then
        evt.SetMessage("最近有发生一起杀人案。我们在下水道附近发现了一个姑娘的尸体，肯定是下水道里的那帮窃贼干的好事，该是收拾那帮家伙的时候了。")
        return
    end
    evt.SetMessage("啊，原来是吸血鬼作怪，残害了这里不少百姓。感谢你们能够除掉这一祸害，现在这里该平安无事了。")
end)
RegisterCanShowTopic(1241, function()
    evt._BeginCanShowTopic(1241)
    local visible = true
    if IsQBitSet(QBit(610)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(1242, nil, function()
    evt.SetMessage("战争期间，邪术师和埃里南部山区的克里根魔族曾经打过交道。这个地方一般是没有办法上去的。不过邪术师在海底修建了一条地道，从他们住的岛屿一直通往克里根人的老巢，这可是一条捷径啊！")
end)

RegisterGlobalEvent(1243, nil, function()
    evt.SetMessage("我们在这场战争中费尽心机，如今竟然在大陆上毫无立足之地。这全是我们的“盟军”克里根人干的好事。他们背信弃义，在我们最需要他们的时候竟不发援兵帮助，我们面对埃拉西亚和埃里联手进攻，寡不敌众，最终功败垂成。唉，下次我们该吸取教训了。")
end)

RegisterGlobalEvent(1244, nil, function()
    evt.SetMessage("据说迪雅发生了大变故，有人看见迪雅的领袖、恩洛斯的前任国王阿基巴德・艾恩法斯特率领大批死灵法师离开了地狱城。")
end)
RegisterCanShowTopic(1244, function()
    evt._BeginCanShowTopic(1244)
    local visible = true
    if IsQBitSet(QBit(710)) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(1245, nil, function()
    if not IsQBitSet(QBit(752)) then
        evt.SetMessage("在尼根有人传说恩洛斯的国王罗兰德还活着。有些邪术师说他们在与克里根人见面的时候曾经看到过他，他被克里根人关在一个笼子里，受着非人的虐待。")
        return
    end
    evt.SetMessage("听说是你们拯救了罗兰德国王，你们真是太了不起了，简直是埃拉西亚最伟大的人物。")
end)
RegisterCanShowTopic(1245, function()
    evt._BeginCanShowTopic(1245)
    local visible = true
    if IsQBitSet(QBit(611)) then
        return visible
    else
        if IsQBitSet(QBit(612)) then
            return visible
        else
            visible = false
            return visible
        end
    end
end)

RegisterGlobalEvent(1246, nil, function()
    evt.SetMessage("死灵法师要升职为巫妖必须得到一个灵魂之坛，以进行永生仪式。灵魂之坛对他们来说可谓生死攸关。为了得到更多的灵魂之坛，他们会不择一切手段，甚至付出生命的代价。")
end)

RegisterGlobalEvent(1247, nil, function()
    evt.SetMessage("邪术师由于信奉暗黑教派，一直被人看作无恶不作的杀人魔王。其实他们遵守人不犯我，我不犯人的信条，从不骚扰百姓。而且他们待人彬彬有礼，做事认真负责。我和他们打过交道，觉得他们并不象传说中那么可怕。")
end)

RegisterGlobalEvent(1248, nil, function()
    if not IsQBitSet(QBit(637)) then -- 破坏科兰克实验室里的魔法防御系统，然后到地狱城找达克・谢德。
        evt.SetMessage("科兰克的实验室地形复杂，守卫森严。实验室的大门是用特殊材料制成，任何魔法都打不开它，而且实验室所处的岛屿地势狭小，大批部队无法登陆。实验室最著名的防御设施是反远距离传送防护盾，有了它任何魔法师都无法施展时空之门魔法攻占实验室。")
        return
    end
    evt.SetMessage("虽然科兰克的实验室警卫森严，但阿基巴德・艾恩法斯特率领死灵法师通过远距离传送装置，一举攻占了那个地方。看来肯定有内应，不然实验室不会这么轻易地被占领。")
end)
RegisterCanShowTopic(1248, function()
    evt._BeginCanShowTopic(1248)
    local visible = true
    if IsQBitSet(QBit(611)) then
        return visible
    else
        if IsQBitSet(QBit(612)) then
            return visible
        else
            visible = false
            return visible
        end
    end
end)

RegisterGlobalEvent(1249, nil, function()
    evt.SetMessage("想要使自己的技术达到专家级水准。告诉你们吧，大多数技术的专家住在哈蒙代尔，埃拉西亚和图拉利昂森林。")
end)

RegisterGlobalEvent(1250, nil, function()
    evt.SetMessage("这两天不断有人莫名其妙地失踪，真不知道发生了什么事？")
end)

RegisterGlobalEvent(1251, nil, function()
    evt.SetMessage("通过布拉卡达中央的远距离传送器，你们可以到达沙漠中的很多地方。你们可以仔细查看一下传送器旁边的柱子，上面写明了所要到的地方。不过你们得小心，有时候这个传送器会出点小问题，不知会把你们送到哪里。")
end)

RegisterGlobalEvent(1252, nil, function()
    if HasAward(Award(28)) then
        evt.SetMessage("我的主人，阿基巴德派来了大批工匠把城堡翻修一新，还留下了很多金银财宝。哦，他们还在城堡中发现了一个地下宝库，想不到哈蒙代尔竟有这么多的宝藏，我在这里居住了这么多年也不知道这个秘密，这真象做梦一样。")
        return
    elseif HasAward(Award(6)) then
        evt.SetMessage("我的主人，盖文・马格努斯派来了大批工匠把城堡翻修一新，还留下了很多金银财宝。哦，他们还在城堡中发现了一个地下宝库，想不到哈蒙代尔竟有这么多的宝藏，我在这里居住了这么多年也不知道这个秘密，这真象做梦一样。")
    else
        evt.SetMessage("主人，哈蒙代尔城堡准备好了，一切听你们的安排。")
        return
    end
end)
RegisterCanShowTopic(1252, function()
    evt._BeginCanShowTopic(1252)
    local visible = true
    if IsQBitSet(QBit(610)) then
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(1253, nil, function()
    evt.SetMessage("魔法柱遍布在四处，你们要仔细找找。它们可以增强你们抵御各种魔法的能力。")
end)

RegisterGlobalEvent(1254, nil, function()
    evt.SetMessage("我的主人，你们虽然把把哈蒙代尔城堡里的大耳怪消灭干净了，可城堡附近仍然有大耳怪在作恶。城堡的东面是有名的争议之地，埃里的精灵国王和埃拉西亚的凯瑟琳王后常率兵在那里交战，而大耳怪趁火打劫，占领了那里废弃的堡垒，不断骚扰过往哈蒙代尔的行人。你们好人做到底，应该去把它们也收拾干净。")
end)

RegisterGlobalEvent(1255, nil, function()
    evt.SetMessage("我的主人，既然哈蒙代尔城堡归你们统治，你们就应该把这里当作家一样。这里的一切都属于你们，一切人都听你们的派遣。")
end)

RegisterGlobalEvent(1256, nil, function()
    evt.SetMessage("如果你们要向埃拉西亚求援，可以在通往拜尔德斯、埃拉西亚和图拉利昂树林三地的大路附近点燃烽火。附近的埃拉西亚军队看到烽火会立即赶来的。")
end)

RegisterGlobalEvent(1257, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1496) then return end
    evt.SetMessage("啊，这船图拉利昂木料是罗伯特・贝尔克耐普托你们送给我的，他一切都好吧。这是你们的酬金，请收下吧。")
    RemoveItem(1496)
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 294)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 241)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 251)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 237)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 273)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 255)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 286)
        return
    else
        return
    end
end)

RegisterGlobalEvent(1258, nil, function()
    evt.SetMessage("这是一箱狮鹫羽毛，你们拿去吧。住在图拉利昂森林的罗伯特・贝尔克耐普会好好酬谢你们的。你们见到他别忘了把我的报酬给他。")
    ClearQBit(QBit(762))
    if IsAtLeast(Gold, 200) then
        if not IsAtLeast(Gold, 200) then
            return
        end
        SubtractValue(Gold, 200)
        AddValue(InventoryItem(1495), 1495)
        SetQBit(QBit(763))
        SetQBit(QBit(769))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(1258, function()
    evt._BeginCanShowTopic(1258)
    local visible = true
    if IsQBitSet(QBit(762)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(769)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(1259, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1494) then return end
    evt.SetMessage("瑞德里克又给我送箭头来了，好吧，谢谢你们，这是你们的酬金，请收下吧。")
    RemoveItem(1494)
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 261)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 286)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 237)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 255)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 294)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 273)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 244)
        return
    else
        return
    end
end)

RegisterGlobalEvent(1260, nil, function()
    evt.SetMessage("这箱图拉利昂木料你们拿去吧。只要把它交给哈蒙代尔的瑞德里克，他会好好酬谢你们的。")
    ClearQBit(QBit(763))
    if IsAtLeast(Gold, 200) then
        if not IsAtLeast(Gold, 200) then
            return
        end
        SubtractValue(Gold, 200)
        AddValue(InventoryItem(1496), 1496)
        SetQBit(QBit(764))
        SetQBit(QBit(770))
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(1260, function()
    evt._BeginCanShowTopic(1260)
    local visible = true
    if IsQBitSet(QBit(763)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(770)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(1261, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1495) then return end
    evt.SetMessage("海利尔又给我送狮鹫羽毛来了，好吧，谢谢你们，这是你们的酬金，请收下吧。")
    RemoveItem(1495)
    evt.ForPlayer(Players.Current)
    if IsAtLeast(DayOfWeek, 0) then
        AddValue(Gold, 234)
        return
    elseif IsAtLeast(DayOfWeek, 1) then
        AddValue(Gold, 267)
        return
    elseif IsAtLeast(DayOfWeek, 2) then
        AddValue(Gold, 250)
        return
    elseif IsAtLeast(DayOfWeek, 3) then
        AddValue(Gold, 291)
        return
    elseif IsAtLeast(DayOfWeek, 4) then
        AddValue(Gold, 244)
        return
    elseif IsAtLeast(DayOfWeek, 5) then
        AddValue(Gold, 285)
        return
    elseif IsAtLeast(DayOfWeek, 6) then
        AddValue(Gold, 273)
        return
    else
        return
    end
end)

RegisterGlobalEvent(1262, nil, function()
    evt.SetMessage("这箱矿砂你们拿去吧。只要把它交给拜尔德斯的阿尔文・伯纳克劳德，他会好好酬谢你们的，他制造玻璃瓶必须得用这个东西。")
    ClearQBit(QBit(767))
    if IsAtLeast(Gold, 2000) then
        if not IsAtLeast(Gold, 2000) then
            return
        end
        SubtractValue(Gold, 2000)
        AddValue(InventoryItem(1497), 1497)
        SetQBit(QBit(765))
        SetQBit(QBit(771))
        SetValue(Counter(7), 0)
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(1262, function()
    evt._BeginCanShowTopic(1262)
    local visible = true
    if IsQBitSet(QBit(767)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(771)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(1263, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1499) then return end
    evt.SetMessage("啊，伊弗农又给我送恩洛斯好酒来了，亏他还能想到我。这是你们的报酬，请收下吧。")
    RemoveItem(1499)
    evt.ForPlayer(Players.Current)
    if IsAtLeast(Counter(9), 24) then
        if IsAtLeast(Counter(9), 120) then
            if IsAtLeast(Counter(9), 240) then
                AddValue(Gold, 2500)
                return
            end
            AddValue(Gold, 2250)
            return
        end
        AddValue(Gold, 2750)
        return
    end
    AddValue(Gold, 3000)
end)

RegisterGlobalEvent(1264, nil, function()
    evt.SetMessage("请把这箱玻璃瓶交给住在埃里的伊弗农。他可以用它们来盛恩洛斯的美酒了。")
    ClearQBit(QBit(765))
    if IsAtLeast(Gold, 2000) then
        if not IsAtLeast(Gold, 2000) then
            return
        end
        SubtractValue(Gold, 2000)
        AddValue(InventoryItem(1498), 1498)
        SetQBit(QBit(766))
        SetQBit(QBit(772))
        SetValue(Counter(8), 0)
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(1264, function()
    evt._BeginCanShowTopic(1264)
    local visible = true
    if IsQBitSet(QBit(765)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(772)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(1265, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1497) then return end
    evt.SetMessage("卡林德拉・高登塞特给我送矿砂来了，谢谢你们，这是你们的报酬，请收下吧。")
    RemoveItem(1497)
    evt.ForPlayer(Players.Current)
    if IsAtLeast(Counter(7), 24) then
        if IsAtLeast(Counter(7), 120) then
            if IsAtLeast(Counter(7), 240) then
                AddValue(Gold, 2500)
                return
            end
            AddValue(Gold, 2250)
            return
        end
        AddValue(Gold, 2750)
        return
    end
    AddValue(Gold, 3000)
end)

RegisterGlobalEvent(1266, nil, function()
    evt.SetMessage("这箱恩洛斯美酒你们拿去吧，去把它交给泰塔利亚的卡林德拉・高登塞特，他会好好酬谢你们的。")
    ClearQBit(QBit(766))
    if IsAtLeast(Gold, 2000) then
        if not IsAtLeast(Gold, 2000) then
            return
        end
        SubtractValue(Gold, 2000)
        AddValue(InventoryItem(1499), 1499)
        SetQBit(QBit(767))
        SetQBit(QBit(773))
        SetValue(Counter(9), 0)
        return
    end
    evt.SetMessage("你的金币不够。")
end)
RegisterCanShowTopic(1266, function()
    evt._BeginCanShowTopic(1266)
    local visible = true
    if IsQBitSet(QBit(766)) then
        visible = true
        return visible
    else
        if IsQBitSet(QBit(773)) then
            visible = false
            return visible
        else
            visible = true
            return visible
        end
    end
end)

RegisterGlobalEvent(1267, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(1498) then return end
    evt.SetMessage("阿尔文・伯纳克劳德有给我送玻璃瓶来了。现在可以用它们来装恩洛斯的美酒了。谢谢你们，这是你们的报酬，请收下吧。")
    RemoveItem(1498)
    evt.ForPlayer(Players.Current)
    if IsAtLeast(Counter(8), 24) then
        if IsAtLeast(Counter(8), 120) then
            if IsAtLeast(Counter(8), 240) then
                AddValue(Gold, 2500)
                return
            end
            AddValue(Gold, 2250)
            return
        end
        AddValue(Gold, 2750)
        return
    end
    AddValue(Gold, 3000)
end)

RegisterGlobalEvent(1268, nil, function()
    evt.SetMessage("这艘船的航班如下：周二、周四、周六开往埃拉西亚，周一、周三开往布拉卡达，周五开往埃里。如果你们完成了升职为神甫的任务，可以在周日坐这艘船去埃弗蒙。")
end)

RegisterGlobalEvent(1269, nil, function()
    evt.SetMessage("你们要通过地道到尼根去，就得走左边的岔道。很多人喜欢走右边的岔道，结果进去后再也没出来。当然，他们可能确实到了尼根，不过是被邪术师押送过去的！")
end)

RegisterGlobalEvent(1270, nil, function()
    evt.SetMessage("埃拉西亚有许多商人常雇人帮他们搬运物品。如果你们缺钱花，可以去那些商人那里干这种活。")
end)

RegisterGlobalEvent(1271, nil, function()
    evt.CastSpell(5, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1272, nil, function()
    evt.CastSpell(36, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1273, nil, function()
    evt.CastSpell(83, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1274, nil, function()
    evt.CastSpell(17, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1275, nil, function()
    evt.CastSpell(25, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1276, nil, function()
    evt.CastSpell(3, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1277, nil, function()
    evt.CastSpell(51, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1278, nil, function()
    evt.CastSpell(8, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1279, nil, function()
    evt.CastSpell(58, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1280, nil, function()
    evt.CastSpell(69, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1281, nil, function()
    evt.CastSpell(38, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1282, nil, function()
    evt.CastSpell(14, 5, 4, 0, 0, 0, 0, 0, 0)
end)

RegisterGlobalEvent(1283, nil, function()
    if IsPlayerBitSet(PlayerBit(31)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualMight, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(31))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(1284, nil, function()
    if IsPlayerBitSet(PlayerBit(32)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualEndurance, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(32))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(1285, nil, function()
    if IsPlayerBitSet(PlayerBit(33)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualIntellect, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(33))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(1286, nil, function()
    if IsPlayerBitSet(PlayerBit(34)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualPersonality, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(34))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(1287, nil, function()
    if IsPlayerBitSet(PlayerBit(35)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualAccuracy, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(35))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(1288, nil, function()
    if IsPlayerBitSet(PlayerBit(36)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualSpeed, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(36))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(1289, nil, function()
    if IsPlayerBitSet(PlayerBit(37)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualLuck, 25) then
        AddValue(SkillPoints, 3)
        evt.StatusText("你获胜了！技能点数  +3")
        SetPlayerBit(PlayerBit(37))
    else
        evt.StatusText("你在这场游戏中失败了。")
    end
end)

RegisterGlobalEvent(1290, nil, function()
    if IsPlayerBitSet(PlayerBit(38)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualMight, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(38))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(1291, nil, function()
    if IsPlayerBitSet(PlayerBit(39)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualEndurance, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(39))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(1292, nil, function()
    if IsPlayerBitSet(PlayerBit(40)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualIntellect, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(40))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(1293, nil, function()
    if IsPlayerBitSet(PlayerBit(41)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualPersonality, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(41))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(1294, nil, function()
    if IsPlayerBitSet(PlayerBit(42)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualAccuracy, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(42))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(1295, nil, function()
    if IsPlayerBitSet(PlayerBit(43)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualSpeed, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(43))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(1296, nil, function()
    if IsPlayerBitSet(PlayerBit(44)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualLuck, 50) then
        AddValue(SkillPoints, 5)
        evt.StatusText("你获胜了！技能点数  +5")
        SetPlayerBit(PlayerBit(44))
    else
        evt.StatusText("你在这场竞赛中失败了。")
    end
end)

RegisterGlobalEvent(1297, nil, function()
    if IsPlayerBitSet(PlayerBit(45)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualMight, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(45))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(1298, nil, function()
    if IsPlayerBitSet(PlayerBit(46)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualEndurance, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(46))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(1299, nil, function()
    if IsPlayerBitSet(PlayerBit(47)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualIntellect, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(47))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(1300, nil, function()
    if IsPlayerBitSet(PlayerBit(48)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualPersonality, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(48))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(1301, nil, function()
    if IsPlayerBitSet(PlayerBit(49)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualAccuracy, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(49))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(1302, nil, function()
    if IsPlayerBitSet(PlayerBit(50)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualSpeed, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(50))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(1303, nil, function()
    if IsPlayerBitSet(PlayerBit(51)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualLuck, 100) then
        AddValue(SkillPoints, 7)
        evt.StatusText("你获胜了！技能点数  +7")
        SetPlayerBit(PlayerBit(51))
    else
        evt.StatusText("你在这场测试中失败了。")
    end
end)

RegisterGlobalEvent(1304, nil, function()
    if IsPlayerBitSet(PlayerBit(52)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualMight, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(52))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(1305, nil, function()
    if IsPlayerBitSet(PlayerBit(53)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualEndurance, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(53))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(1306, nil, function()
    if IsPlayerBitSet(PlayerBit(54)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualIntellect, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(54))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(1307, nil, function()
    if IsPlayerBitSet(PlayerBit(55)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualPersonality, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(55))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(1308, nil, function()
    if IsPlayerBitSet(PlayerBit(56)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualAccuracy, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(56))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(1309, nil, function()
    if IsPlayerBitSet(PlayerBit(57)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualSpeed, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(57))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(1310, nil, function()
    if IsPlayerBitSet(PlayerBit(58)) then
        evt.StatusText("你已经获胜了！")
        return
    elseif IsAtLeast(ActualLuck, 200) then
        AddValue(SkillPoints, 10)
        evt.StatusText("你获胜了！技能点数  +10")
        SetPlayerBit(PlayerBit(58))
    else
        evt.StatusText("你在这场挑战中失败了。")
    end
end)

RegisterGlobalEvent(1311, nil, function()
    evt.SetMessage("什么！你们该不会相信这种胡编的谣言吧？我从未想过破坏你们对本地区的领导！唉！算了，受死吧！")
    evt.SetMonGroupBit(84, MonsterBits.Invisible, 1)
    evt.SetMonGroupBit(85, MonsterBits.Invisible, 0)
end)
RegisterCanShowTopic(1311, function()
    evt._BeginCanShowTopic(1311)
    local visible = true
    if HasItem(1518) then
        visible = true
        return visible
    else
        visible = false
        return visible
    end
end)

RegisterGlobalEvent(1312, nil, function()
    evt.SetMessage("听说哈蒙代尔东南面的祭坛可以把人传送到巨人领地，可是我试了几次，一点反应都没有。你们不妨去碰碰运气，说不定能成功。")
end)

RegisterGlobalEvent(1313, nil, function()
    evt.SetMessage("这里到处都有技能挑战。如果你们能力足够高，挑战获胜的话，就可以得到技能点数作为奖励。")
end)

RegisterGlobalEvent(1314, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2125) then
        evt.SetMessage("我曾受人重托，付钱给拿着蜡封信件的人，你没有蜡封的信件，我不能给你钱。")
        return
    end
    evt.SetMessage("哦，是蜡封的信。这些钱是给你的。快走吧，免得被人看见我们俩在一起，会被人怀疑的。")
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 1000)
    evt.SetNPCTopic(786, 0, 1315) -- 安多弗・波特皮洛 topic 0: 信件
    ClearQBit(QBit(1105)) -- 向新索匹格镇的安多弗・波特皮洛出示舒尔曼的信。
    SetQBit(QBit(1106)) -- 把舒尔曼的信带给铁拳城堡的威尔伯・汉弗里摄政王。
end)

RegisterGlobalEvent(1315, nil, function()
    evt.SetMessage("别说我没付你报酬，你得到的金币是我的。")
end)

RegisterGlobalEvent(1316, nil, function()
    evt.SetMessage("镇南有座堡垒名叫大耳怪前哨。当初是为了抵御大耳怪侵袭而造。因为近来平安无事，就逐渐被遗忘了。谁知大耳怪却趁虚而入，占据了这个堡垒，真令我们羞愧万分。更糟的是，他们把通往地下洞穴的大门的锁也换了。如果有人能解开密码，打开这扇大门，我们会奖励他2000个金币。")
    evt.SetNPCTopic(1076, 0, 1317) -- 贾尼斯 topic 0: 大耳怪前哨
    SetQBit(QBit(1107)) -- 找到大耳怪前哨宝库门的密码并返回新索匹格镇的市政厅。
    AddValue(InventoryItem(2109), 2109)
end)

RegisterGlobalEvent(1317, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2163) then
        evt.SetMessage("难道你站在这里就能解开密码吗？加油干吧。")
        return
    end
    evt.SetMessage("啊，感谢你为我们解决了这个麻烦。这是你该拿的金币。你尽可放心回大耳怪前哨去解决残留的怪兽，我们不会付钱了，但堡垒里的东西你尽管拿吧。")
    SetAward(Award(95))
    AddValue(Experience, 2000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 2000)
    AddValue(131307, 2)
    ClearQBit(QBit(1107)) -- 找到大耳怪前哨宝库门的密码并返回新索匹格镇的市政厅。
    evt.SetNPCTopic(1076, 0, 1318) -- 贾尼斯 topic 0: 邪恶祭祀
    evt.MoveNPC(1081, 0) -- 尤克 -> removed
    evt.MoveNPC(828, 1463) -- 萨穆森・德斯 -> 房屋
end)

RegisterGlobalEvent(1318, nil, function()
    evt.SetMessage("你在大耳怪前哨干得不错。我们想再次和你合作。一个教派前些天占据了西面的一个废庙。为了筹集他们宗教洗礼仪式的费用，他们在通往铁拳城堡的路上打劫过路客商。我们向摄政王上告，可他说他的军队全在西方，然后又王顾左右而言它。我们实在无法忍受，如果你能除掉他们，并把美妙钟琴带回来作证，我们就奖励你5000个金币。")
    evt.SetNPCTopic(1076, 0, 1319) -- 贾尼斯 topic 0: 邪恶祭祀
    SetQBit(QBit(1108)) -- 从羊鸣庙里找到美妙钟琴并返回新索匹格镇的市政厅。
end)

RegisterGlobalEvent(1319, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2095) then
        evt.SetMessage("你没带来美妙钟琴，我无法给你报酬。")
        return
    end
    evt.SetMessage("干得好，这些金币是你的。对你的行侠仗义之举我不胜感激。现在通往铁拳城堡的大路一定安全多了。")
    RemoveItem(2095)
    AddValue(Experience, 10000)
    SetAward(Award(96))
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 5000)
    AddValue(131307, 2)
    ClearQBit(QBit(1108)) -- 从羊鸣庙里找到美妙钟琴并返回新索匹格镇的市政厅。
    evt.SetNPCTopic(1076, 0, 1320) -- 贾尼斯 topic 0: 邪恶祭祀
end)

RegisterGlobalEvent(1320, nil, function()
    evt.SetMessage("通往铁拳城堡之路现在畅通无阻了，我们对你非常满意。")
end)

RegisterGlobalEvent(1321, nil, function()
    evt.SetMessage("鸣月的主人名叫乔治・坎尼斯，那可是个好地方，代我向他问好。")
end)

RegisterGlobalEvent(1322, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2125) then
        evt.SetMessage("欢迎你们，我的勇士们，你们给我带来什么好东西了吗？我可是个大忙人，没空和你们多罗嗦。")
        return
    end
    evt.SetMessage("感谢你给我梢来这些信。<威尔伯开始读信>。我的担心由来已久。真是不幸。哦，不，叛徒，到处是叛徒和阴谋家。我必须立刻组织远征军。<威尔伯降低嗓音>我想你不会把这些信告诉王子的。他一直给郁郁寡欢，情绪低沉，不能再受这些消息打击了。现在我必须召集远征军将领。这袋金币是给你的报酬。我对你很满意。现在我要物色个人去寻找科尔本爵士。")
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 5000)
    evt.ForPlayer(Players.All)
    SetAward(Award(100))
    RemoveItem(2125)
    ClearQBit(QBit(1205))
    ClearQBit(QBit(1106)) -- 把舒尔曼的信带给铁拳城堡的威尔伯・汉弗里摄政王。
    ClearQBit(QBit(1105)) -- 向新索匹格镇的安多弗・波特皮洛出示舒尔曼的信。
    AddValue(Experience, 3000)
    evt.SetNPCTopic(789, 0, 1323) -- 威尔伯・汉弗里 topic 0: 科尔本爵士
end)

RegisterGlobalEvent(1323, nil, function()
    evt.SetMessage("<威尔伯打了个响指>你不会介意帮我个小忙吧。科尔本爵士在布莱克郡地区失踪了。你尽力去打探他的下落，带回音信。如果他真的被恶魔所杀，请尽可能把他的盾牌带回来。我会为你在高级议会多说好话的。你得到的回报将会非常丰厚。")
    SetQBit(QBit(1110)) -- 找到科尔本爵士的盾牌并返回铁拳城堡向威尔伯・汉弗里报告。
    evt.SetNPCTopic(789, 0, 1324) -- 威尔伯・汉弗里 topic 0: 科尔本爵士
end)

RegisterGlobalEvent(1324, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2119) then
        evt.SetMessage("嗯，还没找到盾牌？再努力一把吧，知道他的行踪对我们非常重要。")
        return
    end
    evt.SetMessage("啊，一个高贵的骑士竟被如此肮脏的怪物所杀，真是不幸。你做了件好事，把他的盾牌带回来了。我保证他和他的部下会得到应有的荣誉。我欠你一个人情，所以在高级议会上我会全力帮助你。这是你的酬劳。")
    RemoveItem(2119)
    ClearQBit(QBit(1206))
    AddValue(Experience, 40000)
    SetAward(Award(57))
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 5000)
    AddValue(655595, 10)
    evt.SetNPCTopic(789, 0, 1325) -- 威尔伯・汉弗里 topic 0: 高级议会
    ClearQBit(QBit(1110)) -- 找到科尔本爵士的盾牌并返回铁拳城堡向威尔伯・汉弗里报告。
    evt.ForPlayer(Players.All)
    if not HasAward(Award(63)) then return end
    if not HasAward(Award(57)) then return end
    if not HasAward(Award(58)) then return end
    if not HasAward(Award(59)) then return end
    if not HasAward(Award(60)) then return end
    if not HasAward(Award(61)) then return end
    if HasAward(Award(62)) then
        SetQBit(QBit(1191))
    end
end)

RegisterGlobalEvent(1325, nil, function()
    if not HasAward(Award(63)) then
        evt.SetMessage("我已经绝对信任你了，我会在高级议会里投你的赞成票。我已派人叫斯里克・席尔瓦托恩代我投票。我这两天公务繁忙，实在抽不出空，但我想以你的能力，会把事情安排得井井有条，不会有什么差错。")
        return
    end
    evt.SetMessage("我对你揭发叛徒和其篡位企图的行为不胜感激。我知道你还有重要任务去完成，特赐予你皇家游艇以加快行程，它会把你尽快带到隐士岛的。再次万分感谢。")
    evt.ForPlayer(Players.All)
    SetAward(Award(101))
end)

RegisterGlobalEvent(1326, nil, function()
    evt.SetMessage("我是首席圣武士，负责圣武士的升职。凡是欲升级为十字军的圣武士必须营救一名处于危难之中的少女。如果你不属圣武士职业，将被授予荣耀十字军职位，并获得丰厚的奖金。和被救的少女一起回来，我将把所有参与营救的圣武士升级为十字军。")
    SetQBit(QBit(1112)) -- 营救一名处于危难之中的少女，并带着她一同返回铁拳城堡威尔伯・汉弗里处。
    evt.SetNPCTopic(789, 1, 1327) -- 威尔伯・汉弗里 topic 1: 十字军
end)

RegisterGlobalEvent(1327, nil, function()
    if not IsQBitSet(QBit(1699)) then
        evt.SetMessage("我知道这里很少有少女处于危难之中。但这规矩是自古以来延续下来的，我不能坏了规距。再努力一把吧，我相信你会成功的。我曾听说贵族约翰・席尔瓦的女儿米拉达・席尔瓦被浓雾岛上的一伙强盗绑架了，你不妨去试一试。")
        return
    end
    evt.SetMessage("我已听说了你们勇敢救人的事迹。很高兴你和席尔瓦小姐一起平安归来。我会妥善安置她回到她的亲属那里的。干得真棒。我正式提拔你们为十字军，非圣武士职业者授予荣誉十字军职位。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 26) then
            SetValue(ClassId, 27)
            SetQBit(QBit(1635))
        else
            SetQBit(QBit(1636))
        end
    end
    AddValue(Gold, 5000)
    ClearQBit(QBit(1699))
    ClearQBit(QBit(1112)) -- 营救一名处于危难之中的少女，并带着她一同返回铁拳城堡威尔伯・汉弗里处。
    AddValue(131307, 2)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 15000)
    evt.SetNPCTopic(789, 1, 1328) -- 威尔伯・汉弗里 topic 1: 英雄
end)

RegisterGlobalEvent(1328, nil, function()
    evt.SetMessage("好吧，能成为十字军是件好事。但如能成为英雄就更好了。你也许已经猜到了将去执行什么任务――屠龙。这是难了点，可这是规矩。更难的是你们不能胡乱杀条龙来交差，你们必须杀掉长牙巨龙威瑟海德。它就住在黑摩尔城堡后面山区的山洞里，你必须把它的爪子或是牙齿带回来作为凭证。注意，它已经杀了至少12个想成为英雄的圣武士，你可得小心点。")
    SetQBit(QBit(1113)) -- 杀死盘踞于黑摩尔城堡附近一洞穴里的长牙巨龙威瑟海德，并返回铁拳城堡威尔伯・汉弗里处。
    evt.SetNPCTopic(789, 1, 1329) -- 威尔伯・汉弗里 topic 1: 英雄
end)

RegisterGlobalEvent(1329, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2075) then
        evt.SetMessage("你回来向我诉苦没有用。我不能坏了规矩。长牙巨龙威瑟海德就藏在那些岩洞里等待你的复仇之剑。快去吧。")
        return
    end
    evt.SetMessage("干得好。世上又少了一头怪兽。我正式提拔你们为英雄。荣誉十字军将获得荣誉英雄的职位。你们可终生保持此头衔。")
    AddValue(Experience, 30000)
    RemoveItem(2075)
    ClearQBit(QBit(1209))
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 27) then
            SetValue(ClassId, 28)
            SetQBit(QBit(1637))
        else
            SetQBit(QBit(1638))
        end
    end
    AddValue(327915, 5)
    ClearQBit(QBit(1113)) -- 杀死盘踞于黑摩尔城堡附近一洞穴里的长牙巨龙威瑟海德，并返回铁拳城堡威尔伯・汉弗里处。
    evt.SetNPCTopic(789, 1, 1330) -- 威尔伯・汉弗里 topic 1: 英雄
end)

RegisterGlobalEvent(1330, nil, function()
    evt.SetMessage("和王国的英雄们说话总是令人愉快。等麻烦过去再来吧，到那时候再让我们靠着炉火讲述各自光荣而又英勇的故事！")
end)

RegisterGlobalEvent(1331, nil, function()
    evt.SetMessage("皇宫里一点意思也没有，每个人都教训我该怎么做。忠诚有时真不是个好东西。自从父亲离开后，他们没让我离开城堡半步。我呆在城堡里都好几个月了。你这人似乎不是等闲之辈，带我溜出去和你一起闯荡几天怎样？我没有多少报酬给你，但我欠你一个人情，有朝一日我会报答你的。毕竟，我是王子。我从密门溜出去和你会合。")
    SetQBit(QBit(1114)) -- 哄尼古拉，让他高兴。
    SetQBit(QBit(1700))
    evt.SetNPCTopic(798, 0, 1332) -- 尼古拉・艾恩法斯特 topic 0: 马戏团
end)

RegisterGlobalEvent(1332, nil, function()
    evt.SetMessage("走，我们去马戏团看看。")
end)

RegisterGlobalEvent(1333, nil, function(continueStep)
    if continueStep == 7 then
    end
    if continueStep ~= nil then return end
    evt.MoveNPC(798, 1595) -- 尼古拉・艾恩法斯特 -> 马戏团
    ClearQBit(QBit(1700))
    evt.SetMessage("尼古拉王子趁你睡觉的时候自个儿走了。")
    ClearQBit(QBit(1114)) -- 哄尼古拉，让他高兴。
    SetQBit(QBit(1119)) -- 找到并把尼古拉王子带回铁拳城堡。
    evt.SetNPCTopic(798, 0, 1334) -- 尼古拉・艾恩法斯特 topic 0: 请原谅，陛下
    evt._PressAnyKey(1333, 7)
end)

RegisterGlobalEvent(1334, nil, function()
    evt.SetMessage("咳，<微笑>你相信如果我迷了路，这些好心人会把我带回家吗？我自己也不信。我想我该回城堡去了。")
    SetQBit(QBit(1700))
    evt.SetNPCTopic(798, 0, 1335) -- 尼古拉・艾恩法斯特 topic 0: 请原谅，陛下
end)

RegisterGlobalEvent(1335, nil, function()
    evt.SetMessage("我们该回铁拳城堡了。")
end)

RegisterGlobalEvent(1337, nil, function()
    evt.SetMessage("感谢你带我回家，我欠你一个人情。")
end)

RegisterGlobalEvent(1338, nil, function()
    evt.SetMessage("大家都说我的叔叔心怀叵测，不是个好人。他几乎从我父亲那篡位成功。但我们粉碎了他的阴谋。父亲命坦耐尔把叔叔变成石头，关在图书馆里。那里好久没人去了。")
end)

RegisterGlobalEvent(1339, nil, function()
    evt.SetMessage("你要搭救阿基巴德？如果是神使指示我们这样做，我们就照办吧。但一旦自由了，他一定会成为我们的麻烦的。我知道把他变成石头的那个神铃藏在哪里。但没有第三只眼我没法打开家里地下室的门。打开门需要三颗宝石，我已经得到了两颗，一颗在我父亲的皇冠上，一颗在他的权杖里。但他没告诉我第三颗，也就是“第三只眼”在哪里。如果你能找到，我就能打开地下室，取出神铃。")
    SetQBit(QBit(1120)) -- 找到第三只眼并把它交给铁拳城堡的尼古拉王子。
    evt.SetNPCTopic(798, 1, 1340) -- 尼古拉・艾恩法斯特 topic 1: 阿基巴德叔叔
    evt.SetNPCTopic(793, 1, 0) -- 神使 topic 1 cleared
end)

RegisterGlobalEvent(1340, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2066) then
        evt.SetMessage("没有第三只眼，我无法进入地下室，得到解救阿基巴德的神铃。但我想父亲一定是把它藏在这周围，这样一旦需要，他就可以随时拿出来打开地下室的门。")
        return
    end
    evt.SetMessage("你找到第三只眼了，你真行。你等着，神铃就在地下室。<尼古拉跑出加冕殿，不一会儿就回来了>我找到它了，给你！")
    RemoveItem(2066)
    ClearQBit(QBit(1220))
    ClearQBit(QBit(1120)) -- 找到第三只眼并把它交给铁拳城堡的尼古拉王子。
    evt.ForPlayer(Players.Current)
    AddValue(InventoryItem(2081), 2081)
    SetQBit(QBit(1221))
    evt.SetNPCTopic(798, 1, 1341) -- 尼古拉・艾恩法斯特 topic 1: 阿基巴德叔叔
end)

RegisterGlobalEvent(1341, nil, function()
    evt.SetMessage("我希望你明白自己在干什么，我叔叔可是个臭名昭著的叛徒。")
end)

RegisterGlobalEvent(1343, nil, function()
    if IsQBitSet(QBit(1201)) then return end
    evt.SetMessage("等一下，坦耐尔，只要你让我……哟，<阿基巴德沉默了好一阵子>很感谢你把我从石头的禁锢中解救出来。你说你需要一个我发明的咒语？<阿基巴德从书柜中抽出一个卷轴>好，我把虚空仪式书送给你，做为回报。好好用它吧。所以现在，你肯定很忙，我也是…<阿基巴德挥了挥手就无影无踪了>")
    AddValue(InventoryItem(2164), 2164)
    ClearQBit(QBit(1221))
    SetQBit(QBit(1201))
    ClearQBit(QBit(1121))
    ClearQBit(QBit(1259)) -- 从铁拳城堡皇家图书馆阿基巴德处获得神秘的魔法。
    SetQBit(QBit(1222))
    evt.ForPlayer(Players.All)
    SubtractValue(3277035, 50)
    AddValue(Experience, 50000)
    evt.MoveNPC(797, 0) -- 阿基巴德・艾恩法斯特 -> removed
end)

RegisterGlobalEvent(1344, nil, function()
    evt.SetMessage("感谢你把我从这群坏蛋手里解救出来。我该怎样来报答你呢？")
    SetQBit(QBit(1699))
    SetQBit(QBit(1151))
end)

RegisterGlobalEvent(1345, nil, function()
    evt.SetMessage("我的传统职责是监督王国中那些，嗯，不那么正规的商务活动。这样的活动会永远存在，存在即合理，只需适当的监督和管理。我的家族就在这种理念下做了几百年。但近来，有个自诩为“盗贼王子”的人开始破坏我在自由天堂的权威，还和一个新近崛起的邪恶教派狼狈为奸，那个教派好像叫做什么牛鸣教，或是猫喵教，也许是狗吠教，反正就是动物的叫声。有消息说该教派企图阴谋推翻国王，统治整个恩洛斯。总之是个恶劣的活动，必须要阻止他们。如果你能抓到盗贼王子并把他活捉回来，我会重重奖励你一番。")
    SetQBit(QBit(1122)) -- 擒获盗贼王子并把他押送回斯通城堡安东尼・斯通爵士处。
    evt.SetNPCTopic(801, 0, 1346) -- 安东尼・斯通 topic 0: 盗贼王子
end)

RegisterGlobalEvent(1346, nil, function()
    if not IsQBitSet(QBit(1701)) then
        evt.SetMessage("我对他的行踪一无所知，你问我也是白问。去自由天堂问问吧，他在城市附近肯定有个据点。<微笑>如果你找到他的住处，千万别忘了检查床底下和衣柜里，他说不定就藏在衣服堆里。")
        return
    end
    ClearQBit(QBit(1122)) -- 擒获盗贼王子并把他押送回斯通城堡安东尼・斯通爵士处。
    evt.SetMessage("啊，我的朋友，你把俘虏带回来了，干得真不错！这是给你的报酬。你将得到我在议会的全力支持。<看着盗贼王子>欢迎光临我的寒舍，全能的王子。我为你准备了一个小房间。卫兵，把他带走。")
    evt.SetNPCTopic(801, 0, 1347) -- 安东尼・斯通 topic 0: 高级议会
    AddValue(Gold, 10000)
    AddValue(655595, 10)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 30000)
    SetAward(Award(60))
    ClearQBit(QBit(1701))
    evt.SetNPCTopic(802, 0, 1347) -- 盗贼王子 topic 0: 高级议会
    evt.ForPlayer(Players.All)
    if not HasAward(Award(63)) then return end
    if not HasAward(Award(57)) then return end
    if not HasAward(Award(58)) then return end
    if not HasAward(Award(59)) then return end
    if not HasAward(Award(60)) then return end
    if not HasAward(Award(61)) then return end
    if HasAward(Award(62)) then
        SetQBit(QBit(1191))
    end
end)

RegisterGlobalEvent(1347, nil, function()
    evt.SetMessage("你一举擒获盗贼王子，真是了不起。你帮了我的大忙，我会在高级议会里全力支持你的。")
end)

RegisterGlobalEvent(1348, nil, function()
    evt.SetMessage("我是非正规商业的监管人兼恩洛斯的大主教。负责牧师至神甫和神甫至光明主教的升职。现在神甫的名额满了，没有空缺，我无法补充新人。但如果有人为王国立下奇功，可以得到破格升职。<揉了揉太阳穴>现在就有一个机会。几个月前，自由天堂的一处神庙被烈火所毁。如果你们能重建神庙，我就可以把你们之中的牧师升级为神甫，其他人授于荣誉神甫职位，并付给你们一大笔酬金。你需要雇一个石匠和一个木匠，并告诉他们如何重建神庙。")
    SetQBit(QBit(1129)) -- 雇一个石匠和一个木匠，并把他们带到自由天堂的斯通神庙去修复该神庙，然后回到斯通城堡的安东尼・斯通爵士处。
    evt.SetNPCTopic(801, 1, 1349) -- 安东尼・斯通 topic 1: 神甫
end)

RegisterGlobalEvent(1349, nil, function()
    if not IsQBitSet(QBit(1130)) then
        evt.SetMessage("我要你修建的神庙仍是一片废墟。那里的人们失去了他们灵魂的安慰所，而你却空手而归。做事必须有始有终，快去做吧。")
        return
    end
    evt.SetMessage("干得好极了！神庙修好了，神的愤怒也平息了。我将把你们中的牧师升职为神甫，其他人授予荣誉神甫职位。祝贺你们！")
    ClearQBit(QBit(1129)) -- 雇一个石匠和一个木匠，并把他们带到自由天堂的斯通神庙去修复该神庙，然后回到斯通城堡的安东尼・斯通爵士处。
    evt.SetNPCTopic(801, 1, 1350) -- 安东尼・斯通 topic 1: 大主教
    AddValue(131307, 2)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 15000)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 4) then
            SetValue(ClassId, 5)
            SetQBit(QBit(1647))
        else
            SetQBit(QBit(1648))
        end
    end
end)

RegisterGlobalEvent(1350, nil, function()
    evt.SetMessage("刚升职为神甫，就想再升为光明主教，这未免太仓促了些。许多人为得到这一职位等了一生，死后方才如愿以偿。除非你立下惊天动地的大功劳。现在倒有件现成的。一个邪教僧侣偷走了圣杯，他就住在自由天堂东边的小岛上。如果你能把圣杯夺回来，放入你修好的神庙内，就能被提拔为光明主教。")
    SetQBit(QBit(1131)) -- 前往自由天堂东面的岛屿的神庙，从众僧侣手中夺得圣杯并把它带回到自由天堂的斯通神庙，然后返回斯通城堡见斯通爵士。
    evt.SetNPCTopic(801, 1, 1351) -- 安东尼・斯通 topic 1: 大主教
end)

RegisterGlobalEvent(1351, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(1132)) then
        evt.SetMessage("干得好极了！我将履行我的诺言，将你们破格提拔。你们中的神甫将被提拔为大主教，荣誉神甫提拔为荣誉大主教。")
        for _, player in ipairs(PartyMembers()) do
            evt.ForPlayer(player)
            if IsAtLeast(ClassId, 5) then
                SetValue(ClassId, 6)
                SetQBit(QBit(1649))
            else
                SetQBit(QBit(1650))
            end
        end
        AddValue(327915, 5)
        ClearQBit(QBit(1131)) -- 前往自由天堂东面的岛屿的神庙，从众僧侣手中夺得圣杯并把它带回到自由天堂的斯通神庙，然后返回斯通城堡见斯通爵士。
        evt.ForPlayer(Players.All)
        AddValue(Experience, 30000)
        evt.SetNPCTopic(801, 1, 1352) -- 安东尼・斯通 topic 1: 大主教
    elseif HasItem(2054) then
        evt.SetMessage("你终于找到圣杯了。干得好！但还要把它安置在神庙里。快去吧，干完后你就可获得升职。")
    else
        evt.SetMessage("邪教僧侣仍霸占着圣杯，我们的神庙没有这样一件圣物可不行。你还等什么？")
    end
end)

RegisterGlobalEvent(1352, nil, function()
    evt.SetMessage("你升职为光明主教的速度令我惊讶，你是我一生中见过的最出色的光明主教。我代表整个恩洛斯王国为你所作的一切表示衷心感谢。")
end)

RegisterGlobalEvent(1353, nil, function()
    evt.SetMessage("嘿，你好。你在地板上铺瓷砖吗？噢，对不起，我一下子想不起你到底是谁？哦，欢迎你，大法师。也许你能抽空帮我解决一两个魔法实验的小问题。")
end)

RegisterGlobalEvent(1354, nil, function()
    evt.SetMessage("这是%s，%s的月份。去%s的神坛并在那里祈祷吧，你会得到奖赏的。")
    evt.SetNPCTopic(794, 0, 1355) -- 先知 topic 0: 任务
end)

RegisterGlobalEvent(1355, nil, function()
    evt.SetMessage("你必须等到新的一个月开始才可以进行朝拜。")
end)

RegisterGlobalEvent(1356, nil, function()
    evt.SetMessage("做出了惊人的事迹")
end)

RegisterGlobalEvent(1359, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(1105)) then -- 向新索匹格镇的安多弗・波特皮洛出示舒尔曼的信。
        evt.SetMessage("你不妨向新索匹格镇的安多弗・波特皮洛出示那封信件。")
        SetAutonote(479)
        return
    elseif IsQBitSet(QBit(1106)) then -- 把舒尔曼的信带给铁拳城堡的威尔伯・汉弗里摄政王。
        evt.SetMessage("你必须把信交给铁拳城堡的摄政王威尔伯・汉弗里。")
        SetAutonote(478)
        return
    elseif IsAtLeast(BaseLevel, 25) then
        if not HasAward(Award(57)) then
            evt.SetMessage("要拜见神使，必须先使自由天堂高级议会的六个议员满意。恩洛斯六爵士每位都会给你布置一项任务，完成这项任务后，这名爵士在议会中的代表就会支持你。一旦议员一致通过，你就可以拜见神使了。")
            SetAutonote(476)
            return
        end
        if not HasAward(Award(58)) then
            evt.SetMessage("要拜见神使，必须先使自由天堂高级议会的六个议员满意。恩洛斯六爵士每位都会给你布置一项任务，完成这项任务后，这名爵士在议会中的代表就会支持你。一旦议员一致通过，你就可以拜见神使了。")
            SetAutonote(476)
            return
        end
        if not HasAward(Award(59)) then
            evt.SetMessage("要拜见神使，必须先使自由天堂高级议会的六个议员满意。恩洛斯六爵士每位都会给你布置一项任务，完成这项任务后，这名爵士在议会中的代表就会支持你。一旦议员一致通过，你就可以拜见神使了。")
            SetAutonote(476)
            return
        end
        if not HasAward(Award(60)) then
            evt.SetMessage("要拜见神使，必须先使自由天堂高级议会的六个议员满意。恩洛斯六爵士每位都会给你布置一项任务，完成这项任务后，这名爵士在议会中的代表就会支持你。一旦议员一致通过，你就可以拜见神使了。")
            SetAutonote(476)
            return
        end
        if not HasAward(Award(61)) then
            evt.SetMessage("要拜见神使，必须先使自由天堂高级议会的六个议员满意。恩洛斯六爵士每位都会给你布置一项任务，完成这项任务后，这名爵士在议会中的代表就会支持你。一旦议员一致通过，你就可以拜见神使了。")
            SetAutonote(476)
            return
        end
        if not HasAward(Award(62)) then
            evt.SetMessage("要拜见神使，必须先使自由天堂高级议会的六个议员满意。恩洛斯六爵士每位都会给你布置一项任务，完成这项任务后，这名爵士在议会中的代表就会支持你。一旦议员一致通过，你就可以拜见神使了。")
            SetAutonote(476)
            return
        end
        if not IsQBitSet(QBit(1192)) then
            evt.SetMessage("看起来斯里克・席尔瓦托恩就是隐藏在议会中的叛徒。你必须用证据说服摄政王威尔伯・汉弗里，把叛徒逐出议会。你得到克里格斯的顶级羊鸣庙去一趟，把斯里克和羊鸣教阴谋勾结的确凿证据带回来。")
            SetAutonote(475)
            return
        end
        if not HasAward(Award(75)) then
            evt.SetMessage("在阿基巴德对神使动了手脚之后，神使就沉睡至今。要使其重新觉醒，你需要四块记忆水晶。它们分别在隐士岛、阿拉莫斯城堡、克里格斯城堡和黑摩尔城堡。")
            SetAutonote(474)
            return
        end
        if not HasItem(1666) then return end
        if not HasItem(1667) then
            evt.SetMessage("要进入控制中心，必须先得到飞龙沙漠维兰神殿内的控制块。把控制块交还给神使，就可以进入控制中心了。克里根人的反应器免疫任何类似的攻击，它的唯一克星是控制中心内储存的上古兵器。你一定要拿到这些兵器并掌握使用它们的技能。")
            SetAutonote(473)
            return
        end
        if not HasItem(2164) then
            evt.SetMessage("在破坏反应器之前，你必须取得一种能将反应器的爆炸包裹控制起来的魔法。所以你必须把阿基巴德从石化中解放出来。先和尼古拉交谈，把“第三只眼”交给他，他会让你用坦耐尔之铃使阿基巴德恢复原形。然后你就可以说服阿基巴德传授你想要的魔法。")
            SetAutonote(472)
            return
        end
        if not HasAward(Award(78)) then
            evt.SetMessage("现在你必须摧毁克里根人的蜂房，破坏反应器，击败他们的女王，然后携带着虚空仪式书从那里逃脱，任务就成功完成了。")
            SetAutonote(471)
            return
        end
        evt.SetMessage("你不再需要我的建议了。")
    else
        evt.SetMessage("我建议你在完成恩洛斯六爵士的升职任务前先提高自己。")
        SetAutonote(477)
        return
    end
end)

RegisterGlobalEvent(1360, nil, function()
    evt.SetMessage("1")
    SetQBit(QBit(1133))
    evt.SetNPCTopic(795, 0, 1361) -- 马顿・费里斯 topic 0: 普渡众生
end)

RegisterGlobalEvent(1361, nil, function()
    evt.SetMessage("2")
end)

RegisterGlobalEvent(1362, nil, function()
    evt.SetMessage("3")
end)

RegisterGlobalEvent(1364, nil, function()
    evt.SetMessage("我老是健忘，有时连自己所学的东西都记不起来。真不知道为什么。后来我发现了解决这个毛病的方法。我要发明一面镜子，通过它能回到过去，找到我遗忘的东西。镜子必须由时间沙漏磨成，但我的研究工作太忙了，抽不出空去找这东西。时间沙漏据说是在某个地方附近的黑暗洞穴里。<沉默片刻>不对，那是黑暗之矛藏的地方。<沉默片刻>我应该记得它在哪里的。<打个响指>对了，它埋在这儿南面的古堡里。如果你帮助我制造魔镜，我就在议会里支持你。")
    evt.SetNPCTopic(790, 0, 1365) -- 阿尔伯特・牛顿 topic 0: 议会任务
    SetQBit(QBit(1134)) -- 找到时间沙漏，交还给浓雾镇的阿尔伯特・牛顿爵士。
end)

RegisterGlobalEvent(1365, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(2053) then
        evt.SetMessage("现在我得回忆怎么制造魔镜。我已经把重要细节记在纸上以免遗忘。<停顿>我把纸条放哪儿了？<沉思片刻>我肯定放在什么显眼地方了。也许在实验室里。你已经完成了任务，真是万分感谢。我将在议会里全力支持你，再问一遍，你叫什么名字？")
        AddValue(Experience, 50000)
        SetAward(Award(58))
        RemoveItem(2053)
        ClearQBit(QBit(1207))
        evt.ForPlayer(Players.Current)
        AddValue(655595, 10)
        ClearQBit(QBit(1134)) -- 找到时间沙漏，交还给浓雾镇的阿尔伯特・牛顿爵士。
        evt.SetNPCTopic(790, 0, 1367) -- 阿尔伯特・牛顿 topic 0: 议会任务
        evt.ForPlayer(Players.All)
        if not HasAward(Award(63)) then return end
        if not HasAward(Award(57)) then return end
        if not HasAward(Award(58)) then return end
        if not HasAward(Award(59)) then return end
        if not HasAward(Award(60)) then return end
        if not HasAward(Award(61)) then return end
        if HasAward(Award(62)) then
            SetQBit(QBit(1191))
        end
        return
    elseif HasItem(2107) then
        evt.SetMessage("什么，时间沙漏不在那儿。哦，对了。我忘了件事。我忘把钥匙给你了。你用钥匙打开古堡<停顿>我记不清那是谁的古堡了，但我想那是时间沙漏的唯一藏身地。千万别硬闯，特别是你现在有了钥匙。<停顿>至少我想这把钥匙能打开古堡大门。你去新索匹格北面岛上的古堡，实验室，或是其它什么地方找找看。祝你好运！")
    else
        evt.SetMessage("我仍在找魔镜，<沉默>我的意思是指找时间沙漏。我把它们混一块了。你黑暗洞穴去过没有，不，你南面的古堡去过没有，我老是把东西混在一起。")
        return
    end
end)

RegisterGlobalEvent(1366, nil, function()
    evt.SetMessage("什么，时间沙漏不在那儿。哦，对了。我忘了件事。我忘把钥匙给你了。你用钥匙打开古堡<停顿>我记不清那是谁的古堡了，但我想那是时间沙漏的唯一藏身地。千万别硬闯，特别是你现在有了钥匙。<停顿>至少我想这把钥匙能打开古堡大门。你去新索匹格北面岛上的古堡，实验室，或是其它什么地方找找看。祝你好运！")
end)

RegisterGlobalEvent(1367, nil, function()
    evt.SetMessage("再次感谢你为我拿到了时间沙漏。可我把它放在哪儿去了？<叹气>我会永远在议会中支持你。")
end)

RegisterGlobalEvent(1368, nil, function()
    SetQBit(QBit(1135)) -- 喝下魔法喷泉的泉水并返回浓雾镇的阿尔伯特・牛顿爵士处。
    evt.SetNPCTopic(790, 1, 1369) -- 阿尔伯特・牛顿 topic 1: 巫师
    evt.ForPlayer(Players.All)
    if not IsAtLeast(ClassId, 42) then
        evt.SetMessage("我是首席法师，负责巫师的升职。你们没有一个人是巫师。但我做人很公正，如果你们能找到魔法喷泉，我赐予你们荣誉法师头衔。你们没有法师的法术，但会获得巫师和法师的尊敬。")
        return
    end
    evt.SetMessage("我是首席法师，专门负责巫师的升职。巫师虽然有一定法术，但在元素派法师中却算不了什么。法师会巫师的全部魔法，而且其境界更高。他们拥有比巫师更大的魔法潜力，并赢得更多的尊敬。但修炼之路并不平坦。必须找到魔法喷泉，饮其泉水，然后回来。如果你能做到这些，我就会训练你成为法师。")
end)

RegisterGlobalEvent(1369, nil, function()
    evt.SetMessage("别希望从我这里得到什么暗示。我早忘了喷泉在哪儿？我知道此任务并非轻而易举。如果简单，岂不每位巫师都成为法师了。")
end)

RegisterGlobalEvent(1371, nil, function()
    evt.SetMessage("你终于找到了喷泉，干得不错。它的地点和用处还是个秘密，千万别透露出去。现在我告诉成为法师的秘密。")
    evt.ForPlayer(Players.All)
    AddValue(Experience, 15000)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 42) then
            SetValue(ClassId, 43)
            SetQBit(QBit(1639))
        else
            SetQBit(QBit(1640))
        end
    end
    AddValue(131307, 2)
    ClearQBit(QBit(1135)) -- 喝下魔法喷泉的泉水并返回浓雾镇的阿尔伯特・牛顿爵士处。
    evt.SetNPCTopic(790, 1, 1372) -- 阿尔伯特・牛顿 topic 1: 魔法大师
end)

RegisterGlobalEvent(1372, nil, function()
    evt.SetMessage("你的法术修炼并非到此为止。还有最后一项。只有修炼到魔法大师才能把元素魔法融会贯通。根据你法师修炼的基础，魔法大师将拥有超人一等的法力。他能随时随地纯熟运用各项魔法有效攻击对手。要修炼为大法师必须有一个威力强大的宝物。它在法力无边的大法师德里尔那里。不对，不对。在弗伦德尔那里，不对，也不对。我实在记不起宝物什么样，属于谁了。但我记得我见过它。它在幽灵沼泽附近的考勒根的豪宅里。到那儿看看，把它带回来。有了它，我才能把你训练成魔法大师。")
    SetQBit(QBit(1136)) -- 找回德里克丝水晶并返回浓雾镇的阿尔伯特・牛顿爵士处。
    evt.SetNPCTopic(790, 1, 1373) -- 阿尔伯特・牛顿 topic 1: 魔法大师
end)

RegisterGlobalEvent(1373, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2077) then
        evt.SetMessage("很抱歉，我真忘了你需要什么了。我只知道你要搜查考勒根的豪宅。")
        return
    end
    evt.SetMessage("好消息，我想起你该找什么了。是德里克斯水晶。哦，你已经找到了。好极了。我可以训练你成为魔法大师了。首位大法师德里克斯就是用这块水晶来钻研元素魔法的。火，土，水，空气是元素魔法的四个要素，通过分析它们的构成就可练成此魔法。而且，德里克斯通过该魔法对光的作用而发现了光明魔法和暗黑魔法。自从那时起，每个新的魔法大师在水晶的指引下不断钻研。让我向你展示水晶的秘密，大法师。")
    AddValue(Experience, 30000)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 43) then
            SetValue(ClassId, 46)
            SetQBit(QBit(1641))
        else
            SetQBit(QBit(1642))
        end
    end
    AddValue(327915, 5)
    ClearQBit(QBit(1136)) -- 找回德里克丝水晶并返回浓雾镇的阿尔伯特・牛顿爵士处。
    evt.ForPlayer(Players.All)
    RemoveItem(2077)
    ClearQBit(QBit(1210))
    evt.SetNPCTopic(790, 1, 1353) -- 阿尔伯特・牛顿 topic 1: 大法师
end)

RegisterGlobalEvent(1374, nil, function()
    evt.SetMessage("我现在没时间多说了，我有许多事要做。我正在组建部队，攻击在西海岸的邪恶势力。你必须和我一样明白，他们才是恩洛斯安全真正的威胁。我希望其他贵族能在部队和供给方面助我一臂之力。或是帮我出谋划策。但他们总把时间花在领地，法律和贸易的争吵上，而对真正的威胁却无动于衷。恶魔们在圣蒂尼斯附近的克里格斯城堡建有前哨基地。从那儿派出小股部队，进行骚扰并窃取我军情报。我想派你潜入敌人基地，取得必要得情报并摧毁该基地。不要放走一个恶魔。记住，出其不意，攻其不备是我们的制胜法宝。")
    SetQBit(QBit(1137)) -- 摧毁恶魔据点并返回坦普城堡的奥斯里克・坦普爵士处。
    evt.SetNPCTopic(791, 0, 1375) -- 奥斯里克・坦普 topic 0: 议会任务
end)

RegisterGlobalEvent(1375, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2126) then
        evt.SetMessage("你行动失败了吗？你没让一个恶魔逃脱吧？为了整个战役的成功，一定要毁掉这个据点。它存在一天，你就得努力一天。")
        return
    end
    evt.SetMessage("干得好。根据你带回来的情报，我们掌握了敌人的战略部署。既然这个前哨已被清除，我们就能攻它个出其不意。我会在议会里全力支持你的，希望议会还能干点正事。")
    AddValue(Experience, 40000)
    SetAward(Award(59))
    RemoveItem(2126)
    ClearQBit(QBit(1208))
    evt.ForPlayer(Players.Current)
    ClearQBit(QBit(1137)) -- 摧毁恶魔据点并返回坦普城堡的奥斯里克・坦普爵士处。
    AddValue(655595, 10)
    evt.SetNPCTopic(791, 0, 1377) -- 奥斯里克・坦普 topic 0: 议会任务
    evt.ForPlayer(Players.All)
    if not HasAward(Award(63)) then return end
    if not HasAward(Award(57)) then return end
    if not HasAward(Award(58)) then return end
    if not HasAward(Award(59)) then return end
    if not HasAward(Award(60)) then return end
    if not HasAward(Award(61)) then return end
    if HasAward(Award(62)) then
        SetQBit(QBit(1191))
    end
end)

RegisterGlobalEvent(1377, nil, function()
    evt.SetMessage("你成功除掉了这些恶魔，干得真棒。我得再次感谢你。恶魔的威胁存在一天，我在议会里就会对你支持一天。希望你能督促议会早日采取行动。还有，你带回来的消息证实了我们对敌人老巢的推测。它就在甜水镇附近的天堂谷中。")
end)

RegisterGlobalEvent(1378, nil, function()
    SetQBit(QBit(1138)) -- 得到查德威克的骑士提名并返回坦普城堡的奥斯里克・坦普爵士处。
    evt.SetNPCTopic(792, 0, 1379) -- 查德威克・布莱克普尔 topic 0: 任命
    evt.SetNPCTopic(791, 1, 1381) -- 奥斯里克・坦普 topic 1: 豪侠
    evt.ForPlayer(Players.All)
    if not IsAtLeast(ClassId, 16) then
        evt.SetMessage("我是军事专家，专职负责所有骑士的升职。可惜诸位并不是骑士，因此我的技能对诸位毫无用处。但是如果诸位渴望学习的话，也可以参加升级豪侠的考验。同时寻找一位尊者的举荐，比如是一位豪侠，然后回来，我就会为你们升级。")
        return
    end
    evt.SetMessage("我是军事专家，专职负责恩洛斯所有骑士的升职。磨炼到一定级别的骑士可以升级为豪侠。豪侠拥有钢铁般坚强的意志和超人的武功。他们作战英勇无畏，往往战无不胜，令敌人闻风丧胆。但要成为一名豪侠，你最好能得到另一位豪侠的推荐。")
end)

RegisterGlobalEvent(1379, nil, function()
    evt.SetMessage("你好，听说你在寻找一位举荐人推举你为豪侠？想当年我也曾是一位英勇善战的骑士。尽管现在我已年迈，再也不能冲锋陷阵，驰骋沙场，当年我曾与罗兰德一起参与了继承王位的战争。很高兴看到奥斯利克依然保持着良好的骑士传统。告诉他我很荣幸成为你的举荐。如果他给你什么麻烦的话，让他亲自来见我。")
    evt.SetNPCTopic(791, 1, 1382) -- 奥斯里克・坦普 topic 1: 豪侠
    evt.SetNPCTopic(792, 0, 0) -- 查德威克・布莱克普尔 topic 0 cleared
end)

RegisterGlobalEvent(1380, nil, function()
    evt.SetMessage("祝贺你！我知道你能成为一名优秀的豪侠。我真希望自己能回到当年，与奥斯利克一齐屠杀恶魔。")
    evt.SetNPCTopic(792, 0, 0) -- 查德威克・布莱克普尔 topic 0 cleared
end)

RegisterGlobalEvent(1381, nil, function()
    evt.SetMessage("快来吧！像你这样有如此好的知名度和才干的人获得举荐应该毫无问题。别告诉我你只是徒有虚名，我想你一定人如其名吧？<大笑>别紧张，我只是开个玩笑。说真的，你不妨到自由天堂或洛克汉姆的村镇去转悠一下，听说那里的旅店经常有豪侠光顾。")
end)

RegisterGlobalEvent(1382, nil, function()
    evt.SetMessage("祝贺你！举荐看起来并不太重要，但根据传统要获得升级必须经过这一环节。作为豪侠，你需要懂得捍卫民众的传统和价值。我很高兴你能加入豪侠行列。")
    ClearQBit(QBit(1138)) -- 得到查德威克的骑士提名并返回坦普城堡的奥斯里克・坦普爵士处。
    AddValue(131307, 2)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 15000)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 16) then
            SetValue(ClassId, 17)
            SetQBit(QBit(1643))
        else
            SetQBit(QBit(1644))
        end
    end
    evt.SetNPCTopic(791, 1, 1383) -- 奥斯里克・坦普 topic 1: 勇士
    evt.SetNPCTopic(792, 0, 1380) -- 查德威克・布莱克普尔 topic 0: 豪侠
end)

RegisterGlobalEvent(1383, nil, function()
    evt.SetMessage("一名好豪侠最终的目的是成长为勇士。豪侠是一名勇敢高贵的斗士，而勇士还要拥有强悍的力量。没有什么力量能阻挠勇士获得胜利。整个战争胜负与否取决于那些勇敢无畏，行动敏捷，武艺惊人的勇士们。然而，升级为勇士是非常困难的。你必须打败凶恶残暴的敌人来证明你所具有的杀敌能力和坚强毅力。而称得上敌人的只有一种人，那就是军阀。他异常危险，极度残暴。他控制着恶魔骑士军团，盘据在冰风关隘的东北部。如果能打败他并取回胜利的证据，你就一定能升级为勇士。")
    SetQBit(QBit(1139)) -- 击败军阀并把证据带给奥斯里克・坦普。
    evt.SetNPCTopic(791, 1, 1384) -- 奥斯里克・坦普 topic 1: 勇士
end)

RegisterGlobalEvent(1384, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2128) then
        evt.SetMessage("你并不害怕军阀，是吗？他的恐怖统治已经到头了。如果你害怕得躲在床底下或只敢在大墙外观望，那你永远不可能成为勇士。你必须勇敢无畏的面对他并与他战斗，快去干吧。")
        return
    end
    evt.SetMessage("干得好，实在好极了！我原以为你不能活着出来。科格蒙德比我想象的还利害，然而你比他更出色。你已经证明了你具有勇士的能力。你会毫无惧色的挺身捍卫正义。现在你的敌人害怕与你交战，而你的盟友将在你的勇气鼓舞之下恢复力量和信心。现在我把你升级为勇士。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 17) then
            SetValue(ClassId, 19)
            SetQBit(QBit(1645))
        else
            SetQBit(QBit(1646))
        end
    end
    AddValue(327915, 5)
    ClearQBit(QBit(1139)) -- 击败军阀并把证据带给奥斯里克・坦普。
    evt.ForPlayer(Players.All)
    AddValue(Experience, 40000)
    RemoveItem(2128)
    ClearQBit(QBit(1211))
    evt.SetNPCTopic(791, 1, 1385) -- 奥斯里克・坦普 topic 1: 勇士
end)

RegisterGlobalEvent(1385, nil, function()
    evt.SetMessage("勇士们，见到你们真高兴。你我的时间都很宝贵。你们要去拯救整个恩洛斯王国，而我也有自己的事要干。还是等战斗结束了我们再次团聚，再来共叙我们的友谊和交流各自的传奇经历吧！")
end)

RegisterGlobalEvent(1386, nil, function()
    evt.SetMessage("阿尔法记忆水晶，目前在隐士岛。\n贝塔记忆水晶，目前在阿拉莫斯城堡。\n达尔塔记忆水晶，目前在黑摩尔城堡。\n艾普斯隆记忆水晶，目前在克里格斯城堡。")
    if IsQBitSet(QBit(1186)) then return end -- 前往超级羊鸣庙，找到阿尔法记忆水晶，把它放回到高级议会地下的恩洛斯神使的模块坛处。
    SetQBit(QBit(1186)) -- 前往超级羊鸣庙，找到阿尔法记忆水晶，把它放回到高级议会地下的恩洛斯神使的模块坛处。
    SetQBit(QBit(1187)) -- 前往阿拉莫斯城堡，找到贝塔记忆水晶，把它放回到高级议会地下的恩洛斯神使的模块坛处。
    SetQBit(QBit(1188)) -- 前往黑摩尔城堡，找到德尔塔记忆水晶，把它放回到高级议会地下的恩洛斯神使的模块坛处。
    SetQBit(QBit(1189)) -- 前往克里格斯城堡，找到伊普斯隆记忆水晶，把它放回到高级议会地下的恩洛斯神使的模块坛处。
end)

RegisterGlobalEvent(1387, nil, function()
    evt.SetMessage("把记忆水晶放在记忆模板上可唤醒神使，但这需要四块水晶同时起作用。")
end)

RegisterGlobalEvent(1389, nil, function()
    evt.ForPlayer(Players.All)
    if IsQBitSet(QBit(1190)) then -- 从飞龙沙漠的维兰坟墓中找回控制块，并返回高级议会地下的恩洛斯神使处。
        if HasItem(2076) then
            AddValue(Experience, 500000)
            SetAward(Award(76))
            ClearQBit(QBit(1190)) -- 从飞龙沙漠的维兰坟墓中找回控制块，并返回高级议会地下的恩洛斯神使处。
            RemoveItem(2076)
            ClearQBit(QBit(1219))
            evt.SetNPCTopic(793, 0, 1390) -- 神使 topic 0: 克里根人
            evt.SetNPCTopic(793, 1, 1391) -- 神使 topic 1: 古迹
            evt.SetMessage("现在你可以进入控制中心。我会将你送入中心。但是要注意；控制中心的卫兵已不再受我的指挥，所以进入中心时务必要小心谨慎。")
            return
        end
        evt.SetMessage("我是梅里安，恩洛斯的守护神。谢谢你将我的记忆模板放回原处。因为我拒绝在继承王位战争中帮助阿基巴德，他就从我这里取走了记忆模板。你的到来真是好极了。现在克里根人正在入侵我们的世界，你必须尽力去阻止他们。不幸的是，我不能直接帮助你了。阿基巴德从我这里榨取信息，使我元气大伤。我唯一能帮你就是给你一条建议。\n\n尽管普通的武器和魔法可以杀死大多数克里根人，但他们的精锐卫兵和高等部队皮肤坚硬，有着过人的自然防御力，只有非常锋利的武器才能杀伤他们。在我下面的行星控制中心里有你战斗需要的盔甲和武器。然而只有拥有控制块的人才可以进入。我的仪器告诉我恩洛斯唯一的控制块就在飞龙沙漠的地下。")
        return
    end
    SetAward(Award(75))
    SetQBit(QBit(1190)) -- 从飞龙沙漠的维兰坟墓中找回控制块，并返回高级议会地下的恩洛斯神使处。
    ClearQBit(QBit(1186)) -- 前往超级羊鸣庙，找到阿尔法记忆水晶，把它放回到高级议会地下的恩洛斯神使的模块坛处。
    ClearQBit(QBit(1187)) -- 前往阿拉莫斯城堡，找到贝塔记忆水晶，把它放回到高级议会地下的恩洛斯神使的模块坛处。
    ClearQBit(QBit(1188)) -- 前往黑摩尔城堡，找到德尔塔记忆水晶，把它放回到高级议会地下的恩洛斯神使的模块坛处。
    ClearQBit(QBit(1189)) -- 前往克里格斯城堡，找到伊普斯隆记忆水晶，把它放回到高级议会地下的恩洛斯神使的模块坛处。
    evt.SetMessage("我是梅里安，恩洛斯的守护神。谢谢你将我的记忆模板放回原处。因为我拒绝在继承王位战争中帮助阿基巴德，他就从我这里取走了记忆模板。你的到来真是好极了。现在克里根人正在入侵我们的世界，你必须尽力去阻止他们。不幸的是，我不能直接帮助你了。阿基巴德从我这里榨取信息，使我元气大伤。我唯一能帮你就是给你一条建议。\n\n尽管普通的武器和魔法可以杀死大多数克里根人，但他们的精锐卫兵和高等部队皮肤坚硬，有着过人的自然防御力，只有非常锋利的武器才能杀伤他们。在我下面的行星控制中心里有你战斗需要的盔甲和武器。然而只有拥有控制块的人才可以进入。我的仪器告诉我恩洛斯唯一的控制块就在飞龙沙漠的地下。")
end)

RegisterGlobalEvent(1390, nil, function()
    if IsQBitSet(QBit(1329)) then
        evt.SetMessage("正如我所说，普通兵器对克里根人无能为力。要除掉他们，必须找出它们降落的地点并摧毁主反应器。但主控制器一旦爆炸，会危及整个星球，因此你还得学会一种威力强大的魔法，阻止爆炸毁灭我们的星球。现在知道这种魔法的人都死光了。我只知道阿基巴德通晓这种魔法，但他现在变成了石头。更糟糕的是，普通兵器或魔法不能奈何这个反应器，你只有去拿在控制中心储存的上古兵器方能奏效。")
    elseif IsQBitSet(QBit(1120)) then -- 找到第三只眼并把它交给铁拳城堡的尼古拉王子。
        evt.SetMessage("正如我所说，普通兵器对克里根人无能为力。要除掉他们，必须找出它们降落的地点并摧毁主反应器。但主控制器一旦爆炸，会危及整个星球，因此你还得学会一种威力强大的魔法，阻止爆炸毁灭我们的星球。现在知道这种魔法的人都死光了。我只知道阿基巴德通晓这种魔法，但他现在变成了石头。更糟糕的是，普通兵器或魔法不能奈何这个反应器，你只有去拿在控制中心储存的上古兵器方能奏效。")
    else
        SetQBit(QBit(1259)) -- 从铁拳城堡皇家图书馆阿基巴德处获得神秘的魔法。
        evt.SetNPCTopic(798, 1, 1339) -- 尼古拉・艾恩法斯特 topic 1: 第三只眼
        SetQBit(QBit(1193))
        evt.SetMessage("正如我所说，普通兵器对克里根人无能为力。要除掉他们，必须找出它们降落的地点并摧毁主反应器。但主控制器一旦爆炸，会危及整个星球，因此你还得学会一种威力强大的魔法，阻止爆炸毁灭我们的星球。现在知道这种魔法的人都死光了。我只知道阿基巴德通晓这种魔法，但他现在变成了石头。更糟糕的是，普通兵器或魔法不能奈何这个反应器，你只有去拿在控制中心储存的上古兵器方能奏效。")
    end
end)

RegisterGlobalEvent(1391, nil, function()
    evt.SetMessage("尽管我的记忆已毁于阿基巴德之手，但我还记得我们自古以来势不两立的死对头克里根人是多么可怕。他们出现在1500年以前，凶残好战，疯狂抢夺他人的国土，霸占资源。其实这样做并不仅为了争夺资源，他们就像无耻的蝗虫，在一个星球上无节制的生殖繁衍，一旦这个星球支持不住了，他们会去袭击另一个星球，重新开始他们可怕的生存周期。由于他们的攻击，我们的星球交通断绝，信息闭塞，造成了历史上的寂静时代，就是我们纪年的开始。因为缺乏祖国的支持，我们的科研技术完全失灵，使我们现在处境尴尬。我本想重整旗鼓，修复技能，但在许多人的心目中我只是个宗教偶像，没有人知道我会给这个王国带来什么。也许我们现在面临的克里根人的入侵危机正是个证明我的机会。")
end)

RegisterGlobalEvent(1392, nil, function()
    evt.SetMessage("我碰巧知道你是冒险者清单上的一员，希望得到高级议会的垂青。我并不知道也不关心你到底需要什么。我是个直率的人，我喜欢钱，钱越多越好。我需要一个有能力的代理商使船费在一定期间内固定，这样我就可获利。如果你能完成这一计划，我会在议会给予你充分的支持，并给你丰厚的报酬。具体计划如下：使王国的九个船公司中都同意每磅货物每英里的运价保持在48个金币以上。他们都知道竞争非常激烈，必须保持同一价格，没人会愿意波动价格。我不管你采取什么方法使他们都同。只要你完成这一任务，就回来向我报告。")
    SetQBit(QBit(1140)) -- 稳定王国内所有9个驿站的价格并回到银湾镇的弗丽斯夫人处。
    SetQBit(QBit(1706))
    evt.SetNPCTopic(799, 0, 1393) -- 劳里达・弗丽斯 topic 0: 钱财
end)

RegisterGlobalEvent(1393, nil, function()
    if not IsQBitSet(QBit(1141)) then
        evt.SetMessage("并不是所有的船公司都同意提高价格。为什么你半途而废就回来报告？如果你完成了任务使这些傻瓜都同意得提高价格，我就可以获得暴利。难道我必须亲自出马吗？我还应该另派他人？为什么我的周围都是低能儿？你别高兴，由于你未能完成任务使我损失了巨额财产，我的损失将从你的工资中扣除。")
        return
    end
    evt.SetMessage("总算办妥了，我还以为你完不成任务。毕竟你在某些方面确实干得不错。我会在议会支持你。还有，这是你的报酬。")
    if not IsQBitSet(QBit(1707)) then
        AddValue(Gold, 25000)
        ClearQBit(QBit(1140)) -- 稳定王国内所有9个驿站的价格并回到银湾镇的弗丽斯夫人处。
        SubtractValue(655595, 10)
        evt.ForPlayer(Players.All)
        SetAward(Award(61))
        AddValue(Experience, 25000)
        evt.SetNPCTopic(799, 0, 1394) -- 劳里达・弗丽斯 topic 0: 钱财
        evt.ForPlayer(Players.All)
        if not HasAward(Award(63)) then return end
        if not HasAward(Award(57)) then return end
        if not HasAward(Award(58)) then return end
        if not HasAward(Award(59)) then return end
        if not HasAward(Award(60)) then return end
        if not HasAward(Award(61)) then return end
        if HasAward(Award(62)) then
            SetQBit(QBit(1191))
        end
        return
    end
    AddValue(Gold, 5000)
    ClearQBit(QBit(1140)) -- 稳定王国内所有9个驿站的价格并回到银湾镇的弗丽斯夫人处。
    SubtractValue(655595, 10)
    evt.ForPlayer(Players.All)
    SetAward(Award(61))
    AddValue(Experience, 25000)
    evt.SetNPCTopic(799, 0, 1394) -- 劳里达・弗丽斯 topic 0: 钱财
    evt.ForPlayer(Players.All)
    if not HasAward(Award(63)) then return end
    if not HasAward(Award(57)) then return end
    if not HasAward(Award(58)) then return end
    if not HasAward(Award(59)) then return end
    if not HasAward(Award(60)) then return end
    if not HasAward(Award(61)) then return end
    if HasAward(Award(62)) then
        SetQBit(QBit(1191))
    end
end)

RegisterGlobalEvent(1394, nil, function()
    evt.SetMessage("你不必担心我的提价会使农民遭殃。我的动机是好的。我需要更多的钱贮藏产粮区丰收后多余的粮食。这样，粮食的运费就减低，人们就能得到价廉物美的粮食。怎么样，我没你想象的那么坏吧。")
end)

RegisterGlobalEvent(1395, nil, function()
    evt.SetMessage("也许很难相信，我是这世界上的顶尖德鲁伊之一。我负责众德鲁伊的升职。一旦他们修炼到一定级别，就可以升为高级德鲁伊和大德鲁伊。要升为高级德鲁伊，必须进行太阳仪式。你们必需在每年的春秋分或冬夏至，即三月20日，六月21日，九月23日或十二月21日的正午站在石圈的中心，我会通过魔法与你联系，指导你进行整个仪式，并且将你们升级为高级德鲁伊，非德鲁伊者授予荣誉高级德鲁伊头衔。你们一定会觉得不虚此行的。")
    SetQBit(QBit(1142)) -- 在春秋分或冬夏至前往银湾镇北边的石圈拜祭太阳神坛（提示：3月20日是春分）。
    evt.SetNPCTopic(799, 1, 1396) -- 劳里达・弗丽斯 topic 1: 高级德鲁伊
end)

RegisterGlobalEvent(1396, nil, function()
    evt.SetMessage("你只有在春秋分或冬夏至的正午站在石圈中央，完成整个太阳仪式，方能升级为高级德鲁伊。除此之外别无它法。")
end)

RegisterGlobalEvent(1397, nil, function()
    evt.SetMessage("你想成为大德鲁伊，就必须完成月亮仪式。这在德鲁伊教派分裂前是件轻而易举的事，现在可就困难了。你必须杀出一条血路找到神坛。神坛在月亮神庙里，现在被邪恶的塞德里克・德鲁泽控制着。他们不会让你平安地进行仪式，你要随机应变，从容应对。像太阳仪式一样，月亮仪式同样必须定时定点进行。你要在满月的午夜时分站在月亮神庙的月亮神坛前，到时我会通过魔法与你联络，并指引你进行整个仪式。")
    SetQBit(QBit(1143)) -- 在满月的午夜时分来到月亮神庙拜祭月亮神坛。
    evt.SetNPCTopic(1090, 1, 1398) -- 劳里达・弗丽斯 topic 1: 大德鲁伊
end)

RegisterGlobalEvent(1398, nil, function()
    evt.SetMessage("你必须在满月的午夜时分站在月亮神坛前并完成整个月亮仪式方能升级为大德鲁伊，除此别无它法。")
end)

RegisterGlobalEvent(1399, nil, function()
    evt.SetMessage("我能感觉到西方的国土正在遭受蹂躏践踏，我的德鲁伊兄弟。如果你把手放在地面用心倾听，你也会有同样的感觉。我出于责任心才到这儿来，但我希望你来调查这桩不幸的由来。我想它一定与流星雨之夜有关。")
end)

RegisterGlobalEvent(1400, nil, function()
    evt.SetMessage("我已经无法忍受严冬的折磨了，在我的国土上，冬天是最讨厌的季节。事实上这些年来夏日的阳光从未照耀这片国土。我想一定是季节变换出了什么毛病，我一定要找出原因。你的大名我已如雷贯耳，听说你无所不能，我想和你做笔交易。你把冬天赶走，我将在高级议会里全力支持你。我听说西北某处的山头上有位世外高人，对于节气变化有相当的研究。")
    SetQBit(QBit(1144)) -- 结束冬天，带着好消息返回斯壮姆嘉德城堡的斯壮姆嘉德爵士处。
    evt.SetNPCTopic(800, 0, 1401) -- 埃里克・冯・斯壮姆嘉德 topic 0: 冬天
    evt.SetNPCTopic(804, 0, 1409) -- 深山隐士 topic 0: 冬天
end)

RegisterGlobalEvent(1401, nil, function()
    evt.SetMessage("你能不能快点完成你的伟业。大雪已经高高堆集起来了，我们将不得不踩着高跷造房子了。")
end)

RegisterGlobalEvent(1402, nil, function()
    evt.SetMessage("当冬天不再肆虐，白雪无影无踪的时候我正向窗外眺望。奇迹，多么伟大的奇迹啊。你为我和我的人民立下如此丰功伟绩<拍着胸脯>埃里克・冯・斯壮姆嘉德将是你永远的朋友。")
    ClearQBit(QBit(1144)) -- 结束冬天，带着好消息返回斯壮姆嘉德城堡的斯壮姆嘉德爵士处。
    SetQBit(QBit(1199))
    AddValue(655595, 10)
    evt.SetNPCTopic(800, 0, 1403) -- 埃里克・冯・斯壮姆嘉德 topic 0: 冬天
    evt.ForPlayer(Players.All)
    SetAward(Award(62))
    AddValue(Experience, 50000)
    evt.ForPlayer(Players.All)
    if not HasAward(Award(63)) then return end
    if not HasAward(Award(57)) then return end
    if not HasAward(Award(58)) then return end
    if not HasAward(Award(59)) then return end
    if not HasAward(Award(60)) then return end
    if not HasAward(Award(61)) then return end
    if HasAward(Award(62)) then
        SetQBit(QBit(1191))
    end
end)

RegisterGlobalEvent(1403, nil, function()
    evt.SetMessage("因为你的功绩，我将在高级议会全力支持你。只要你在，冬天就不会再次肆虐。")
end)

RegisterGlobalEvent(1404, nil, function()
    evt.SetMessage("20年前，我在铁拳城堡举行的一年一度的弓箭手比武大会中赢得了冠军，因此我被授权负责弓箭手至高级射手，以及高级射手至神箭手的升职。如果你们能帮我个小忙，我将把你们中的弓箭手升级为高级射手。我需要钥匙，进入建于恩洛斯各主要居民点附近的老龙塔，射杀飞行怪兽。我们只射怪兽，而不射空中的其他飞行物。因为此计划甚得人心，你们中非弓箭手者将被授予荣誉高级射手职位。钥匙就在我的领土南面入口附近的旧堡垒里，前些年食人妖和同伙从我这里把钥匙抢走了。你去把钥匙夺回来，我会奖励你的。你在那里对付这些怪兽不必心慈手软，他们抢走了我的哨所，罪有应得。")
    SetQBit(QBit(1145)) -- 从白帽镇南边的冰风堡垒中找回龙塔钥匙，并把它带给斯壮姆嘉德城堡的斯壮姆嘉德爵士。
    evt.SetNPCTopic(800, 1, 1405) -- 埃里克・冯・斯壮姆嘉德 topic 1: 高级射手
end)

RegisterGlobalEvent(1405, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2106) then
        evt.SetMessage("不夺回钥匙就没有报酬，我们的交易直截了当。快去把钥匙夺回来吧。")
        return
    end
    evt.SetMessage("很好，你拿到钥匙了，一定把那些讨厌的怪兽杀了个精光吧。我特此将你们所有弓箭手提拔为高级射手，非弓箭手者授予荣誉高级射手职位。")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 0) then
            SetValue(ClassId, 1)
            SetQBit(QBit(1655))
        else
            SetQBit(QBit(1656))
        end
    end
    ClearQBit(QBit(1145)) -- 从白帽镇南边的冰风堡垒中找回龙塔钥匙，并把它带给斯壮姆嘉德城堡的斯壮姆嘉德爵士。
    AddValue(131307, 2)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 15000)
    evt.SetNPCTopic(800, 1, 1406) -- 埃里克・冯・斯壮姆嘉德 topic 1: 神箭手
end)

RegisterGlobalEvent(1406, nil, function()
    evt.SetMessage("我要钥匙来进入龙塔的目的是为了阻止他们不分青红皂白，滥杀飞行生物。我们可以调节塔楼，使其只攻击大型怪兽。为了王国的利益，我要求所有的塔楼都要具有此项功能。由于一些修行不够的巫师们不知此塔楼的功能，他们常常遭到莫名其妙的攻击使魔法攻击力大减。现在你们有了钥匙。如果你们能使所有的塔楼只攻击大型飞行怪兽，我将把你们中的高级射手升级为神箭手。你们中的荣誉高级射手升级为荣誉神箭手。")
    SetQBit(QBit(1146)) -- 重新设置每个镇的龙塔，并返回斯壮姆嘉德城堡的斯壮姆嘉德爵士处。
    evt.SetNPCTopic(800, 1, 1413) -- 埃里克・冯・斯壮姆嘉德 topic 1: 神箭手
end)

RegisterGlobalEvent(1407, nil, function()
    evt.SetMessage("欢迎你们，我的神箭手！我将始终和你们心心相印！")
end)

RegisterGlobalEvent(1408, nil, function()
    evt.SetMessage("我喜欢这个世界熙熙攘攘的热闹景象。在这里我目睹了喧闹的世界变成死寂一片的全过程。多么沉寂，冰冷得令人不敢靠近。这几乎是命中注定的。坐看着白云苍狗，起伏不定，风起云涌，变幻莫测。我对天气的预测几乎百发百中。<微笑>现在，我预感暴风雪将更加猖獗肆虐。")
end)

RegisterGlobalEvent(1409, nil, function()
    evt.SetMessage("斯壮姆嘉德希望看到奇迹能使气候有所变化？我一直认为这场暴风雪是对着他来的。但是破解这种异常的天气对我来说轻而易举。你快赶回去吧，还可以赶得上邀功领赏。")
    SetQBit(QBit(1252))
    evt.SetNPCTopic(800, 0, 1402) -- 埃里克・冯・斯壮姆嘉德 topic 0: 冬天
    evt.SetNPCTopic(804, 0, 1410) -- 深山隐士 topic 0: 冬天
end)

RegisterGlobalEvent(1410, nil, function()
    evt.SetMessage("能和你们结识我很荣幸，可惜我已封刀退隐，不能和你们闯荡江湖了。我想你们还有很多事去干，天下没有不散的宴席，我们就此后会有期吧。")
end)

RegisterGlobalEvent(1411, nil, function()
    evt.SetMessage("真见鬼！又是功败垂成。")
end)

RegisterGlobalEvent(1413, nil, function()
    if IsQBitSet(QBit(1180)) then
        if IsQBitSet(QBit(1181)) then
            if IsQBitSet(QBit(1182)) then
                if IsQBitSet(QBit(1183)) then
                    if IsQBitSet(QBit(1184)) then
                        if not IsQBitSet(QBit(1185)) then
                            evt.SetMessage("嗯，塔楼还没有全被重新设置。如果你们耐心寻找的话，塔楼其实很容易被发现。最容易发现的塔楼位于我们西面的白帽镇。")
                            return
                        end
                        evt.SetMessage("我已经完全信任你了。你解决了我们王国最关键的问题，而且还毫不居功。现在我们可以自由地在城镇上空任意飞行了。我很荣幸把你们中的高级射手升级为神箭手，荣誉高级射手升级为荣誉神箭手。")
                        AddValue(327915, 5)
                        ClearQBit(QBit(1146)) -- 重新设置每个镇的龙塔，并返回斯壮姆嘉德城堡的斯壮姆嘉德爵士处。
                        evt.ForPlayer(Players.All)
                        AddValue(Experience, 40000)
                        for _, player in ipairs(PartyMembers()) do
                            evt.ForPlayer(player)
                            if IsAtLeast(ClassId, 1) then
                                SetValue(ClassId, 2)
                                SetQBit(QBit(1657))
                            else
                                SetQBit(QBit(1658))
                            end
                        end
                        evt.SetNPCTopic(800, 1, 1407) -- 埃里克・冯・斯壮姆嘉德 topic 1: 神箭手
                        return
                    end
                end
            end
        end
    end
    evt.SetMessage("嗯，塔楼还没有全被重新设置。如果你们耐心寻找的话，塔楼其实很容易被发现。最容易发现的塔楼位于我们西面的白帽镇。")
end)

RegisterGlobalEvent(1414, nil, function()
    evt.SetMessage("斯里克・席尔瓦托恩竟然拒绝执行我的命令。这简直是叛变。我和他相知已久，他对我的话总是言听计从，这次他一定是糊涂了。对了，一定是他夜以继日地调查羊鸣教这个邪教，以致过度疲劳而犯了错误。我还在他的房间里发现羊鸣教的一件披风。也许你能使他恢复正常。这群可恶的家伙真该为其所作所为付出代价。我首先要拿克里格斯东部他们的总部开刀。这件披风你拿去吧，也许对你会有用的。")
    SetQBit(QBit(1224)) -- 在克里格斯城堡东面的顶级羊鸣庙中找到治疗斯里克・席尔瓦托恩的方法，并带着好消息回到威尔伯・汉弗里处。
    AddValue(InventoryItem(2105), 2105)
    evt.SetNPCTopic(789, 0, 1415) -- 威尔伯・汉弗里 topic 0: 席尔瓦托恩的治愈
end)

RegisterGlobalEvent(1415, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(2122) then
        evt.SetMessage("噢，老天！如此说来斯里克・席尔瓦托恩真是叛徒。又有谁会料到呢？你把这封信带给我，真是做了件天大的好事。赶快把这个消息通报给高级议会，我们就可以清除叛徒，一劳永逸。")
        ClearQBit(QBit(1224)) -- 在克里格斯城堡东面的顶级羊鸣庙中找到治疗斯里克・席尔瓦托恩的方法，并带着好消息回到威尔伯・汉弗里处。
        SetQBit(QBit(1225)) -- 把证明斯里克・席尔瓦托恩叛国的信件交给自由天堂的高级议会。
    elseif HasItem(2105) then
        evt.SetMessage("你快去完成你的任务，使斯里克・席尔瓦托恩神志清醒。我想这个可怜的家伙一定是中了羊鸣教施展的心智魔法。")
        return
    else
        evt.ForPlayer(Players.Current)
        AddValue(InventoryItem(2105), 2105)
        evt.SetMessage("你快去完成你的任务，使斯里克・席尔瓦托恩神志清醒。我想这个可怜的家伙一定是中了羊鸣教施展的心智魔法。")
        return
    end
end)

RegisterGlobalEvent(1416, nil, function()
    evt.SetMessage("我对你揭发叛徒和其篡位企图的行为不胜感激。我知道你还有重要任务去完成，特赐予你皇家游艇以加快行程，它会把你尽快带到隐士岛的。再次万分感谢。")
end)

RegisterGlobalEvent(1417, nil, function()
    evt.SetMessage("欢迎来到太阳马戏团。我们有各种各样的游戏节目，使你高兴而来，满意而归。你还能在游戏比赛中获得奖品，并以之交换桶装酒或金字塔。一桶酒需要10个点数，一个金字塔需要30个点数。你要明白一块天然磁石值1个点数，一支鹰身女妖的羽毛值3个点数，一片四叶草值5个点数。")
end)

RegisterGlobalEvent(1418, nil, function()
    local function Step_0()
        if IsAtLeast(CircusPrises, 30) then return 2 end
        return 1
    end
    local function Step_1()
        return 6
    end
    local function Step_2()
        AddValue(InventoryItem(2092), 2092)
        return 3
    end
    local function Step_3()
        evt.SetMessage("祝贺你，你赢得了金字塔。干得真是太棒了。我们的奖品可不封顶，你还可以尽情玩下去。")
        return 4
    end
    local function Step_4()
        evt.ForPlayer(Players.All)
        return 5
    end
    local function Step_5()
        return 14
    end
    local function Step_6()
        if IsAtLeast(CircusPrises, 10) then return 8 end
        return 7
    end
    local function Step_7()
        return 12
    end
    local function Step_8()
        AddValue(InventoryItem(2093), 2093)
        return 9
    end
    local function Step_9()
        evt.SetMessage("祝贺你，你赢得了桶装酒。我们的奖品可不封顶，你还可以尽情地玩下去！")
        return 10
    end
    local function Step_10()
        evt.ForPlayer(Players.All)
        return 11
    end
    local function Step_11()
        return 14
    end
    local function Step_12()
        evt.SetMessage("你没有达到10个点数，我很抱歉。为什么不去再玩两个游戏呢？")
        return 13
    end
    local function Step_13()
        return nil
    end
    local function Step_14()
        if HasItem(2090) then return 16 end
        return 15
    end
    local function Step_15()
        return 18
    end
    local function Step_16()
        RemoveItem(2090)
        return 17
    end
    local function Step_17()
        return 14
    end
    local function Step_18()
        if HasItem(2091) then return 20 end
        return 19
    end
    local function Step_19()
        return 22
    end
    local function Step_20()
        RemoveItem(2091)
        return 21
    end
    local function Step_21()
        return 18
    end
    local function Step_22()
        if HasItem(2097) then return 24 end
        return 23
    end
    local function Step_23()
        return 26
    end
    local function Step_24()
        RemoveItem(2097)
        return 25
    end
    local function Step_25()
        return 22
    end
    local function Step_26()
        return nil
    end
    local step = 0
    while step ~= nil do
        if step == 0 then
            step = Step_0()
        elseif step == 1 then
            step = Step_1()
        elseif step == 2 then
            step = Step_2()
        elseif step == 3 then
            step = Step_3()
        elseif step == 4 then
            step = Step_4()
        elseif step == 5 then
            step = Step_5()
        elseif step == 6 then
            step = Step_6()
        elseif step == 7 then
            step = Step_7()
        elseif step == 8 then
            step = Step_8()
        elseif step == 9 then
            step = Step_9()
        elseif step == 10 then
            step = Step_10()
        elseif step == 11 then
            step = Step_11()
        elseif step == 12 then
            step = Step_12()
        elseif step == 13 then
            step = Step_13()
        elseif step == 14 then
            step = Step_14()
        elseif step == 15 then
            step = Step_15()
        elseif step == 16 then
            step = Step_16()
        elseif step == 17 then
            step = Step_17()
        elseif step == 18 then
            step = Step_18()
        elseif step == 19 then
            step = Step_19()
        elseif step == 20 then
            step = Step_20()
        elseif step == 21 then
            step = Step_21()
        elseif step == 22 then
            step = Step_22()
        elseif step == 23 then
            step = Step_23()
        elseif step == 24 then
            step = Step_24()
        elseif step == 25 then
            step = Step_25()
        elseif step == 26 then
            step = Step_26()
        else
            step = nil
        end
    end
end)

RegisterGlobalEvent(1419, nil, function()
    evt.SetMessage("欢迎你！咱们不妨来较量一番。花50个金币，我就和你切磋一下武艺。如果你表现好的话，可以获得天然磁石，鹰身女妖的羽毛或四叶草，这根据你的武功而定。但如果你不堪一击，什么别想得到。拿着这些奖励你可以到主帐篷内换取奖品。")
end)

RegisterGlobalEvent(1420, nil, function()
    if not IsAtLeast(Gold, 50) then
        return
    end
    SubtractValue(Gold, 50)
    if IsAtLeast(ActualMight, 200) then
        local randomStep = PickRandomOption(1420, 4, {4, 7, 10, 13, 16, 19})
        if randomStep == 4 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 7 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 10 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 13 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 16 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 19 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualMight, 150) then
        local randomStep = PickRandomOption(1420, 25, {25, 28, 31, 34, 37, 40})
        if randomStep == 25 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 28 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 31 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 34 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 37 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 40 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualMight, 100) then
        local randomStep = PickRandomOption(1420, 46, {46, 49, 52, 55, 58, 61})
        if randomStep == 46 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 49 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 52 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 55 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 58 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 61 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualMight, 75) then
        local randomStep = PickRandomOption(1420, 66, {66, 69, 72, 75, 78, 80})
        if randomStep == 66 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 69 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 72 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 75 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 78 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 80 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualMight, 50) then
        local randomStep = PickRandomOption(1420, 85, {85, 88, 91, 94, 96, 98})
        if randomStep == 85 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 88 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 91 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 94 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 96 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 98 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    else
        local randomStep = PickRandomOption(1420, 101, {101, 104, 107, 109, 111, 113})
        if randomStep == 101 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 104 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 107 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 109 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 111 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 113 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    end
end)

RegisterGlobalEvent(1421, nil, function()
    if not IsAtLeast(Gold, 50) then
        return
    end
    SubtractValue(Gold, 50)
    if IsAtLeast(ActualEndurance, 200) then
        local randomStep = PickRandomOption(1421, 4, {4, 7, 10, 13, 16, 19})
        if randomStep == 4 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 7 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 10 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 13 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 16 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 19 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualEndurance, 150) then
        local randomStep = PickRandomOption(1421, 25, {25, 28, 31, 34, 37, 40})
        if randomStep == 25 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 28 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 31 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 34 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 37 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 40 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualEndurance, 100) then
        local randomStep = PickRandomOption(1421, 46, {46, 49, 52, 55, 58, 61})
        if randomStep == 46 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 49 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 52 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 55 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 58 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 61 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualEndurance, 75) then
        local randomStep = PickRandomOption(1421, 66, {66, 69, 72, 75, 78, 80})
        if randomStep == 66 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 69 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 72 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 75 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 78 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 80 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualEndurance, 50) then
        local randomStep = PickRandomOption(1421, 85, {85, 88, 91, 94, 96, 98})
        if randomStep == 85 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 88 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 91 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 94 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 96 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 98 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    else
        local randomStep = PickRandomOption(1421, 101, {101, 104, 107, 109, 111, 113})
        if randomStep == 101 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 104 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 107 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 109 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 111 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 113 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    end
end)

RegisterGlobalEvent(1422, nil, function()
    if not IsAtLeast(Gold, 50) then
        return
    end
    SubtractValue(Gold, 50)
    if IsAtLeast(ActualSpeed, 200) then
        local randomStep = PickRandomOption(1422, 4, {4, 7, 10, 13, 16, 19})
        if randomStep == 4 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 7 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 10 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 13 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 16 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 19 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualSpeed, 150) then
        local randomStep = PickRandomOption(1422, 25, {25, 28, 31, 34, 37, 40})
        if randomStep == 25 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 28 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 31 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 34 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 37 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 40 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualSpeed, 100) then
        local randomStep = PickRandomOption(1422, 46, {46, 49, 52, 55, 58, 61})
        if randomStep == 46 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 49 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 52 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 55 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 58 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 61 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualSpeed, 75) then
        local randomStep = PickRandomOption(1422, 66, {66, 69, 72, 75, 78, 80})
        if randomStep == 66 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 69 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 72 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 75 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 78 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 80 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualSpeed, 50) then
        local randomStep = PickRandomOption(1422, 85, {85, 88, 91, 94, 96, 98})
        if randomStep == 85 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 88 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 91 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 94 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 96 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 98 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    else
        local randomStep = PickRandomOption(1422, 101, {101, 104, 107, 109, 111, 113})
        if randomStep == 101 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 104 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 107 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 109 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 111 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 113 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    end
end)

RegisterGlobalEvent(1423, nil, function()
    if not IsAtLeast(Gold, 50) then
        return
    end
    SubtractValue(Gold, 50)
    if IsAtLeast(ActualAccuracy, 200) then
        local randomStep = PickRandomOption(1423, 4, {4, 7, 10, 13, 16, 19})
        if randomStep == 4 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 7 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 10 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 13 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 16 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 19 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualAccuracy, 150) then
        local randomStep = PickRandomOption(1423, 25, {25, 28, 31, 34, 37, 40})
        if randomStep == 25 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 28 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 31 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 34 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 37 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 40 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualAccuracy, 100) then
        local randomStep = PickRandomOption(1423, 46, {46, 49, 52, 55, 58, 61})
        if randomStep == 46 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 49 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 52 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 55 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 58 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 61 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualAccuracy, 75) then
        local randomStep = PickRandomOption(1423, 66, {66, 69, 72, 75, 78, 80})
        if randomStep == 66 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 69 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 72 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 75 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 78 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 80 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualAccuracy, 50) then
        local randomStep = PickRandomOption(1423, 85, {85, 88, 91, 94, 96, 98})
        if randomStep == 85 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 88 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 91 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 94 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 96 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 98 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    else
        local randomStep = PickRandomOption(1423, 101, {101, 104, 107, 109, 111, 113})
        if randomStep == 101 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 104 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 107 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 109 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 111 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 113 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    end
end)

RegisterGlobalEvent(1424, nil, function()
    if not IsAtLeast(Gold, 50) then
        return
    end
    SubtractValue(Gold, 50)
    if IsAtLeast(ActualLuck, 200) then
        local randomStep = PickRandomOption(1424, 4, {4, 7, 10, 13, 16, 19})
        if randomStep == 4 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 7 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 10 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 13 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 16 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 19 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualLuck, 150) then
        local randomStep = PickRandomOption(1424, 25, {25, 28, 31, 34, 37, 40})
        if randomStep == 25 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 28 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 31 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 34 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 37 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 40 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualLuck, 100) then
        local randomStep = PickRandomOption(1424, 46, {46, 49, 52, 55, 58, 61})
        if randomStep == 46 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 49 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 52 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 55 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 58 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 61 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualLuck, 75) then
        local randomStep = PickRandomOption(1424, 66, {66, 69, 72, 75, 78, 80})
        if randomStep == 66 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 69 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 72 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 75 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 78 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 80 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualLuck, 50) then
        local randomStep = PickRandomOption(1424, 85, {85, 88, 91, 94, 96, 98})
        if randomStep == 85 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 88 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 91 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 94 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 96 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 98 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    else
        local randomStep = PickRandomOption(1424, 101, {101, 104, 107, 109, 111, 113})
        if randomStep == 101 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 104 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 107 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 109 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 111 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 113 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    end
end)

RegisterGlobalEvent(1425, nil, function()
    if not IsAtLeast(Gold, 50) then
        return
    end
    SubtractValue(Gold, 50)
    if IsAtLeast(ActualIntellect, 200) then
        local randomStep = PickRandomOption(1425, 4, {4, 7, 10, 13, 16, 19})
        if randomStep == 4 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 7 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 10 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 13 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 16 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 19 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualIntellect, 150) then
        local randomStep = PickRandomOption(1425, 25, {25, 28, 31, 34, 37, 40})
        if randomStep == 25 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 28 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 31 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 34 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 37 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 40 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        end
    elseif IsAtLeast(ActualIntellect, 100) then
        local randomStep = PickRandomOption(1425, 46, {46, 49, 52, 55, 58, 61})
        if randomStep == 46 then
            AddValue(InventoryItem(2097), 2097)
            evt.SetMessage("真是难以置信，你太出色了，该不是作弊吧。我遵守诺言，把四叶草奖励给你。")
            return
        elseif randomStep == 49 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 52 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 55 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 58 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 61 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualIntellect, 75) then
        local randomStep = PickRandomOption(1425, 66, {66, 69, 72, 75, 78, 80})
        if randomStep == 66 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 69 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 72 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 75 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 78 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 80 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    elseif IsAtLeast(ActualIntellect, 50) then
        local randomStep = PickRandomOption(1425, 85, {85, 88, 91, 94, 96, 98})
        if randomStep == 85 then
            AddValue(InventoryItem(2091), 2091)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 88 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 91 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 94 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 96 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 98 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    else
        local randomStep = PickRandomOption(1425, 101, {101, 104, 107, 109, 111, 113})
        if randomStep == 101 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("棒极了，你赢得了鹰身女妖的羽毛。")
            return
        elseif randomStep == 104 then
            AddValue(InventoryItem(2090), 2090)
            evt.SetMessage("干得真不赖，我奖励你一块天然磁石。")
            return
        elseif randomStep == 107 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 109 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 111 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        elseif randomStep == 113 then
            evt.SetMessage("真不幸，你差点就赢了。再出50个金币，我就再给你一次机会。")
            return
        end
    end
end)

RegisterGlobalEvent(1426, nil, function()
    SetAutonote(461)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2082) then
            RemoveItem(2082)
            AddValue(Gold, 2000)
            evt.SetMessage("尽管脏了些，但我想它还管用，这是我许诺给你的报酬，多谢你的帮助。")
            return
        end
    end
    evt.SetMessage("为了重建自由天堂的神庙，我到处收集神庙的铜锣。如果你有的话，我每面锣出价2000个金币。")
end)

RegisterGlobalEvent(1427, nil, function()
    SetAutonote(462)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2085) then
            RemoveItem(2085)
            AddValue(Gold, 1000)
            SubtractValue(131307, 2)
            evt.SetMessage("嗯，这是人的腿骨。很不错，我愿付1000个金币。")
            return
        end
    end
    evt.SetMessage("我正在寻找能在仪式上派上用场的骨头。我本来想要人或类人猿的骨头，但你只要找到能用的就行了。如果找到的骨头合适的话，我会给你1000个金币。")
end)

RegisterGlobalEvent(1428, nil, function()
    SetAutonote(463)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2090) then
            RemoveItem(2090)
            AddValue(Gold, 5)
            evt.SetMessage("谢谢你，你真是太慷慨了！这真是件可爱的礼物，这是我给你的5个金币。")
            return
        end
    end
    evt.SetMessage("许多人去不了马戏团，所以我专门收集马戏团的奖品卖给那些人。如果你有的话，每块天然磁石我出价5个金币。")
end)

RegisterGlobalEvent(1429, nil, function()
    SetAutonote(464)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2091) then
            RemoveItem(2091)
            AddValue(Gold, 10)
            evt.SetMessage("多谢你了，这事可不要向我的女儿声张。我要让她大吃一惊。这是我给你的10个金币。")
            return
        end
    end
    evt.SetMessage("我的女儿吵着要去看马戏团。可我们总是没有时间。我想给她一些鹰身女妖的羽毛来补偿她。如果你有的话，每支鹰身女妖的羽毛我出价10个金币。")
end)

RegisterGlobalEvent(1430, nil, function()
    SetAutonote(465)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2092) then
            RemoveItem(2092)
            AddValue(Gold, 1000)
            evt.SetMessage("多谢了！我可等不及把这东西带到阿卜杜的沙漠胜地去换东西了。这是我的酬谢，请收下。")
            return
        end
    end
    evt.SetMessage("我听说有了金字塔就可以到阿卜杜的沙漠胜地去交换些新鲜玩意儿。我希望有朝一日能如愿，所以专门收集金字塔。如果你有的话，每个金字塔我出价1000个金币。")
end)

RegisterGlobalEvent(1431, nil, function()
    SetAutonote(466)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2093) then
            RemoveItem(2093)
            AddValue(Gold, 300)
            evt.SetMessage("我的宝贝！感谢你为我带来了好酒！这是300个金币，真是物有所值。")
            return
        end
    end
    evt.SetMessage("我对你在马戏团里赢来的好酒十分感兴趣，只要你有，我出价每桶酒300个金币。")
end)

RegisterGlobalEvent(1432, nil, function()
    SetAutonote(467)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2096) then
            RemoveItem(2096)
            AddValue(Gold, 500)
            evt.SetMessage("这颗牙齿确实与众不同。我出价500个金币买下了。")
            return
        end
    end
    evt.SetMessage("我对牙齿有异乎寻常的收集爱好，而且永远得不到满足。如果你有珍稀少见的牙齿，我会出价500个金币收购。")
end)

RegisterGlobalEvent(1433, nil, function()
    SetAutonote(468)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2097) then
            RemoveItem(2097)
            AddValue(Gold, 25)
            evt.SetMessage("太棒了。到马戏团来一试身手十分方便，输了也不失面子，真是不错。这是你的25个金币。")
            return
        end
    end
    evt.SetMessage("我曾去过马戏团三次，但每次都一无所获。我对那里的奖品四叶草爱不释手，如果你有，我出价每片25个金币。")
end)

RegisterGlobalEvent(1434, nil, function()
    SetAutonote(469)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2102) then
            RemoveItem(2102)
            AddValue(Gold, 500)
            evt.SetMessage("真是太棒了！感谢你的琥珀，这是我答应你的500个金币。")
            return
        end
    end
    evt.SetMessage("我听说铁拳城堡北面的洞穴里有储量丰富的琥珀。我在自由天堂一直忙碌，无法抽身，但我对这些琥珀很感兴趣。每颗琥珀我出价500个金币。")
end)

RegisterGlobalEvent(1435, nil, function()
    evt.SetMessage("你也许听说过，自从死灵法师教派在王位争夺战争中遭到重创后，他们的残部就躲进了黑摩尔城堡。谁知道他们现在在捣什么鬼！但我确信记载有无尽黑夜仪式过程的巫妖之书被他们带入了城堡，如果能把这本书毁了，就能打乱这个邪派的行动步骤。为了得到这本书我努力了好几次，可惜都因为城堡的防御太严而功败垂成。如果你能把这本书销毁，我会重谢你的。")
    SetQBit(QBit(1228)) -- 在黑摩尔城堡中找到并摧毁巫妖之书，然后返回黑摩尔镇的德里・罗斯处。
    evt.SetNPCTopic(1115, 0, 1436) -- 德里・罗斯 topic 0: 任务
end)

RegisterGlobalEvent(1436, nil, function()
    evt.ForPlayer(Players.All)
    if not IsQBitSet(QBit(1033)) then
        evt.SetMessage("我并不急于销毁此经书。如果你成功了，就回来领取奖赏。如果失败了也没什么大不了的，毕竟城堡中的怪兽实在太多了。")
        return
    end
    evt.SetMessage("真是难以置信！我本来对你不抱多少希望，想不到你干得如此出色。现在巫妖之书被毁了，死灵法师教派已经死到临头了。我对你的此行动感激不尽，请收下我的报酬和我的一片谢意。")
    SetAward(Award(102))
    AddValue(Experience, 50000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 5000)
    AddValue(327915, 5)
    ClearQBit(QBit(1228)) -- 在黑摩尔城堡中找到并摧毁巫妖之书，然后返回黑摩尔镇的德里・罗斯处。
    evt.SetNPCTopic(1115, 0, 0) -- 德里・罗斯 topic 0 cleared
    evt.MoveNPC(1115, 0) -- 德里・罗斯 -> removed
end)

RegisterGlobalEvent(1437, nil, function()
    evt.SetMessage("欢迎来到我的沙漠胜地。你也许注意到了我们这地方不像一般的城镇那样鱼龙混杂，乌烟瘴气。在这里你可以尽情享受沙漠中的静谧，彻底地得到放松。如果你感兴趣的话，我们这里专门有人用珍稀之物交换兵器和铠甲，如果你是个行家的话，一定会感到不虚此行的。")
end)

RegisterGlobalEvent(1438, nil, function()
    evt.SetMessage("现在流传着一些关于我的这个胜地的谣言。其实人们所说的阿拉斯这个返老还童的喷泉并不在这里，它在西面的某个地方，从这里出发有几天的路程。")
end)

RegisterGlobalEvent(1439, nil, function()
    evt.SetMessage("你好！我愿意用一套上好的铠甲交换金字塔或桶装酒。")
end)

RegisterGlobalEvent(1440, nil, function()
    evt.SetMessage("我愿意用上好的兵器交换金字塔或桶装酒。")
end)

RegisterGlobalEvent(1441, nil, function()
    evt.SetMessage("我有大量的魔法小物件。我可以用来交换金字塔或桶装酒。")
end)

RegisterGlobalEvent(1442, nil, function()
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2092) then
            RemoveItem(2092)
            evt.GiveItem(6, ItemType.Armor_)
            evt.SetMessage("很高兴和你做生意，这是给你的盔甲。")
            return
        end
    end
    evt.SetMessage("你没有金字塔，我们之间没有生意可做。")
end)

RegisterGlobalEvent(1443, nil, function()
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2092) then
            RemoveItem(2092)
            evt.GiveItem(6, ItemType.Weapon_)
            evt.SetMessage("很高兴和你做生意，这是给你的兵器。")
            return
        end
    end
    evt.SetMessage("你没有金字塔，我们之间没有生意可做。")
end)

RegisterGlobalEvent(1444, nil, function()
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2092) then
            RemoveItem(2092)
            evt.GiveItem(6, ItemType.Misc)
            evt.SetMessage("很高兴和你做生意，这是给你的小物件。")
            return
        end
    end
    evt.SetMessage("你没有金字塔，我们之间没有生意可做。")
end)

RegisterGlobalEvent(1445, nil, function()
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2093) then
            RemoveItem(2093)
            evt.GiveItem(4, ItemType.Armor_)
            evt.SetMessage("很高兴和你做生意，这是给你的盔甲。")
            return
        end
    end
    evt.SetMessage("你没有可供交换的桶装酒。")
end)

RegisterGlobalEvent(1446, nil, function()
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2093) then
            RemoveItem(2093)
            evt.GiveItem(4, ItemType.Weapon_)
            evt.SetMessage("很高兴和你做生意，这是给你的兵器。")
            return
        end
    end
    evt.SetMessage("你没有可供交换的桶装酒。")
end)

RegisterGlobalEvent(1447, nil, function()
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2093) then
            RemoveItem(2093)
            evt.GiveItem(4, ItemType.Misc)
            evt.SetMessage("很高兴和你做生意，这是给你的小物件。")
            return
        end
    end
    evt.SetMessage("你没有可供交换的桶装酒。")
end)

RegisterGlobalEvent(1448, nil, function()
    SetAutonote(470)
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2103) then
            RemoveItem(2103)
            local randomStep = PickRandomOption(1448, 24, {24, 27, 30, 33, 36, 39})
            if randomStep == 24 then
                AddValue(InventoryItem(2056), 2056)
                evt.SetMessage("谢谢你给我神灯，这是给你的石头。")
                return
            elseif randomStep == 27 then
                AddValue(InventoryItem(2065), 2065)
                evt.SetMessage("谢谢你给我神灯，这是给你的石头。")
                return
            elseif randomStep == 30 then
                AddValue(InventoryItem(2064), 2064)
                evt.SetMessage("谢谢你给我神灯，这是给你的石头。")
                return
            elseif randomStep == 33 then
                AddValue(InventoryItem(2063), 2063)
                evt.SetMessage("谢谢你给我神灯，这是给你的石头。")
                return
            elseif randomStep == 36 then
                AddValue(InventoryItem(2059), 2059)
                evt.SetMessage("谢谢你给我神灯，这是给你的石头。")
                return
            elseif randomStep == 39 then
                AddValue(InventoryItem(2062), 2062)
                evt.SetMessage("谢谢你给我神灯，这是给你的石头。")
                return
            end
            return
        end
    end
    evt.SetMessage("我专门收集使用过的魔法神灯。现在我身上身无分文，我用些漂亮的石头换你的神灯，怎么样？")
end)

RegisterGlobalEvent(1573, nil, function()
    evt.SetMessage("天下最好的手杖高手杰斯佩・莱斯住在银湾镇附近，如果你要使自己的手杖技能精益求精，不妨找他求教。")
end)

RegisterGlobalEvent(1574, nil, function()
    evt.SetMessage("住在布莱克郡的盖・汉普顿对剑术无所不知。如果你要成为长剑大师，可以去找他。")
end)

RegisterGlobalEvent(1575, nil, function()
    evt.SetMessage("和朱尔斯・米尔斯的匕首技能相比，我简直是个初出茅庐的新手。他就住在斯通城堡附近，要提高匕首技能只有去找他。")
end)

RegisterGlobalEvent(1576, nil, function()
    evt.SetMessage("阿维里・辛西亚在我们出生前就开始钻研战斧技能。但他从不授艺予人。但你们如果干些惊天动地的大事，他说不定会破例。他总游荡在幽灵沼泽附近。")
end)

RegisterGlobalEvent(1577, nil, function()
    evt.SetMessage("天下使矛的第一高手，伯顿・罗德福德住在幽灵沼泽。我真不明白他为什么隐居在这么偏僻的地方。也许他不喜欢被他的学生打扰。")
end)

RegisterGlobalEvent(1578, nil, function()
    evt.SetMessage("斯壮姆嘉德射箭技能精湛，但从不收徒。要成为弓箭技能的大师，你可以去克里格斯城堡找德斯蒙德・威勒求教。")
end)

RegisterGlobalEvent(1579, nil, function()
    evt.SetMessage("要成为使用钉锤的大师，你得找布莱克郡的埃罗・奥斯特曼。")
end)

RegisterGlobalEvent(1580, nil, function()
    evt.SetMessage("很少人知道世上还有这种武器。我只见过李克斯拉使用过这类武器。以前她住在天堂谷，不知她现在是否还住在这个地方。")
end)

RegisterGlobalEvent(1581, nil, function()
    evt.SetMessage("没人能像布莱克郡的布朗・梅克那样把盾牌使得如此纯熟自如。你要成为盾牌的大师可以去找他。")
end)

RegisterGlobalEvent(1582, nil, function()
    evt.SetMessage("阿伦・瑟勒是传授皮甲技能的最佳导师。他通常住在斯通城堡附近。")
end)

RegisterGlobalEvent(1583, nil, function()
    evt.SetMessage("要成为锁甲的大师，你只有去找戴维・费什。他住在幽灵沼泽中。")
end)

RegisterGlobalEvent(1584, nil, function()
    evt.SetMessage("福雷斯特・萨德斯是恩洛斯顶尖圣武士之一。他住在坦普城堡附近，可以教授你如何精通钢甲。")
end)

RegisterGlobalEvent(1585, nil, function()
    evt.SetMessage("要成为火系魔法的大师，你必须找浓雾镇的杰扎贝尔。")
end)

RegisterGlobalEvent(1586, nil, function()
    evt.SetMessage("浓雾镇的考・萨伦能教你空气魔法的绝招。")
end)

RegisterGlobalEvent(1587, nil, function()
    evt.SetMessage("要成为水系魔法的大师，你必须拜浓雾镇的哈普・科林斯为师。")
end)

RegisterGlobalEvent(1588, nil, function()
    evt.SetMessage("住在银湾镇的李维・伯塔纳能使你成为土系魔法的大师。")
end)

RegisterGlobalEvent(1589, nil, function()
    evt.SetMessage("要掌握灵魂魔法的精髓，必须求助于毕肖普・因奎斯特。他住在铁拳城堡的后面，还挺好找的。")
end)

RegisterGlobalEvent(1590, nil, function()
    evt.SetMessage("银湾镇的坦恩・罗普可以训练你为心智魔法的大师。")
end)

RegisterGlobalEvent(1591, nil, function()
    evt.SetMessage("要成为肢体魔法的大师，你必须去找银湾镇的吉尔伯特・汉默。")
end)

RegisterGlobalEvent(1592, nil, function()
    evt.SetMessage("光明魔法是一种高深莫测的魔法。你可以在阿拉莫斯城堡附近某处找到此项魔法的伟大导师奇罗尼。")
end)

RegisterGlobalEvent(1593, nil, function()
    evt.SetMessage("苏朗满是我学习暗黑魔法的老师。他在天堂谷中拥有一间小屋。")
end)

RegisterGlobalEvent(1594, nil, function()
    evt.SetMessage("住在自由天堂的汉斯・吉福德可传授你鉴定物品的最高深技巧。")
end)

RegisterGlobalEvent(1595, nil, function()
    evt.SetMessage("威尔・奥特曼是我见过的最精明的商人。如果你要提高你的经商术，可以去找他。")
end)

RegisterGlobalEvent(1596, nil, function()
    evt.SetMessage("我的修补术和瑞安・特里克尔相比不值一提。你可以说服他传授你大师级的修补术。我听说他住在斯通城堡附近。")
end)

RegisterGlobalEvent(1597, nil, function()
    evt.SetMessage("贾森・泰福勒是最好的健身术教练。如果你受得了他的严格训练，不妨去自由天堂找他。")
end)

RegisterGlobalEvent(1598, nil, function()
    evt.SetMessage("你要成为冥想术的大师，可以去浓雾镇向诺里奥・阿里格纳求教。")
end)

RegisterGlobalEvent(1599, nil, function()
    evt.SetMessage("要成为洞察术的大师，你可以去幽灵沼泽向麦克罗・加里瓜拉求教。")
end)

RegisterGlobalEvent(1600, nil, function()
    evt.SetMessage("贾克斯・科霍一直为斯壮姆嘉德爵士开发试验性的药剂配方，如果他有时间，他可以帮助你成为炼金术的大师。")
end)

RegisterGlobalEvent(1601, nil, function()
    evt.SetMessage("天下最伟大的陷阱拆卸术高手盖贝・莱斯特现在在斯通城堡附近授艺。如果想使拆卸术登峰造极，不妨去找他。")
end)

RegisterGlobalEvent(1602, nil, function()
    evt.SetMessage("约翰・特克可使你成为学习术的大师。我觉得他依然住在银湾镇。")
end)

RegisterGlobalEvent(1603, nil, function()
    evt.SetMessage("现任的矮人国国王斯纳格是谋权篡位后登上矮人国王位的。原国王洛克林被他放逐边疆。大多数矮人国的民众不堪忍受斯纳格的残暴统制，都希望洛克林能重登王位。不幸的是，斯纳格占据了洛克林的岩洞和矮人国最大的铁矿。他为了巩固王位，撤了我矮人国武器大师的职位。我们需要有人帮助，使用任何手段把斯纳格赶下台。如果你能助我们一臂之力，尽管你是人类，我也会把矮人擅使的战斧绝招传授给你。")
    SetQBit(QBit(1148)) -- 前往斯纳格的岩洞，除掉斯纳格，并把他的战斧交给幽灵沼泽萦绕旅店的阿维里・辛西亚。
    evt.SetNPCTopic(817, 0, 1604) -- 阿维里・辛西亚 topic 0: 任务
end)

RegisterGlobalEvent(1604, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2118) then
        evt.SetMessage("我需要你证明斯纳格已经被打败了，很抱歉我不能相信你的一面之词。你最好能带回斯纳格的私人物品来证明，比如他的战斧。")
        return
    end
    evt.SetMessage("啊，真是一个光荣的日子！斯纳格已经倒台了，现在我们可以找回洛克林国王让他重登王位。我们永远感激你，矮人国的所有民众都欠你一个人情。")
    SetAward(Award(79))
    AddValue(Experience, 20000)
    evt.ForPlayer(Players.Current)
    SetQBit(QBit(1051))
    ClearQBit(QBit(1148)) -- 前往斯纳格的岩洞，除掉斯纳格，并把他的战斧交给幽灵沼泽萦绕旅店的阿维里・辛西亚。
    AddValue(327915, 5)
    evt.SetNPCTopic(817, 0, 1520) -- 阿维里・辛西亚 topic 0: 战斧大师训练
end)

RegisterGlobalEvent(1605, nil, function()
    evt.SetMessage("浓雾镇的镇长正考虑在与恶势力的战斗期间让银色兄弟会来管理整个城镇。但我知道银色兄弟会下属的银舵除奸队打着“向恶势力进军”的旗号杀戮了许多无辜的人。遗憾的是，没有幸存的目击者佐证他们的暴行。你的任务是突袭本镇东南边他们的前哨站，搜索证据，让我可以说服镇长取缔他们。")
    SetQBit(QBit(1149)) -- 突袭浓雾镇附近的银舵前哨并把他们堕落的证据带给浓雾镇的治安官。
    evt.SetNPCTopic(822, 0, 1606) -- 查尔斯・德索匹格 topic 0: 任务
end)

RegisterGlobalEvent(1606, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2123) then
        evt.SetMessage("继续搜索吧，镇长和我的身家性命都掌握在你的手中。如果没有证据我们无法采取行动。")
        return
    end
    evt.SetMessage("果然不出我所料！但镇长上了他们的黑名单并被列为第三号人物真让我吃惊不小。他虽然不太能胜任镇长一职，但为人倒是不坏。再次感谢你。请接受这些金币和我的感激之情。")
    RemoveItem(2123)
    SetAward(Award(80))
    AddValue(Experience, 15000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 3000)
    AddValue(131307, 2)
    ClearQBit(QBit(1149)) -- 突袭浓雾镇附近的银舵前哨并把他们堕落的证据带给浓雾镇的治安官。
    evt.SetNPCTopic(822, 0, 0) -- 查尔斯・德索匹格 topic 0 cleared
    evt.SetNPCTopic(831, 0, 1608) -- 贝特朗・斯科里弗纳 topic 0: 银舵
end)

RegisterGlobalEvent(1607, nil, function()
    evt.SetMessage("我也许应该让银色兄弟会管理浓雾镇及周边地区。他们有能力扫清所有恶势力，使浓雾岛成为人间天堂。")
end)

RegisterGlobalEvent(1608, nil, function()
    evt.SetMessage("真不敢相信银舵那帮人竟打算杀害我！我一辈子都没做错事！嗯，我是说至少和其他镇长相比不坏。实在感谢你阻止了他们的阴谋。")
end)

RegisterGlobalEvent(1609, nil, function()
    evt.SetMessage("你能帮羊鸣教个忙吗？我的弟兄们逃离旧庙去了西北方，匆忙中把举行仪式必不可少的蜡烛台遗忘在庙里。没有一个神甫敢回去取，他们惧怕笼罩在神庙上的魔法诅咒，如果你能把蜡烛台取回来，我们会由衷感谢你并给你重赏。")
    SetQBit(QBit(1150)) -- 为新索匹格的安多弗・波特皮洛夺回废庙中的蜡烛台。
    evt.SetNPCTopic(786, 1, 1610) -- 安多弗・波特皮洛 topic 1: 任务
end)

RegisterGlobalEvent(1610, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2069) then
        evt.SetMessage("是否诅咒同样也使你畏缩不前了？我能理解。羊鸣教是有耐心的，快重整旗鼓去把蜡烛台拿回来，我正准备好好酬谢你。")
        return
    end
    evt.SetMessage("好极了，赞美羊鸣教！你对魔法诅咒毫无畏惧，太了不起了。这是你的报酬，感谢你的援手。")
    RemoveItem(2069)
    SetAward(Award(81))
    AddValue(Experience, 2000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 1000)
    SubtractValue(655595, 10)
    ClearQBit(QBit(1150)) -- 为新索匹格的安多弗・波特皮洛夺回废庙中的蜡烛台。
    evt.SetNPCTopic(786, 1, 0) -- 安多弗・波特皮洛 topic 1 cleared
end)

RegisterGlobalEvent(1611, nil, function()
    evt.SetMessage("谁能料到我驰骋整个恩洛斯征讨的邪恶势力竟在我的眼皮底下。杰拉德・布莱克墨斯曾经是我的二把手。在谋杀我的不久前，他勾结羊鸣教，羊鸣教帮他除去兄弟会里反对他的人，我就是其中一个目标，我死后杰拉德控制了整个银色兄弟会。现在的银舵和他们过去追猎的敌人一样邪恶。我能肯定，我们兄弟会的腐败是羊鸣教导致的。另外，杰拉德的兄弟马库斯，一个巫师，为银舵提供了很多高质量装备，他现在正在东南方一个小岛上的炼铁厂中帮人干活。")
end)

RegisterGlobalEvent(1612, nil, function()
    if not IsQBitSet(QBit(1151)) then
        evt.SetMessage("我的侄女米拉达在浓雾岛被绑架，软禁在离岛不远处的银舵前哨内。她是极少数得知我已被害的知情者之一，肯定是因为这个，杰拉德绑架了她。他还逼我侄女与他成婚，以巩固他在银色兄弟会中的地位。")
        return
    end
    evt.SetMessage("感谢你救了我的侄女。这堵墙后面是我连杰拉德也未透露的密室，你可以任意拿取你需要的东西。与其留给杰拉德，我更愿意让你带走。")
end)

RegisterGlobalEvent(1613, nil, function()
    evt.SetMessage("羊鸣教的神甫曾给杰拉德一块刻有他名字的十字架。我不清楚这块铭牌到底有什么用，可能是为了证明他是羊鸣教的朋友。")
    evt.SetNPCTopic(799, 2, 1675) -- 劳里达・弗丽斯 topic 2: 十字架
    evt.SetNPCTopic(801, 2, 1676) -- 安东尼・斯通 topic 2: 十字架
end)

RegisterGlobalEvent(1614, nil, function()
    evt.SetMessage("你是不是想打败斯纳格？他知道怎样在众矮人中立于不败之地。他现在深居于洛克林的旧岩洞里，并被忠于他的矮人部落守着。一旦发生意外，他就会立刻锁住寝宫的大门，一切由手下人对付。你必须得到寝宫的钥匙，不然根本打不开那扇牢不可破的石门。我曾是洛克林国王的管家，对那间屋子了如指掌，还藏了把钥匙。你真幸运。我被斯纳格监禁在这儿。我最想看到的是斯纳格的倒台。这是钥匙，是对你救我脱此牢笼的酬劳。")
    evt.MoveNPC(851, 0) -- 吉姆・哈蒙德 -> removed
    if HasItem(2108) then return end
    AddValue(InventoryItem(2108), 2108)
end)
RegisterCanShowTopic(1614, function()
    evt._BeginCanShowTopic(1614)
    local visible = true
    if HasItem(2108) then
        visible = false
        return visible
    else
        visible = true
        return visible
    end
end)

RegisterGlobalEvent(1615, nil, function()
    evt.SetMessage("感谢你解救了我。我想也许因为我是神甫，银舵才没有对我下毒手。说实话，我真奇怪他们怎么还有点仁慈之心。我听到周围传来奇怪的声音，我想这里肯定隐藏着秘密。我现在该走了，这鬼地方我一刻也不想呆了。")
    evt.MoveNPC(859, 0) -- 奥利弗・温德尔 -> removed
end)

RegisterGlobalEvent(1616, nil, function()
    evt.SetMessage("龙骑兵在附近的道路上四处打劫，还抢劫我的商队，拿走了珍贵的竖琴。我可没能耐夺回我的竖琴，如果你能为我代劳，我会重重酬谢你的。")
    SetQBit(QBit(1152)) -- 前往铁拳城堡南面的龙骑兵洞穴，夺回竖琴，并把它交还给铁拳城堡的安德鲁・贝斯普。
    evt.SetNPCTopic(862, 0, 1617) -- 安德鲁・贝斯普 topic 0: 任务
end)

RegisterGlobalEvent(1617, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(2099) then
        evt.SetMessage("万分感谢！我的妻子对这把竖琴喜爱极了，很高兴你把它完璧归赵。这是你的报酬。我听说龙骑兵在为阴影教做事。如果真有此事，新索匹格的镇长一定想要看到证据。再次感谢你对我的帮助。")
        RemoveItem(2099)
        SetAward(Award(82))
        AddValue(Experience, 10000)
        evt.ForPlayer(Players.Current)
        AddValue(Gold, 5000)
        AddValue(131307, 2)
        ClearQBit(QBit(1152)) -- 前往铁拳城堡南面的龙骑兵洞穴，夺回竖琴，并把它交还给铁拳城堡的安德鲁・贝斯普。
        evt.SetNPCTopic(862, 0, 0) -- 安德鲁・贝斯普 topic 0 cleared
    elseif HasItem(2098) then
        evt.SetMessage("这是件乐器，但不是竖琴。让我来解释它们的区别：你带回来的是长笛，是有洞的管子，而竖琴有琴弦，懂了吗？我相信竖琴还在，你把它带回来我会报答你的。")
    else
        evt.SetMessage("我的竖琴仍未见踪影，但我的承诺还生效，我知道龙骑兵在南面的海滩附近有个基地，你可以去那儿看看，把竖琴夺回来。")
    end
end)

RegisterGlobalEvent(1618, nil, function()
    evt.SetMessage("我钻研出了一些灵魂不死的理论，并想验证这些理论。我现在需要一具不死生物的残骸，最好是个强大的。其实，史上第一个巫妖――疯子埃斯里克的残骸，那是最好不过了。我只是个书生，没有能力得到他的残骸。但我存了些钱，如果你能帮我得到埃斯里克的残骸，我会酬谢你的。")
    SetQBit(QBit(1153)) -- 在自由天堂西面的埃斯里克的坟墓中找到埃斯里克的头骨，将它交给自由天堂的盖贝里・卡特曼。
    evt.SetNPCTopic(956, 0, 1619) -- 盖贝里・卡特曼 topic 0: 任务
end)

RegisterGlobalEvent(1619, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2084) then
        evt.SetMessage("相信我，我对任务的艰巨性一清二楚。你可以慢慢做，但要把任务做好。")
        return
    end
    evt.SetMessage("你干得真不错。现在我可以完成我的研究了。如果我钻研出无尽黑夜仪式是怎样进行的，就能找出办法逆转这个过程。这是我许诺给你的报酬。")
    RemoveItem(2084)
    SetAward(Award(83))
    AddValue(Experience, 15000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 7500)
    ClearQBit(QBit(1153)) -- 在自由天堂西面的埃斯里克的坟墓中找到埃斯里克的头骨，将它交给自由天堂的盖贝里・卡特曼。
    evt.SetNPCTopic(956, 0, 0) -- 盖贝里・卡特曼 topic 0 cleared
    evt.MoveNPC(956, 0) -- 盖贝里・卡特曼 -> removed
end)

RegisterGlobalEvent(1621, nil, function()
    evt.SetMessage("我的城镇总不时被巨型蜘蛛抢劫掠夺。我很确信如果把蜘蛛女王杀了，剩下的余党就会不战而逃了。现在我正在重金寻找能杀死蜘蛛女王的勇士。")
    SetQBit(QBit(1154)) -- 除掉新索匹格的废庙中的蜘蛛女王，并把它的心带给新索匹格镇的布福德・提・奥曼。
    evt.SetNPCTopic(992, 0, 1622) -- 布福德・提・奥曼 topic 0: 任务
end)

RegisterGlobalEvent(1622, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2101) then
        evt.SetMessage("没人能带着杀死蜘蛛女王的凭据回来，因此我许诺的报酬还在。")
        return
    end
    evt.SetMessage("多么美妙的战利品。这颗蜘蛛的心脏证明你干掉了邪恶的蜘蛛女王。希望蜘蛛不再骚扰新索匹格镇了。这些是给你的报酬。")
    RemoveItem(2101)
    SetAward(Award(84))
    AddValue(Experience, 3000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 1000)
    ClearQBit(QBit(1154)) -- 除掉新索匹格的废庙中的蜘蛛女王，并把它的心带给新索匹格镇的布福德・提・奥曼。
    evt.SetNPCTopic(992, 0, 0) -- 布福德・提・奥曼 topic 0 cleared
end)

RegisterGlobalEvent(1623, nil, function()
    evt.SetMessage("塞德里克・德鲁泽和他的苍穹会霸占了独立碑，这块碑对德鲁伊来说是个古老的圣地。他们所进行的黑暗仪式玷污了圣碑的纯洁，这种行为必须被制止，他们用作仪式中心的神坛必须被摧毁。请帮我们完成这项任务，我们会为此酬谢你的。")
    SetQBit(QBit(1155)) -- 摧毁在银湾镇西面独立碑中的祭坛并返回银湾镇的埃里诺・范德贝尔特处。
    evt.SetNPCTopic(1052, 0, 1624) -- 埃里诺・范德贝尔特 topic 0: 任务
end)

RegisterGlobalEvent(1624, nil, function()
    if not IsQBitSet(QBit(1047)) then
        evt.SetMessage("很高兴再次见到你，但苍穹会仍占据着独立碑。")
        return
    end
    evt.SetMessage("感谢你的帮助，这是对你的努力的奖励。我们可以好好睡觉了，因为塞德里克和他那些德鲁伊背叛者们再也不能玷污这块圣洁的地区了。")
    ClearQBit(QBit(1155)) -- 摧毁在银湾镇西面独立碑中的祭坛并返回银湾镇的埃里诺・范德贝尔特处。
    AddValue(131307, 2)
    AddValue(Gold, 3000)
    evt.ForPlayer(Players.All)
    SetAward(Award(85))
    AddValue(Experience, 15000)
    evt.SetNPCTopic(1052, 0, 0) -- 埃里诺・范德贝尔特 topic 0 cleared
    evt.MoveNPC(1052, 0) -- 埃里诺・范德贝尔特 -> removed
end)

RegisterGlobalEvent(1625, nil, function()
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if HasItem(2094) then
            RemoveItem(2094)
            AddValue(Gold, 300)
            evt.SetMessage("多么可爱的眼镜蛇蛋啊。我得马上孵化它们以加强我的旗舰业务。这是那些蛋的报酬。只要眼镜蛇蛋还有人要，你有多少我收购多少。")
            return
        end
    end
    evt.SetMessage("我是个珍稀动物的收藏者。靠贩卖此类动物给人当宠物谋生。现在眼镜蛇很抢手，但我的存货不多。你如果手头上有眼镜蛇蛋我愿出高价。记住，如果你找到眼镜蛇蛋，我会出最令你满意的价钱。")
end)

RegisterGlobalEvent(1626, nil, function()
    evt.SetMessage("已被删除的蝙蝠粪的信息")
    SetQBit(QBit(1157))
    evt.SetNPCTopic(1074, 0, 1627) -- 巴拉德・恩特 topic 0: 任务
    AddValue(InventoryItem(2050), 2050)
end)

RegisterGlobalEvent(1628, nil, function()
    evt.SetMessage("附近有一处神拳会的庙宇。我曾是它的成员。最近他们发现了一颗能量强大的邪恶水晶。他们想以此为讨价还价的筹码申请加入羊鸣教。但我不想见到水晶落入羊鸣教的魔掌，必须毁掉它。请潜入庙里毁了那颗水晶。")
    SetQBit(QBit(1158)) -- 摧毁神拳庙中的水晶并返回布特雷格湾的温斯顿・舒则处。
    evt.SetNPCTopic(1075, 0, 1629) -- 温斯顿・舒则 topic 0: 任务
end)

RegisterGlobalEvent(1629, nil, function()
    if not IsQBitSet(QBit(1045)) then
        evt.SetMessage("你必须加紧行动，不然羊鸣教就要接收它了。我不知道还有多久，但无疑时间紧迫。")
        return
    end
    evt.SetMessage("干得好。很高兴你能及时完成任务。我可不愿看到羊鸣教用水晶来为非作歹，你为整个恩洛斯做了件大好事。")
    ClearQBit(QBit(1158)) -- 摧毁神拳庙中的水晶并返回布特雷格湾的温斯顿・舒则处。
    AddValue(Gold, 3000)
    AddValue(131307, 2)
    evt.ForPlayer(Players.All)
    SetAward(Award(87))
    AddValue(Experience, 10000)
    evt.SetNPCTopic(1075, 0, 0) -- 温斯顿・舒则 topic 0 cleared
    evt.MoveNPC(1075, 0) -- 温斯顿・舒则 -> removed
end)

RegisterGlobalEvent(1630, nil, function()
    evt.SetMessage("我的丈夫埃曼纽尔前些天和他的几个朋友去星岛寻找财宝。从那以后再也没见到他们，几天来一直为此而忧心忡忡。我不敢上那个岛，传言那是美杜莎女妖的老巢。如果你能找到他并把他带回来，我将感激不尽。")
    SetQBit(QBit(1160)) -- 从布莱克郡附近的巨蛇庙中解救埃曼纽尔，并把他带回布莱克郡的乔安娜・克拉维兹处。
    evt.SetNPCTopic(903, 0, 1631) -- 乔安娜・克拉维兹 topic 0: 任务
end)

RegisterGlobalEvent(1631, nil, function()
    if not IsQBitSet(QBit(1702)) then
        evt.SetMessage("没找到？你没找到他说明他正处在危险之中。如果你有幸发现了他，请把他带回来，我一直在等着他的归来。")
        return
    end
    evt.SetMessage("哦，感谢你把埃曼纽尔带回我的身边。在这个世界上他对我来说意味着一切。请收下我的报酬，虽然不多，但聊表心意。")
    ClearQBit(QBit(1702))
    ClearQBit(QBit(1160)) -- 从布莱克郡附近的巨蛇庙中解救埃曼纽尔，并把他带回布莱克郡的乔安娜・克拉维兹处。
    AddValue(Gold, 500)
    evt.ForPlayer(Players.All)
    SetAward(Award(88))
    AddValue(Experience, 20000)
    evt.MoveNPC(893, 1354) -- 埃曼纽尔・克拉维兹 -> 房屋
    evt.SetNPCTopic(893, 0, 0) -- 埃曼纽尔・克拉维兹 topic 0 cleared
    evt.SetNPCTopic(903, 0, 0) -- 乔安娜・克拉维兹 topic 0 cleared
end)

RegisterGlobalEvent(1632, nil, function()
    evt.SetMessage("感谢你使我恢复原形，我乐意坐下来聊聊，但现在必须离开这鬼地方。")
end)

RegisterGlobalEvent(1633, nil, function()
    evt.SetMessage("感谢你使我恢复原形，我乐意坐下来聊聊，但现在必须离开这鬼地方。")
end)

RegisterGlobalEvent(1634, nil, function()
    evt.SetMessage("你能带我离开这儿吗？我要回布莱克郡和妻子团聚。")
    SetQBit(QBit(1702))
end)

RegisterGlobalEvent(1635, nil, function()
    evt.SetMessage("我的一个探险家朋友最近在旅途中发现一件威力强大的宝物，名字叫莫德里德。他想把它运来给我，问我是否有兴趣买下来。但不幸的是有人袭击了他们的商队并偷走了这件宝物。袭击者是向坦普城堡西面逃窜而去的。我想他们在那里肯定有个基地。如果你能把那件宝物夺回来，我将把宝物买卖的钱分一部分给你。")
    SetQBit(QBit(1161)) -- 在坦普城堡附近的龙骑兵堡垒里找到失落的神器，并把它交给自由天堂的佐尔丹・菲尔普。
    evt.SetNPCTopic(861, 0, 1636) -- 佐尔丹・菲尔普 topic 0: 任务
end)

RegisterGlobalEvent(1636, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2020) then
        evt.SetMessage("你好，还没有人找到莫德里德，我们的买卖仍然有效。如果你把它夺回来，我就把宝物买卖的钱分一部分给你。")
        return
    end
    evt.SetMessage("这就是极富传奇色彩的莫德里德，嗯？有意思，我还指望它会更神奇些呢。我对这玩意儿兴趣不大，你拿着吧，我会向我的朋友商量付款的。")
    SetAward(Award(89))
    AddValue(Experience, 10000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 30000)
    AddValue(327915, 5)
    ClearQBit(QBit(1161)) -- 在坦普城堡附近的龙骑兵堡垒里找到失落的神器，并把它交给自由天堂的佐尔丹・菲尔普。
    evt.SetNPCTopic(861, 0, 0) -- 佐尔丹・菲尔普 topic 0 cleared
    evt.MoveNPC(861, 0) -- 佐尔丹・菲尔普 -> removed
end)

RegisterGlobalEvent(1637, nil, function()
    evt.SetMessage("阴影教的教众近来南下扩张，试图对该地区的商人施加影响。我拒绝他们进入我的城镇，他们竟然绑架了雪莱・卡耐基，我们镇德高望重的老医师，想以此来“说服”我让他们在此地经营。真不敢相信他们已经来到南岸来进行敲诈勒索了，我还以为在这里是安全的。请去营救雪莱吧，我会给你丰厚的报酬。全镇人民将对你感激不尽。")
    SetQBit(QBit(1162)) -- 将雪莉从阴影教隐蔽所救出来，并带她前往新索匹格镇的弗兰克・费尔基德处。
    evt.SetNPCTopic(788, 0, 1638) -- 弗兰克・费尔基德 topic 0: 任务
end)

RegisterGlobalEvent(1638, nil, function()
    if not IsQBitSet(QBit(1703)) then
        evt.SetMessage("还没找到雪莱吗？我想阴影教肯定把她藏在阴影教众群居躲藏的地方了。找到他们就可以找到雪莱。")
        return
    end
    evt.SetMessage("十分感谢你搭救了雪莱！你为整个新索匹格镇作出了难以估量的贡献。我们对你的恩情将永远铭记在心。")
    ClearQBit(QBit(1703))
    ClearQBit(QBit(1162)) -- 将雪莉从阴影教隐蔽所救出来，并带她前往新索匹格镇的弗兰克・费尔基德处。
    AddValue(Gold, 2000)
    evt.ForPlayer(Players.All)
    SetAward(Award(90))
    AddValue(Experience, 10000)
    evt.SetNPCTopic(788, 0, 0) -- 弗兰克・费尔基德 topic 0 cleared
end)

RegisterGlobalEvent(1639, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2124) then
        evt.SetMessage("我对阴影教已深恶痛绝了，但没有掌握他们罪行的充分证据，没办法处罚他们。如果有确凿的证据，我就能禀告安东尼・斯通爵士，把他们绳之以法。")
        return
    end
    evt.SetMessage("真有意思，阴影教竟然雇佣龙骑兵。我想安东尼・斯通肯定想了解这个消息。下次见到他时，我会把这封信给他看的。现在我们有了证据，斯通会对阴影教采取行动的。")
    RemoveItem(2124)
    AddValue(Experience, 5000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 5000)
    AddValue(131307, 2)
    evt.SetNPCTopic(788, 1, 0) -- 弗兰克・费尔基德 topic 1 cleared
end)

RegisterGlobalEvent(1640, nil, function()
    evt.SetMessage("感谢你把我从这些可恶的歹徒手中营救出来！现在我想要回新索匹格我的家乡。")
    SetQBit(QBit(1703))
end)

RegisterGlobalEvent(1641, nil, function()
    evt.SetMessage("哦，亲爱的，你能帮助我吗？我女儿安吉拉不见了！我想她也许在城镇附近的废庙中四处游荡，如果这样的话她的处境十分危险，天知道有什么可怕的东西在这诅咒笼罩的神庙中藏着！求求你找到她并带她回来 。")
    SetQBit(QBit(1163)) -- 将安吉拉从废庙中救出来，并带她前往新索匹格镇的威尔特・德沃森处。
    evt.SetNPCTopic(939, 0, 1642) -- 威尔特・德沃森 topic 0: 任务
end)

RegisterGlobalEvent(1642, nil, function()
    if not IsQBitSet(QBit(1704)) then
        evt.SetMessage("你还没有找到可怜的安吉拉吗？她一定遇到了什么不测！")
        return
    end
    evt.SetMessage("她还活着！你能找到她真是太好了！这些作为你的奖励，请收下吧。")
    evt.MoveNPC(980, 1316) -- 安吉拉・德沃森 -> 房屋
    ClearQBit(QBit(1704))
    ClearQBit(QBit(1163)) -- 将安吉拉从废庙中救出来，并带她前往新索匹格镇的威尔特・德沃森处。
    AddValue(Gold, 500)
    AddValue(Food, 10)
    evt.ForPlayer(Players.All)
    SetAward(Award(91))
    AddValue(Experience, 1000)
    evt.SetNPCTopic(939, 0, 0) -- 威尔特・德沃森 topic 0 cleared
    evt.SetNPCTopic(980, 0, 0) -- 安吉拉・德沃森 topic 0 cleared
end)

RegisterGlobalEvent(1643, nil, function()
    evt.SetMessage("我迷路了，<哭泣>我要回家。")
    SetQBit(QBit(1704))
end)

RegisterGlobalEvent(1644, nil, function()
    evt.SetMessage("我的好友谢勒尔与一群朋友为了寻找传言中的古庙共同去了布特雷格湾中的小岛，她的朋友回来说谢勒尔被岛上的食人族捉住了并囚禁在古庙里。我相信目前她还未遭毒手，但情况十分危急，请抓紧时间去营救她。")
    SetQBit(QBit(1164)) -- 将谢勒尔从布特雷格湾岛屿上的食人族手中解救出来，并带她前往自由天堂的卡尔罗・托米尼处。
    evt.SetNPCTopic(985, 0, 1645) -- 卡尔罗・托米尼 topic 0: 任务
end)

RegisterGlobalEvent(1645, nil, function()
    if not IsQBitSet(QBit(1705)) then
        evt.SetMessage("哦，亲爱的，你还没找到她吗？她准是被祭天了，要么就是被吃了。请务必找到她，要是她已经不在人世了，请为她报仇。")
        return
    end
    evt.SetMessage("好极了！她还活着。真是麻烦你了。请收下我的一片感激之情。")
    evt.MoveNPC(940, 1400) -- 谢勒尔・伊万诺夫 -> 房屋
    ClearQBit(QBit(1705))
    ClearQBit(QBit(1164)) -- 将谢勒尔从布特雷格湾岛屿上的食人族手中解救出来，并带她前往自由天堂的卡尔罗・托米尼处。
    evt.SetNPCTopic(940, 0, 0) -- 谢勒尔・伊万诺夫 topic 0 cleared
    AddValue(Gold, 1500)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 10000)
    SetAward(Award(92))
    evt.SetNPCTopic(985, 0, 0) -- 卡尔罗・托米尼 topic 0 cleared
end)

RegisterGlobalEvent(1646, nil, function()
    evt.SetMessage("你好！求求你，请把我从这鬼地方带走吧，我不想死！")
    SetQBit(QBit(1705))
end)

RegisterGlobalEvent(1647, nil, function()
    evt.SetMessage("我们的镇子正被一个可怕的诅咒笼罩着，尽管大多数人都不相信这个事实。在满月之际，我们全都会变成狼人。虽然我们都不是恶人，但我们并不知道自己变成狼人后做了什么可怕的事情。我们也不方便把这事禀告艾克顿・斯宾德勒爵士，他现在还并没有意识到我们就是那些狼人。请你想方设法让我们恢复正常吧！")
    SetQBit(QBit(1165)) -- 摧毁狼穴中的狼人祭坛并返回布莱克郡的玛利亚・特里潘处。
    evt.SetNPCTopic(997, 0, 1648) -- 玛利亚・特里潘 topic 0: 任务
end)

RegisterGlobalEvent(1648, nil, function()
    if not IsQBitSet(QBit(1041)) then
        evt.SetMessage("我们真的没希望了吗？求求你想个办法解除咒语把我们变为正常人吧。")
        return
    end
    evt.SetMessage("太谢谢你了。现在我们晚上可以平平安安的睡觉了，用不着担心会像野兽一样夜晚四处游荡为非作歹。真不幸连爵士自己都被变成了狼人，我们会怀念他的。为了感谢你对我们的信任和帮助，请收下这些。")
    ClearQBit(QBit(1165)) -- 摧毁狼穴中的狼人祭坛并返回布莱克郡的玛利亚・特里潘处。
    AddValue(Gold, 4000)
    AddValue(327915, 5)
    evt.ForPlayer(Players.All)
    AddValue(Experience, 20000)
    SetAward(Award(94))
    evt.SetNPCTopic(997, 0, 0) -- 玛利亚・特里潘 topic 0 cleared
    evt.MoveNPC(997, 0) -- 玛利亚・特里潘 -> removed
end)

RegisterGlobalEvent(1651, nil, function()
    evt.SetMessage("当狼人从山区挖掘隧道进入斯宾德勒领地大肆杀戮时我正在他家作客。我杀开一条血路，想从隧道逃走，但最后还是被他们抓住了。他们残忍地把我杀害了。")
end)

RegisterGlobalEvent(1652, nil, function()
    evt.SetMessage("在我逃跑的途中，我把纯洁珍珠藏在这里的岩洞里。珍珠可以保护你免受狼人的诅咒。如果珍珠放在狼人的神坛上还可以破坏神坛，这样就可以解除狼人的诅咒，让所有人恢复原形。珍珠就在这个岩洞的尽头，请帮我个忙，把珍珠交给威尔伯・汉弗里。他是所有圣武士的首领，珍珠应该放在他那儿。")
    SetQBit(QBit(1166))
    evt.SetNPCTopic(789, 2, 1655) -- 威尔伯・汉弗里 topic 2: 纯洁珍珠
end)

RegisterGlobalEvent(1653, nil, function()
    evt.SetMessage("狼人首领拥有腐败珍珠，它是我的纯洁珍珠的天生对头。他正是用这颗珍珠施放诅咒的。我撤退时无法为民除害，现在我把此事拜托给你了。希望能得到你的好消息。")
    SetQBit(QBit(1167)) -- 在狼穴中找到腐败珍珠，交给同在狼穴中的幽灵巴塞萨。
    evt.SetNPCTopic(1080, 2, 1654) -- 幽灵巴塞萨 topic 2: 任务
end)

RegisterGlobalEvent(1654, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2078) then
        evt.SetMessage("狼人首领拥有腐败珍珠，它是我的纯洁珍珠的天生对头。他正是用这颗珍珠施放诅咒的。我撤退时无法为民除害，现在我把此事拜托给你了。希望能得到你的好消息。")
        return
    end
    evt.SetMessage("感谢你打败了狼人首领。我一直愧疚自己不够强大，没能阻止这场悲剧的发生。你让我的灵魂可以摆脱愧疚，继续走下去了。真是太感谢你了。我得把珍珠带走，免得它在恩洛斯继续危害人间。")
    RemoveItem(2078)
    AddValue(Experience, 5000)
    SetAward(Award(93))
    evt.ForPlayer(Players.Current)
    ClearQBit(QBit(1167)) -- 在狼穴中找到腐败珍珠，交给同在狼穴中的幽灵巴塞萨。
    SetQBit(QBit(1059))
    evt.SetNPCTopic(1080, 2, 0) -- 幽灵巴塞萨 topic 2 cleared
end)

RegisterGlobalEvent(1655, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2079) then
        evt.SetMessage("纯洁珍珠是圣武士的宝物中仅存的一件，它最后落在巴塞萨的手里。听说他曾经在布莱克郡造访斯宾德勒爵士，但近来已经有好几个月没有他的音讯了。")
        return
    end
    evt.SetMessage("这是什么？啊，你拿到了纯洁珍珠。看到这个令我想起了巴塞萨，哦，他已经与世长辞了。遵从他的遗愿，我将保存这珍珠。我以我们两人共同的名义感谢你。")
    RemoveItem(2079)
    AddValue(Experience, 10000)
    evt.ForPlayer(Players.Current)
    ClearQBit(QBit(1166))
    evt.SetNPCTopic(789, 2, 0) -- 威尔伯・汉弗里 topic 2 cleared
end)

RegisterGlobalEvent(1660, nil, function()
    evt.SetMessage("你不是大耳！你走！我们用城堡观察人！你们再不能杀我们！")
end)

RegisterGlobalEvent(1661, nil, function()
    evt.SetMessage("感谢你把大耳怪从堡垒中赶走了，我们已经完全控制了局势。对你的见义勇为行为真是非常感谢。")
end)

RegisterGlobalEvent(1662, nil, function()
    evt.SetMessage("你们好，我的孩子们！真高兴能再次见到你们。我这老头如今没什么用，不能再教给你们什么东西了，以后的路要靠你们自己去闯荡。至于那天晚上袭击甜水镇的恶魔，我对它们也几乎一无所知。但我知道有人知道这其中的一切。那就是在自由天堂的神使。只有神使清楚该如何除掉这群横行恩洛斯的恶魔。但是拜见神使必须得到高级议会六个成员的一致同意，每个成员代表了恩洛斯的每个爵士的意见。无论如何，你必须想尽一切办法得到神使的面授机宜，把恩洛斯的魔怪们杀个干净。")
end)

RegisterGlobalEvent(1664, nil, function()
    evt.SetMessage("我研制出一种魔法可以使时间倒转，让我重获青春。这需要进行一项复杂的仪式。我知道如何进行这项仪式。但问题是我需要把这些魔法小雕像放各地的底座上。虎像放在甜水镇；熊像放在克里格斯镇；鹰像放在飞龙沙漠；狼像放在幽灵沼泽；龙像放在布特雷格湾。我年纪大了，走不了这么远的路，而且我还要准备仪式，没法自己亲自完成整个程序，我需要你的帮助。小雕像就在我屋子外面的箱子里，把它们放到各地相应的底座上，即使实验失败了，你回来后我仍会重重酬谢你的。")
    SetQBit(QBit(1243)) -- 把小雕像放在甜水镇、克里格斯、飞龙沙漠、幽灵沼泽和布特雷格湾，然后返回布莱克郡的特威伦处。
    SetQBit(QBit(1244))
    evt.SetNPCTopic(872, 0, 1665) -- 特威伦 topic 0: 任务
end)

RegisterGlobalEvent(1665, nil, function()
    evt.SetMessage("我仪式的准备工作已近尾声。万事具备，只欠东风。把小雕像放置完毕就行了。")
end)

RegisterGlobalEvent(1666, nil, function()
    evt.SetMessage("很久以前我曾是宫廷魔法师。但自从阿基巴德犯上作乱后，一切都变得面目全非。阿基巴德作为巫师拥有傲世群伦的魔法技能。他掌握了几项现已失传的咒语，所以再也不需要我了。从此我隐居在此潜心钻研我的魔法，任凭岁月流逝，消蚀着我的生命。")
end)

RegisterGlobalEvent(1667, nil, function()
    evt.SetMessage("真是个奇迹，我又重获青春，实在太感谢你们了。你们是否考虑一直跟着我干？我多年来收集了不少饰品，就在外面的箱子里，你们可以尽情拿取，作为对你们的酬劳。我得在这儿料理一些事情，然后回到铁拳城堡去看看那里是否欢迎我这样的前宫廷魔法师。")
    ClearQBit(QBit(1243)) -- 把小雕像放在甜水镇、克里格斯、飞龙沙漠、幽灵沼泽和布特雷格湾，然后返回布莱克郡的特威伦处。
    SetQBit(QBit(1245))
    evt.ForPlayer(Players.All)
    AddValue(Experience, 75000)
    SetAward(Award(98))
    evt.SetNPCTopic(826, 0, 0) -- 特威伦 topic 0 cleared
    evt.MoveNPC(826, 0) -- 特威伦 -> removed
end)

RegisterGlobalEvent(1668, nil, function()
    evt.SetMessage("当克里格斯城堡的怪兽造反时，我正在那里学习魔法。我立即逃离该城堡，匆忙中把一颗价值连城的宝石蛋忘在那里。这颗宝石蛋是我们家的传家宝，从寂静时代流传至今。我屡次想夺回宝石蛋，但怪兽警卫森严，我又不是他们的对手。谁能替我把宝石蛋夺回来，我就重重赏他。")
    SetQBit(QBit(1168)) -- 在克里格斯城堡中找回宝石蛋，交还给克里格斯镇的埃米尔・利姆。
    evt.SetNPCTopic(986, 0, 1669) -- 埃米尔・利姆 topic 0: 任务
end)

RegisterGlobalEvent(1669, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2100) then
        evt.SetMessage("克里格斯城堡是一座火山中的城堡。我们魔法师们害怕怪兽危害周围的城镇，就把城堡周围的泥土堆积起来不让他们出来。现在他们就在城堡里，而宝石蛋也在里面。")
        return
    end
    evt.SetMessage("感谢你夺回了宝石蛋，它对我来说是最宝贵的东西。")
    RemoveItem(2100)
    SetAward(Award(97))
    AddValue(Experience, 50000)
    evt.ForPlayer(Players.Current)
    AddValue(327915, 5)
    AddValue(Gold, 5000)
    ClearQBit(QBit(1168)) -- 在克里格斯城堡中找回宝石蛋，交还给克里格斯镇的埃米尔・利姆。
    evt.SetNPCTopic(986, 0, 0) -- 埃米尔・利姆 topic 0 cleared
    evt.MoveNPC(986, 0) -- 埃米尔・利姆 -> removed
end)

RegisterGlobalEvent(1670, nil, function()
    evt.SetMessage("我是烈火爵士，长生不朽的土地神。我的能量来自于土地深处。但是现在，我汲取能量的通道被北边的几扇门封住了，这几扇门被强大的魔力锁住。我需要你解开这些门上的魔力之锁，让我的力量能够再次觉醒。虽然这些魔力之锁很强大，但琥珀可以破坏它们。")
    SetQBit(QBit(1169)) -- 解开烈火爵士的大厅中被魔力锁住的门，然后返回烈火爵士处。
    evt.SetNPCTopic(1083, 0, 1673) -- 烈火爵士 topic 0: 任务
end)

RegisterGlobalEvent(1671, nil, function()
    evt.SetMessage("如果你在岩洞中迷路了，可以向我的仆人求助。如果你有琥珀的话，他们就会认为你是我的贵客，你可以请他们把你远程传送回到我的身边。但如果你没有琥珀也不要紧，他们会吸走你一些生命力用来传送你。不要担心，这很少会致命。")
end)

RegisterGlobalEvent(1672, nil, function()
    evt.SetMessage("自从一个奇怪的生物来此定居后，这几扇门就被魔力锁住了。我在恩洛斯大陆上活了这么久，千奇百怪的东西见过不少，却不知这个生物是什么玩意儿。真不明白为什么它会在这里定居，为什么它仅此一只。我希望有人把它给除掉，它给我带来了不少麻烦。")
end)

RegisterGlobalEvent(1673, nil, function()
    if not IsQBitSet(QBit(1095)) then
        evt.SetMessage("我是个有耐心的人，我希望能量通道能够再次畅通无阻。你是我挑选的最佳人选，我不会看错人的，加油干吧！")
        return
    end
    evt.SetMessage("多谢你的援助，使我重新获得了魔法源泉。我要把失去的魔法找回来，重振雄风。")
    if IsQBitSet(QBit(1383)) then return end
    ClearQBit(QBit(1169)) -- 解开烈火爵士的大厅中被魔力锁住的门，然后返回烈火爵士处。
    SetQBit(QBit(1383))
    evt.ForPlayer(Players.All)
    SetAward(Award(99))
    AddValue(Experience, 10000)
    evt.SetNPCTopic(1083, 2, 0) -- 烈火爵士 topic 2 cleared
end)

RegisterGlobalEvent(1675, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2068) then
        evt.SetMessage("最近银色兄弟会不断骚扰我的生意，打劫我们的商队。真不知道为什么约翰爵士不加以管束。这种情况必须制止。如果你能说服他不再给我添麻烦，我会给你大量金币作为报酬。")
        return
    end
    evt.SetMessage("所以说，约翰爵士被杀害了，银舵已经被羊鸣教收买了？那倒是解释了过去发生的很多事。你们把这个带给我，干得真不错，不过你们得去安东尼・斯通那儿拿取报酬。")
    RemoveItem(2068)
    AddValue(Experience, 10000)
    evt.ForPlayer(Players.Current)
    evt.SetNPCTopic(801, 2, 1677) -- 安东尼・斯通 topic 2: 十字架
    evt.SetNPCTopic(799, 2, 0) -- 劳里达・弗丽斯 topic 2 cleared
end)

RegisterGlobalEvent(1676, nil, function()
    evt.ForPlayer(Players.All)
    if not HasItem(2068) then
        evt.SetMessage("银色兄弟会对我合法组织的攻击已经变本加厉了。如果你能去和约翰爵士谈谈，了解他为什么会容忍手下的残暴行径，我将对你感激不尽。")
        return
    end
    evt.SetMessage("我早该知道是羊鸣教在背后捣鬼，几乎每个阴谋都有他们在暗中策划。多谢你们把这个带给我。它解释了我对银色兄弟会的疑问。")
    RemoveItem(2068)
    AddValue(Experience, 10000)
    evt.ForPlayer(Players.Current)
    AddValue(Gold, 5000)
    evt.SetNPCTopic(801, 2, 0) -- 安东尼・斯通 topic 2 cleared
    evt.SetNPCTopic(799, 2, 0) -- 劳里达・弗丽斯 topic 2 cleared
end)

RegisterGlobalEvent(1677, nil, function()
    evt.SetMessage("所以是羊鸣教幕后主导了银舵的腐化和约翰・席尔瓦爵士的谋杀？他真是不幸，愿他的灵魂能在天堂安息。<流泪>劳里达要你到我这里拿报酬？她真是个铁公鸡。好吧，这些是给你的报酬。")
    AddValue(Gold, 5000)
    evt.SetNPCTopic(801, 2, 0) -- 安东尼・斯通 topic 2 cleared
end)

RegisterGlobalEvent(1678, nil, function()
    evt.SetMessage("<劳里达・弗丽斯通过心灵感应咒语与你联系>欢迎光临太阳仪式，你站在生命圈的中央，面向北方，你的前方一片光明。想想那句名言吧，“有钱能使鬼推磨”，<咯咯地笑>开个玩笑，别当真。现在闭上眼睛，想象你站在世界和时间的中心，多么神圣的时刻啊。<沉默良久>睁开眼睛。我提拔你们中的德鲁伊为高级德鲁伊，非德鲁伊者为荣誉高级德鲁伊。<劳里达消失了>")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 12) then
            SetValue(ClassId, 13)
            SetQBit(QBit(1651))
        else
            SetQBit(QBit(1652))
        end
    end
    AddValue(131307, 2)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(1142)) -- 在春秋分或冬夏至前往银湾镇北边的石圈拜祭太阳神坛（提示：3月20日是春分）。
    SetQBit(QBit(1197))
    AddValue(Experience, 15000)
    evt.SetNPCTopic(1090, 0, 0) -- 劳里达・弗丽斯 topic 0 cleared
    evt.SetNPCTopic(799, 1, 1397) -- 劳里达・弗丽斯 topic 1: 大德鲁伊
end)

RegisterGlobalEvent(1679, nil, function()
    evt.SetMessage("<劳里达・弗丽丝通过心灵感应魔法与你联系>欢迎光临月亮仪式，请站在月亮坛前，面向北面，闭上眼睛想象你处于四季循环和生命轮回的中心<沉默良久>睁开眼睛吧，我的朋友，我把你们中的高级德鲁伊升级为大德鲁伊，所有荣誉高级德鲁伊赐予荣誉大德鲁伊头衔。<劳里达消失了>")
    for _, player in ipairs(PartyMembers()) do
        evt.ForPlayer(player)
        if IsAtLeast(ClassId, 13) then
            SetValue(ClassId, 15)
            SetQBit(QBit(1653))
        else
            SetQBit(QBit(1654))
        end
    end
    AddValue(327915, 5)
    evt.ForPlayer(Players.All)
    ClearQBit(QBit(1143)) -- 在满月的午夜时分来到月亮神庙拜祭月亮神坛。
    SetQBit(QBit(1198))
    AddValue(Experience, 40000)
    evt.SetNPCTopic(1091, 0, 0) -- 劳里达・弗丽斯 topic 0 cleared
    evt.SetNPCTopic(799, 1, 1399) -- 劳里达・弗丽斯 topic 1: 大德鲁伊
end)

RegisterGlobalEvent(1688, nil, function()
    evt.ForPlayer(Players.All)
    if not HasAward(Award(59)) then
        evt.SetMessage("坦普爵士授权于我在这个决议上投票表决。得到他的许可，并有他的推荐，我自然会投票为你说好话。")
        return
    end
    evt.SetMessage("奥斯里克已指示我帮助你，我会以他的名义对你全力支持。")
end)

RegisterGlobalEvent(1689, nil, function()
    evt.ForPlayer(Players.All)
    if not HasAward(Award(61)) then
        evt.SetMessage("弗丽斯夫人对你的问题无动于衷，我对你的要求自然不加考虑。")
        return
    end
    evt.SetMessage("我以劳里达的名义允许你拜访神使。")
end)

RegisterGlobalEvent(1690, nil, function()
    evt.ForPlayer(Players.All)
    if not HasAward(Award(60)) then
        evt.SetMessage("斯通爵士没有指示我对你投赞成票，你必须首先得到他的同意。")
        return
    end
    evt.SetMessage("安东尼同意了你的拜见神使的要求，我以他的名义投赞成票。")
end)

RegisterGlobalEvent(1691, nil, function()
    evt.ForPlayer(Players.All)
    if not HasAward(Award(62)) then
        evt.SetMessage("没有斯壮姆嘉德爵士的许可我不能决定此事。只有使他回心转意我才能投票赞成。")
        return
    end
    evt.SetMessage("根据埃里克・冯・斯壮姆嘉德的授意，我投票赞成你拜访神使。")
end)

RegisterGlobalEvent(1692, nil, function()
    evt.ForPlayer(Players.All)
    if not HasAward(Award(58)) then
        evt.SetMessage("如果牛顿爵士不为你的要求说好话，我可不会投票赞成你。")
        return
    end
    evt.SetMessage("阿尔伯特已授意让我投票赞成你拜访神使。")
end)

RegisterGlobalEvent(1693, nil, function()
    evt.ForPlayer(Players.All)
    if HasItem(2122) then
        evt.MoveNPC(1089, 0) -- 斯里克・席尔瓦托恩 -> removed
        RemoveItem(2122)
        evt.SetMessage("你赢啦？做梦吧！艾恩法斯特王朝快要完蛋了，我将成为王国的主宰。不过，你放心，我不会忘记你的。")
        AddValue(655595, 10)
        SetQBit(QBit(1192))
        evt.ForPlayer(Players.All)
        SetAward(Award(63))
        ClearQBit(QBit(1214))
        ClearQBit(QBit(1225)) -- 把证明斯里克・席尔瓦托恩叛国的信件交给自由天堂的高级议会。
        if IsQBitSet(QBit(1224)) then -- 在克里格斯城堡东面的顶级羊鸣庙中找到治疗斯里克・席尔瓦托恩的方法，并带着好消息回到威尔伯・汉弗里处。
            ClearQBit(QBit(1224)) -- 在克里格斯城堡东面的顶级羊鸣庙中找到治疗斯里克・席尔瓦托恩的方法，并带着好消息回到威尔伯・汉弗里处。
        end
        evt.SetNPCTopic(789, 0, 1416) -- 威尔伯・汉弗里 topic 0: 皇冠的服务
        if not HasAward(Award(57)) then return end
        if not HasAward(Award(58)) then return end
        if not HasAward(Award(59)) then return end
        if not HasAward(Award(60)) then return end
        if not HasAward(Award(61)) then return end
        if HasAward(Award(62)) then
            SetQBit(QBit(1191))
        end
        return
    elseif HasAward(Award(57)) then
        evt.SetMessage("只要我还在议会中有一席之地，我就不会赞让你拜访神使，我对你的忠诚度有所怀疑，不能满足你的要求。")
        evt.SetNPCTopic(789, 0, 1414) -- 威尔伯・汉弗里 topic 0: 席尔瓦托恩的拒绝
    else
        evt.SetMessage("你并没有发誓效忠我的主人汉弗里爵士，我不能对你投赞成票。")
        return
    end
end)

RegisterGlobalEvent(1711, nil, function()
    evt.SetMessage("一伙羊鸣教教徒和作恶多端的匪徒袭击并霸占了浓雾岛。他们是通过西北方岛上的一个远距离传送装置上岛的。我已经启动了远距离传送装置，你可以通过它上岛把它们一网打尽。我肯定它们偷来的赃物都藏在岛上。你可以通过它们的远距离传送装置返回。")
    SetQBit(QBit(1325))
    evt.SetNPCTopic(950, 0, 0) -- 凯瑟琳・美斯特 topic 0 cleared
end)

RegisterGlobalEvent(1722, nil, function()
    evt.StatusText("光明之路")
end)

RegisterGlobalEvent(1723, nil, function()
    evt.StatusText("黑暗之路")
    AddValue(BaseMight, 1)
    SetAutonote(480)
    evt.ChangeEvent(1722)
end)

RegisterGlobalEvent(1724, nil, function()
    evt.StatusText("你确定要更改路线吗？暗黑魔法将从你的魔法全书中消失，暗黑魔法技能将从你的脑海中消除。（Yes：是/No：否）")
    AddValue(BaseAccuracy, 1)
    SetAutonote(484)
    evt.ChangeEvent(1722)
end)

RegisterGlobalEvent(1725, nil, function()
    evt.StatusText("你确定要更改路线吗？光明魔法将从你的魔法全书中消失，光明魔法技能将从你的脑海中消除。（Yes：是/No：否）")
    AddValue(BasePersonality, 1)
    SetAutonote(482)
    evt.ChangeEvent(1722)
end)

RegisterGlobalEvent(1726, nil, function()
    evt.StatusText("孩子，浪子回头永远不迟。选择光明之路吧。")
    AddValue(BaseIntellect, 1)
    SetAutonote(481)
    evt.ChangeEvent(1722)
end)

RegisterGlobalEvent(1727, nil, function()
    evt.StatusText("黑暗耐心而永恒地等待着你。选择黑暗之路吧。")
    AddValue(BaseEndurance, 1)
    SetAutonote(483)
    evt.ChangeEvent(1722)
end)

RegisterGlobalEvent(1728, nil, function()
    evt.StatusText("yes")
    AddValue(BaseSpeed, 1)
    SetAutonote(485)
    evt.ChangeEvent(1722)
end)

RegisterGlobalEvent(1729, nil, function()
    evt.StatusText("您已经选择了你的道路，或者还没有准备好去做。")
    AddValue(BaseLuck, 1)
    SetAutonote(486)
    evt.ChangeEvent(1722)
end)

RegisterGlobalEvent(1730, nil, function()
    evt.StatusText("锅是空的")
end)

RegisterGlobalEvent(1731, nil, function()
    evt.StatusText("防火值永久+1")
    AddValue(FireResistance, 1)
    SetAutonote(487)
    evt.ChangeEvent(1730)
end)

RegisterGlobalEvent(1732, nil, function()
    evt.StatusText("防寒值永久+1")
    AddValue(WaterResistance, 1)
    SetAutonote(488)
    evt.ChangeEvent(1730)
end)

RegisterGlobalEvent(1733, nil, function()
    evt.StatusText("防电值永久+1")
    AddValue(AirResistance, 1)
    SetAutonote(489)
    evt.ChangeEvent(1730)
end)

RegisterGlobalEvent(1734, nil, function()
    evt.StatusText("防毒值永久+1")
    AddValue(EarthResistance, 1)
    SetAutonote(490)
    evt.ChangeEvent(1730)
end)

RegisterGlobalEvent(1735, nil, function()
    evt.StatusText("防魔法值永久+1")
    AddValue(FireResistance, 1)
    SetAutonote(491)
    evt.ChangeEvent(1730)
end)

RegisterGlobalEvent(1736, nil, function()
    evt.StatusText("菜盆里是空的")
end)

RegisterGlobalEvent(1737, nil, function()
    AddValue(Food, 3)
    evt.ChangeEvent(1736)
end)

RegisterGlobalEvent(1738, nil, function()
    evt.GiveItem(1, ItemType.Ring_)
    AddValue(Food, 3)
    evt.ChangeEvent(1736)
end)

RegisterGlobalEvent(1739, nil, function()
    evt.GiveItem(2, ItemType.Ring_)
    AddValue(Food, 3)
    evt.ChangeEvent(1736)
end)

RegisterGlobalEvent(1740, nil, function()
    evt.GiveItem(3, ItemType.Ring_)
    AddValue(Food, 3)
    evt.ChangeEvent(1736)
end)

RegisterGlobalEvent(1741, nil, function()
    evt.StatusText("空袋子")
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1742, nil, function()
    AddValue(Food, 2)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1743, nil, function()
    evt.StatusText("空包")
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1744, nil, function()
    evt.GiveItem(1, 0)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1745, nil, function()
    evt.GiveItem(2, 0)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1746, nil, function()
    evt.GiveItem(3, 0)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1747, nil, function()
    AddValue(Gold, 50)
    AddValue(Gold, 200)
    evt.ChangeEvent(0)
end)

RegisterGlobalEvent(1748, nil, function()
    local randomStep = PickRandomOption(1748, 1, {1, 5})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
            evt.StatusText("患病！")
            return
        end
        evt.StatusText("这儿没什么东西")
    elseif randomStep == 5 then
        evt.StatusText("这儿没什么东西")
    end
end)

RegisterGlobalEvent(1749, nil, function()
    local randomStep = PickRandomOption(1749, 1, {1, 5, 9})
    if randomStep == 1 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedYellow, 0)
        end
        evt.GiveItem(1, 24)
    elseif randomStep == 5 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(DiseasedRed, 0)
        end
        evt.GiveItem(2, 24)
    elseif randomStep == 9 then
        if not IsAtLeast(DisarmTrapSkill, 1) then
            SetValue(Unconscious, 0)
        end
        evt.GiveItem(3, 24)
    end
    evt.ChangeEvent(1748)
end)

RegisterGlobalEvent(1750, nil, function()
    evt.StatusText("这儿没什么东西")
end)

RegisterGlobalEvent(1751, nil, function()
    if not IsAtLeast(DisarmTrapSkill, 5) then
        SetValue(Afraid, 0)
        evt.StatusText("搜索失败！")
        return
    end
    evt.GiveItem(1, ItemType.Scroll_)
    evt.ChangeEvent(1750)
end)

RegisterGlobalEvent(1752, nil, function()
    if not IsAtLeast(DisarmTrapSkill, 6) then
        SetValue(Asleep, 0)
        evt.StatusText("搜索失败！")
        return
    end
    evt.GiveItem(2, ItemType.Scroll_)
    evt.ChangeEvent(1750)
end)

RegisterGlobalEvent(1753, nil, function()
    if not IsAtLeast(DisarmTrapSkill, 7) then
        SetValue(DiseasedGreen, 0)
        evt.StatusText("搜索失败！")
        return
    end
    evt.GiveItem(3, ItemType.Scroll_)
    evt.ChangeEvent(1750)
end)

RegisterGlobalEvent(1754, nil, function()
    if not IsAtLeast(DisarmTrapSkill, 8) then
        SetValue(Eradicated, 0)
        evt.StatusText("搜索失败！")
        return
    end
    evt.GiveItem(4, ItemType.Scroll_)
    evt.ChangeEvent(1750)
end)

RegisterGlobalEvent(1755, nil, function()
    evt.StatusText("空桶")
end)

RegisterGlobalEvent(1756, nil, function()
    AddValue(InventoryItem(1762), 1762)
    evt.ChangeEvent(1755)
end)

RegisterGlobalEvent(1757, nil, function()
    AddValue(InventoryItem(1763), 1763)
    evt.ChangeEvent(1755)
end)

RegisterGlobalEvent(1758, nil, function()
    AddValue(InventoryItem(1764), 1764)
    evt.ChangeEvent(1755)
end)

RegisterGlobalEvent(1759, nil, function()
    evt.StatusText("无用的水晶")
end)

RegisterGlobalEvent(1760, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2056), 2056)
        evt.ChangeEvent(0)
    end
end)

RegisterGlobalEvent(1761, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2057), 2057)
        evt.ChangeEvent(0)
    end
end)

RegisterGlobalEvent(1762, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2058), 2058)
        evt.ChangeEvent(0)
    end
end)

RegisterGlobalEvent(1763, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2059), 2059)
        evt.ChangeEvent(0)
    end
end)

RegisterGlobalEvent(1764, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2060), 2060)
        evt.ChangeEvent(0)
    end
end)

RegisterGlobalEvent(1765, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2061), 2061)
        evt.ChangeEvent(0)
    end
end)

RegisterGlobalEvent(1766, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2062), 2062)
        evt.ChangeEvent(0)
    end
end)

RegisterGlobalEvent(1767, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2063), 2063)
        evt.ChangeEvent(0)
    end
end)

RegisterGlobalEvent(1768, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2064), 2064)
        evt.ChangeEvent(0)
    end
end)

RegisterGlobalEvent(1769, nil, function()
    if IsAtLeast(DisarmTrapSkill, 10) then
        AddValue(InventoryItem(2065), 2065)
        evt.ChangeEvent(0)
    end
end)


-- NPCNewsTopics/NPCFollowers/Reputation native greeting text dependencies, active source language.
evt.importedGlobalText = evt.importedGlobalText or {}
evt.importedGlobalText[97] = "金币"
evt.importedGlobalText[155] = "你的金币不够"
evt.importedGlobalText[379] = "被痛恨"
evt.importedGlobalText[383] = "他的"
evt.importedGlobalText[384] = "她的"
evt.importedGlobalText[388] = "爵士"
evt.importedGlobalText[389] = "夫人"
evt.importedGlobalText[392] = "不友善"
evt.importedGlobalText[395] = "早晨"
evt.importedGlobalText[396] = "白天"
evt.importedGlobalText[397] = "晚上"
evt.importedGlobalText[399] = "中立"
evt.importedGlobalText[402] = "友善"
evt.importedGlobalText[434] = "受爱戴"
